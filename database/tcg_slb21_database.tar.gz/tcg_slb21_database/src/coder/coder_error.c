
int coder_error_flag = 0;

int return_coder_error_flag() {
  return coder_error_flag;
}

void set_coder_error_flag(int flag) {
  coder_error_flag = flag;
}

