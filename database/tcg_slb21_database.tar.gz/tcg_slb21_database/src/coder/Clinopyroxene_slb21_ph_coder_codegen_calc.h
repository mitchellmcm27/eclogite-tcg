#include <math.h>


static double coder_g(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = 1.0*n2;
    double x1 = 1.0*n3;
    double x2 = 1.0*n5;
    double x3 = 1.0*n1 + x0 + x1 + x2;
    double x4 = 3.5*n4 + x3;
    double x5 = 444600.0*n3 + 728000.0*n4 + 437400.0*n5;
    double x6 = 0.027777777777777773*x5;
    double x7 = n3*(444600.0*n1 + 444600.0*n2 + 1682800.0*n4 + 828000.0*n5);
    double x8 = n4*(2369250.0*n1 + 2369250.0*n2 + 5476612.5*n3 + 911250.0*n5);
    double x9 = n5*(437400.0*n1 + 437400.0*n2 + 828000.0*n3 + 280000.0*n4);
    double x10 = n1*(*endmember[0].mu0)(T, P);
    double x11 = n2*(*endmember[1].mu0)(T, P);
    double x12 = n3*(*endmember[2].mu0)(T, P);
    double x13 = n4*(*endmember[3].mu0)(T, P);
    double x14 = n5*(*endmember[4].mu0)(T, P);
    double x15 = n1 + n3;
    double x16 = n4 + n5;
    double x17 = 1.0/(n2 + x15 + x16);
    double x18 = 1.0*n4;
    double x19 = n1 + n2 + n4;
    double x20 = T*(x0*log(n2*x17) + x1*log(n3*x17) + 1.0*x15*log(x15*x17) + 1.0*x16*log(x16*x17) + x18*(log(n4*x17) - 0.69314718055994495) + 1.0*x19*log(x17*x19) + x2*log(n5*x17) + (2.0*n1 + 2.0*n2 + 2.0*n3 + 2.0*n5 + x18)*log(x17*(0.5*n4 + x3)));
    double x21 = 0.083333333333333315*x5;
    double x22 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));

if (T >= 5.0) {
   result = (n1*x6 + n2*x6 + x4*(-n2*(13.381349999999999*T - 44.604500000000002) + x10 + x11 + x12 + x13 + x14 + 8.3144626181532395*x20) + 0.027777777777777773*x7 + 0.0085352842554488641*x8 + 0.027777777777777773*x9)/x4;
}
else {
   result = (n1*x21 + n2*x21 + x4*(n2*(66.906750000000002*((x22)*(x22)*(x22)) + (40.14405*T - 200.72024999999999)*(x22 - 1) - 66.906750000000002) + 3*x10 + 3*x11 + 3*x12 + 3*x13 + 3*x14 + 24.943387854459719*x20) + 0.083333333333333315*x7 + 0.025605852766346592*x8 + 0.083333333333333315*x9)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = pow(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5, -2);
    double x1 = 444600.0*n3 + 728000.0*n4 + 437400.0*n5;
    double x2 = 0.027777777777777773*x1;
    double x3 = n3*(444600.0*n1 + 444600.0*n2 + 1682800.0*n4 + 828000.0*n5);
    double x4 = n4*(2369250.0*n1 + 2369250.0*n2 + 5476612.5*n3 + 911250.0*n5);
    double x5 = n5*(437400.0*n1 + 437400.0*n2 + 828000.0*n3 + 280000.0*n4);
    double x6 = 3.5*n4;
    double x7 = 1.0*n5;
    double x8 = 1.0*n2;
    double x9 = 1.0*n1;
    double x10 = 1.0*n3;
    double x11 = x10 + x9;
    double x12 = x11 + x7 + x8;
    double x13 = x12 + x6;
    double x14 = (*endmember[0].mu0)(T, P);
    double x15 = n1*x14;
    double x16 = (*endmember[1].mu0)(T, P);
    double x17 = n2*x16;
    double x18 = (*endmember[2].mu0)(T, P);
    double x19 = n3*x18;
    double x20 = (*endmember[3].mu0)(T, P);
    double x21 = n4*x20;
    double x22 = (*endmember[4].mu0)(T, P);
    double x23 = n5*x22;
    double x24 = 13.381349999999999*T;
    double x25 = x24 - 44.604500000000002;
    double x26 = n2*x25;
    double x27 = n1 + n3;
    double x28 = n4 + n5;
    double x29 = n2 + x27 + x28;
    double x30 = 1.0/x29;
    double x31 = log(n2*x30);
    double x32 = log(n3*x30);
    double x33 = log(n5*x30);
    double x34 = log(n4*x30);
    double x35 = 1.0*n4;
    double x36 = 1.0*log(x27*x30);
    double x37 = 1.0*log(x28*x30);
    double x38 = n1 + n2 + n4;
    double x39 = 1.0*log(x30*x38);
    double x40 = 2.0*n1 + 2.0*n2 + 2.0*n3 + 2.0*n5 + x35;
    double x41 = 0.5*n4 + x12;
    double x42 = log(x30*x41);
    double x43 = x10*x32 + x27*x36 + x28*x37 + x31*x8 + x33*x7 + x35*(x34 - 0.69314718055994495) + x38*x39 + x40*x42;
    double x44 = 8.3144626181532395*T;
    double x45 = x43*x44;
    double x46 = x0*(n1*x2 + n2*x2 + x13*(x15 + x17 + x19 + x21 + x23 - x26 + x45) + 0.027777777777777773*x3 + 0.0085352842554488641*x4 + 0.027777777777777773*x5);
    double x47 = -0.081632653061224483*x46;
    double x48 = 1.0/x13;
    double x49 = 2.0*x42;
    double x50 = -x30*x8;
    double x51 = -x10*x30;
    double x52 = -x30*x35;
    double x53 = pow(x29, -2);
    double x54 = -x41*x53;
    double x55 = x29*x40/x41;
    double x56 = x55*(1.0*x30 + x54);
    double x57 = x49 + x50 + x51 + x52 + x56;
    double x58 = x35 + x7;
    double x59 = -x30*x58;
    double x60 = -x30*x7;
    double x61 = x35 + x8 + x9;
    double x62 = x29*x61*(x30 - x38*x53)/x38 + x39 + x60;
    double x63 = x59 + x62;
    double x64 = x11*x29*(-x27*x53 + x30)/x27 + x36;
    double x65 = x57 + x63 + x64;
    double x66 = x10*x18 + x14*x9 + x16*x8 + x20*x35 + x22*x7 - x25*x8 + x45;
    double x67 = 24699.999999999996*n3 + 40444.444444444438*n4 + 24299.999999999996*n5 + x66;
    double x68 = T >= 5.0;
    double x69 = 0.083333333333333315*x1;
    double x70 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x71 = 66.906750000000002*((x70)*(x70)*(x70)) + (40.14405*T - 200.72024999999999)*(x70 - 1) - 66.906750000000002;
    double x72 = n2*x71;
    double x73 = 24.943387854459719*T;
    double x74 = x43*x73;
    double x75 = x0*(n1*x69 + n2*x69 + x13*(3*x15 + 3*x17 + 3*x19 + 3*x21 + 3*x23 + x72 + x74) + 0.083333333333333315*x3 + 0.025605852766346592*x4 + 0.083333333333333315*x5);
    double x76 = -0.027210884353741499*x75;
    double x77 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x78 = 3.0*x15 + 3.0*x17 + 3.0*x19 + 3.0*x21 + 3.0*x23 + x71*x8 + x74;
    double x79 = 74099.999999999985*n3 + 121333.33333333331*n4 + 72899.999999999985*n5 + x78;
    double x80 = 1.0*x29;
    double x81 = -x11*x30;
    double x82 = x51 + x81;
    double x83 = x49 + x52 + x56;
    double x84 = 1.0*x31 + x63 + x80*(-n2*x53 + x30) + x82 + x83;
    double x85 = -x30*x61;
    double x86 = 1.0*x32 + x50 + x59 + x60 + x64 + x80*(-n3*x53 + x30) + x83 + x85;
    double x87 = T*x43;
    double x88 = x37 + x29*x58*(-x28*x53 + x30)/x28;
    double x89 = 1.0*x34 + 1.0*x42 + x50 + x55*(0.5*x30 + x54) + x62 + x80*(-n4*x53 + x30) + x82 + x88 - 0.69314718055994495;
    double x90 = 1.0*x33 + x57 + x80*(-n5*x53 + x30) + x81 + x85 + x88;

if (x68) {
   result[0] = x47 + x48*(x13*(x14 + x44*x65) + x67);
}
else {
   result[0] = x76 + x77*(x13*(3*x14 + x65*x73) + x79);
}
if (x68) {
   result[1] = x47 + x48*(x13*(x16 - x24 + x44*x84 + 44.604500000000002) + x67);
}
else {
   result[1] = x76 + x77*(x13*(3*x16 + x71 + x73*x84) + x79);
}
if (x68) {
   result[2] = x47 + x48*(24699.999999999996*n1 + 24699.999999999996*n2 + 93488.888888888876*n4 + 45999.999999999993*n5 + x13*(x18 + x44*x86) + x66);
}
else {
   result[2] = x76 + x77*(74099.999999999985*n1 + 74099.999999999985*n2 + 280466.66666666663*n4 + 137999.99999999997*n5 + x13*(3*x18 + x73*x86) + x78);
}
if (x68) {
   result[3] = -0.2857142857142857*x46 + x48*(40444.444444444438*n1 + 40444.444444444438*n2 + 93488.888888888876*n3 + 15555.555555555555*n5 + x13*(x20 + x44*x89) + 3.5*x15 + 3.5*x17 + 3.5*x19 + x20*x6 + 3.5*x23 - 3.5*x26 + 29.100619163536336*x87);
}
else {
   result[3] = -0.095238095238095247*x75 + x77*(121333.33333333331*n1 + 121333.33333333331*n2 + 280466.66666666663*n3 + 46666.666666666657*n5 + x13*(3*x20 + x73*x89) + 10.5*x15 + 10.5*x17 + 10.5*x19 + 10.5*x21 + 10.5*x23 + 3.5*x72 + 87.301857490609009*x87);
}
if (x68) {
   result[4] = x47 + x48*(24299.999999999996*n1 + 24299.999999999996*n2 + 45999.999999999993*n3 + 15555.555555555555*n4 + x13*(x22 + x44*x90) + x66);
}
else {
   result[4] = x76 + x77*(72899.999999999985*n1 + 72899.999999999985*n2 + 137999.99999999997*n3 + 46666.666666666657*n4 + x13*(3*x22 + x73*x90) + x78);
}
}
        
static void coder_d2gdn2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x1 = pow(x0, -3);
    double x2 = 444600.0*n3 + 728000.0*n4 + 437400.0*n5;
    double x3 = 0.027777777777777773*x2;
    double x4 = n3*(444600.0*n1 + 444600.0*n2 + 1682800.0*n4 + 828000.0*n5);
    double x5 = n4*(2369250.0*n1 + 2369250.0*n2 + 5476612.5*n3 + 911250.0*n5);
    double x6 = n5*(437400.0*n1 + 437400.0*n2 + 828000.0*n3 + 280000.0*n4);
    double x7 = 3.5*n4;
    double x8 = 1.0*n5;
    double x9 = 1.0*n2;
    double x10 = 1.0*n1;
    double x11 = 1.0*n3;
    double x12 = x10 + x11;
    double x13 = x12 + x8 + x9;
    double x14 = x13 + x7;
    double x15 = (*endmember[0].mu0)(T, P);
    double x16 = n1*x15;
    double x17 = (*endmember[1].mu0)(T, P);
    double x18 = n2*x17;
    double x19 = (*endmember[2].mu0)(T, P);
    double x20 = n3*x19;
    double x21 = (*endmember[3].mu0)(T, P);
    double x22 = n4*x21;
    double x23 = (*endmember[4].mu0)(T, P);
    double x24 = n5*x23;
    double x25 = 13.381349999999999*T;
    double x26 = x25 - 44.604500000000002;
    double x27 = n2*x26;
    double x28 = n1 + n3;
    double x29 = n4 + n5;
    double x30 = n2 + x28 + x29;
    double x31 = 1.0/x30;
    double x32 = log(n2*x31);
    double x33 = log(n3*x31);
    double x34 = log(n5*x31);
    double x35 = log(n4*x31);
    double x36 = 1.0*n4;
    double x37 = 1.0*log(x28*x31);
    double x38 = 1.0*log(x29*x31);
    double x39 = n1 + n2 + n4;
    double x40 = 1.0*log(x31*x39);
    double x41 = 2.0*n2;
    double x42 = 2.0*n3;
    double x43 = 2.0*n5;
    double x44 = 2.0*n1 + x36 + x41 + x42 + x43;
    double x45 = 0.5*n4 + x13;
    double x46 = log(x31*x45);
    double x47 = T*(x11*x33 + x28*x37 + x29*x38 + x32*x9 + x34*x8 + x36*(x35 - 0.69314718055994495) + x39*x40 + x44*x46);
    double x48 = 8.3144626181532395*x47;
    double x49 = x1*(n1*x3 + n2*x3 + x14*(x16 + x18 + x20 + x22 + x24 - x27 + x48) + 0.027777777777777773*x4 + 0.0085352842554488641*x5 + 0.027777777777777773*x6);
    double x50 = 0.046647230320699701*x49;
    double x51 = pow(x0, -2);
    double x52 = 2.0*x46;
    double x53 = -x31*x9;
    double x54 = -x11*x31;
    double x55 = -x31*x36;
    double x56 = 1.0*x31;
    double x57 = pow(x30, -2);
    double x58 = -x45*x57;
    double x59 = x56 + x58;
    double x60 = 1.0/x45;
    double x61 = x44*x60;
    double x62 = x59*x61;
    double x63 = x30*x62;
    double x64 = x52 + x53 + x54 + x55 + x63;
    double x65 = x36 + x8;
    double x66 = -x31*x65;
    double x67 = -x31*x8;
    double x68 = x10 + x36 + x9;
    double x69 = 1.0/x39;
    double x70 = x31 - x39*x57;
    double x71 = x69*x70;
    double x72 = x68*x71;
    double x73 = x30*x72 + x40 + x67;
    double x74 = x66 + x73;
    double x75 = 1.0/x28;
    double x76 = -x28*x57 + x31;
    double x77 = x75*x76;
    double x78 = x12*x77;
    double x79 = x30*x78 + x37;
    double x80 = T*(x64 + x74 + x79);
    double x81 = 8.3144626181532395*x80;
    double x82 = x10*x15 + x11*x19 + x17*x9 + x21*x36 + x23*x8 - x26*x9 + x48;
    double x83 = 24699.999999999996*n3 + 40444.444444444438*n4 + 24299.999999999996*n5 + x82;
    double x84 = x51*(x14*(x15 + x81) + x83);
    double x85 = 1.0/x14;
    double x86 = 2.0*x30;
    double x87 = -2*x57;
    double x88 = pow(x30, -3);
    double x89 = 2*x88;
    double x90 = x39*x89;
    double x91 = x30*x68;
    double x92 = x69*x91;
    double x93 = x71*x86 + x92*(x87 + x90) - x70*x91/((x39)*(x39));
    double x94 = x57*x9;
    double x95 = x11*x57;
    double x96 = x57*x8;
    double x97 = x72 + x94 + x95 + x96;
    double x98 = x36*x57;
    double x99 = x57*x65 + x62 + x98;
    double x100 = x59*x60;
    double x101 = -2.0*x57;
    double x102 = x45*x89;
    double x103 = x30*x61;
    double x104 = 1.0*x30;
    double x105 = x44/((x45)*(x45));
    double x106 = x105*x59;
    double x107 = 4.0*x100*x30 + x103*(x101 + x102) - x104*x106;
    double x108 = x107 + x99;
    double x109 = x108 + x97;
    double x110 = x28*x89;
    double x111 = x12*x30;
    double x112 = x111*x75;
    double x113 = -x111*x76/((x28)*(x28)) + x112*(x110 + x87) + x77*x86 + x78;
    double x114 = T*x14;
    double x115 = x114*(x109 + x113 + x93);
    double x116 = T >= 5.0;
    double x117 = 0.083333333333333315*x2;
    double x118 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x119 = (40.14405*T - 200.72024999999999)*(x118 - 1);
    double x120 = ((x118)*(x118)*(x118));
    double x121 = 66.906750000000002*x120;
    double x122 = x121 - 66.906750000000002;
    double x123 = x119 + x122;
    double x124 = n2*x123;
    double x125 = 24.943387854459719*x47;
    double x126 = x1*(n1*x117 + n2*x117 + x14*(x124 + x125 + 3*x16 + 3*x18 + 3*x20 + 3*x22 + 3*x24) + 0.083333333333333315*x4 + 0.025605852766346592*x5 + 0.083333333333333315*x6);
    double x127 = 0.01554907677356657*x126;
    double x128 = 24.943387854459719*x80;
    double x129 = x123*x9 + x125 + 3.0*x16 + 3.0*x18 + 3.0*x20 + 3.0*x22 + 3.0*x24;
    double x130 = 74099.999999999985*n3 + 121333.33333333331*n4 + 72899.999999999985*n5 + x129;
    double x131 = x51*(x130 + x14*(x128 + 3*x15));
    double x132 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x133 = 1.0*x17;
    double x134 = -x57;
    double x135 = x112*(x110 + x134);
    double x136 = x135 + x78;
    double x137 = -2.0*x31;
    double x138 = x137 + x93;
    double x139 = x114*(x109 + x136 + x138);
    double x140 = x104*(-n2*x57 + x31);
    double x141 = -x12*x31;
    double x142 = x141 + x54;
    double x143 = x52 + x55 + x63;
    double x144 = T*(x140 + x142 + x143 + 1.0*x32 + x74);
    double x145 = 8.3144626181532395*x144 - x25;
    double x146 = x145 + 44.604500000000002;
    double x147 = 1.0*x15 + x81;
    double x148 = x14*(x146 + x17) + x83;
    double x149 = 0.081632653061224483*x51;
    double x150 = -x148*x149;
    double x151 = x50 - 0.081632653061224483*x84;
    double x152 = x128 + 3.0*x15;
    double x153 = 24.943387854459719*x144;
    double x154 = 1.0*x119 + x153 + 3.0*x17;
    double x155 = x130 + x14*(x123 + x153 + 3*x17);
    double x156 = 0.027210884353741499*x51;
    double x157 = -x155*x156;
    double x158 = x127 - 0.027210884353741499*x131;
    double x159 = x92*(x134 + x90);
    double x160 = x159 + x97;
    double x161 = x107 + x160;
    double x162 = x114*(x113 + x137 + x161 + x99);
    double x163 = -x31*x68;
    double x164 = x104*(-n3*x57 + x31);
    double x165 = T*(x143 + x163 + x164 + 1.0*x33 + x53 + x66 + x67 + x79);
    double x166 = 8.3144626181532395*x165;
    double x167 = x166 + 1.0*x19;
    double x168 = 24699.999999999996*n1 + 24699.999999999996*n2 + 93488.888888888876*n4 + 45999.999999999993*n5 + x14*(x166 + x19) + x82;
    double x169 = -x149*x168;
    double x170 = 24.943387854459719*x165;
    double x171 = x170 + 3.0*x19;
    double x172 = 74099.999999999985*n1 + 74099.999999999985*n2 + 280466.66666666663*n4 + 137999.99999999997*n5 + x129 + x14*(x170 + 3*x19);
    double x173 = -x156*x172;
    double x174 = -3.0*x31;
    double x175 = 0.5*x30;
    double x176 = 0.5*x31 + x58;
    double x177 = x176*x60*x86;
    double x178 = x100*x104 + x103*(x102 - 1.5*x57) + x177;
    double x179 = -x106*x175 + x178;
    double x180 = x93 + x97;
    double x181 = x114*(x136 + x174 + x179 + x180 + x99);
    double x182 = x104*(-n4*x57 + x31);
    double x183 = x176*x61;
    double x184 = 1.0/x29;
    double x185 = -x29*x57 + x31;
    double x186 = x184*x185;
    double x187 = x186*x65;
    double x188 = x187*x30 + x38;
    double x189 = T*(x142 + x182 + x183*x30 + x188 + 1.0*x35 + 1.0*x46 + x53 + x73 - 0.69314718055994495);
    double x190 = 8.3144626181532395*x189;
    double x191 = x190 + 1.0*x21;
    double x192 = 40444.444444444438*n1 + 40444.444444444438*n2 + 93488.888888888876*n3 + 15555.555555555555*n5 + x14*(x190 + x21) + 3.5*x16 + 3.5*x18 + 3.5*x20 + x21*x7 + 3.5*x24 - 3.5*x27 + 29.100619163536336*x47;
    double x193 = -x149*x192 + 0.16326530612244897*x49;
    double x194 = 24.943387854459719*x189;
    double x195 = x194 + 3.0*x21;
    double x196 = 121333.33333333331*n1 + 121333.33333333331*n2 + 280466.66666666663*n3 + 46666.666666666657*n5 + 3.5*x124 + x14*(x194 + 3*x21) + 10.5*x16 + 10.5*x18 + 10.5*x20 + 10.5*x22 + 10.5*x24 + 87.301857490609009*x47;
    double x197 = 0.054421768707482998*x126 - x156*x196;
    double x198 = x135 - 4.0*x31 + x78 + x99;
    double x199 = x114*(x161 + x198);
    double x200 = x104*(-n5*x57 + x31);
    double x201 = T*(x141 + x163 + x188 + x200 + 1.0*x34 + x64);
    double x202 = 8.3144626181532395*x201;
    double x203 = x202 + 1.0*x23;
    double x204 = 24299.999999999996*n1 + 24299.999999999996*n2 + 45999.999999999993*n3 + 15555.555555555555*n4 + x14*(x202 + x23) + x82;
    double x205 = -x149*x204;
    double x206 = 24.943387854459719*x201;
    double x207 = x206 + 3.0*x23;
    double x208 = 72899.999999999985*n1 + 72899.999999999985*n2 + 137999.99999999997*n3 + 46666.666666666657*n4 + x129 + x14*(x206 + 3*x23);
    double x209 = -x156*x208;
    double x210 = x148*x51;
    double x211 = x41*x88;
    double x212 = x12*x57;
    double x213 = x212 + x95;
    double x214 = x213 + x72 - x94;
    double x215 = x108 + x96;
    double x216 = x215 + x56;
    double x217 = x114*(x214 + x216 + x30*(x101 + x211) + x93 + x140/n2);
    double x218 = x155*x51;
    double x219 = x174 + x215;
    double x220 = -1.0*x57;
    double x221 = x214 + x30*(x211 + x220);
    double x222 = x114*(x159 + x219 + x221);
    double x223 = x133 + x145 + 8.3144626181532395*x222;
    double x224 = x150 + x50;
    double x225 = x121 + x154 + 24.943387854459719*x222;
    double x226 = x127 + x157;
    double x227 = x179 + x96;
    double x228 = x114*(x138 + x221 + x227 + x99);
    double x229 = x168*x51;
    double x230 = -x95;
    double x231 = x42*x88;
    double x232 = x57*x68 + x94;
    double x233 = x114*(x113 + x216 + x230 + x232 + x30*(x101 + x231) + x164/n3);
    double x234 = x172*x51;
    double x235 = x230 + x232 + x30*(x220 + x231);
    double x236 = x114*(x198 + x227 + x235);
    double x237 = x114*(x136 + x219 + x235);
    double x238 = 2.0*n4*x88;
    double x239 = x105*x176;
    double x240 = x30*x65;
    double x241 = x184*x240*(x29*x89 + x87) - x185*x240/((x29)*(x29)) + x186*x86 + x187;
    double x242 = x241 + x56;
    double x243 = x183 + x212 - x98;
    double x244 = x114*(x103*(x102 + x220) - x175*x239 + x177 + x180 + x242 + x243 + x30*(x101 + x238) + x182/n4);
    double x245 = x114*(-x104*x239 + x137 + x160 + x178 + x241 + x243 + x30*(x220 + x238));
    double x246 = x204*x51;
    double x247 = x208*x51;
    double x248 = x114*(x107 + x213 + x232 + x242 + x30*(x101 + x43*x88) + x62 - x96 + x98 + x200/n5);

if (x116) {
   result[0] = x50 - 0.16326530612244897*x84 + x85*(8.3144626181532395*x115 + 2.0*x15 + 16.628925236306479*x80);
}
else {
   result[0] = x127 - 0.054421768707482998*x131 + x132*(24.943387854459719*x115 + 6.0*x15 + 49.886775708919437*x80);
}
if (x116) {
   result[1] = x150 + x151 + x85*(x133 + 8.3144626181532395*x139 + x146 + x147);
}
else {
   result[1] = x132*(x122 + 24.943387854459719*x139 + x152 + x154) + x157 + x158;
}
if (x116) {
   result[2] = x151 + x169 + x85*(x147 + 8.3144626181532395*x162 + x167 + 24699.999999999996);
}
else {
   result[2] = x132*(x152 + 24.943387854459719*x162 + x171 + 74099.999999999985) + x158 + x173;
}
if (x116) {
   result[3] = x193 - 0.2857142857142857*x84 + x85*(3.5*x15 + 8.3144626181532395*x181 + x191 + 29.100619163536336*x80 + 40444.444444444438);
}
else {
   result[3] = -0.095238095238095247*x131 + x132*(10.5*x15 + 24.943387854459719*x181 + x195 + 87.301857490609009*x80 + 121333.33333333331) + x197;
}
if (x116) {
   result[4] = x151 + x205 + x85*(x147 + 8.3144626181532395*x199 + x203 + 24299.999999999996);
}
else {
   result[4] = x132*(x152 + 24.943387854459719*x199 + x207 + 72899.999999999985) + x158 + x209;
}
if (x116) {
   result[5] = -0.16326530612244897*x210 + x50 + x85*(-26.762699999999999*T + 16.628925236306479*x144 + 2.0*x17 + 8.3144626181532395*x217 + 89.209000000000003);
}
else {
   result[5] = x127 + x132*(2.0*x119 + 133.8135*x120 + 49.886775708919437*x144 + 6.0*x17 + 24.943387854459719*x217 - 133.8135) - 0.054421768707482998*x218;
}
if (x116) {
   result[6] = x169 + x224 + x85*(x167 + x223 + 24744.604499999998);
}
else {
   result[6] = x132*(x171 + x225 + 74033.093249999991) + x173 + x226;
}
if (x116) {
   result[7] = x193 - 0.2857142857142857*x210 + x85*(-46.834724999999999*T + 29.100619163536336*x144 + 3.5*x17 + x191 + 8.3144626181532395*x228 + 40600.560194444435);
}
else {
   result[7] = x132*(3.5*x119 + 234.17362500000002*x120 + 87.301857490609009*x144 + 10.5*x17 + x195 + 24.943387854459719*x228 + 121099.15970833332) + x197 - 0.095238095238095247*x218;
}
if (x116) {
   result[8] = x205 + x224 + x85*(x203 + x223 + 24344.604499999998);
}
else {
   result[8] = x132*(x207 + x225 + 72833.093249999991) + x209 + x226;
}
if (x116) {
   result[9] = -0.16326530612244897*x229 + x50 + x85*(16.628925236306479*x165 + 2.0*x19 + 8.3144626181532395*x233);
}
else {
   result[9] = x127 + x132*(49.886775708919437*x165 + 6.0*x19 + 24.943387854459719*x233) - 0.054421768707482998*x234;
}
if (x116) {
   result[10] = x193 - 0.2857142857142857*x229 + x85*(29.100619163536336*x165 + 3.5*x19 + x191 + 8.3144626181532395*x236 + 93488.888888888876);
}
else {
   result[10] = x132*(87.301857490609009*x165 + 10.5*x19 + x195 + 24.943387854459719*x236 + 280466.66666666663) + x197 - 0.095238095238095247*x234;
}
if (x116) {
   result[11] = x169 + x205 + x50 + x85*(x167 + x203 + 8.3144626181532395*x237 + 45999.999999999993);
}
else {
   result[11] = x127 + x132*(x171 + x207 + 24.943387854459719*x237 + 137999.99999999997) + x173 + x209;
}
if (x116) {
   result[12] = -0.5714285714285714*x192*x51 + 0.5714285714285714*x49 + x85*(58.201238327072673*x189 + 7.0*x21 + 8.3144626181532395*x244);
}
else {
   result[12] = 0.19047619047619049*x126 + x132*(174.60371498121802*x189 + 21.0*x21 + 24.943387854459719*x244) - 0.19047619047619049*x196*x51;
}
if (x116) {
   result[13] = x193 - 0.2857142857142857*x246 + x85*(x191 + 29.100619163536336*x201 + 3.5*x23 + 8.3144626181532395*x245 + 15555.555555555555);
}
else {
   result[13] = x132*(x195 + 87.301857490609009*x201 + 10.5*x23 + 24.943387854459719*x245 + 46666.666666666657) + x197 - 0.095238095238095247*x247;
}
if (x116) {
   result[14] = -0.16326530612244897*x246 + x50 + x85*(16.628925236306479*x201 + 2.0*x23 + 8.3144626181532395*x248);
}
else {
   result[14] = x127 + x132*(49.886775708919437*x201 + 6.0*x23 + 24.943387854459719*x248) - 0.054421768707482998*x247;
}
}
        
static void coder_d3gdn3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x1 = pow(x0, -4);
    double x2 = 444600.0*n3 + 728000.0*n4 + 437400.0*n5;
    double x3 = 0.027777777777777773*x2;
    double x4 = n3*(444600.0*n1 + 444600.0*n2 + 1682800.0*n4 + 828000.0*n5);
    double x5 = n4*(2369250.0*n1 + 2369250.0*n2 + 5476612.5*n3 + 911250.0*n5);
    double x6 = n5*(437400.0*n1 + 437400.0*n2 + 828000.0*n3 + 280000.0*n4);
    double x7 = 3.5*n4;
    double x8 = 1.0*n5;
    double x9 = 1.0*n2;
    double x10 = 1.0*n1;
    double x11 = 1.0*n3;
    double x12 = x10 + x11;
    double x13 = x12 + x8 + x9;
    double x14 = x13 + x7;
    double x15 = (*endmember[0].mu0)(T, P);
    double x16 = n1*x15;
    double x17 = (*endmember[1].mu0)(T, P);
    double x18 = n2*x17;
    double x19 = (*endmember[2].mu0)(T, P);
    double x20 = n3*x19;
    double x21 = (*endmember[3].mu0)(T, P);
    double x22 = n4*x21;
    double x23 = (*endmember[4].mu0)(T, P);
    double x24 = n5*x23;
    double x25 = 13.381349999999999*T;
    double x26 = x25 - 44.604500000000002;
    double x27 = n2*x26;
    double x28 = n1 + n3;
    double x29 = n4 + n5;
    double x30 = n2 + x28 + x29;
    double x31 = 1.0/x30;
    double x32 = log(n2*x31);
    double x33 = log(n3*x31);
    double x34 = log(n5*x31);
    double x35 = log(n4*x31);
    double x36 = 1.0*n4;
    double x37 = 1.0*log(x28*x31);
    double x38 = 1.0*log(x29*x31);
    double x39 = n1 + n2 + n4;
    double x40 = 1.0*log(x31*x39);
    double x41 = 2.0*n2;
    double x42 = 2.0*n3;
    double x43 = 2.0*n5;
    double x44 = 2.0*n1 + x36 + x41 + x42 + x43;
    double x45 = 0.5*n4 + x13;
    double x46 = log(x31*x45);
    double x47 = x11*x33 + x28*x37 + x29*x38 + x32*x9 + x34*x8 + x36*(x35 - 0.69314718055994495) + x39*x40 + x44*x46;
    double x48 = 8.3144626181532395*T;
    double x49 = x47*x48;
    double x50 = x1*(n1*x3 + n2*x3 + x14*(x16 + x18 + x20 + x22 + x24 - x27 + x49) + 0.027777777777777773*x4 + 0.0085352842554488641*x5 + 0.027777777777777773*x6);
    double x51 = -0.039983340274885454*x50;
    double x52 = pow(x0, -3);
    double x53 = 2.0*x46;
    double x54 = -x31*x9;
    double x55 = -x11*x31;
    double x56 = -x31*x36;
    double x57 = 1.0/x45;
    double x58 = 1.0*x31;
    double x59 = pow(x30, -2);
    double x60 = -x45*x59;
    double x61 = x58 + x60;
    double x62 = x57*x61;
    double x63 = x44*x62;
    double x64 = x30*x63;
    double x65 = x53 + x54 + x55 + x56 + x64;
    double x66 = x36 + x8;
    double x67 = -x31*x66;
    double x68 = -x31*x8;
    double x69 = x10 + x36 + x9;
    double x70 = 1.0/x39;
    double x71 = x31 - x39*x59;
    double x72 = x70*x71;
    double x73 = x69*x72;
    double x74 = x30*x73 + x40 + x68;
    double x75 = x67 + x74;
    double x76 = 1.0/x28;
    double x77 = -x28*x59 + x31;
    double x78 = x76*x77;
    double x79 = x12*x78;
    double x80 = x30*x79 + x37;
    double x81 = x65 + x75 + x80;
    double x82 = x48*x81;
    double x83 = x10*x15 + x11*x19 + x17*x9 + x21*x36 + x23*x8 - x26*x9 + x49;
    double x84 = 24699.999999999996*n3 + 40444.444444444438*n4 + 24299.999999999996*n5 + x83;
    double x85 = x52*(x14*(x15 + x82) + x84);
    double x86 = pow(x0, -2);
    double x87 = T*x81;
    double x88 = 2.0*x72;
    double x89 = -2*x59;
    double x90 = pow(x30, -3);
    double x91 = 2*x90;
    double x92 = x39*x91;
    double x93 = x89 + x92;
    double x94 = x69*x70;
    double x95 = x93*x94;
    double x96 = pow(x39, -2);
    double x97 = x71*x96;
    double x98 = x69*x97;
    double x99 = x30*x88 + x30*x95 - x30*x98;
    double x100 = x59*x9;
    double x101 = x11*x59;
    double x102 = x59*x8;
    double x103 = x100 + x101 + x102 + x73;
    double x104 = x36*x59;
    double x105 = x104 + x59*x66 + x63;
    double x106 = 4.0*x30;
    double x107 = 2.0*x59;
    double x108 = -x107;
    double x109 = x45*x91;
    double x110 = x108 + x109;
    double x111 = x44*x57;
    double x112 = x110*x111;
    double x113 = 1.0*x30;
    double x114 = pow(x45, -2);
    double x115 = x114*x61;
    double x116 = x115*x44;
    double x117 = x106*x62 + x112*x30 - x113*x116;
    double x118 = x105 + x117;
    double x119 = x103 + x118;
    double x120 = 2.0*x78;
    double x121 = x28*x91;
    double x122 = x121 + x89;
    double x123 = x12*x76;
    double x124 = x122*x123;
    double x125 = pow(x28, -2);
    double x126 = x125*x77;
    double x127 = x12*x126;
    double x128 = x120*x30 + x124*x30 - x127*x30 + x79;
    double x129 = T*(x119 + x128 + x99);
    double x130 = 8.3144626181532395*x129;
    double x131 = x86*(x130*x14 + 2.0*x15 + 16.628925236306479*x87);
    double x132 = 1.0/x14;
    double x133 = 24.943387854459719*x129;
    double x134 = 2.0*x90;
    double x135 = n4*x134;
    double x136 = -x135;
    double x137 = x136 - x66*x91;
    double x138 = x41*x90;
    double x139 = -x138;
    double x140 = x42*x90;
    double x141 = -x140;
    double x142 = x43*x90;
    double x143 = -x142;
    double x144 = x139 + x141 + x143;
    double x145 = 3.0*x30;
    double x146 = 6*x90;
    double x147 = pow(x30, -4);
    double x148 = 6*x147;
    double x149 = -x148*x39;
    double x150 = x30*x94;
    double x151 = x69*x96;
    double x152 = 2*x30;
    double x153 = x145*x70*x93 - x145*x97 + x150*(x146 + x149) - x151*x152*x93 + x152*x69*x71/((x39)*(x39)*(x39)) + 3.0*x72 + 2*x95 - 2*x98;
    double x154 = x144 + x153;
    double x155 = x137 + x154;
    double x156 = 6.0*x30;
    double x157 = x110*x57;
    double x158 = 2.0*x44;
    double x159 = 6.0*x90;
    double x160 = -x148*x45;
    double x161 = x111*x30;
    double x162 = x158*x30;
    double x163 = pow(x45, -3);
    double x164 = x163*x61;
    double x165 = x110*x114;
    double x166 = 2*x112 - x115*x156 - x115*x158 + x156*x157 + x161*(x159 + x160) + x162*x164 - x162*x165 + 6.0*x62;
    double x167 = -x148*x28;
    double x168 = x123*x30;
    double x169 = x12*x125;
    double x170 = x12*x152*x77/((x28)*(x28)*(x28)) + x122*x145*x76 - x122*x152*x169 + 2*x124 - x126*x145 - 2*x127 + x168*(x146 + x167) + 3.0*x78;
    double x171 = x166 + x170;
    double x172 = x14*(x155 + x171);
    double x173 = T >= 5.0;
    double x174 = 0.083333333333333315*x2;
    double x175 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x176 = (40.14405*T - 200.72024999999999)*(x175 - 1);
    double x177 = ((x175)*(x175)*(x175));
    double x178 = 66.906750000000002*x177;
    double x179 = x178 - 66.906750000000002;
    double x180 = x176 + x179;
    double x181 = n2*x180;
    double x182 = 24.943387854459719*T;
    double x183 = x182*x47;
    double x184 = x1*(n1*x174 + n2*x174 + x14*(3*x16 + 3*x18 + x181 + x183 + 3*x20 + 3*x22 + 3*x24) + 0.083333333333333315*x4 + 0.025605852766346592*x5 + 0.083333333333333315*x6);
    double x185 = -0.013327780091628489*x184;
    double x186 = 24.943387854459719*x87;
    double x187 = 3.0*x16 + 3.0*x18 + x180*x9 + x183 + 3.0*x20 + 3.0*x22 + 3.0*x24;
    double x188 = 74099.999999999985*n3 + 121333.33333333331*n4 + 72899.999999999985*n5 + x187;
    double x189 = x52*(x14*(3*x15 + x186) + x188);
    double x190 = x86*(x133*x14 + 6.0*x15 + 49.886775708919437*x87);
    double x191 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x192 = -x59;
    double x193 = x121 + x192;
    double x194 = x123*x193;
    double x195 = x194*x30;
    double x196 = x195 + x79;
    double x197 = -2.0*x31;
    double x198 = x197 + x99;
    double x199 = x119 + x196 + x198;
    double x200 = T*x199;
    double x201 = 16.628925236306479*x200;
    double x202 = 1.0*x59;
    double x203 = x193*x30;
    double x204 = 4*x90;
    double x205 = x124 - x127 + x168*(x167 + x204) - x169*x203 + x194;
    double x206 = x120 + 2.0*x203*x76 + x205;
    double x207 = x166 + x206;
    double x208 = x14*(x155 + x202 + x207);
    double x209 = -n2*x59 + x31;
    double x210 = x113*x209;
    double x211 = -x12*x31;
    double x212 = x211 + x55;
    double x213 = x53 + x56 + x64;
    double x214 = x210 + x212 + x213 + 1.0*x32 + x75;
    double x215 = x214*x48 - x25;
    double x216 = x215 + 44.604500000000002;
    double x217 = x14*(x17 + x216) + x84;
    double x218 = 0.046647230320699701*x52;
    double x219 = x217*x218;
    double x220 = 1.0*x17;
    double x221 = x199*x48;
    double x222 = 1.0*x15 + x82;
    double x223 = x14*x221 + x216 + x220 + x222;
    double x224 = 0.16326530612244897*x86;
    double x225 = -x223*x224 + x51;
    double x226 = -0.081632653061224483*x131 + 0.093294460641399402*x85;
    double x227 = 49.886775708919437*x200;
    double x228 = x182*x214;
    double x229 = x14*(3*x17 + x180 + x228) + x188;
    double x230 = 0.01554907677356657*x52;
    double x231 = x229*x230;
    double x232 = x182*x199;
    double x233 = 3.0*x15 + x186;
    double x234 = 3.0*x17 + 1.0*x176 + x228;
    double x235 = x14*x232 + x179 + x233 + x234;
    double x236 = 0.054421768707482998*x86;
    double x237 = x185 - x235*x236;
    double x238 = 0.031098153547133141*x189 - 0.027210884353741499*x190;
    double x239 = x192 + x92;
    double x240 = x239*x94;
    double x241 = x240*x30;
    double x242 = x103 + x241;
    double x243 = x117 + x242;
    double x244 = x105 + x128 + x197 + x243;
    double x245 = T*x244;
    double x246 = 16.628925236306479*x245;
    double x247 = x239*x30;
    double x248 = x150*(x149 + x204) - x151*x247 + x240 + x95 - x98;
    double x249 = x144 + x248;
    double x250 = 2.0*x247*x70 + x88;
    double x251 = x249 + x250;
    double x252 = x137 + x251;
    double x253 = x14*(x171 + x202 + x252);
    double x254 = -x31*x69;
    double x255 = -n3*x59 + x31;
    double x256 = x113*x255;
    double x257 = x213 + x254 + x256 + 1.0*x33 + x54 + x67 + x68 + x80;
    double x258 = x257*x48;
    double x259 = 24699.999999999996*n1 + 24699.999999999996*n2 + 93488.888888888876*n4 + 45999.999999999993*n5 + x14*(x19 + x258) + x83;
    double x260 = x218*x259;
    double x261 = x244*x48;
    double x262 = 1.0*x19 + x258;
    double x263 = x14*x261 + x222 + x262 + 24699.999999999996;
    double x264 = -x224*x263;
    double x265 = x226 + x51;
    double x266 = 49.886775708919437*x245;
    double x267 = x182*x257;
    double x268 = 74099.999999999985*n1 + 74099.999999999985*n2 + 280466.66666666663*n4 + 137999.99999999997*n5 + x14*(3*x19 + x267) + x187;
    double x269 = x230*x268;
    double x270 = x182*x244;
    double x271 = 3.0*x19 + x267;
    double x272 = x14*x270 + x233 + x271 + 74099.999999999985;
    double x273 = -x236*x272;
    double x274 = x185 + x238;
    double x275 = -3.0*x31;
    double x276 = 0.5*x30;
    double x277 = 0.5*x31 + x60;
    double x278 = x277*x57;
    double x279 = 2.0*x278;
    double x280 = x279*x30;
    double x281 = x109 - 1.5*x59;
    double x282 = x111*x281;
    double x283 = x113*x62 + x280 + x282*x30;
    double x284 = -x116*x276 + x283;
    double x285 = x103 + x99;
    double x286 = x105 + x196 + x275 + x284 + x285;
    double x287 = T*x286;
    double x288 = x113*x44;
    double x289 = x114*x288;
    double x290 = -x281*x289;
    double x291 = x276*x44;
    double x292 = x281*x57;
    double x293 = x106*x292 + x113*x157 + x161*(x160 + 5.0*x90);
    double x294 = x112 - 1.5*x116 + x164*x288 - x165*x291 + x282 + x293;
    double x295 = -x115*x145 + x290 + x294 + 5.0*x62;
    double x296 = x14*(x107 + x155 + x206 + x295);
    double x297 = x286*x48;
    double x298 = -n4*x59 + x31;
    double x299 = x113*x298;
    double x300 = x111*x277;
    double x301 = 1.0/x29;
    double x302 = -x29*x59 + x31;
    double x303 = x301*x302;
    double x304 = x303*x66;
    double x305 = x30*x304 + x38;
    double x306 = x212 + x299 + x30*x300 + x305 + 1.0*x35 + 1.0*x46 + x54 + x74 - 0.69314718055994495;
    double x307 = x306*x48;
    double x308 = 1.0*x21 + x307;
    double x309 = x14*x297 + 3.5*x15 + x308 + 29.100619163536336*x87 + 40444.444444444438;
    double x310 = T*x47;
    double x311 = 40444.444444444438*n1 + 40444.444444444438*n2 + 93488.888888888876*n3 + 15555.555555555555*n5 + x14*(x21 + x307) + 3.5*x16 + 3.5*x18 + 3.5*x20 + x21*x7 + 3.5*x24 - 3.5*x27 + 29.100619163536336*x310;
    double x312 = x218*x311 - 0.1399416909620991*x50;
    double x313 = x182*x286;
    double x314 = x182*x306;
    double x315 = 3.0*x21 + x314;
    double x316 = x14*x313 + 10.5*x15 + x315 + 87.301857490609009*x87 + 121333.33333333331;
    double x317 = 121333.33333333331*n1 + 121333.33333333331*n2 + 280466.66666666663*n3 + 46666.666666666657*n5 + x14*(3*x21 + x314) + 10.5*x16 + 10.5*x18 + 3.5*x181 + 10.5*x20 + 10.5*x22 + 10.5*x24 + 87.301857490609009*x310;
    double x318 = x230*x317;
    double x319 = -0.046647230320699715*x184 + x318;
    double x320 = x105 + x195 - 4.0*x31 + x79;
    double x321 = x243 + x320;
    double x322 = T*x321;
    double x323 = 16.628925236306479*x322;
    double x324 = x14*(x107 + x207 + x252);
    double x325 = -n5*x59 + x31;
    double x326 = x113*x325;
    double x327 = x211 + x254 + x305 + x326 + 1.0*x34 + x65;
    double x328 = x327*x48;
    double x329 = 24299.999999999996*n1 + 24299.999999999996*n2 + 45999.999999999993*n3 + 15555.555555555555*n4 + x14*(x23 + x328) + x83;
    double x330 = x218*x329;
    double x331 = x321*x48;
    double x332 = 1.0*x23 + x328;
    double x333 = x14*x331 + x222 + x332 + 24299.999999999996;
    double x334 = -x224*x333;
    double x335 = 49.886775708919437*x322;
    double x336 = x182*x327;
    double x337 = 72899.999999999985*n1 + 72899.999999999985*n2 + 137999.99999999997*n3 + 46666.666666666657*n4 + x14*(3*x23 + x336) + x187;
    double x338 = x230*x337;
    double x339 = x182*x321;
    double x340 = 3.0*x23 + x336;
    double x341 = x14*x339 + x233 + x340 + 72899.999999999985;
    double x342 = -x236*x341;
    double x343 = 1.0/n2;
    double x344 = x12*x59;
    double x345 = x101 + x344;
    double x346 = -x100 + x345 + x73;
    double x347 = x102 + x118;
    double x348 = x347 + x58;
    double x349 = x210*x343 + x30*(x108 + x138) + x346 + x348 + x99;
    double x350 = x349*x48;
    double x351 = 3.0*x59;
    double x352 = x166 + x351;
    double x353 = x137 + x168*(x167 + x91) + 2*x194;
    double x354 = x154 + x353;
    double x355 = x14*(x352 + x354);
    double x356 = 0.046647230320699701*x85;
    double x357 = x217*x52;
    double x358 = T*x214;
    double x359 = -26.762699999999999*T + x14*x350 + 2.0*x17 + 16.628925236306479*x358 + 89.209000000000003;
    double x360 = 0.081632653061224483*x86;
    double x361 = 0.093294460641399402*x357 - x359*x360;
    double x362 = x182*x349;
    double x363 = 0.01554907677356657*x189;
    double x364 = x229*x52;
    double x365 = x14*x362 + 6.0*x17 + 2.0*x176 + 133.8135*x177 + 49.886775708919437*x358 - 133.8135;
    double x366 = 0.027210884353741499*x86;
    double x367 = 0.031098153547133141*x364 - x365*x366;
    double x368 = x14*(x113*x193*x76 + x205 + x252 + x352 + 1.0*x78);
    double x369 = x275 + x347;
    double x370 = -x202;
    double x371 = x30*(x138 + x370) + x346;
    double x372 = x241 + x369 + x371;
    double x373 = x372*x48;
    double x374 = x221 + x373;
    double x375 = x14*x373 + x215 + x220;
    double x376 = x262 + x375 + 24744.604499999998;
    double x377 = -x360*x376;
    double x378 = x356 + x51;
    double x379 = x219 - x223*x360 + x378;
    double x380 = x260 - x263*x360;
    double x381 = x182*x372;
    double x382 = x232 + x381;
    double x383 = x14*x381 + x178 + x234;
    double x384 = x271 + x383 + 74033.093249999991;
    double x385 = -x366*x384;
    double x386 = x185 + x363;
    double x387 = x231 - x235*x366 + x386;
    double x388 = x269 - x272*x366;
    double x389 = x102 + x284;
    double x390 = x105 + x198 + x371 + x389;
    double x391 = x390*x48;
    double x392 = 4.0*x59;
    double x393 = x295 + x392;
    double x394 = x14*(x354 + x393);
    double x395 = 0.2857142857142857*x86;
    double x396 = -x309*x360 + x312 + 0.16326530612244897*x85;
    double x397 = -46.834724999999999*T + x14*x391 + 3.5*x17 + x308 + 29.100619163536336*x358 + 40600.560194444435;
    double x398 = 0.16326530612244897*x357 - x360*x397;
    double x399 = x182*x390;
    double x400 = 0.095238095238095247*x86;
    double x401 = x14*x399 + 10.5*x17 + 3.5*x176 + 234.17362500000002*x177 + x315 + 87.301857490609009*x358 + 121099.15970833332;
    double x402 = 0.054421768707482998*x364 - x366*x401;
    double x403 = 0.054421768707482998*x189 - x316*x366;
    double x404 = x319 + x403;
    double x405 = x166 + x392;
    double x406 = x353 + x405;
    double x407 = x14*(x251 + x406);
    double x408 = x332 + x375 + 24344.604499999998;
    double x409 = -x360*x408;
    double x410 = x330 - x333*x360;
    double x411 = x340 + x383 + 72833.093249999991;
    double x412 = -x366*x411;
    double x413 = x338 - x341*x366;
    double x414 = -x101;
    double x415 = 1.0/n3;
    double x416 = x100 + x59*x69;
    double x417 = x128 + x256*x415 + x30*(x108 + x140) + x348 + x414 + x416;
    double x418 = x417*x48;
    double x419 = 2*x240;
    double x420 = x150*(x149 + x91);
    double x421 = x144 + x419 + x420;
    double x422 = x166 + x421;
    double x423 = x137 + x422;
    double x424 = x14*(x170 + x351 + x423);
    double x425 = x259*x52;
    double x426 = T*x257;
    double x427 = x14*x418 + 2.0*x19 + 16.628925236306479*x426;
    double x428 = -x360*x427 + 0.093294460641399402*x425;
    double x429 = x182*x417;
    double x430 = x268*x52;
    double x431 = x14*x429 + 6.0*x19 + 49.886775708919437*x426;
    double x432 = -x366*x431 + 0.031098153547133141*x430;
    double x433 = x30*(x140 + x370) + x414 + x416;
    double x434 = x320 + x389 + x433;
    double x435 = x434*x48;
    double x436 = x206 + x392;
    double x437 = x113*x239*x70 + 1.0*x72;
    double x438 = x14*(x137 + x249 + x295 + x436 + x437);
    double x439 = x14*x435 + 3.5*x19 + x308 + 29.100619163536336*x426 + 93488.888888888876;
    double x440 = -x360*x439 + 0.16326530612244897*x425;
    double x441 = x182*x434;
    double x442 = x14*x441 + 10.5*x19 + x315 + 87.301857490609009*x426 + 280466.66666666663;
    double x443 = -x366*x442 + 0.054421768707482998*x430;
    double x444 = x196 + x369 + x433;
    double x445 = x444*x48;
    double x446 = x14*(x423 + x436);
    double x447 = x14*x445 + x262 + x332 + 45999.999999999993;
    double x448 = -x360*x447;
    double x449 = x182*x444;
    double x450 = x14*x449 + x271 + x340 + 137999.99999999997;
    double x451 = -x366*x450;
    double x452 = 1.0/n4;
    double x453 = x109 + x370;
    double x454 = x111*x453;
    double x455 = x114*x277;
    double x456 = x44*x455;
    double x457 = 2.0*x30;
    double x458 = x30*x66;
    double x459 = x29*x91 + x89;
    double x460 = x301*x459;
    double x461 = pow(x29, -2);
    double x462 = x302*x461;
    double x463 = x303*x457 + x304 + x458*x460 - x458*x462;
    double x464 = x463 + x58;
    double x465 = -x104 + x300 + x344;
    double x466 = -x276*x456 + x280 + x285 + x299*x452 + x30*x454 + x30*(x108 + x135) + x464 + x465;
    double x467 = x466*x48;
    double x468 = x353 + 5.0*x59;
    double x469 = x279 + x290;
    double x470 = x113*x455;
    double x471 = -x113*x115 + 2*x282;
    double x472 = x453*x57;
    double x473 = 4.0*x90;
    double x474 = x161*(x160 + x473) + x292*x457 + x457*x472;
    double x475 = -1.0*x116 + x164*x291 - x470 + x471 + x474 + 2.0*x62;
    double x476 = x469 + x475;
    double x477 = x14*(x154 + x468 + x476);
    double x478 = 0.5714285714285714*x86;
    double x479 = x311*x52;
    double x480 = T*x306;
    double x481 = x14*x467 + 7.0*x21 + 58.201238327072673*x480;
    double x482 = -x360*x481 + 0.32653061224489793*x479;
    double x483 = x482 - 0.48979591836734693*x50;
    double x484 = x182*x466;
    double x485 = 0.19047619047619049*x86;
    double x486 = x317*x52;
    double x487 = x14*x484 + 21.0*x21 + 174.60371498121802*x480;
    double x488 = -0.16326530612244899*x184 - x366*x487 + 0.108843537414966*x486;
    double x489 = x197 + x242 + x283 + x30*(x135 + x370) - x44*x470 + x463 + x465;
    double x490 = x48*x489;
    double x491 = -x115*x457 + x294 - x455*x457 + 3.0*x62;
    double x492 = x468 + x491;
    double x493 = x14*(x251 + x469 + x492);
    double x494 = x329*x52;
    double x495 = T*x327;
    double x496 = x14*x490 + 3.5*x23 + x308 + 29.100619163536336*x495 + 15555.555555555555;
    double x497 = -x360*x496 + 0.16326530612244897*x494;
    double x498 = x182*x489;
    double x499 = x337*x52;
    double x500 = x14*x498 + 10.5*x23 + x315 + 87.301857490609009*x495 + 46666.666666666657;
    double x501 = -0.046647230320699708*x184 + x318;
    double x502 = -x366*x500 + 0.054421768707482998*x499 + x501;
    double x503 = 1.0/n5;
    double x504 = -x102 + x104 + x117 + x30*(x108 + x142) + x326*x503 + x345 + x416 + x464 + x63;
    double x505 = x48*x504;
    double x506 = x353 + 6.0*x59;
    double x507 = x14*(x422 + x506);
    double x508 = x14*x505 + 2.0*x23 + 16.628925236306479*x495;
    double x509 = -x360*x508 + 0.093294460641399402*x494;
    double x510 = x182*x504;
    double x511 = x14*x510 + 6.0*x23 + 49.886775708919437*x495;
    double x512 = -x366*x511 + 0.031098153547133141*x499;
    double x513 = 0.24489795918367346*x86;
    double x514 = 6.0*x147;
    double x515 = -n2*x514;
    double x516 = n2*x91;
    double x517 = x113*x343;
    double x518 = x137 + x143;
    double x519 = -x12*x91;
    double x520 = x141 + x519;
    double x521 = n2*x473 + x518 + x520;
    double x522 = 1.0*x209*x343 + x521;
    double x523 = -x392;
    double x524 = x166 + x523;
    double x525 = x14*(x153 + x30*(x159 + x515) + x517*(x516 + x89) + x522 + x524 - x210/((n2)*(n2)));
    double x526 = 0.081632653061224497*x86;
    double x527 = T*x349;
    double x528 = -x224*x376 + x51;
    double x529 = T*x372;
    double x530 = 16.628925236306479*x529;
    double x531 = x166 + x370;
    double x532 = x248 + x250;
    double x533 = x30*(x473 + x515) + x517*(x192 + x516) + x522;
    double x534 = x14*(x531 + x532 + x533);
    double x535 = x132*(x350 + x48*x534 + x530) + x361;
    double x536 = x185 - x236*x384;
    double x537 = 49.886775708919437*x529;
    double x538 = x191*(x182*x534 + x362 + x537) + x367;
    double x539 = T*x390;
    double x540 = x14*(x153 + x295 + x370 + x533);
    double x541 = -x224*x408 + x51;
    double x542 = x185 - x236*x411;
    double x543 = x30*(x134 + x515) + x521;
    double x544 = x14*(x405 + x419 + x420 + x543);
    double x545 = x48*x544 + x530;
    double x546 = x182*x544 + x537;
    double x547 = x14*(x248 + x393 + x437 + x543);
    double x548 = x391 + 29.100619163536336*x529;
    double x549 = x312 + x398;
    double x550 = x399 + 87.301857490609009*x529;
    double x551 = x351 + x543;
    double x552 = x14*(x153 + x476 + x551);
    double x553 = x14*(x469 + x491 + x532 + x551);
    double x554 = -n3*x514;
    double x555 = n3*x91;
    double x556 = x113*x415;
    double x557 = x139 - x69*x91;
    double x558 = n3*x473 + x557;
    double x559 = 1.0*x255*x415 + x518 + x558;
    double x560 = x14*(x170 + x30*(x159 + x554) + x524 + x556*(x555 + x89) + x559 - x256/((n3)*(n3)));
    double x561 = T*x417;
    double x562 = T*x434;
    double x563 = x206 + x30*(x473 + x554) + x556*(x192 + x555) + x559;
    double x564 = x14*(x295 + x563);
    double x565 = T*x444;
    double x566 = 16.628925236306479*x565;
    double x567 = x14*(x531 + x563);
    double x568 = -x224*x447 + x51;
    double x569 = 49.886775708919437*x565;
    double x570 = x185 - x236*x450;
    double x571 = x143 + x30*(x134 + x554) + x558;
    double x572 = x469 + x571;
    double x573 = x14*(x475 + x506 + x572);
    double x574 = x14*(x492 + x572);
    double x575 = x14*(x406 + x571);
    double x576 = T*x466;
    double x577 = -n4*x514;
    double x578 = n4*x91;
    double x579 = x113*x452;
    double x580 = x163*x277;
    double x581 = 2*x66;
    double x582 = 2*x458;
    double x583 = x145*x460 - x145*x462 + x301*x458*(x146 - x148*x29) + 3.0*x303 - x459*x461*x582 + x460*x581 - x462*x581 + x302*x582/((x29)*(x29)*(x29));
    double x584 = n4*x473 + x519 + x583;
    double x585 = -x289*x453 + 1.0*x298*x452;
    double x586 = x14*(x145*x472 + x154 + x161*(x160 + 3.0*x90) + 3.0*x278 + x291*x580 - 1.5*x30*x455 + x30*(x159 + x577) + 2*x454 - 1.0*x456 + x523 + x579*(x578 + x89) + x584 + x585 - x299/((n4)*(n4)));
    double x587 = T*x489;
    double x588 = x114*x281;
    double x589 = 4.0*x278 + x584;
    double x590 = x14*(x108 - x145*x455 + x251 + x282 + x288*x580 - x291*x588 + x30*(x473 + x577) + x454 - 1.5*x456 + x474 + x579*(x192 + x578) + x585 + x589);
    double x591 = T*x504;
    double x592 = x14*(-x106*x455 + x107 - x158*x455 + x162*x580 - x162*x588 + x293 + x30*(x134 + x577) + x421 + x471 + x589 + 1.0*x62);
    double x593 = x14*(n5*x473 + x113*x503*(n5*x91 + x89) + x136 + x30*(-n5*x514 + x159) + 1.0*x325*x503 + x520 + x524 + x557 + x583 - x326/((n5)*(n5)));

if (x173) {
   result[0] = -0.24489795918367346*x131 + x132*(x133 + x172*x48) + x51 + 0.1399416909620991*x85;
}
else {
   result[0] = x185 + 0.046647230320699715*x189 - 0.081632653061224497*x190 + x191*(74.830163563379159*x129 + x172*x182);
}
if (x173) {
   result[1] = x132*(x130 + x201 + x208*x48) + x219 + x225 + x226;
}
else {
   result[1] = x191*(x133 + x182*x208 + x227) + x231 + x237 + x238;
}
if (x173) {
   result[2] = x132*(x130 + x246 + x253*x48) + x260 + x264 + x265;
}
else {
   result[2] = x191*(x133 + x182*x253 + x266) + x269 + x273 + x274;
}
if (x173) {
   result[3] = -0.2857142857142857*x131 + x132*(29.100619163536336*x129 + 16.628925236306479*x287 + x296*x48) - x224*x309 + x312 + 0.32653061224489793*x85;
}
else {
   result[3] = 0.108843537414966*x189 - 0.095238095238095247*x190 + x191*(87.301857490609009*x129 + x182*x296 + 49.886775708919437*x287) - x236*x316 + x319;
}
if (x173) {
   result[4] = x132*(x130 + x323 + x324*x48) + x265 + x330 + x334;
}
else {
   result[4] = x191*(x133 + x182*x324 + x335) + x274 + x338 + x342;
}
if (x173) {
   result[5] = x132*(x201 + x350 + x355*x48) + x225 + x356 + x361;
}
else {
   result[5] = x191*(x182*x355 + x227 + x362) + x237 + x363 + x367;
}
if (x173) {
   result[6] = x132*(x261 + x368*x48 + x374) + x377 + x379 + x380;
}
else {
   result[6] = x191*(x182*x368 + x270 + x382) + x385 + x387 + x388;
}
if (x173) {
   result[7] = x132*(29.100619163536336*x200 + x297 + x391 + x394*x48) - x223*x395 + x396 + x398;
}
else {
   result[7] = x191*(x182*x394 + 87.301857490609009*x200 + x313 + x399) - x235*x400 + x402 + x404;
}
if (x173) {
   result[8] = x132*(x331 + x374 + x407*x48) + x379 + x409 + x410;
}
else {
   result[8] = x191*(x182*x407 + x339 + x382) + x387 + x412 + x413;
}
if (x173) {
   result[9] = x132*(x246 + x418 + x424*x48) + x264 + x378 + x428;
}
else {
   result[9] = x191*(x182*x424 + x266 + x429) + x273 + x386 + x432;
}
if (x173) {
   result[10] = x132*(29.100619163536336*x245 + x297 + x435 + x438*x48) - x263*x395 + x396 + x440;
}
else {
   result[10] = x191*(x182*x438 + 87.301857490609009*x245 + x313 + x441) - x272*x400 + x404 + x443;
}
if (x173) {
   result[11] = x132*(x261 + x331 + x445 + x446*x48) + x378 + x380 + x410 + x448;
}
else {
   result[11] = x191*(x182*x446 + x270 + x339 + x449) + x386 + x388 + x413 + x451;
}
if (x173) {
   result[12] = x132*(58.201238327072673*x287 + x467 + x477*x48) - x309*x478 + x483 + 0.5714285714285714*x85;
}
else {
   result[12] = 0.19047619047619049*x189 + x191*(x182*x477 + 174.60371498121802*x287 + x484) - x316*x485 + x488;
}
if (x173) {
   result[13] = x132*(x297 + 29.100619163536336*x322 + x48*x493 + x490) - x333*x395 + x396 + x497;
}
else {
   result[13] = x191*(x182*x493 + x313 + 87.301857490609009*x322 + x498) - x341*x400 + x403 + x502;
}
if (x173) {
   result[14] = x132*(x323 + x48*x507 + x505) + x334 + x378 + x509;
}
else {
   result[14] = x191*(x182*x507 + x335 + x510) + x342 + x386 + x512;
}
if (x173) {
   result[15] = x132*(x362 + x48*x525) + 0.1399416909620991*x357 - x359*x513 + x51;
}
else {
   result[15] = x185 + x191*(x182*x525 + 74.830163563379159*x527) + 0.046647230320699715*x364 - x365*x526;
}
if (x173) {
   result[16] = x260 + x528 + x535;
}
else {
   result[16] = x269 + x536 + x538;
}
if (x173) {
   result[17] = x132*(x48*x540 + 29.100619163536336*x527 + 16.628925236306479*x539) - x224*x397 + x312 + 0.32653061224489793*x357 - x359*x395;
}
else {
   result[17] = x191*(x182*x540 + 87.301857490609009*x527 + 49.886775708919437*x539) - x236*x401 + x319 + 0.108843537414966*x364 - x365*x400;
}
if (x173) {
   result[18] = x330 + x535 + x541;
}
else {
   result[18] = x338 + x538 + x542;
}
if (x173) {
   result[19] = x132*(x418 + x545) + x219 + x428 + x528;
}
else {
   result[19] = x191*(x429 + x546) + x231 + x432 + x536;
}
if (x173) {
   result[20] = x132*(x435 + x48*x547 + x548) - x376*x395 + x440 + x549;
}
else {
   result[20] = x191*(x182*x547 + x441 + x550) + x319 - x384*x400 + x402 + x443;
}
if (x173) {
   result[21] = x132*(x445 + x545) + x219 + x260 + x330 + x377 + x409 + x448 + x51;
}
else {
   result[21] = x185 + x191*(x449 + x546) + x231 + x269 + x338 + x385 + x412 + x451;
}
if (x173) {
   result[22] = x132*(x467 + x48*x552 + 58.201238327072673*x539) + 0.5714285714285714*x357 - x397*x478 + x483;
}
else {
   result[22] = x191*(x182*x552 + x484 + 174.60371498121802*x539) + 0.19047619047619049*x364 - x401*x485 + x488;
}
if (x173) {
   result[23] = x132*(x48*x553 + x490 + x548) - x395*x408 + x497 + x549;
}
else {
   result[23] = x191*(x182*x553 + x498 + x550) - x400*x411 + x402 + x502;
}
if (x173) {
   result[24] = x132*(x505 + x545) + x219 + x509 + x541;
}
else {
   result[24] = x191*(x510 + x546) + x231 + x512 + x542;
}
if (x173) {
   result[25] = x132*(x429 + x48*x560) + 0.1399416909620991*x425 - x427*x513 + x51;
}
else {
   result[25] = x185 + x191*(x182*x560 + 74.830163563379159*x561) + 0.046647230320699715*x430 - x431*x526;
}
if (x173) {
   result[26] = x132*(x48*x564 + 29.100619163536336*x561 + 16.628925236306479*x562) - x224*x439 + x312 - x395*x427 + 0.32653061224489793*x425;
}
else {
   result[26] = x191*(x182*x564 + 87.301857490609009*x561 + 49.886775708919437*x562) - x236*x442 + x319 - x400*x431 + 0.108843537414966*x430;
}
if (x173) {
   result[27] = x132*(x418 + x48*x567 + x566) + x330 + x428 + x568;
}
else {
   result[27] = x191*(x182*x567 + x429 + x569) + x338 + x432 + x570;
}
if (x173) {
   result[28] = x132*(x467 + x48*x573 + 58.201238327072673*x562) + 0.5714285714285714*x425 - x439*x478 + x483;
}
else {
   result[28] = x191*(x182*x573 + x484 + 174.60371498121802*x562) + 0.19047619047619049*x430 - x442*x485 + x488;
}
if (x173) {
   result[29] = x132*(x435 + x48*x574 + x490 + 29.100619163536336*x565) + x312 - x395*x447 + x440 + x497;
}
else {
   result[29] = x191*(x182*x574 + x441 + x498 + 87.301857490609009*x565) - x400*x450 + x443 + x502;
}
if (x173) {
   result[30] = x132*(x48*x575 + x505 + x566) + x260 + x509 + x568;
}
else {
   result[30] = x191*(x182*x575 + x510 + x569) + x269 + x512 + x570;
}
if (x173) {
   result[31] = x132*(x48*x586 + 87.301857490609009*x576) + 1.7142857142857142*x479 - 0.8571428571428571*x481*x86 - 1.7142857142857142*x50;
}
else {
   result[31] = -0.57142857142857151*x184 + x191*(x182*x586 + 261.90557247182704*x576) + 0.57142857142857151*x486 - 0.28571428571428575*x487*x86;
}
if (x173) {
   result[32] = x132*(x467 + x48*x590 + 58.201238327072673*x587) - x478*x496 + x482 + 0.5714285714285714*x494 - 0.48979591836734687*x50;
}
else {
   result[32] = x191*(x182*x590 + x484 + 174.60371498121802*x587) - x485*x500 + x488 + 0.19047619047619049*x499;
}
if (x173) {
   result[33] = x132*(x48*x592 + 16.628925236306479*x587 + 29.100619163536336*x591) - x224*x496 + x312 - x395*x508 + 0.32653061224489793*x494;
}
else {
   result[33] = x191*(x182*x592 + 49.886775708919437*x587 + 87.301857490609009*x591) - x236*x500 - x400*x511 + 0.108843537414966*x499 + x501;
}
if (x173) {
   result[34] = x132*(x48*x593 + x510) + 0.1399416909620991*x494 - x508*x513 + x51;
}
else {
   result[34] = x185 + x191*(x182*x593 + 74.830163563379159*x591) + 0.046647230320699715*x499 - x511*x526;
}
}
        
static double coder_dgdt(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].dmu0dT)(T, P);
    double x1 = n2*(*endmember[1].dmu0dT)(T, P);
    double x2 = n3*(*endmember[2].dmu0dT)(T, P);
    double x3 = n4*(*endmember[3].dmu0dT)(T, P);
    double x4 = n5*(*endmember[4].dmu0dT)(T, P);
    double x5 = n1 + n3;
    double x6 = n4 + n5;
    double x7 = 1.0/(n2 + x5 + x6);
    double x8 = n2*log(n2*x7);
    double x9 = n3*log(n3*x7);
    double x10 = n5*log(n5*x7);
    double x11 = n4*(log(n4*x7) - 0.69314718055994495);
    double x12 = x5*log(x5*x7);
    double x13 = x6*log(x6*x7);
    double x14 = n1 + n2 + n4;
    double x15 = x14*log(x14*x7);
    double x16 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 1.0*n5;
    double x17 = (2.0*n1 + 2.0*n2 + 2.0*n3 + 1.0*n4 + 2.0*n5)*log(x7*(0.5*n4 + x16));
    double x18 = sqrt(1 - 0.19999999999999998*T);
    double x19 = 1.0*x18;
    double x20 = fmin(4, x19);
    double x21 = (4 - x19 >= 0. ? 1. : 0.)/x18;

if (T >= 5.0) {
   result = -13.381349999999999*n2 + x0 + x1 + 8.3144626181532395*x10 + 8.3144626181532395*x11 + 8.3144626181532395*x12 + 8.3144626181532395*x13 + 8.3144626181532395*x15 + 8.3144626181532395*x17 + x2 + x3 + x4 + 8.3144626181532395*x8 + 8.3144626181532395*x9;
}
else {
   result = (3.5*n4 + x16)*(n2*(-20.072025*((x20)*(x20))*x21 + 40.14405*x20 - 0.099999999999999992*x21*(40.14405*T - 200.72024999999999) - 40.14405) + 3*x0 + 3*x1 + 24.943387854459719*x10 + 24.943387854459719*x11 + 24.943387854459719*x12 + 24.943387854459719*x13 + 24.943387854459719*x15 + 24.943387854459719*x17 + 3*x2 + 3*x3 + 3*x4 + 24.943387854459719*x8 + 24.943387854459719*x9)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = n1 + n3;
    double x2 = n4 + n5;
    double x3 = n2 + x1 + x2;
    double x4 = 1.0/x3;
    double x5 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 1.0*n5;
    double x6 = 0.5*n4 + x5;
    double x7 = log(x4*x6);
    double x8 = 16.628925236306479*x7;
    double x9 = 8.3144626181532395*n2;
    double x10 = -x4*x9;
    double x11 = 8.3144626181532395*n3;
    double x12 = -x11*x4;
    double x13 = 8.3144626181532395*n4;
    double x14 = -x13*x4;
    double x15 = 16.628925236306479*n1 + 16.628925236306479*n2 + 16.628925236306479*n3 + 16.628925236306479*n5 + x13;
    double x16 = pow(x3, -2);
    double x17 = -x16*x6;
    double x18 = x3/x6;
    double x19 = x18*(x17 + 1.0*x4);
    double x20 = x15*x19;
    double x21 = x10 + x12 + x14 + x20 + x8;
    double x22 = n1 + n2 + n4;
    double x23 = log(x22*x4);
    double x24 = 8.3144626181532395*n5;
    double x25 = -x24*x4;
    double x26 = 8.3144626181532395*n1;
    double x27 = x13 + x26 + x9;
    double x28 = x3*(-x16*x22 + x4)/x22;
    double x29 = 8.3144626181532395*x23 + x25 + x27*x28;
    double x30 = log(x1*x4);
    double x31 = x13 + x24;
    double x32 = -x31*x4;
    double x33 = x11 + x26;
    double x34 = x3*(-x1*x16 + x4)/x1;
    double x35 = 8.3144626181532395*x30 + x32 + x33*x34;
    double x36 = T >= 5.0;
    double x37 = 3*x0;
    double x38 = 49.886775708919437*x7;
    double x39 = n2*x4;
    double x40 = -24.943387854459719*x39;
    double x41 = n3*x4;
    double x42 = -24.943387854459719*x41;
    double x43 = n4*x4;
    double x44 = -24.943387854459719*x43;
    double x45 = 24.943387854459719*n4;
    double x46 = 49.886775708919437*n1 + 49.886775708919437*n2 + 49.886775708919437*n3 + 49.886775708919437*n5 + x45;
    double x47 = x19*x46;
    double x48 = x38 + x40 + x42 + x44 + x47;
    double x49 = 24.943387854459719*x23;
    double x50 = n5*x4;
    double x51 = -24.943387854459719*x50;
    double x52 = 24.943387854459719*n1;
    double x53 = 24.943387854459719*n2;
    double x54 = x45 + x52 + x53;
    double x55 = x28*x54 + x49 + x51;
    double x56 = 24.943387854459719*x30;
    double x57 = 24.943387854459719*n5;
    double x58 = x45 + x57;
    double x59 = -x4*x58;
    double x60 = 24.943387854459719*n3;
    double x61 = x52 + x60;
    double x62 = x34*x61 + x56 + x59;
    double x63 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x64 = 3.5*n4 + x5;
    double x65 = x63*x64;
    double x66 = (*endmember[1].dmu0dT)(T, P);
    double x67 = 3*x66;
    double x68 = (*endmember[2].dmu0dT)(T, P);
    double x69 = 3*x68;
    double x70 = (*endmember[3].dmu0dT)(T, P);
    double x71 = 3*x70;
    double x72 = (*endmember[4].dmu0dT)(T, P);
    double x73 = 3*x72;
    double x74 = log(x39);
    double x75 = log(x41);
    double x76 = log(x50);
    double x77 = log(x43);
    double x78 = log(x2*x4);
    double x79 = 24.943387854459719*x78;
    double x80 = 24.943387854459719*x7;
    double x81 = sqrt(1 - 0.19999999999999998*T);
    double x82 = 1.0*x81;
    double x83 = fmin(4, x82);
    double x84 = (4 - x82 >= 0. ? 1. : 0.)/x81;
    double x85 = -20.072025*((x83)*(x83))*x84 + 40.14405*x83 - 0.099999999999999992*x84*(40.14405*T - 200.72024999999999) - 40.14405;
    double x86 = n1*x37 + n2*x67 + n2*x85 + n3*x69 + n4*x71 + n5*x73 + x1*x56 + x2*x79 + x22*x49 + x45*(x77 - 0.69314718055994495) + x53*x74 + x57*x76 + x60*x75 + x80*(2.0*n1 + 2.0*n2 + 2.0*n3 + 1.0*n4 + 2.0*n5);
    double x87 = x63*x86;
    double x88 = x64*x86/((0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5)*(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5));
    double x89 = 1.0*x87 - 0.027210884353741499*x88;
    double x90 = -x33*x4;
    double x91 = x3*(-n2*x16 + x4);
    double x92 = x14 + x20 + x8;
    double x93 = x12 + x29;
    double x94 = -x4*x61;
    double x95 = x38 + x44 + x47;
    double x96 = x42 + x55;
    double x97 = -x27*x4;
    double x98 = x3*(-n3*x16 + x4);
    double x99 = -x4*x54;
    double x100 = x3*(-n4*x16 + x4);
    double x101 = x18*(x17 + 0.5*x4);
    double x102 = x3*(-x16*x2 + x4)/x2;
    double x103 = x102*x31 + 8.3144626181532395*x78 + x90;
    double x104 = x102*x58 + x79 + x94;
    double x105 = x3*(-n5*x16 + x4);

if (x36) {
   result[0] = x0 + x21 + x29 + x35;
}
else {
   result[0] = x65*(x37 + x48 + x55 + x62) + x89;
}
if (x36) {
   result[1] = x32 + x66 + 8.3144626181532395*x74 + x90 + 8.3144626181532395*x91 + x92 + x93 - 13.381349999999999;
}
else {
   result[1] = x65*(x59 + x67 + 24.943387854459719*x74 + x85 + 24.943387854459719*x91 + x94 + x95 + x96) + x89;
}
if (x36) {
   result[2] = x10 + x25 + x35 + x68 + 8.3144626181532395*x75 + x92 + x97 + 8.3144626181532395*x98;
}
else {
   result[2] = x65*(x40 + x51 + x62 + x69 + 24.943387854459719*x75 + x95 + 24.943387854459719*x98 + x99) + x89;
}
if (x36) {
   result[3] = x10 + 8.3144626181532395*x100 + x101*x15 + x103 + 8.3144626181532395*x7 + x70 + 8.3144626181532395*x77 + x93 - 5.7631463216439762;
}
else {
   result[3] = x65*(24.943387854459719*x100 + x101*x46 + x104 + x40 + x71 + 24.943387854459719*x77 + x80 + x96 - 17.289438964931929) + 3.5*x87 - 0.095238095238095247*x88;
}
if (x36) {
   result[4] = x103 + 8.3144626181532395*x105 + x21 + x72 + 8.3144626181532395*x76 + x97;
}
else {
   result[4] = x65*(x104 + 24.943387854459719*x105 + x48 + x73 + 24.943387854459719*x76 + x99) + x89;
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n1 + n2 + n4;
    double x1 = 1.0/x0;
    double x2 = n1 + n3;
    double x3 = n4 + n5;
    double x4 = n2 + x2 + x3;
    double x5 = 1.0/x4;
    double x6 = pow(x4, -2);
    double x7 = -x0*x6 + x5;
    double x8 = x1*x7;
    double x9 = 16.628925236306479*x4;
    double x10 = 8.3144626181532395*n1;
    double x11 = 8.3144626181532395*n2;
    double x12 = 8.3144626181532395*n4;
    double x13 = x10 + x11 + x12;
    double x14 = x13*x4;
    double x15 = -2*x6;
    double x16 = pow(x4, -3);
    double x17 = 2*x16;
    double x18 = x0*x17;
    double x19 = x1*(x15 + x18);
    double x20 = x7/((x0)*(x0));
    double x21 = x14*x19 - x14*x20 + x8*x9;
    double x22 = x11*x6;
    double x23 = 8.3144626181532395*n3;
    double x24 = x23*x6;
    double x25 = 8.3144626181532395*n5;
    double x26 = x25*x6;
    double x27 = x13*x8;
    double x28 = x22 + x24 + x26 + x27;
    double x29 = x12 + x25;
    double x30 = x12*x6;
    double x31 = 16.628925236306479*n2;
    double x32 = 16.628925236306479*n3;
    double x33 = 16.628925236306479*n5;
    double x34 = 16.628925236306479*n1 + x12 + x31 + x32 + x33;
    double x35 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 1.0*n5;
    double x36 = 0.5*n4 + x35;
    double x37 = 1.0/x36;
    double x38 = -x36*x6;
    double x39 = x38 + 1.0*x5;
    double x40 = x37*x39;
    double x41 = x34*x40;
    double x42 = x29*x6 + x30 + x41;
    double x43 = x4*x40;
    double x44 = x17*x36;
    double x45 = x37*x4;
    double x46 = x45*(x44 - 2.0*x6);
    double x47 = x4/((x36)*(x36));
    double x48 = x39*x47;
    double x49 = 1.0*x48;
    double x50 = x34*x46 - x34*x49 + 33.257850472612958*x43;
    double x51 = x42 + x50;
    double x52 = x28 + x51;
    double x53 = x10 + x23;
    double x54 = 1.0/x2;
    double x55 = -x2*x6 + x5;
    double x56 = x54*x55;
    double x57 = x53*x56;
    double x58 = x4*x53;
    double x59 = x17*x2;
    double x60 = x54*(x15 + x59);
    double x61 = x55/((x2)*(x2));
    double x62 = x56*x9 + x57 + x58*x60 - x58*x61;
    double x63 = T >= 5.0;
    double x64 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x65 = 3*(*endmember[0].dmu0dT)(T, P);
    double x66 = log(x36*x5);
    double x67 = 49.886775708919437*x66;
    double x68 = 24.943387854459719*n2;
    double x69 = -x5*x68;
    double x70 = 24.943387854459719*n3;
    double x71 = -x5*x70;
    double x72 = 24.943387854459719*n4;
    double x73 = -x5*x72;
    double x74 = 49.886775708919437*n2;
    double x75 = 49.886775708919437*n3;
    double x76 = 49.886775708919437*n5;
    double x77 = 49.886775708919437*n1 + x72 + x74 + x75 + x76;
    double x78 = x40*x77;
    double x79 = x4*x78;
    double x80 = x67 + x69 + x71 + x73 + x79;
    double x81 = 24.943387854459719*log(x0*x5);
    double x82 = 24.943387854459719*n5;
    double x83 = -x5*x82;
    double x84 = 24.943387854459719*n1;
    double x85 = x68 + x72 + x84;
    double x86 = x8*x85;
    double x87 = x4*x86 + x81 + x83;
    double x88 = 24.943387854459719*log(x2*x5);
    double x89 = x72 + x82;
    double x90 = -x5*x89;
    double x91 = x70 + x84;
    double x92 = x56*x91;
    double x93 = x4*x92 + x88 + x90;
    double x94 = x65 + x80 + x87 + x93;
    double x95 = x64*x94;
    double x96 = 49.886775708919437*x4;
    double x97 = x4*x85;
    double x98 = x19*x97 - x20*x97 + x8*x96;
    double x99 = x6*x68;
    double x100 = x6*x70;
    double x101 = x6*x82;
    double x102 = x100 + x101 + x86 + x99;
    double x103 = x6*x72;
    double x104 = x103 + x6*x89 + x78;
    double x105 = 99.773551417838874*x43 + x46*x77 - x49*x77;
    double x106 = x104 + x105;
    double x107 = x102 + x106;
    double x108 = x4*x91;
    double x109 = x108*x60 - x108*x61 + x56*x96 + x92;
    double x110 = 3.5*n4 + x35;
    double x111 = x110*x64;
    double x112 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x113 = pow(x112, -2);
    double x114 = x110*x113;
    double x115 = x114*x94;
    double x116 = 3*(*endmember[1].dmu0dT)(T, P);
    double x117 = 3*(*endmember[2].dmu0dT)(T, P);
    double x118 = 3*(*endmember[3].dmu0dT)(T, P);
    double x119 = 3*(*endmember[4].dmu0dT)(T, P);
    double x120 = log(n2*x5);
    double x121 = log(n3*x5);
    double x122 = log(n5*x5);
    double x123 = log(n4*x5);
    double x124 = 24.943387854459719*log(x3*x5);
    double x125 = 24.943387854459719*x66;
    double x126 = sqrt(1 - 0.19999999999999998*T);
    double x127 = 1.0*x126;
    double x128 = fmin(4, x127);
    double x129 = (4 - x127 >= 0. ? 1. : 0.)/x126;
    double x130 = -20.072025*((x128)*(x128))*x129 + 40.14405*x128 - 0.099999999999999992*x129*(40.14405*T - 200.72024999999999) - 40.14405;
    double x131 = n1*x65 + n2*x116 + n2*x130 + n3*x117 + n4*x118 + n5*x119 + x0*x81 + x120*x68 + x121*x70 + x122*x82 + x124*x3 + x125*(2.0*n1 + 2.0*n2 + 2.0*n3 + 1.0*n4 + 2.0*n5) + x2*x88 + x72*(x123 - 0.69314718055994495);
    double x132 = x113*x131;
    double x133 = x110*x131/((x112)*(x112)*(x112));
    double x134 = -0.054421768707482998*x132 + 0.01554907677356657*x133;
    double x135 = -x6;
    double x136 = x54*(x135 + x59);
    double x137 = x136*x58;
    double x138 = x137 + x57;
    double x139 = -16.628925236306479*x5;
    double x140 = x139 + x21;
    double x141 = x108*x136;
    double x142 = x141 + x92;
    double x143 = -49.886775708919437*x5;
    double x144 = x143 + x98;
    double x145 = -0.027210884353741499*x115 + x134 + 1.0*x95;
    double x146 = -x5*x91;
    double x147 = -n2*x6 + x5;
    double x148 = 24.943387854459719*x4;
    double x149 = x147*x148;
    double x150 = x67 + x73 + x79;
    double x151 = x71 + x87;
    double x152 = x116 + 24.943387854459719*x120 + x130 + x146 + x149 + x150 + x151 + x90;
    double x153 = 1.0*x64;
    double x154 = 0.027210884353741499*x114;
    double x155 = x152*x153 - x152*x154;
    double x156 = x1*(x135 + x18);
    double x157 = x14*x156;
    double x158 = x157 + x28;
    double x159 = x158 + x50;
    double x160 = x156*x97;
    double x161 = x102 + x160;
    double x162 = x105 + x161;
    double x163 = -x5*x85;
    double x164 = -n3*x6 + x5;
    double x165 = x148*x164;
    double x166 = x117 + 24.943387854459719*x121 + x150 + x163 + x165 + x69 + x83 + x93;
    double x167 = x153*x166 - x154*x166;
    double x168 = 24.943387854459719*x5;
    double x169 = -x168;
    double x170 = 0.5*x48;
    double x171 = x38 + 0.5*x5;
    double x172 = x171*x37;
    double x173 = x172*x9;
    double x174 = x45*(x44 - 1.5*x6);
    double x175 = x173 + x174*x34 + 8.3144626181532395*x43;
    double x176 = -x170*x34 + x175;
    double x177 = x21 + x28;
    double x178 = -74.830163563379159*x5;
    double x179 = x172*x96;
    double x180 = x148*x40 + x174*x77 + x179;
    double x181 = -x170*x77 + x180;
    double x182 = x102 + x98;
    double x183 = -n4*x6 + x5;
    double x184 = x148*x183;
    double x185 = x172*x77;
    double x186 = 1.0/x3;
    double x187 = -x3*x6 + x5;
    double x188 = x186*x187;
    double x189 = x188*x89;
    double x190 = x124 + x146 + x189*x4;
    double x191 = x118 + 24.943387854459719*x123 + x125 + x151 + x184 + x185*x4 + x190 + x69 - 17.289438964931929;
    double x192 = -0.19047619047619049*x132 + 0.054421768707482998*x133 + x153*x191 - x154*x191;
    double x193 = x137 + x42 - 33.257850472612958*x5 + x57;
    double x194 = x104 + x141 - 99.773551417838874*x5 + x92;
    double x195 = -n5*x6 + x5;
    double x196 = x148*x195;
    double x197 = x119 + 24.943387854459719*x122 + x163 + x190 + x196 + x80;
    double x198 = x153*x197 - x154*x197;
    double x199 = -16.628925236306479*x6;
    double x200 = x16*x31;
    double x201 = 1.0/n2;
    double x202 = 8.3144626181532395*x4;
    double x203 = x53*x6;
    double x204 = x203 + x24;
    double x205 = x204 - x22 + x27;
    double x206 = 8.3144626181532395*x5;
    double x207 = x26 + x51;
    double x208 = x206 + x207;
    double x209 = x152*x64;
    double x210 = -49.886775708919437*x6;
    double x211 = x16*x74;
    double x212 = x6*x91;
    double x213 = x100 + x212;
    double x214 = x213 + x86 - x99;
    double x215 = x101 + x106;
    double x216 = x168 + x215;
    double x217 = x114*x152;
    double x218 = x169 + x207;
    double x219 = -8.3144626181532395*x6;
    double x220 = x205 + x4*(x200 + x219);
    double x221 = x157 + x218 + x220;
    double x222 = x134 + x167;
    double x223 = x178 + x215;
    double x224 = -24.943387854459719*x6;
    double x225 = x214 + x4*(x211 + x224);
    double x226 = x111*(x160 + x223 + x225) + x155;
    double x227 = x176 + x26;
    double x228 = x101 + x181;
    double x229 = -x24;
    double x230 = x16*x32;
    double x231 = 1.0/n3;
    double x232 = x13*x6 + x22;
    double x233 = x166*x64;
    double x234 = -x100;
    double x235 = x16*x75;
    double x236 = x6*x85 + x99;
    double x237 = x114*x166;
    double x238 = x229 + x232 + x4*(x219 + x230);
    double x239 = x234 + x236 + x4*(x224 + x235);
    double x240 = n4*x16;
    double x241 = 16.628925236306479*x240;
    double x242 = 1.0/n4;
    double x243 = x45*(x44 - 1.0*x6);
    double x244 = x171*x47;
    double x245 = 0.5*x244;
    double x246 = x29*x4;
    double x247 = x186*(x15 + x17*x3);
    double x248 = x187/((x3)*(x3));
    double x249 = x188*x29 + x188*x9 + x246*x247 - x246*x248;
    double x250 = x206 + x249;
    double x251 = x172*x34 + x203 - x30;
    double x252 = 49.886775708919437*x240;
    double x253 = x4*x89;
    double x254 = x188*x96 + x189 + x247*x253 - x248*x253;
    double x255 = x168 + x254;
    double x256 = -x103 + x185 + x212;
    double x257 = 1.0*x244;
    double x258 = x197*x64;
    double x259 = x114*x197;
    double x260 = 1.0/n5;

if (x63) {
   result[0] = x21 + x52 + x62;
}
else {
   result[0] = x111*(x107 + x109 + x98) - 0.054421768707482998*x115 + x134 + 2.0*x95;
}
if (x63) {
   result[1] = x138 + x140 + x52;
}
else {
   result[1] = x111*(x107 + x142 + x144) + x145 + x155;
}
if (x63) {
   result[2] = x139 + x159 + x42 + x62;
}
else {
   result[2] = x111*(x104 + x109 + x143 + x162) + x145 + x167;
}
if (x63) {
   result[3] = x138 + x169 + x176 + x177 + x42;
}
else {
   result[3] = x111*(x104 + x142 + x178 + x181 + x182) - 0.095238095238095247*x115 + x192 + 3.5*x95;
}
if (x63) {
   result[4] = x159 + x193;
}
else {
   result[4] = x111*(x162 + x194) + x145 + x198;
}
if (x63) {
   result[5] = x147*x201*x202 + x205 + x208 + x21 + x4*(x199 + x200);
}
else {
   result[5] = x111*(x149*x201 + x214 + x216 + x4*(x210 + x211) + x98) + x134 + 2.0*x209 - 0.054421768707482998*x217;
}
if (x63) {
   result[6] = x221;
}
else {
   result[6] = x222 + x226;
}
if (x63) {
   result[7] = x140 + x220 + x227 + x42;
}
else {
   result[7] = x111*(x104 + x144 + x225 + x228) + x192 + 3.5*x209 - 0.095238095238095247*x217;
}
if (x63) {
   result[8] = x221;
}
else {
   result[8] = x134 + x198 + x226;
}
if (x63) {
   result[9] = x164*x202*x231 + x208 + x229 + x232 + x4*(x199 + x230) + x62;
}
else {
   result[9] = x111*(x109 + x165*x231 + x216 + x234 + x236 + x4*(x210 + x235)) + x134 + 2.0*x233 - 0.054421768707482998*x237;
}
if (x63) {
   result[10] = x193 + x227 + x238;
}
else {
   result[10] = x111*(x194 + x228 + x239) + x192 + 3.5*x233 - 0.095238095238095247*x237;
}
if (x63) {
   result[11] = x138 + x218 + x238;
}
else {
   result[11] = x111*(x142 + x223 + x239) + x198 + x222;
}
if (x63) {
   result[12] = x173 + x177 + x183*x202*x242 + x243*x34 - x245*x34 + x250 + x251 + x4*(x199 + x241);
}
else {
   result[12] = x111*(x179 + x182 + x184*x242 + x243*x77 - x245*x77 + x255 + x256 + x4*(x210 + x252)) - 0.19047619047619049*x114*x191 - 0.66666666666666674*x132 + 0.19047619047619049*x133 + 7.0*x191*x64;
}
if (x63) {
   result[13] = x139 + x158 + x175 + x249 + x251 - x257*x34 + x4*(x219 + x241);
}
else {
   result[13] = x111*(x143 + x161 + x180 + x254 + x256 - x257*x77 + x4*(x224 + x252)) + x192 + 3.5*x258 - 0.095238095238095247*x259;
}
if (x63) {
   result[14] = x195*x202*x260 + x204 + x232 + x250 - x26 + x30 + x4*(x16*x33 + x199) + x41 + x50;
}
else {
   result[14] = x111*(-x101 + x103 + x105 + x196*x260 + x213 + x236 + x255 + x4*(x16*x76 + x210) + x78) + x134 + 2.0*x258 - 0.054421768707482998*x259;
}
}
        
static void coder_d4gdn3dt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = 8.3144626181532395*n4;
    double x1 = 8.3144626181532395*n5 + x0;
    double x2 = n1 + n3;
    double x3 = n4 + n5;
    double x4 = n2 + x2 + x3;
    double x5 = pow(x4, -3);
    double x6 = 2*x5;
    double x7 = 16.628925236306479*x5;
    double x8 = -n4*x7;
    double x9 = -x1*x6 + x8;
    double x10 = 16.628925236306479*n2;
    double x11 = -x10*x5;
    double x12 = 16.628925236306479*n3;
    double x13 = -x12*x5;
    double x14 = 16.628925236306479*n5;
    double x15 = -x14*x5;
    double x16 = x11 + x13 + x15;
    double x17 = n1 + n2 + n4;
    double x18 = 1.0/x17;
    double x19 = 1.0/x4;
    double x20 = pow(x4, -2);
    double x21 = -x17*x20 + x19;
    double x22 = x18*x21;
    double x23 = 24.943387854459719*x22;
    double x24 = 8.3144626181532395*n1;
    double x25 = 8.3144626181532395*n2 + x0 + x24;
    double x26 = pow(x17, -2);
    double x27 = x21*x26;
    double x28 = x25*x27;
    double x29 = -2*x20;
    double x30 = x17*x6;
    double x31 = x29 + x30;
    double x32 = x18*x25;
    double x33 = x31*x32;
    double x34 = 24.943387854459719*x4;
    double x35 = x18*x31;
    double x36 = 6*x5;
    double x37 = pow(x4, -4);
    double x38 = 6*x37;
    double x39 = -x17*x38;
    double x40 = x4*(x36 + x39);
    double x41 = 2*x4;
    double x42 = x25*x41;
    double x43 = x26*x31;
    double x44 = x21/((x17)*(x17)*(x17));
    double x45 = x23 - x27*x34 - 2*x28 + x32*x40 + 2*x33 + x34*x35 - x42*x43 + x42*x44;
    double x46 = x16 + x45;
    double x47 = x46 + x9;
    double x48 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 1.0*n5;
    double x49 = 0.5*n4 + x48;
    double x50 = 1.0/x49;
    double x51 = -x20*x49;
    double x52 = 1.0*x19 + x51;
    double x53 = x50*x52;
    double x54 = 49.886775708919437*x53;
    double x55 = x49*x6;
    double x56 = -2.0*x20 + x55;
    double x57 = 16.628925236306479*n1 + x0 + x10 + x12 + x14;
    double x58 = x50*x57;
    double x59 = x56*x58;
    double x60 = 49.886775708919437*x4;
    double x61 = x50*x56;
    double x62 = pow(x49, -2);
    double x63 = x52*x62;
    double x64 = 2.0*x57;
    double x65 = -x60*x63;
    double x66 = -x38*x49;
    double x67 = x4*(6.0*x5 + x66);
    double x68 = x4*x64;
    double x69 = pow(x49, -3);
    double x70 = x52*x69;
    double x71 = x56*x62;
    double x72 = x54 + x58*x67 + 2*x59 + x60*x61 - x63*x64 + x65 + x68*x70 - x68*x71;
    double x73 = 1.0/x2;
    double x74 = x19 - x2*x20;
    double x75 = x73*x74;
    double x76 = 24.943387854459719*x75;
    double x77 = 8.3144626181532395*n3 + x24;
    double x78 = pow(x2, -2);
    double x79 = x74*x78;
    double x80 = x77*x79;
    double x81 = x2*x6;
    double x82 = x29 + x81;
    double x83 = x73*x77;
    double x84 = x82*x83;
    double x85 = x73*x82;
    double x86 = -x2*x38;
    double x87 = x4*(x36 + x86);
    double x88 = x41*x77;
    double x89 = x78*x82;
    double x90 = x74/((x2)*(x2)*(x2));
    double x91 = -x34*x79 + x34*x85 + x76 - 2*x80 + x83*x87 + 2*x84 - x88*x89 + x88*x90;
    double x92 = x72 + x91;
    double x93 = T >= 5.0;
    double x94 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x95 = 49.886775708919437*x22;
    double x96 = 24.943387854459719*n1;
    double x97 = 24.943387854459719*n2;
    double x98 = 24.943387854459719*n4;
    double x99 = x96 + x97 + x98;
    double x100 = x18*x99;
    double x101 = x100*x31;
    double x102 = x27*x99;
    double x103 = x101*x4 - x102*x4 + x4*x95;
    double x104 = x20*x97;
    double x105 = 24.943387854459719*n3;
    double x106 = x105*x20;
    double x107 = 24.943387854459719*n5;
    double x108 = x107*x20;
    double x109 = x22*x99;
    double x110 = x104 + x106 + x108 + x109;
    double x111 = x107 + x98;
    double x112 = x20*x98;
    double x113 = 49.886775708919437*n2;
    double x114 = 49.886775708919437*n3;
    double x115 = 49.886775708919437*n5;
    double x116 = 49.886775708919437*n1 + x113 + x114 + x115 + x98;
    double x117 = x116*x53;
    double x118 = x111*x20 + x112 + x117;
    double x119 = 99.773551417838874*x4;
    double x120 = x116*x50;
    double x121 = x120*x56;
    double x122 = x116*x63;
    double x123 = 1.0*x122;
    double x124 = x119*x53 + x121*x4 - x123*x4;
    double x125 = x118 + x124;
    double x126 = x110 + x125;
    double x127 = x105 + x96;
    double x128 = x127*x75;
    double x129 = 49.886775708919437*x75;
    double x130 = x127*x73;
    double x131 = x130*x82;
    double x132 = x127*x79;
    double x133 = x128 + x129*x4 + x131*x4 - x132*x4;
    double x134 = x103 + x126 + x133;
    double x135 = x134*x94;
    double x136 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x137 = pow(x136, -2);
    double x138 = 3*(*endmember[0].dmu0dT)(T, P);
    double x139 = log(x19*x49);
    double x140 = 49.886775708919437*x139;
    double x141 = -x19*x97;
    double x142 = -x105*x19;
    double x143 = -x19*x98;
    double x144 = x117*x4;
    double x145 = x140 + x141 + x142 + x143 + x144;
    double x146 = 24.943387854459719*log(x17*x19);
    double x147 = -x107*x19;
    double x148 = x109*x4 + x146 + x147;
    double x149 = 24.943387854459719*log(x19*x2);
    double x150 = -x111*x19;
    double x151 = x128*x4 + x149 + x150;
    double x152 = x138 + x145 + x148 + x151;
    double x153 = x137*x152;
    double x154 = 49.886775708919437*x5;
    double x155 = n4*x154;
    double x156 = -x155;
    double x157 = -x111*x6 + x156;
    double x158 = x113*x5;
    double x159 = -x158;
    double x160 = x114*x5;
    double x161 = -x160;
    double x162 = x115*x5;
    double x163 = -x162;
    double x164 = x159 + x161 + x163;
    double x165 = 74.830163563379159*x4;
    double x166 = x41*x99;
    double x167 = x100*x40 + 2*x101 - 2*x102 - x165*x27 + x165*x35 - x166*x43 + x166*x44 + 74.830163563379159*x22;
    double x168 = x164 + x167;
    double x169 = x157 + x168;
    double x170 = 149.66032712675832*x4;
    double x171 = 2.0*x116;
    double x172 = x171*x4;
    double x173 = x120*x67 + 2*x121 - 2.0*x122 + x170*x61 - x170*x63 + x172*x70 - x172*x71 + 149.66032712675832*x53;
    double x174 = x127*x41;
    double x175 = x130*x87 + 2*x131 - 2*x132 - x165*x79 + x165*x85 - x174*x89 + x174*x90 + 74.830163563379159*x75;
    double x176 = x173 + x175;
    double x177 = 3.5*n4 + x48;
    double x178 = x177*x94;
    double x179 = pow(x136, -3);
    double x180 = x177*x179;
    double x181 = x152*x180;
    double x182 = x137*x177;
    double x183 = x134*x182;
    double x184 = 3*(*endmember[1].dmu0dT)(T, P);
    double x185 = 3*(*endmember[2].dmu0dT)(T, P);
    double x186 = 3*(*endmember[3].dmu0dT)(T, P);
    double x187 = 3*(*endmember[4].dmu0dT)(T, P);
    double x188 = log(n2*x19);
    double x189 = log(n3*x19);
    double x190 = log(n5*x19);
    double x191 = log(n4*x19);
    double x192 = 24.943387854459719*log(x19*x3);
    double x193 = 24.943387854459719*x139;
    double x194 = sqrt(1 - 0.19999999999999998*T);
    double x195 = 1.0*x194;
    double x196 = fmin(4, x195);
    double x197 = (4 - x195 >= 0. ? 1. : 0.)/x194;
    double x198 = -20.072025*((x196)*(x196))*x197 + 40.14405*x196 - 0.099999999999999992*x197*(40.14405*T - 200.72024999999999) - 40.14405;
    double x199 = n1*x138 + n2*x184 + n2*x198 + n3*x185 + n4*x186 + n5*x187 + x105*x189 + x107*x190 + x146*x17 + x149*x2 + x188*x97 + x192*x3 + x193*(2.0*n1 + 2.0*n2 + 2.0*n3 + 1.0*n4 + 2.0*n5) + x98*(x191 - 0.69314718055994495);
    double x200 = x179*x199;
    double x201 = x177*x199/((x136)*(x136)*(x136)*(x136));
    double x202 = 0.046647230320699715*x200 - 0.013327780091628489*x201;
    double x203 = 8.3144626181532395*x20;
    double x204 = -x20;
    double x205 = x204 + x81;
    double x206 = x205*x4;
    double x207 = x206*x73;
    double x208 = x205*x83;
    double x209 = 4*x5;
    double x210 = x4*(x209 + x86);
    double x211 = x206*x78;
    double x212 = x208 + x210*x83 - x211*x77 - x80 + x84;
    double x213 = 16.628925236306479*x207 + x212 + 16.628925236306479*x75;
    double x214 = x213 + x72;
    double x215 = 24.943387854459719*x20;
    double x216 = x205*x73;
    double x217 = x130*x205;
    double x218 = -x127*x211 + x130*x210 + x131 - x132 + x217;
    double x219 = x129 + x216*x60 + x218;
    double x220 = x173 + x219;
    double x221 = x217*x4;
    double x222 = x128 + x221;
    double x223 = -49.886775708919437*x19;
    double x224 = x103 + x223;
    double x225 = x126 + x222 + x224;
    double x226 = 2.0*x94;
    double x227 = 0.054421768707482998*x137;
    double x228 = x177*x227;
    double x229 = x202 + x225*x226 - x225*x228;
    double x230 = -x127*x19;
    double x231 = -n2*x20 + x19;
    double x232 = x231*x34;
    double x233 = x140 + x143 + x144;
    double x234 = x142 + x148;
    double x235 = x150 + x184 + 24.943387854459719*x188 + x198 + x230 + x232 + x233 + x234;
    double x236 = 0.01554907677356657*x180;
    double x237 = -x227*x235 + x235*x236;
    double x238 = 1.0*x135 - 0.108843537414966*x153 + 0.031098153547133141*x181 - 0.027210884353741499*x183;
    double x239 = x204 + x30;
    double x240 = x239*x32;
    double x241 = x4*(x209 + x39);
    double x242 = x239*x4;
    double x243 = x242*x26;
    double x244 = x240 + x241*x32 - x243*x25 - x28 + x33;
    double x245 = x16 + x244;
    double x246 = x18*x242;
    double x247 = 16.628925236306479*x22 + 16.628925236306479*x246;
    double x248 = x245 + x247;
    double x249 = x248 + x9;
    double x250 = x100*x239;
    double x251 = x100*x241 + x101 - x102 - x243*x99 + x250;
    double x252 = x164 + x251;
    double x253 = x18*x239;
    double x254 = x253*x60 + x95;
    double x255 = x252 + x254;
    double x256 = x157 + x255;
    double x257 = x202 + x238;
    double x258 = x250*x4;
    double x259 = x110 + x258;
    double x260 = x124 + x259;
    double x261 = x118 + x133 + x223 + x260;
    double x262 = x226*x261 - x228*x261;
    double x263 = -x19*x99;
    double x264 = -n3*x20 + x19;
    double x265 = x264*x34;
    double x266 = x141 + x147 + x151 + x185 + 24.943387854459719*x189 + x233 + x263 + x265;
    double x267 = -x227*x266 + x236*x266;
    double x268 = 16.628925236306479*x20;
    double x269 = x4*x57;
    double x270 = 1.0*x269;
    double x271 = -1.5*x20 + x55;
    double x272 = x271*x62;
    double x273 = -x270*x272;
    double x274 = -x34*x63;
    double x275 = x271*x58;
    double x276 = x57*x63;
    double x277 = 0.5*x71;
    double x278 = 8.3144626181532395*x4;
    double x279 = x271*x50;
    double x280 = 33.257850472612958*x4;
    double x281 = x4*(5.0*x5 + x66);
    double x282 = x278*x61 + x279*x280 + x281*x58;
    double x283 = -x269*x277 + x270*x70 + x275 - 1.5*x276 + x282 + x59;
    double x284 = x273 + x274 + x283 + 41.572313090766201*x53;
    double x285 = -74.830163563379159*x19;
    double x286 = 0.5*x4;
    double x287 = 0.5*x19 + x51;
    double x288 = x287*x50;
    double x289 = 49.886775708919437*x288;
    double x290 = x289*x4;
    double x291 = x120*x271;
    double x292 = x290 + x291*x4 + x34*x53;
    double x293 = -x122*x286 + x292;
    double x294 = x103 + x110;
    double x295 = x118 + x222 + x285 + x293 + x294;
    double x296 = 49.886775708919437*x20;
    double x297 = x116*x4;
    double x298 = 1.0*x297;
    double x299 = -x272*x298;
    double x300 = x119*x279 + x120*x281 + x34*x61;
    double x301 = x121 - 1.5*x122 - x277*x297 + x291 + x298*x70 + x300;
    double x302 = -x165*x63 + x299 + x301 + 124.71693927229859*x53;
    double x303 = -n4*x20 + x19;
    double x304 = x303*x34;
    double x305 = x120*x287;
    double x306 = 1.0/x3;
    double x307 = x19 - x20*x3;
    double x308 = x306*x307;
    double x309 = x111*x308;
    double x310 = x192 + x230 + x309*x4;
    double x311 = x141 + x186 + 24.943387854459719*x191 + x193 + x234 + x304 + x305*x4 + x310 - 17.289438964931929;
    double x312 = 0.16326530612244899*x200 - x227*x311 + x236*x311;
    double x313 = -0.046647230320699715*x201 + x312;
    double x314 = x118 + x128 - 99.773551417838874*x19 + x221;
    double x315 = x260 + x314;
    double x316 = x226*x315 - x228*x315;
    double x317 = -n5*x20 + x19;
    double x318 = x317*x34;
    double x319 = x145 + x187 + 24.943387854459719*x190 + x263 + x310 + x318;
    double x320 = -x227*x319 + x236*x319;
    double x321 = x215 + x72;
    double x322 = x4*(x6 + x86);
    double x323 = 2*x208 + x322*x83 + x9;
    double x324 = x323 + x46;
    double x325 = 74.830163563379159*x20;
    double x326 = x173 + x325;
    double x327 = x130*x322 + x157 + 2*x217;
    double x328 = x168 + x327;
    double x329 = -0.054421768707482998*x153 + 0.01554907677356657*x181;
    double x330 = -x296;
    double x331 = 1.0/n2;
    double x332 = x127*x20;
    double x333 = x106 + x332;
    double x334 = -x104 + x109 + x333;
    double x335 = 24.943387854459719*x19;
    double x336 = x108 + x125;
    double x337 = x335 + x336;
    double x338 = x103 + x232*x331 + x334 + x337 + x4*(x158 + x330);
    double x339 = 1.0*x94;
    double x340 = x137*x235;
    double x341 = x180*x235;
    double x342 = 0.027210884353741499*x182;
    double x343 = x338*x339 - x338*x342 - 0.108843537414966*x340 + 0.031098153547133141*x341;
    double x344 = x202 + x329;
    double x345 = x261*x339 - x261*x342 + x267 + x344;
    double x346 = x285 + x336;
    double x347 = -x215;
    double x348 = x334 + x4*(x158 + x347);
    double x349 = x258 + x346 + x348;
    double x350 = x225*x339 - x225*x342 + x237 + x339*x349 - x342*x349;
    double x351 = 33.257850472612958*x20;
    double x352 = x284 + x351;
    double x353 = 3.5*x94;
    double x354 = 99.773551417838874*x20;
    double x355 = x302 + x354;
    double x356 = 0.095238095238095247*x182;
    double x357 = x108 + x293;
    double x358 = x118 + x224 + x348 + x357;
    double x359 = x339*x358 - 0.19047619047619049*x340 + 0.054421768707482998*x341 - x342*x358;
    double x360 = -0.19047619047619049*x153 + 0.054421768707482998*x181 + x295*x339 - x295*x342;
    double x361 = x313 + x360;
    double x362 = x351 + x72;
    double x363 = x323 + x362;
    double x364 = x173 + x354;
    double x365 = x327 + x364;
    double x366 = x315*x339 - x315*x342;
    double x367 = 2*x240;
    double x368 = x4*(x39 + x6);
    double x369 = x32*x368;
    double x370 = x16 + x367 + x369;
    double x371 = x370 + x72;
    double x372 = x371 + x9;
    double x373 = 2*x250;
    double x374 = x100*x368;
    double x375 = x164 + x373 + x374;
    double x376 = x173 + x375;
    double x377 = x157 + x376;
    double x378 = -x106;
    double x379 = 1.0/n3;
    double x380 = x104 + x20*x99;
    double x381 = x133 + x265*x379 + x337 + x378 + x380 + x4*(x160 + x330);
    double x382 = x137*x266;
    double x383 = x180*x266;
    double x384 = x339*x381 - x342*x381 - 0.108843537414966*x382 + 0.031098153547133141*x383;
    double x385 = x213 + x351;
    double x386 = 8.3144626181532395*x22 + 8.3144626181532395*x246;
    double x387 = x219 + x354;
    double x388 = x23 + x253*x34;
    double x389 = x378 + x380 + x4*(x160 + x347);
    double x390 = x314 + x357 + x389;
    double x391 = x339*x390 - x342*x390 - 0.19047619047619049*x382 + 0.054421768707482998*x383;
    double x392 = x222 + x346 + x389;
    double x393 = x320 + x339*x392 - x342*x392;
    double x394 = 41.572313090766201*x20 + x323;
    double x395 = x273 + 16.628925236306479*x288;
    double x396 = x287*x62;
    double x397 = 0.5*x269;
    double x398 = 2*x275 - x278*x63;
    double x399 = 16.628925236306479*x4;
    double x400 = -1.0*x20 + x55;
    double x401 = x400*x50;
    double x402 = x4*(4.0*x5 + x66);
    double x403 = x279*x399 + x399*x401 + x402*x58;
    double x404 = -1.0*x276 - x278*x396 + x397*x70 + x398 + x403 + 16.628925236306479*x53;
    double x405 = x395 + x404;
    double x406 = 7.0*x94;
    double x407 = 124.71693927229859*x20 + x327;
    double x408 = x289 + x299;
    double x409 = -x34*x396;
    double x410 = x116*x286;
    double x411 = x274 + 2*x291;
    double x412 = x120*x402 + x279*x60 + x401*x60;
    double x413 = -x123 + x409 + x410*x70 + x411 + x412 + x54;
    double x414 = x408 + x413;
    double x415 = 0.19047619047619049*x182;
    double x416 = 1.0/n4;
    double x417 = x120*x400;
    double x418 = x396*x4;
    double x419 = x111*x4;
    double x420 = x29 + x3*x6;
    double x421 = x306*x420;
    double x422 = pow(x3, -2);
    double x423 = x307*x422;
    double x424 = x308*x60 + x309 + x419*x421 - x419*x423;
    double x425 = x335 + x424;
    double x426 = -x112 + x305 + x332;
    double x427 = -0.5*x116*x418 + x290 + x294 + x304*x416 + x4*x417 + x4*(x155 + x330) + x425 + x426;
    double x428 = x137*x311;
    double x429 = x180*x311;
    double x430 = 0.57142857142857151*x200 - 0.16326530612244899*x201 + x339*x427 - x342*x427 - 0.38095238095238099*x428 + 0.108843537414966*x429;
    double x431 = 24.943387854459719*x53;
    double x432 = x283 - x396*x399 - x399*x63 + x431;
    double x433 = x394 + x432;
    double x434 = x301 - x396*x60 + 74.830163563379159*x53 + x65;
    double x435 = x407 + x434;
    double x436 = 1.0*x396;
    double x437 = x116*x436;
    double x438 = x223 + x259 + x292 - x4*x437 + x4*(x155 + x347) + x424 + x426;
    double x439 = x137*x319;
    double x440 = x180*x319;
    double x441 = -0.046647230320699708*x201 + x312;
    double x442 = x339*x438 - x342*x438 - 0.19047619047619049*x439 + 0.054421768707482998*x440 + x441;
    double x443 = 49.886775708919444*x20;
    double x444 = x323 + x443;
    double x445 = 149.66032712675832*x20 + x327;
    double x446 = 1.0/n5;
    double x447 = -x108 + x112 + x117 + x124 + x318*x446 + x333 + x380 + x4*(x162 + x330) + x425;
    double x448 = x339*x447 - x342*x447 - 0.108843537414966*x439 + 0.031098153547133141*x440;
    double x449 = -x113*x37;
    double x450 = n2*x6;
    double x451 = x331*(x29 + x450);
    double x452 = pow(n2, -2);
    double x453 = x231*x331;
    double x454 = 33.257850472612958*x5;
    double x455 = x15 + x9;
    double x456 = -x6*x77;
    double x457 = x13 + x456;
    double x458 = n2*x454 + x455 + x457;
    double x459 = 8.3144626181532395*x453 + x458;
    double x460 = -x351;
    double x461 = x460 + x72;
    double x462 = 3.0*x94;
    double x463 = 149.66032712675832*x5;
    double x464 = 149.66032712675832*x37;
    double x465 = -n2*x464;
    double x466 = 99.773551417838874*x5;
    double x467 = x157 + x163;
    double x468 = -x127*x6;
    double x469 = x161 + x468;
    double x470 = n2*x466 + x467 + x469;
    double x471 = 24.943387854459719*x453 + x470;
    double x472 = -x354;
    double x473 = x173 + x472;
    double x474 = 0.081632653061224497*x182;
    double x475 = -x203;
    double x476 = x475 + x72;
    double x477 = x244 + x247;
    double x478 = x331*(x204 + x450);
    double x479 = x278*x478 + x4*(x449 + x454) + x459;
    double x480 = x476 + x477 + x479;
    double x481 = x202 + x267;
    double x482 = x226*x349 - x228*x349;
    double x483 = x481 + x482;
    double x484 = x173 + x347;
    double x485 = x251 + x254;
    double x486 = x34*x478 + x4*(x465 + x466) + x471;
    double x487 = x178*(x484 + x485 + x486) + x343;
    double x488 = x202 + x482;
    double x489 = x4*(x449 + x7) + x458;
    double x490 = x362 + x367 + x369 + x489;
    double x491 = x4*(x154 + x465) + x470;
    double x492 = x178*(x364 + x373 + x374 + x491) + x237;
    double x493 = x488 + x492;
    double x494 = x349*x353 - x349*x356 + x359;
    double x495 = x215 + x489;
    double x496 = x325 + x491;
    double x497 = -x114*x37;
    double x498 = n3*x6;
    double x499 = x379*(x29 + x498);
    double x500 = pow(n3, -2);
    double x501 = x264*x379;
    double x502 = x11 - x25*x6;
    double x503 = n3*x454 + x502;
    double x504 = x455 + 8.3144626181532395*x501 + x503;
    double x505 = -n3*x464;
    double x506 = x159 - x6*x99;
    double x507 = n3*x466 + x506;
    double x508 = x467 + 24.943387854459719*x501 + x507;
    double x509 = x379*(x204 + x498);
    double x510 = x213 + x278*x509 + x4*(x454 + x497) + x504;
    double x511 = x219 + x34*x509 + x4*(x466 + x505) + x508;
    double x512 = x226*x392 - x228*x392;
    double x513 = x15 + x4*(x497 + x7) + x503;
    double x514 = x395 + x513;
    double x515 = x163 + x4*(x154 + x505) + x507;
    double x516 = x408 + x515;
    double x517 = -49.886775708919437*n4*x37;
    double x518 = x400*x58;
    double x519 = n4*x6;
    double x520 = x416*(x29 + x519);
    double x521 = pow(n4, -2);
    double x522 = x4*(3.0*x5 + x66);
    double x523 = x287*x69;
    double x524 = 2*x1;
    double x525 = x306*(-x3*x38 + x36);
    double x526 = x4*x524;
    double x527 = x420*x422;
    double x528 = x307/((x3)*(x3)*(x3));
    double x529 = x1*x4*x525 + 24.943387854459719*x308 + x34*x421 - x34*x423 + x421*x524 - x423*x524 - x526*x527 + x526*x528;
    double x530 = n4*x454 + x456 + x529;
    double x531 = x303*x416;
    double x532 = x400*x62;
    double x533 = -x270*x532 + 8.3144626181532395*x531;
    double x534 = -n4*x464;
    double x535 = 2*x111;
    double x536 = 2*x419;
    double x537 = x165*x421 - x165*x423 + 74.830163563379159*x308 + x419*x525 + x421*x535 - x423*x535 - x527*x536 + x528*x536;
    double x538 = n4*x466 + x468 + x537;
    double x539 = -x298*x532 + 24.943387854459719*x531;
    double x540 = x416*(x204 + x519);
    double x541 = 1.5*x396;
    double x542 = 33.257850472612958*x288 + x530;
    double x543 = 99.773551417838874*x288 + x538;
    double x544 = x317*x446;
    double x545 = x446*(n5*x6 + x29);
    double x546 = pow(n5, -2);

if (x93) {
   result[0] = x47 + x92;
}
else {
   result[0] = 3.0*x135 - 0.16326530612244899*x153 + x178*(x169 + x176) + 0.046647230320699715*x181 - 0.081632653061224497*x183 + x202;
}
if (x93) {
   result[1] = x203 + x214 + x47;
}
else {
   result[1] = x178*(x169 + x215 + x220) + x229 + x237 + x238;
}
if (x93) {
   result[2] = x203 + x249 + x92;
}
else {
   result[2] = x178*(x176 + x215 + x256) + x257 + x262 + x267;
}
if (x93) {
   result[3] = x213 + x268 + x284 + x47;
}
else {
   result[3] = 3.5*x135 - 0.38095238095238099*x153 + x178*(x169 + x219 + x296 + x302) + 0.108843537414966*x181 - 0.095238095238095247*x183 + x226*x295 - x228*x295 + x313;
}
if (x93) {
   result[4] = x214 + x249 + x268;
}
else {
   result[4] = x178*(x220 + x256 + x296) + x257 + x316 + x320;
}
if (x93) {
   result[5] = x321 + x324;
}
else {
   result[5] = x178*(x326 + x328) + x229 + x329 + x343;
}
if (x93) {
   result[6] = 8.3144626181532395*x207 + x212 + x249 + x321 + 8.3144626181532395*x75;
}
else {
   result[6] = x178*(x216*x34 + x218 + x256 + x326 + x76) + x345 + x350;
}
if (x93) {
   result[7] = x324 + x352;
}
else {
   result[7] = x178*(x328 + x355) + x225*x353 - x225*x356 + x359 + x361;
}
if (x93) {
   result[8] = x248 + x363;
}
else {
   result[8] = x178*(x255 + x365) + x320 + x344 + x350 + x366;
}
if (x93) {
   result[9] = x215 + x372 + x91;
}
else {
   result[9] = x178*(x175 + x325 + x377) + x262 + x344 + x384;
}
if (x93) {
   result[10] = x245 + x284 + x385 + x386 + x9;
}
else {
   result[10] = x178*(x157 + x252 + x302 + x387 + x388) + x261*x353 - x261*x356 + x361 + x391;
}
if (x93) {
   result[11] = x372 + x385;
}
else {
   result[11] = x178*(x377 + x387) + x345 + x366 + x393;
}
if (x93) {
   result[12] = x394 + x405 + x46;
}
else {
   result[12] = -0.66666666666666674*x153 + x178*(x168 + x407 + x414) + 0.19047619047619049*x181 + x295*x406 - x295*x415 + x430;
}
if (x93) {
   result[13] = x248 + x395 + x433;
}
else {
   result[13] = x178*(x255 + x408 + x435) + x315*x353 - x315*x356 + x360 + x442;
}
if (x93) {
   result[14] = x371 + x444;
}
else {
   result[14] = x178*(x376 + x445) + x316 + x344 + x448;
}
if (x93) {
   result[15] = -x231*x278*x452 + x278*x451 + x4*(x154 + x449) + x45 + x459 + x461;
}
else {
   result[15] = x178*(x167 - x232*x452 + x34*x451 + x4*(x463 + x465) + x471 + x473) + x202 + x338*x462 - x338*x474 - 0.16326530612244899*x340 + 0.046647230320699715*x341;
}
if (x93) {
   result[16] = x480;
}
else {
   result[16] = x483 + x487;
}
if (x93) {
   result[17] = x284 + x45 + x475 + x479;
}
else {
   result[17] = x178*(x167 + x302 + x347 + x486) + x226*x358 - x228*x358 + x313 + x338*x353 - x338*x356 - 0.38095238095238099*x340 + 0.108843537414966*x341;
}
if (x93) {
   result[18] = x480;
}
else {
   result[18] = x320 + x487 + x488;
}
if (x93) {
   result[19] = x490;
}
else {
   result[19] = x384 + x493;
}
if (x93) {
   result[20] = x244 + x352 + x386 + x489;
}
else {
   result[20] = x178*(x251 + x355 + x388 + x491) + x313 + x391 + x494;
}
if (x93) {
   result[21] = x490;
}
else {
   result[21] = x393 + x483 + x492;
}
if (x93) {
   result[22] = x405 + x45 + x495;
}
else {
   result[22] = x178*(x167 + x414 + x496) - 0.66666666666666674*x340 + 0.19047619047619049*x341 + x358*x406 - x358*x415 + x430;
}
if (x93) {
   result[23] = x395 + x432 + x477 + x495;
}
else {
   result[23] = x178*(x408 + x434 + x485 + x496) + x442 + x494;
}
if (x93) {
   result[24] = x490;
}
else {
   result[24] = x448 + x493;
}
if (x93) {
   result[25] = -x264*x278*x500 + x278*x499 + x4*(x154 + x497) + x461 + x504 + x91;
}
else {
   result[25] = x178*(x175 - x265*x500 + x34*x499 + x4*(x463 + x505) + x473 + x508) + x202 + x381*x462 - x381*x474 - 0.16326530612244899*x382 + 0.046647230320699715*x383;
}
if (x93) {
   result[26] = x284 + x510;
}
else {
   result[26] = x178*(x302 + x511) + x226*x390 - x228*x390 + x313 + x353*x381 - x356*x381 - 0.38095238095238099*x382 + 0.108843537414966*x383;
}
if (x93) {
   result[27] = x476 + x510;
}
else {
   result[27] = x178*(x484 + x511) + x202 + x320 + x384 + x512;
}
if (x93) {
   result[28] = x404 + x444 + x514;
}
else {
   result[28] = x178*(x413 + x445 + x516) - 0.66666666666666674*x382 + 0.19047619047619049*x383 + x390*x406 - x390*x415 + x430;
}
if (x93) {
   result[29] = x433 + x514;
}
else {
   result[29] = x178*(x435 + x516) + x353*x392 - x356*x392 + x391 + x442;
}
if (x93) {
   result[30] = x363 + x513;
}
else {
   result[30] = x178*(x365 + x515) + x448 + x481 + x512;
}
if (x93) {
   result[31] = -x278*x303*x521 + x278*x520 + 24.943387854459719*x288 + x34*x401 + x397*x523 + x4*(x154 + x517) - 12.471693927229859*x418 - x436*x57 + x46 + x460 + 2*x518 + x522*x58 + x530 + x533;
}
else {
   result[31] = x178*(x120*x522 + x165*x401 + x168 + 74.830163563379159*x288 - x304*x521 + x34*x520 + x4*(x463 + x534) + x410*x523 + 2*x417 - 37.41508178168958*x418 - x437 + x472 + x538 + x539) - 0.28571428571428575*x182*x427 + 2.0*x200 - 0.57142857142857151*x201 + 10.5*x427*x94 - 2.0*x428 + 0.57142857142857151*x429;
}
if (x93) {
   result[32] = x248 - x268 + x270*x523 - x272*x397 + x275 + x278*x540 + x4*(x454 + x517) + x403 + x409 + x518 + x533 - x541*x57 + x542;
}
else {
   result[32] = x178*(-x116*x541 - x165*x396 + x255 - x272*x410 + x291 + x298*x523 + x34*x540 + x4*(x466 + x534) + x412 + x417 - x443 + x539 + x543) + x406*x438 - x415*x438 + x430 - 0.66666666666666674*x439 + 0.19047619047619049*x440;
}
if (x93) {
   result[33] = x268 - x272*x68 - x280*x396 + x282 + x370 - x396*x64 + x398 + x4*(x517 + x7) + x523*x68 + 8.3144626181532395*x53 + x542;
}
else {
   result[33] = x178*(-x119*x396 - x171*x396 - x172*x272 + x172*x523 + x296 + x300 + x375 + x4*(x154 + x534) + x411 + x431 + x543) + x226*x438 - x228*x438 + x353*x447 - x356*x447 - 0.38095238095238099*x439 + 0.108843537414966*x440 + x441;
}
if (x93) {
   result[34] = n5*x454 - x278*x317*x546 + x278*x545 + x4*(-x115*x37 + x154) + x457 + x461 + x502 + x529 + 8.3144626181532395*x544 + x8;
}
else {
   result[34] = x178*(n5*x466 + x156 - x318*x546 + x34*x545 + x4*(-n5*x464 + x463) + x469 + x473 + x506 + x537 + 24.943387854459719*x544) + x202 - 0.16326530612244899*x439 + 0.046647230320699715*x440 + x447*x462 - x447*x474;
}
}
        
static double coder_dgdp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].dmu0dP)(T, P);
    double x1 = n2*(*endmember[1].dmu0dP)(T, P);
    double x2 = n3*(*endmember[2].dmu0dP)(T, P);
    double x3 = n4*(*endmember[3].dmu0dP)(T, P);
    double x4 = n5*(*endmember[4].dmu0dP)(T, P);

if (T >= 5.0) {
   result = x0 + x1 + x2 + x3 + x4;
}
else {
   result = (1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5)*(3*x0 + 3*x1 + 3*x2 + 3*x3 + 3*x4)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = T >= 5.0;
    double x2 = 3*x0;
    double x3 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x4 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x5 = x3*x4;
    double x6 = (*endmember[1].dmu0dP)(T, P);
    double x7 = 3*x6;
    double x8 = (*endmember[2].dmu0dP)(T, P);
    double x9 = 3*x8;
    double x10 = (*endmember[3].dmu0dP)(T, P);
    double x11 = 3*x10;
    double x12 = (*endmember[4].dmu0dP)(T, P);
    double x13 = 3*x12;
    double x14 = n1*x2 + n2*x7 + n3*x9 + n4*x11 + n5*x13;
    double x15 = x14*x3;
    double x16 = x14*x4/((0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5)*(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5));
    double x17 = 1.0*x15 - 0.027210884353741499*x16;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x17 + x2*x5;
}
if (x1) {
   result[1] = x6;
}
else {
   result[1] = x17 + x5*x7;
}
if (x1) {
   result[2] = x8;
}
else {
   result[2] = x17 + x5*x9;
}
if (x1) {
   result[3] = x10;
}
else {
   result[3] = x11*x5 + 3.5*x15 - 0.095238095238095247*x16;
}
if (x1) {
   result[4] = x12;
}
else {
   result[4] = x13*x5 + x17;
}
}
        
static void coder_d3gdn2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x2 = (*endmember[0].dmu0dP)(T, P);
    double x3 = x1*x2;
    double x4 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x2*x7;
    double x9 = (*endmember[1].dmu0dP)(T, P);
    double x10 = (*endmember[2].dmu0dP)(T, P);
    double x11 = (*endmember[3].dmu0dP)(T, P);
    double x12 = (*endmember[4].dmu0dP)(T, P);
    double x13 = 3*n1*x2 + 3*n2*x9 + 3*n3*x10 + 3*n4*x11 + 3*n5*x12;
    double x14 = x13*x5;
    double x15 = x13*x6/((x4)*(x4)*(x4));
    double x16 = -0.054421768707482998*x14 + 0.01554907677356657*x15;
    double x17 = x16 + 3.0*x3 - 0.081632653061224497*x8;
    double x18 = 3.0*x1;
    double x19 = 0.081632653061224497*x7;
    double x20 = x18*x9 - x19*x9;
    double x21 = x10*x18 - x10*x19;
    double x22 = x11*x18 - x11*x19 - 0.19047619047619049*x14 + 0.054421768707482998*x15;
    double x23 = x12*x18 - x12*x19;
    double x24 = x1*x9;
    double x25 = x7*x9;
    double x26 = x16 + x20;
    double x27 = x1*x10;
    double x28 = x10*x7;
    double x29 = x1*x12;
    double x30 = x12*x7;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x16 + 6.0*x3 - 0.16326530612244899*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x17 + x20;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 + x21;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x22 + 10.5*x3 - 0.2857142857142857*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 + x23;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x16 + 6.0*x24 - 0.16326530612244899*x25;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x21 + x26;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x22 + 10.5*x24 - 0.2857142857142857*x25;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x23 + x26;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x16 + 6.0*x27 - 0.16326530612244899*x28;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x22 + 10.5*x27 - 0.2857142857142857*x28;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x16 + x21 + x23;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 21.0*x1*x11 - 0.5714285714285714*x11*x7 - 0.66666666666666674*x14 + 0.19047619047619049*x15;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = x22 + 10.5*x29 - 0.28571428571428575*x30;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x16 + 6.0*x29 - 0.16326530612244899*x30;
}
}
        
static void coder_d4gdn3dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].dmu0dP)(T, P);
    double x2 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = pow(x2, -3);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = (*endmember[1].dmu0dP)(T, P);
    double x10 = (*endmember[2].dmu0dP)(T, P);
    double x11 = (*endmember[3].dmu0dP)(T, P);
    double x12 = (*endmember[4].dmu0dP)(T, P);
    double x13 = 3*n1*x1 + 3*n2*x9 + 3*n3*x10 + 3*n4*x11 + 3*n5*x12;
    double x14 = x13*x5;
    double x15 = x13*x6/((x2)*(x2)*(x2)*(x2));
    double x16 = 0.046647230320699715*x14 - 0.013327780091628489*x15;
    double x17 = 0.046647230320699715*x7;
    double x18 = 0.16326530612244899*x3;
    double x19 = x16 - x18*x9;
    double x20 = -0.32653061224489799*x4 + 0.093294460641399415*x8;
    double x21 = x16 + x20;
    double x22 = -x10*x18;
    double x23 = x10*x17 + x22;
    double x24 = -x11*x18 + 0.16326530612244899*x14;
    double x25 = x11*x17 - 0.046647230320699715*x15 + x24;
    double x26 = x12*x17 - x12*x18;
    double x27 = x7*x9;
    double x28 = x3*x9;
    double x29 = x16 - 0.32653061224489799*x28;
    double x30 = -0.16326530612244899*x4 + 0.046647230320699708*x8;
    double x31 = x19 + 0.046647230320699708*x27;
    double x32 = x30 + x31;
    double x33 = -0.5714285714285714*x4;
    double x34 = x25 + x33 + 0.16326530612244899*x8;
    double x35 = -0.5714285714285714*x28;
    double x36 = 0.16326530612244899*x27 + x35;
    double x37 = x16 + x30;
    double x38 = x10*x3;
    double x39 = -0.32653061224489799*x38;
    double x40 = x10*x7;
    double x41 = x39 + 0.093294460641399429*x40;
    double x42 = -0.5714285714285714*x38;
    double x43 = 0.16326530612244899*x40 + x42;
    double x44 = x22 + 0.046647230320699708*x40;
    double x45 = x26 + x44;
    double x46 = x11*x3;
    double x47 = x11*x7;
    double x48 = 0.57142857142857151*x14 - 0.16326530612244899*x15;
    double x49 = -1.142857142857143*x46 + 0.32653061224489799*x47 + x48;
    double x50 = x12*x3;
    double x51 = x12*x7;
    double x52 = -0.046647230320699708*x15 + x24 + 0.046647230320699708*x47;
    double x53 = -0.57142857142857151*x50 + 0.16326530612244899*x51 + x52;
    double x54 = -0.32653061224489799*x50 + 0.093294460641399429*x51;
    double x55 = 0.093294460641399415*x27 + x29;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x16 - 0.48979591836734698*x4 + 0.13994169096209913*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x17*x9 + x19 + x20;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x21 + x23;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x25 - 1.1428571428571428*x4 + 0.32653061224489799*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x21 + x26;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 0.093294460641399429*x27 + x29 + x30;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x23 + x32;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x34 + x36;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x26 + x32;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x37 + x41;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x34 + x43;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x37 + x45;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = -2.0*x4 + x49 + 0.5714285714285714*x8;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = x33 + x53 + 0.16326530612244897*x8;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x37 + x54;
}
if (x0) {
   result[15] = 0;
}
else {
   result[15] = x16 + 0.13994169096209913*x27 - 0.48979591836734698*x28;
}
if (x0) {
   result[16] = 0;
}
else {
   result[16] = x23 + x55;
}
if (x0) {
   result[17] = 0;
}
else {
   result[17] = x25 + 0.32653061224489799*x27 - 1.1428571428571428*x28;
}
if (x0) {
   result[18] = 0;
}
else {
   result[18] = x26 + x55;
}
if (x0) {
   result[19] = 0;
}
else {
   result[19] = x31 + x41;
}
if (x0) {
   result[20] = 0;
}
else {
   result[20] = x25 + x36 + x43;
}
if (x0) {
   result[21] = 0;
}
else {
   result[21] = x31 + x45;
}
if (x0) {
   result[22] = 0;
}
else {
   result[22] = 0.5714285714285714*x27 - 2.0*x28 + x49;
}
if (x0) {
   result[23] = 0;
}
else {
   result[23] = 0.16326530612244897*x27 + x35 + x53;
}
if (x0) {
   result[24] = 0;
}
else {
   result[24] = x31 + x54;
}
if (x0) {
   result[25] = 0;
}
else {
   result[25] = x16 - 0.48979591836734698*x38 + 0.13994169096209913*x40;
}
if (x0) {
   result[26] = 0;
}
else {
   result[26] = x25 - 1.1428571428571428*x38 + 0.32653061224489799*x40;
}
if (x0) {
   result[27] = 0;
}
else {
   result[27] = x16 + x26 + x39 + 0.093294460641399415*x40;
}
if (x0) {
   result[28] = 0;
}
else {
   result[28] = -2.0*x38 + 0.5714285714285714*x40 + x49;
}
if (x0) {
   result[29] = 0;
}
else {
   result[29] = 0.16326530612244897*x40 + x42 + x53;
}
if (x0) {
   result[30] = 0;
}
else {
   result[30] = x16 + x44 + x54;
}
if (x0) {
   result[31] = 0;
}
else {
   result[31] = 2.0*x14 - 0.57142857142857151*x15 - 6.0*x46 + 1.7142857142857144*x47;
}
if (x0) {
   result[32] = 0;
}
else {
   result[32] = -1.1428571428571428*x46 + 0.32653061224489793*x47 + x48 - 2.0*x50 + 0.57142857142857151*x51;
}
if (x0) {
   result[33] = 0;
}
else {
   result[33] = -1.142857142857143*x50 + 0.32653061224489799*x51 + x52;
}
if (x0) {
   result[34] = 0;
}
else {
   result[34] = x16 - 0.48979591836734698*x50 + 0.13994169096209913*x51;
}
}
        
static double coder_d2gdt2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dT2)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dT2)(T, P);
    double x3 = n4*(*endmember[3].d2mu0dT2)(T, P);
    double x4 = n5*(*endmember[4].d2mu0dT2)(T, P);
    double x5 = 0.19999999999999998*T;
    double x6 = 1 - x5;
    double x7 = sqrt(x6);
    double x8 = 1.0*x7;
    double x9 = (4 - x8 >= 0. ? 1. : 0.);
    double x10 = 0.40144049999999992*T - 2.0072024999999996;
    double x11 = 1.0/(x5 - 1);
    double x12 = x11*0;
    double x13 = x9/pow(x6, 3.0/2.0);
    double x14 = fmin(4, x8);
    double x15 = 2.0072025*((x14)*(x14));

if (T >= 5.0) {
   result = x0 + x1 + x2 + x3 + x4;
}
else {
   result = (1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5)*(-n2*(-x10*x12 + x10*x13 + 4.014405*x11*x14*((x9)*(x9)) - x12*x15 + x13*x15 + 8.02881*x9/x7) + 3*x0 + 3*x1 + 3*x2 + 3*x3 + 3*x4)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = T >= 5.0;
    double x2 = 3*x0;
    double x3 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x4 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x5 = x3*x4;
    double x6 = (*endmember[1].d2mu0dT2)(T, P);
    double x7 = 3*x6;
    double x8 = (*endmember[2].d2mu0dT2)(T, P);
    double x9 = 3*x8;
    double x10 = (*endmember[3].d2mu0dT2)(T, P);
    double x11 = 3*x10;
    double x12 = (*endmember[4].d2mu0dT2)(T, P);
    double x13 = 3*x12;
    double x14 = 0.19999999999999998*T;
    double x15 = 1 - x14;
    double x16 = sqrt(x15);
    double x17 = 1.0*x16;
    double x18 = (4 - x17 >= 0. ? 1. : 0.);
    double x19 = 8.02881*x18/x16;
    double x20 = 0.40144049999999992*T - 2.0072024999999996;
    double x21 = 1.0/(x14 - 1);
    double x22 = x21*0;
    double x23 = x20*x22;
    double x24 = x18/pow(x15, 3.0/2.0);
    double x25 = x20*x24;
    double x26 = fmin(4, x17);
    double x27 = 2.0072025*((x26)*(x26));
    double x28 = x22*x27;
    double x29 = x24*x27;
    double x30 = 4.014405*((x18)*(x18))*x21*x26;
    double x31 = n1*x2 + n2*x7 - n2*(x19 - x23 + x25 - x28 + x29 + x30) + n3*x9 + n4*x11 + n5*x13;
    double x32 = x3*x31;
    double x33 = x31*x4/((0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5)*(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5));
    double x34 = 1.0*x32 - 0.027210884353741499*x33;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x2*x5 + x34;
}
if (x1) {
   result[1] = x6;
}
else {
   result[1] = x34 + x5*(-x19 + x23 - x25 + x28 - x29 - x30 + x7);
}
if (x1) {
   result[2] = x8;
}
else {
   result[2] = x34 + x5*x9;
}
if (x1) {
   result[3] = x10;
}
else {
   result[3] = x11*x5 + 3.5*x32 - 0.095238095238095247*x33;
}
if (x1) {
   result[4] = x12;
}
else {
   result[4] = x13*x5 + x34;
}
}
        
static void coder_d4gdn2dt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x2 = (*endmember[0].d2mu0dT2)(T, P);
    double x3 = x1*x2;
    double x4 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x2*x7;
    double x9 = 3*(*endmember[1].d2mu0dT2)(T, P);
    double x10 = (*endmember[2].d2mu0dT2)(T, P);
    double x11 = (*endmember[3].d2mu0dT2)(T, P);
    double x12 = (*endmember[4].d2mu0dT2)(T, P);
    double x13 = 0.19999999999999998*T;
    double x14 = 1 - x13;
    double x15 = sqrt(x14);
    double x16 = 1.0*x15;
    double x17 = (4 - x16 >= 0. ? 1. : 0.);
    double x18 = 8.02881*x17/x15;
    double x19 = 0.40144049999999992*T - 2.0072024999999996;
    double x20 = 1.0/(x13 - 1);
    double x21 = x20*0;
    double x22 = x19*x21;
    double x23 = x17/pow(x14, 3.0/2.0);
    double x24 = x19*x23;
    double x25 = fmin(4, x16);
    double x26 = 2.0072025*((x25)*(x25));
    double x27 = x21*x26;
    double x28 = x23*x26;
    double x29 = 4.014405*((x17)*(x17))*x20*x25;
    double x30 = 3*n1*x2 + n2*x9 - n2*(x18 - x22 + x24 - x27 + x28 + x29) + 3*n3*x10 + 3*n4*x11 + 3*n5*x12;
    double x31 = x30*x5;
    double x32 = x30*x6/((x4)*(x4)*(x4));
    double x33 = -0.054421768707482998*x31 + 0.01554907677356657*x32;
    double x34 = 3.0*x3 + x33 - 0.081632653061224497*x8;
    double x35 = -x18 + x22 - x24 + x27 - x28 - x29 + x9;
    double x36 = x1*x35;
    double x37 = x35*x7;
    double x38 = 1.0*x36 - 0.027210884353741499*x37;
    double x39 = 3.0*x1;
    double x40 = 0.081632653061224497*x7;
    double x41 = x10*x39 - x10*x40;
    double x42 = x11*x39 - x11*x40 - 0.19047619047619049*x31 + 0.054421768707482998*x32;
    double x43 = x12*x39 - x12*x40;
    double x44 = x33 + x38;
    double x45 = x1*x10;
    double x46 = x10*x7;
    double x47 = x1*x12;
    double x48 = x12*x7;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 6.0*x3 + x33 - 0.16326530612244899*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x34 + x38;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x34 + x41;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 10.5*x3 + x42 - 0.2857142857142857*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x34 + x43;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x33 + 2.0*x36 - 0.054421768707482998*x37;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x41 + x44;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = 3.5*x36 - 0.095238095238095247*x37 + x42;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x43 + x44;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x33 + 6.0*x45 - 0.16326530612244899*x46;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x42 + 10.5*x45 - 0.2857142857142857*x46;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x33 + x41 + x43;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 21.0*x1*x11 - 0.5714285714285714*x11*x7 - 0.66666666666666674*x31 + 0.19047619047619049*x32;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = x42 + 10.5*x47 - 0.28571428571428575*x48;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x33 + 6.0*x47 - 0.16326530612244899*x48;
}
}
        
static void coder_d5gdn3dt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dT2)(T, P);
    double x2 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = pow(x2, -3);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = 3*(*endmember[1].d2mu0dT2)(T, P);
    double x10 = (*endmember[2].d2mu0dT2)(T, P);
    double x11 = (*endmember[3].d2mu0dT2)(T, P);
    double x12 = (*endmember[4].d2mu0dT2)(T, P);
    double x13 = 0.19999999999999998*T;
    double x14 = 1 - x13;
    double x15 = sqrt(x14);
    double x16 = 1.0*x15;
    double x17 = (4 - x16 >= 0. ? 1. : 0.);
    double x18 = 8.02881*x17/x15;
    double x19 = 0.40144049999999992*T - 2.0072024999999996;
    double x20 = 1.0/(x13 - 1);
    double x21 = x20*0;
    double x22 = x19*x21;
    double x23 = x17/pow(x14, 3.0/2.0);
    double x24 = x19*x23;
    double x25 = fmin(4, x16);
    double x26 = 2.0072025*((x25)*(x25));
    double x27 = x21*x26;
    double x28 = x23*x26;
    double x29 = 4.014405*((x17)*(x17))*x20*x25;
    double x30 = 3*n1*x1 + n2*x9 - n2*(x18 - x22 + x24 - x27 + x28 + x29) + 3*n3*x10 + 3*n4*x11 + 3*n5*x12;
    double x31 = x30*x5;
    double x32 = x30*x6/((x2)*(x2)*(x2)*(x2));
    double x33 = 0.046647230320699715*x31 - 0.013327780091628489*x32;
    double x34 = x33 - 0.32653061224489799*x4 + 0.093294460641399415*x8;
    double x35 = -x18 + x22 - x24 + x27 - x28 - x29 + x9;
    double x36 = x3*x35;
    double x37 = x35*x7;
    double x38 = -0.054421768707482998*x36 + 0.01554907677356657*x37;
    double x39 = 0.16326530612244899*x3;
    double x40 = -x10*x39;
    double x41 = 0.046647230320699715*x7;
    double x42 = x10*x41 + x40;
    double x43 = -x11*x39 + 0.16326530612244899*x31;
    double x44 = x11*x41 - 0.046647230320699715*x32 + x43;
    double x45 = -x12*x39 + x12*x41;
    double x46 = x33 - 0.16326530612244899*x4 + 0.046647230320699708*x8;
    double x47 = -0.108843537414966*x36 + 0.031098153547133141*x37;
    double x48 = x38 + x46;
    double x49 = -0.19047619047619049*x36 + 0.054421768707482998*x37;
    double x50 = -0.5714285714285714*x4;
    double x51 = x44 + x50 + 0.16326530612244899*x8;
    double x52 = x10*x3;
    double x53 = -0.32653061224489799*x52;
    double x54 = x10*x7;
    double x55 = x53 + 0.093294460641399429*x54;
    double x56 = -0.5714285714285714*x52;
    double x57 = 0.16326530612244899*x54 + x56;
    double x58 = x40 + 0.046647230320699708*x54;
    double x59 = x45 + x58;
    double x60 = x11*x3;
    double x61 = x11*x7;
    double x62 = 0.57142857142857151*x31 - 0.16326530612244899*x32;
    double x63 = -1.142857142857143*x60 + 0.32653061224489799*x61 + x62;
    double x64 = x12*x3;
    double x65 = x12*x7;
    double x66 = -0.046647230320699708*x32 + x43 + 0.046647230320699708*x61;
    double x67 = -0.57142857142857151*x64 + 0.16326530612244899*x65 + x66;
    double x68 = -0.32653061224489799*x64 + 0.093294460641399429*x65;
    double x69 = x33 + x47;
    double x70 = x33 + x38;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x33 - 0.48979591836734698*x4 + 0.13994169096209913*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x34 + x38;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x34 + x42;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = -1.1428571428571428*x4 + x44 + 0.32653061224489799*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x34 + x45;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x46 + x47;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x42 + x48;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x49 + x51;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x45 + x48;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x46 + x55;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x51 + x57;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x46 + x59;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = -2.0*x4 + x63 + 0.5714285714285714*x8;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = x50 + x67 + 0.16326530612244897*x8;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x46 + x68;
}
if (x0) {
   result[15] = 0;
}
else {
   result[15] = x33 - 0.16326530612244899*x36 + 0.046647230320699715*x37;
}
if (x0) {
   result[16] = 0;
}
else {
   result[16] = x42 + x69;
}
if (x0) {
   result[17] = 0;
}
else {
   result[17] = -0.38095238095238099*x36 + 0.108843537414966*x37 + x44;
}
if (x0) {
   result[18] = 0;
}
else {
   result[18] = x45 + x69;
}
if (x0) {
   result[19] = 0;
}
else {
   result[19] = x55 + x70;
}
if (x0) {
   result[20] = 0;
}
else {
   result[20] = x44 + x49 + x57;
}
if (x0) {
   result[21] = 0;
}
else {
   result[21] = x59 + x70;
}
if (x0) {
   result[22] = 0;
}
else {
   result[22] = -0.66666666666666674*x36 + 0.19047619047619049*x37 + x63;
}
if (x0) {
   result[23] = 0;
}
else {
   result[23] = x49 + x67;
}
if (x0) {
   result[24] = 0;
}
else {
   result[24] = x68 + x70;
}
if (x0) {
   result[25] = 0;
}
else {
   result[25] = x33 - 0.48979591836734698*x52 + 0.13994169096209913*x54;
}
if (x0) {
   result[26] = 0;
}
else {
   result[26] = x44 - 1.1428571428571428*x52 + 0.32653061224489799*x54;
}
if (x0) {
   result[27] = 0;
}
else {
   result[27] = x33 + x45 + x53 + 0.093294460641399415*x54;
}
if (x0) {
   result[28] = 0;
}
else {
   result[28] = -2.0*x52 + 0.5714285714285714*x54 + x63;
}
if (x0) {
   result[29] = 0;
}
else {
   result[29] = 0.16326530612244897*x54 + x56 + x67;
}
if (x0) {
   result[30] = 0;
}
else {
   result[30] = x33 + x58 + x68;
}
if (x0) {
   result[31] = 0;
}
else {
   result[31] = 2.0*x31 - 0.57142857142857151*x32 - 6.0*x60 + 1.7142857142857144*x61;
}
if (x0) {
   result[32] = 0;
}
else {
   result[32] = -1.1428571428571428*x60 + 0.32653061224489793*x61 + x62 - 2.0*x64 + 0.57142857142857151*x65;
}
if (x0) {
   result[33] = 0;
}
else {
   result[33] = -1.142857142857143*x64 + 0.32653061224489799*x65 + x66;
}
if (x0) {
   result[34] = 0;
}
else {
   result[34] = x33 - 0.48979591836734698*x64 + 0.13994169096209913*x65;
}
}
        
static double coder_d2gdtdp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P) + n3*(*endmember[2].d2mu0dTdP)(T, P) + n4*(*endmember[3].d2mu0dTdP)(T, P) + n5*(*endmember[4].d2mu0dTdP)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].d2mu0dTdP)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d2mu0dTdP)(T, P);
    double x6 = (*endmember[2].d2mu0dTdP)(T, P);
    double x7 = (*endmember[3].d2mu0dTdP)(T, P);
    double x8 = (*endmember[4].d2mu0dTdP)(T, P);
    double x9 = n1*x0 + n2*x5 + n3*x6 + n4*x7 + n5*x8;
    double x10 = x2*x9;
    double x11 = x3*x9/((0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5)*(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5));
    double x12 = 3.0*x10 - 0.081632653061224497*x11;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x12;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x12 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x12 + x4*x6;
}
if (x1) {
   result[3] = x7;
}
else {
   result[3] = 10.5*x10 - 0.2857142857142857*x11 + x4*x7;
}
if (x1) {
   result[4] = x8;
}
else {
   result[4] = x12 + x4*x8;
}
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dTdP)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = x1*x2;
    double x4 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = (*endmember[1].d2mu0dTdP)(T, P);
    double x10 = (*endmember[2].d2mu0dTdP)(T, P);
    double x11 = (*endmember[3].d2mu0dTdP)(T, P);
    double x12 = (*endmember[4].d2mu0dTdP)(T, P);
    double x13 = n1*x1 + n2*x9 + n3*x10 + n4*x11 + n5*x12;
    double x14 = x13*x5;
    double x15 = x13*x6/((x4)*(x4)*(x4));
    double x16 = -0.16326530612244899*x14 + 0.046647230320699708*x15;
    double x17 = x16 + 3.0*x3 - 0.081632653061224497*x8;
    double x18 = 3.0*x2;
    double x19 = 0.081632653061224497*x7;
    double x20 = x18*x9 - x19*x9;
    double x21 = x10*x18 - x10*x19;
    double x22 = x11*x18 - x11*x19 - 0.5714285714285714*x14;
    double x23 = 0.16326530612244899*x15 + x22;
    double x24 = x12*x18 - x12*x19;
    double x25 = x2*x9;
    double x26 = x7*x9;
    double x27 = x16 + x20;
    double x28 = x10*x2;
    double x29 = x10*x7;
    double x30 = x12*x2;
    double x31 = x12*x7;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x16 + 6.0*x3 - 0.16326530612244899*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x17 + x20;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 + x21;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x23 + 10.5*x3 - 0.2857142857142857*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 + x24;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x16 + 6.0*x25 - 0.16326530612244899*x26;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x21 + x27;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x23 + 10.5*x25 - 0.2857142857142857*x26;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x24 + x27;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x16 + 6.0*x28 - 0.16326530612244899*x29;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x23 + 10.5*x28 - 0.2857142857142857*x29;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x16 + x21 + x24;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 21.0*x11*x2 - 0.5714285714285714*x11*x7 - 2.0*x14 + 0.5714285714285714*x15;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = 0.16326530612244897*x15 + x22 + 10.5*x30 - 0.2857142857142857*x31;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x16 + 6.0*x30 - 0.16326530612244899*x31;
}
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dTdP)(T, P);
    double x2 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = pow(x2, -3);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = (*endmember[1].d2mu0dTdP)(T, P);
    double x10 = (*endmember[2].d2mu0dTdP)(T, P);
    double x11 = (*endmember[3].d2mu0dTdP)(T, P);
    double x12 = (*endmember[4].d2mu0dTdP)(T, P);
    double x13 = n1*x1 + n2*x9 + n3*x10 + n4*x11 + n5*x12;
    double x14 = x13*x5;
    double x15 = x13*x6/((x2)*(x2)*(x2)*(x2));
    double x16 = 0.13994169096209913*x14 - 0.039983340274885461*x15;
    double x17 = x16 - 0.32653061224489799*x4 + 0.093294460641399415*x8;
    double x18 = 0.16326530612244899*x3;
    double x19 = 0.046647230320699708*x7;
    double x20 = -x18*x9 + x19*x9;
    double x21 = -x10*x18 + x10*x19;
    double x22 = -x11*x18 + x11*x19 + 0.48979591836734693*x14;
    double x23 = -0.13994169096209913*x15 + x22;
    double x24 = -x12*x18 + x12*x19;
    double x25 = x16 - 0.16326530612244899*x4 + 0.046647230320699708*x8;
    double x26 = x3*x9;
    double x27 = x7*x9;
    double x28 = -0.32653061224489799*x26 + 0.093294460641399415*x27;
    double x29 = x20 + x25;
    double x30 = x23 - 0.5714285714285714*x4;
    double x31 = x30 + 0.16326530612244899*x8;
    double x32 = -0.5714285714285714*x26;
    double x33 = 0.16326530612244899*x27 + x32;
    double x34 = x10*x3;
    double x35 = x10*x7;
    double x36 = -0.32653061224489799*x34 + 0.093294460641399415*x35;
    double x37 = -0.5714285714285714*x34;
    double x38 = 0.16326530612244899*x35 + x37;
    double x39 = x21 + x24;
    double x40 = x11*x3;
    double x41 = -1.1428571428571428*x40;
    double x42 = x11*x7;
    double x43 = 1.7142857142857144*x14 - 0.48979591836734698*x15 + x41 + 0.32653061224489799*x42;
    double x44 = x12*x3;
    double x45 = x12*x7;
    double x46 = -0.5714285714285714*x44 + 0.16326530612244899*x45;
    double x47 = -0.32653061224489799*x44 + 0.093294460641399415*x45;
    double x48 = x16 + x28;
    double x49 = x16 + x20;
    double x50 = x23 + x46;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x16 - 0.48979591836734698*x4 + 0.13994169096209913*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x17 + x20;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 + x21;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x23 - 1.1428571428571428*x4 + 0.32653061224489799*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 + x24;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x25 + x28;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x21 + x29;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x31 + x33;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x24 + x29;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x25 + x36;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x31 + x38;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x25 + x39;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = -2.0*x4 + x43 + 0.5714285714285714*x8;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = x30 + x46 + 0.16326530612244897*x8;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x25 + x47;
}
if (x0) {
   result[15] = 0;
}
else {
   result[15] = x16 - 0.48979591836734698*x26 + 0.13994169096209913*x27;
}
if (x0) {
   result[16] = 0;
}
else {
   result[16] = x21 + x48;
}
if (x0) {
   result[17] = 0;
}
else {
   result[17] = x23 - 1.1428571428571428*x26 + 0.32653061224489799*x27;
}
if (x0) {
   result[18] = 0;
}
else {
   result[18] = x24 + x48;
}
if (x0) {
   result[19] = 0;
}
else {
   result[19] = x36 + x49;
}
if (x0) {
   result[20] = 0;
}
else {
   result[20] = x23 + x33 + x38;
}
if (x0) {
   result[21] = 0;
}
else {
   result[21] = x39 + x49;
}
if (x0) {
   result[22] = 0;
}
else {
   result[22] = -2.0*x26 + 0.5714285714285714*x27 + x43;
}
if (x0) {
   result[23] = 0;
}
else {
   result[23] = 0.16326530612244897*x27 + x32 + x50;
}
if (x0) {
   result[24] = 0;
}
else {
   result[24] = x47 + x49;
}
if (x0) {
   result[25] = 0;
}
else {
   result[25] = x16 - 0.48979591836734698*x34 + 0.13994169096209913*x35;
}
if (x0) {
   result[26] = 0;
}
else {
   result[26] = x23 - 1.1428571428571428*x34 + 0.32653061224489799*x35;
}
if (x0) {
   result[27] = 0;
}
else {
   result[27] = x16 + x24 + x36;
}
if (x0) {
   result[28] = 0;
}
else {
   result[28] = -2.0*x34 + 0.5714285714285714*x35 + x43;
}
if (x0) {
   result[29] = 0;
}
else {
   result[29] = 0.16326530612244897*x35 + x37 + x50;
}
if (x0) {
   result[30] = 0;
}
else {
   result[30] = x16 + x21 + x47;
}
if (x0) {
   result[31] = 0;
}
else {
   result[31] = 6.0*x14 - 1.7142857142857142*x15 - 6.0*x40 + 1.7142857142857142*x42;
}
if (x0) {
   result[32] = 0;
}
else {
   result[32] = 1.7142857142857142*x14 - 0.48979591836734687*x15 + x41 + 0.32653061224489793*x42 - 2.0*x44 + 0.5714285714285714*x45;
}
if (x0) {
   result[33] = 0;
}
else {
   result[33] = -0.1399416909620991*x15 + x22 - 1.1428571428571428*x44 + 0.32653061224489793*x45;
}
if (x0) {
   result[34] = 0;
}
else {
   result[34] = x16 - 0.48979591836734698*x44 + 0.13994169096209913*x45;
}
}
        
static double coder_d2gdp2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P) + n3*(*endmember[2].d2mu0dP2)(T, P) + n4*(*endmember[3].d2mu0dP2)(T, P) + n5*(*endmember[4].d2mu0dP2)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].d2mu0dP2)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d2mu0dP2)(T, P);
    double x6 = (*endmember[2].d2mu0dP2)(T, P);
    double x7 = (*endmember[3].d2mu0dP2)(T, P);
    double x8 = (*endmember[4].d2mu0dP2)(T, P);
    double x9 = n1*x0 + n2*x5 + n3*x6 + n4*x7 + n5*x8;
    double x10 = x2*x9;
    double x11 = x3*x9/((0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5)*(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5));
    double x12 = 3.0*x10 - 0.081632653061224497*x11;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x12;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x12 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x12 + x4*x6;
}
if (x1) {
   result[3] = x7;
}
else {
   result[3] = 10.5*x10 - 0.2857142857142857*x11 + x4*x7;
}
if (x1) {
   result[4] = x8;
}
else {
   result[4] = x12 + x4*x8;
}
}
        
static void coder_d4gdn2dp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dP2)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = x1*x2;
    double x4 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = (*endmember[1].d2mu0dP2)(T, P);
    double x10 = (*endmember[2].d2mu0dP2)(T, P);
    double x11 = (*endmember[3].d2mu0dP2)(T, P);
    double x12 = (*endmember[4].d2mu0dP2)(T, P);
    double x13 = n1*x1 + n2*x9 + n3*x10 + n4*x11 + n5*x12;
    double x14 = x13*x5;
    double x15 = x13*x6/((x4)*(x4)*(x4));
    double x16 = -0.16326530612244899*x14 + 0.046647230320699708*x15;
    double x17 = x16 + 3.0*x3 - 0.081632653061224497*x8;
    double x18 = 3.0*x2;
    double x19 = 0.081632653061224497*x7;
    double x20 = x18*x9 - x19*x9;
    double x21 = x10*x18 - x10*x19;
    double x22 = x11*x18 - x11*x19 - 0.5714285714285714*x14;
    double x23 = 0.16326530612244899*x15 + x22;
    double x24 = x12*x18 - x12*x19;
    double x25 = x2*x9;
    double x26 = x7*x9;
    double x27 = x16 + x20;
    double x28 = x10*x2;
    double x29 = x10*x7;
    double x30 = x12*x2;
    double x31 = x12*x7;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x16 + 6.0*x3 - 0.16326530612244899*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x17 + x20;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 + x21;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x23 + 10.5*x3 - 0.2857142857142857*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 + x24;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x16 + 6.0*x25 - 0.16326530612244899*x26;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x21 + x27;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x23 + 10.5*x25 - 0.2857142857142857*x26;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x24 + x27;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x16 + 6.0*x28 - 0.16326530612244899*x29;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x23 + 10.5*x28 - 0.2857142857142857*x29;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x16 + x21 + x24;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 21.0*x11*x2 - 0.5714285714285714*x11*x7 - 2.0*x14 + 0.5714285714285714*x15;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = 0.16326530612244897*x15 + x22 + 10.5*x30 - 0.2857142857142857*x31;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x16 + 6.0*x30 - 0.16326530612244899*x31;
}
}
        
static void coder_d5gdn3dp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dP2)(T, P);
    double x2 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = pow(x2, -3);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = (*endmember[1].d2mu0dP2)(T, P);
    double x10 = (*endmember[2].d2mu0dP2)(T, P);
    double x11 = (*endmember[3].d2mu0dP2)(T, P);
    double x12 = (*endmember[4].d2mu0dP2)(T, P);
    double x13 = n1*x1 + n2*x9 + n3*x10 + n4*x11 + n5*x12;
    double x14 = x13*x5;
    double x15 = x13*x6/((x2)*(x2)*(x2)*(x2));
    double x16 = 0.13994169096209913*x14 - 0.039983340274885461*x15;
    double x17 = x16 - 0.32653061224489799*x4 + 0.093294460641399415*x8;
    double x18 = 0.16326530612244899*x3;
    double x19 = 0.046647230320699708*x7;
    double x20 = -x18*x9 + x19*x9;
    double x21 = -x10*x18 + x10*x19;
    double x22 = -x11*x18 + x11*x19 + 0.48979591836734693*x14;
    double x23 = -0.13994169096209913*x15 + x22;
    double x24 = -x12*x18 + x12*x19;
    double x25 = x16 - 0.16326530612244899*x4 + 0.046647230320699708*x8;
    double x26 = x3*x9;
    double x27 = x7*x9;
    double x28 = -0.32653061224489799*x26 + 0.093294460641399415*x27;
    double x29 = x20 + x25;
    double x30 = x23 - 0.5714285714285714*x4;
    double x31 = x30 + 0.16326530612244899*x8;
    double x32 = -0.5714285714285714*x26;
    double x33 = 0.16326530612244899*x27 + x32;
    double x34 = x10*x3;
    double x35 = x10*x7;
    double x36 = -0.32653061224489799*x34 + 0.093294460641399415*x35;
    double x37 = -0.5714285714285714*x34;
    double x38 = 0.16326530612244899*x35 + x37;
    double x39 = x21 + x24;
    double x40 = x11*x3;
    double x41 = -1.1428571428571428*x40;
    double x42 = x11*x7;
    double x43 = 1.7142857142857144*x14 - 0.48979591836734698*x15 + x41 + 0.32653061224489799*x42;
    double x44 = x12*x3;
    double x45 = x12*x7;
    double x46 = -0.5714285714285714*x44 + 0.16326530612244899*x45;
    double x47 = -0.32653061224489799*x44 + 0.093294460641399415*x45;
    double x48 = x16 + x28;
    double x49 = x16 + x20;
    double x50 = x23 + x46;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x16 - 0.48979591836734698*x4 + 0.13994169096209913*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x17 + x20;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 + x21;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x23 - 1.1428571428571428*x4 + 0.32653061224489799*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 + x24;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x25 + x28;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x21 + x29;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x31 + x33;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x24 + x29;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x25 + x36;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x31 + x38;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x25 + x39;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = -2.0*x4 + x43 + 0.5714285714285714*x8;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = x30 + x46 + 0.16326530612244897*x8;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x25 + x47;
}
if (x0) {
   result[15] = 0;
}
else {
   result[15] = x16 - 0.48979591836734698*x26 + 0.13994169096209913*x27;
}
if (x0) {
   result[16] = 0;
}
else {
   result[16] = x21 + x48;
}
if (x0) {
   result[17] = 0;
}
else {
   result[17] = x23 - 1.1428571428571428*x26 + 0.32653061224489799*x27;
}
if (x0) {
   result[18] = 0;
}
else {
   result[18] = x24 + x48;
}
if (x0) {
   result[19] = 0;
}
else {
   result[19] = x36 + x49;
}
if (x0) {
   result[20] = 0;
}
else {
   result[20] = x23 + x33 + x38;
}
if (x0) {
   result[21] = 0;
}
else {
   result[21] = x39 + x49;
}
if (x0) {
   result[22] = 0;
}
else {
   result[22] = -2.0*x26 + 0.5714285714285714*x27 + x43;
}
if (x0) {
   result[23] = 0;
}
else {
   result[23] = 0.16326530612244897*x27 + x32 + x50;
}
if (x0) {
   result[24] = 0;
}
else {
   result[24] = x47 + x49;
}
if (x0) {
   result[25] = 0;
}
else {
   result[25] = x16 - 0.48979591836734698*x34 + 0.13994169096209913*x35;
}
if (x0) {
   result[26] = 0;
}
else {
   result[26] = x23 - 1.1428571428571428*x34 + 0.32653061224489799*x35;
}
if (x0) {
   result[27] = 0;
}
else {
   result[27] = x16 + x24 + x36;
}
if (x0) {
   result[28] = 0;
}
else {
   result[28] = -2.0*x34 + 0.5714285714285714*x35 + x43;
}
if (x0) {
   result[29] = 0;
}
else {
   result[29] = 0.16326530612244897*x35 + x37 + x50;
}
if (x0) {
   result[30] = 0;
}
else {
   result[30] = x16 + x21 + x47;
}
if (x0) {
   result[31] = 0;
}
else {
   result[31] = 6.0*x14 - 1.7142857142857142*x15 - 6.0*x40 + 1.7142857142857142*x42;
}
if (x0) {
   result[32] = 0;
}
else {
   result[32] = 1.7142857142857142*x14 - 0.48979591836734687*x15 + x41 + 0.32653061224489793*x42 - 2.0*x44 + 0.5714285714285714*x45;
}
if (x0) {
   result[33] = 0;
}
else {
   result[33] = -0.1399416909620991*x15 + x22 - 1.1428571428571428*x44 + 0.32653061224489793*x45;
}
if (x0) {
   result[34] = 0;
}
else {
   result[34] = x16 - 0.48979591836734698*x44 + 0.13994169096209913*x45;
}
}
        
static double coder_d3gdt3(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT3)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dT3)(T, P);
    double x3 = n4*(*endmember[3].d3mu0dT3)(T, P);
    double x4 = n5*(*endmember[4].d3mu0dT3)(T, P);
    double x5 = 0.19999999999999998*T;
    double x6 = x5 - 1;
    double x7 = 1 - x5;
    double x8 = 1.0*sqrt(x7);
    double x9 = x8 - 4;
    double x10 = 0;
    double x11 = pow(x7, -3.0/2.0);
    double x12 = (4 - x8 >= 0. ? 1. : 0.);
    double x13 = 1.2043214999999998*x11*x12;
    double x14 = 40.14405*T - 200.72024999999999;
    double x15 = pow(x6, -2);
    double x16 = x10*x15;
    double x17 = x12/pow(x7, 5.0/2.0);
    double x18 = x11*0;
    double x19 = fmin(4, x8);
    double x20 = ((x19)*(x19));

if (T >= 5.0) {
   result = x0 + x1 + x2 + x3 + x4;
}
else {
   result = (1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5)*(-n2*(-x10*x13*x19 - 1.2043214999999998*x10/x6 + 0.40144049999999998*x11*((x12)*(x12)*(x12)) - 1.2043214999999998*((x12)*(x12))*x15*x19 + x13 + 0.0029999999999999992*x14*x16 + 0.0029999999999999996*x14*x17 - 0.0009999999999999998*x14*x18 + 0.60216074999999991*x16*x20 + 0.60216075000000002*x17*x20 - 0.20072024999999999*x18*x20) + 3*x0 + 3*x1 + 3*x2 + 3*x3 + 3*x4)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = T >= 5.0;
    double x2 = 3*x0;
    double x3 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x4 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x5 = x3*x4;
    double x6 = (*endmember[1].d3mu0dT3)(T, P);
    double x7 = 3*x6;
    double x8 = (*endmember[2].d3mu0dT3)(T, P);
    double x9 = 3*x8;
    double x10 = (*endmember[3].d3mu0dT3)(T, P);
    double x11 = 3*x10;
    double x12 = (*endmember[4].d3mu0dT3)(T, P);
    double x13 = 3*x12;
    double x14 = 0.19999999999999998*T;
    double x15 = x14 - 1;
    double x16 = 1 - x14;
    double x17 = 1.0*sqrt(x16);
    double x18 = x17 - 4;
    double x19 = 0;
    double x20 = 1.2043214999999998*x19/x15;
    double x21 = pow(x16, -3.0/2.0);
    double x22 = (4 - x17 >= 0. ? 1. : 0.);
    double x23 = 1.2043214999999998*x21*x22;
    double x24 = 0.40144049999999998*x21*((x22)*(x22)*(x22));
    double x25 = 40.14405*T - 200.72024999999999;
    double x26 = pow(x15, -2);
    double x27 = x19*x26;
    double x28 = 0.0029999999999999992*x25*x27;
    double x29 = x22/pow(x16, 5.0/2.0);
    double x30 = 0.0029999999999999996*x25*x29;
    double x31 = x21*0;
    double x32 = 0.0009999999999999998*x25*x31;
    double x33 = fmin(4, x17);
    double x34 = ((x33)*(x33));
    double x35 = 0.60216074999999991*x27*x34;
    double x36 = 0.60216075000000002*x29*x34;
    double x37 = 0.20072024999999999*x31*x34;
    double x38 = 1.2043214999999998*((x22)*(x22))*x26*x33;
    double x39 = x19*x23*x33;
    double x40 = n1*x2 + n2*x7 - n2*(-x20 + x23 + x24 + x28 + x30 - x32 + x35 + x36 - x37 - x38 - x39) + n3*x9 + n4*x11 + n5*x13;
    double x41 = x3*x40;
    double x42 = x4*x40/((0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5)*(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5));
    double x43 = 1.0*x41 - 0.027210884353741499*x42;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x2*x5 + x43;
}
if (x1) {
   result[1] = x6;
}
else {
   result[1] = x43 + x5*(x20 - x23 - x24 - x28 - x30 + x32 - x35 - x36 + x37 + x38 + x39 + x7);
}
if (x1) {
   result[2] = x8;
}
else {
   result[2] = x43 + x5*x9;
}
if (x1) {
   result[3] = x10;
}
else {
   result[3] = x11*x5 + 3.5*x41 - 0.095238095238095247*x42;
}
if (x1) {
   result[4] = x12;
}
else {
   result[4] = x13*x5 + x43;
}
}
        
static void coder_d5gdn2dt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x2 = (*endmember[0].d3mu0dT3)(T, P);
    double x3 = x1*x2;
    double x4 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x2*x7;
    double x9 = 3*(*endmember[1].d3mu0dT3)(T, P);
    double x10 = (*endmember[2].d3mu0dT3)(T, P);
    double x11 = (*endmember[3].d3mu0dT3)(T, P);
    double x12 = (*endmember[4].d3mu0dT3)(T, P);
    double x13 = 0.19999999999999998*T;
    double x14 = x13 - 1;
    double x15 = 1 - x13;
    double x16 = 1.0*sqrt(x15);
    double x17 = x16 - 4;
    double x18 = 0;
    double x19 = 1.2043214999999998*x18/x14;
    double x20 = pow(x15, -3.0/2.0);
    double x21 = (4 - x16 >= 0. ? 1. : 0.);
    double x22 = 1.2043214999999998*x20*x21;
    double x23 = 0.40144049999999998*x20*((x21)*(x21)*(x21));
    double x24 = 40.14405*T - 200.72024999999999;
    double x25 = pow(x14, -2);
    double x26 = x18*x25;
    double x27 = 0.0029999999999999992*x24*x26;
    double x28 = x21/pow(x15, 5.0/2.0);
    double x29 = 0.0029999999999999996*x24*x28;
    double x30 = x20*0;
    double x31 = 0.0009999999999999998*x24*x30;
    double x32 = fmin(4, x16);
    double x33 = ((x32)*(x32));
    double x34 = 0.60216074999999991*x26*x33;
    double x35 = 0.60216075000000002*x28*x33;
    double x36 = 0.20072024999999999*x30*x33;
    double x37 = 1.2043214999999998*((x21)*(x21))*x25*x32;
    double x38 = x18*x22*x32;
    double x39 = 3*n1*x2 + n2*x9 - n2*(-x19 + x22 + x23 + x27 + x29 - x31 + x34 + x35 - x36 - x37 - x38) + 3*n3*x10 + 3*n4*x11 + 3*n5*x12;
    double x40 = x39*x5;
    double x41 = x39*x6/((x4)*(x4)*(x4));
    double x42 = -0.054421768707482998*x40 + 0.01554907677356657*x41;
    double x43 = 3.0*x3 + x42 - 0.081632653061224497*x8;
    double x44 = x19 - x22 - x23 - x27 - x29 + x31 - x34 - x35 + x36 + x37 + x38 + x9;
    double x45 = x1*x44;
    double x46 = x44*x7;
    double x47 = 1.0*x45 - 0.027210884353741499*x46;
    double x48 = 3.0*x1;
    double x49 = 0.081632653061224497*x7;
    double x50 = x10*x48 - x10*x49;
    double x51 = x11*x48 - x11*x49 - 0.19047619047619049*x40 + 0.054421768707482998*x41;
    double x52 = x12*x48 - x12*x49;
    double x53 = x42 + x47;
    double x54 = x1*x10;
    double x55 = x10*x7;
    double x56 = x1*x12;
    double x57 = x12*x7;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 6.0*x3 + x42 - 0.16326530612244899*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x43 + x47;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x43 + x50;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 10.5*x3 + x51 - 0.2857142857142857*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x43 + x52;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x42 + 2.0*x45 - 0.054421768707482998*x46;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x50 + x53;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = 3.5*x45 - 0.095238095238095247*x46 + x51;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x52 + x53;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x42 + 6.0*x54 - 0.16326530612244899*x55;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x51 + 10.5*x54 - 0.2857142857142857*x55;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x42 + x50 + x52;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 21.0*x1*x11 - 0.5714285714285714*x11*x7 - 0.66666666666666674*x40 + 0.19047619047619049*x41;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = x51 + 10.5*x56 - 0.28571428571428575*x57;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x42 + 6.0*x56 - 0.16326530612244899*x57;
}
}
        
static void coder_d6gdn3dt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dT3)(T, P);
    double x2 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = pow(x2, -3);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = 3*(*endmember[1].d3mu0dT3)(T, P);
    double x10 = (*endmember[2].d3mu0dT3)(T, P);
    double x11 = (*endmember[3].d3mu0dT3)(T, P);
    double x12 = (*endmember[4].d3mu0dT3)(T, P);
    double x13 = 0.19999999999999998*T;
    double x14 = x13 - 1;
    double x15 = 1 - x13;
    double x16 = 1.0*sqrt(x15);
    double x17 = x16 - 4;
    double x18 = 0;
    double x19 = 1.2043214999999998*x18/x14;
    double x20 = pow(x15, -3.0/2.0);
    double x21 = (4 - x16 >= 0. ? 1. : 0.);
    double x22 = 1.2043214999999998*x20*x21;
    double x23 = 0.40144049999999998*x20*((x21)*(x21)*(x21));
    double x24 = 40.14405*T - 200.72024999999999;
    double x25 = pow(x14, -2);
    double x26 = x18*x25;
    double x27 = 0.0029999999999999992*x24*x26;
    double x28 = x21/pow(x15, 5.0/2.0);
    double x29 = 0.0029999999999999996*x24*x28;
    double x30 = x20*0;
    double x31 = 0.0009999999999999998*x24*x30;
    double x32 = fmin(4, x16);
    double x33 = ((x32)*(x32));
    double x34 = 0.60216074999999991*x26*x33;
    double x35 = 0.60216075000000002*x28*x33;
    double x36 = 0.20072024999999999*x30*x33;
    double x37 = 1.2043214999999998*((x21)*(x21))*x25*x32;
    double x38 = x18*x22*x32;
    double x39 = 3*n1*x1 + n2*x9 - n2*(-x19 + x22 + x23 + x27 + x29 - x31 + x34 + x35 - x36 - x37 - x38) + 3*n3*x10 + 3*n4*x11 + 3*n5*x12;
    double x40 = x39*x5;
    double x41 = x39*x6/((x2)*(x2)*(x2)*(x2));
    double x42 = 0.046647230320699715*x40 - 0.013327780091628489*x41;
    double x43 = -0.32653061224489799*x4 + x42 + 0.093294460641399415*x8;
    double x44 = x19 - x22 - x23 - x27 - x29 + x31 - x34 - x35 + x36 + x37 + x38 + x9;
    double x45 = x3*x44;
    double x46 = x44*x7;
    double x47 = -0.054421768707482998*x45 + 0.01554907677356657*x46;
    double x48 = 0.16326530612244899*x3;
    double x49 = -x10*x48;
    double x50 = 0.046647230320699715*x7;
    double x51 = x10*x50 + x49;
    double x52 = -x11*x48 + 0.16326530612244899*x40;
    double x53 = x11*x50 - 0.046647230320699715*x41 + x52;
    double x54 = -x12*x48 + x12*x50;
    double x55 = -0.16326530612244899*x4 + x42 + 0.046647230320699708*x8;
    double x56 = -0.108843537414966*x45 + 0.031098153547133141*x46;
    double x57 = x47 + x55;
    double x58 = -0.19047619047619049*x45 + 0.054421768707482998*x46;
    double x59 = -0.5714285714285714*x4;
    double x60 = x53 + x59 + 0.16326530612244899*x8;
    double x61 = x10*x3;
    double x62 = -0.32653061224489799*x61;
    double x63 = x10*x7;
    double x64 = x62 + 0.093294460641399429*x63;
    double x65 = -0.5714285714285714*x61;
    double x66 = 0.16326530612244899*x63 + x65;
    double x67 = x49 + 0.046647230320699708*x63;
    double x68 = x54 + x67;
    double x69 = x11*x3;
    double x70 = x11*x7;
    double x71 = 0.57142857142857151*x40 - 0.16326530612244899*x41;
    double x72 = -1.142857142857143*x69 + 0.32653061224489799*x70 + x71;
    double x73 = x12*x3;
    double x74 = x12*x7;
    double x75 = -0.046647230320699708*x41 + x52 + 0.046647230320699708*x70;
    double x76 = -0.57142857142857151*x73 + 0.16326530612244899*x74 + x75;
    double x77 = -0.32653061224489799*x73 + 0.093294460641399429*x74;
    double x78 = x42 + x56;
    double x79 = x42 + x47;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = -0.48979591836734698*x4 + x42 + 0.13994169096209913*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x43 + x47;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x43 + x51;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = -1.1428571428571428*x4 + x53 + 0.32653061224489799*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x43 + x54;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x55 + x56;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x51 + x57;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x58 + x60;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x54 + x57;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x55 + x64;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x60 + x66;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x55 + x68;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = -2.0*x4 + x72 + 0.5714285714285714*x8;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = x59 + x76 + 0.16326530612244897*x8;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x55 + x77;
}
if (x0) {
   result[15] = 0;
}
else {
   result[15] = x42 - 0.16326530612244899*x45 + 0.046647230320699715*x46;
}
if (x0) {
   result[16] = 0;
}
else {
   result[16] = x51 + x78;
}
if (x0) {
   result[17] = 0;
}
else {
   result[17] = -0.38095238095238099*x45 + 0.108843537414966*x46 + x53;
}
if (x0) {
   result[18] = 0;
}
else {
   result[18] = x54 + x78;
}
if (x0) {
   result[19] = 0;
}
else {
   result[19] = x64 + x79;
}
if (x0) {
   result[20] = 0;
}
else {
   result[20] = x53 + x58 + x66;
}
if (x0) {
   result[21] = 0;
}
else {
   result[21] = x68 + x79;
}
if (x0) {
   result[22] = 0;
}
else {
   result[22] = -0.66666666666666674*x45 + 0.19047619047619049*x46 + x72;
}
if (x0) {
   result[23] = 0;
}
else {
   result[23] = x58 + x76;
}
if (x0) {
   result[24] = 0;
}
else {
   result[24] = x77 + x79;
}
if (x0) {
   result[25] = 0;
}
else {
   result[25] = x42 - 0.48979591836734698*x61 + 0.13994169096209913*x63;
}
if (x0) {
   result[26] = 0;
}
else {
   result[26] = x53 - 1.1428571428571428*x61 + 0.32653061224489799*x63;
}
if (x0) {
   result[27] = 0;
}
else {
   result[27] = x42 + x54 + x62 + 0.093294460641399415*x63;
}
if (x0) {
   result[28] = 0;
}
else {
   result[28] = -2.0*x61 + 0.5714285714285714*x63 + x72;
}
if (x0) {
   result[29] = 0;
}
else {
   result[29] = 0.16326530612244897*x63 + x65 + x76;
}
if (x0) {
   result[30] = 0;
}
else {
   result[30] = x42 + x67 + x77;
}
if (x0) {
   result[31] = 0;
}
else {
   result[31] = 2.0*x40 - 0.57142857142857151*x41 - 6.0*x69 + 1.7142857142857144*x70;
}
if (x0) {
   result[32] = 0;
}
else {
   result[32] = -1.1428571428571428*x69 + 0.32653061224489793*x70 + x71 - 2.0*x73 + 0.57142857142857151*x74;
}
if (x0) {
   result[33] = 0;
}
else {
   result[33] = -1.142857142857143*x73 + 0.32653061224489799*x74 + x75;
}
if (x0) {
   result[34] = 0;
}
else {
   result[34] = x42 - 0.48979591836734698*x73 + 0.13994169096209913*x74;
}
}
        
static double coder_d3gdt2dp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P) + n3*(*endmember[2].d3mu0dT2dP)(T, P) + n4*(*endmember[3].d3mu0dT2dP)(T, P) + n5*(*endmember[4].d3mu0dT2dP)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d3mu0dT2dP)(T, P);
    double x6 = (*endmember[2].d3mu0dT2dP)(T, P);
    double x7 = (*endmember[3].d3mu0dT2dP)(T, P);
    double x8 = (*endmember[4].d3mu0dT2dP)(T, P);
    double x9 = n1*x0 + n2*x5 + n3*x6 + n4*x7 + n5*x8;
    double x10 = x2*x9;
    double x11 = x3*x9/((0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5)*(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5));
    double x12 = 3.0*x10 - 0.081632653061224497*x11;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x12;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x12 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x12 + x4*x6;
}
if (x1) {
   result[3] = x7;
}
else {
   result[3] = 10.5*x10 - 0.2857142857142857*x11 + x4*x7;
}
if (x1) {
   result[4] = x8;
}
else {
   result[4] = x12 + x4*x8;
}
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = x1*x2;
    double x4 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = (*endmember[1].d3mu0dT2dP)(T, P);
    double x10 = (*endmember[2].d3mu0dT2dP)(T, P);
    double x11 = (*endmember[3].d3mu0dT2dP)(T, P);
    double x12 = (*endmember[4].d3mu0dT2dP)(T, P);
    double x13 = n1*x1 + n2*x9 + n3*x10 + n4*x11 + n5*x12;
    double x14 = x13*x5;
    double x15 = x13*x6/((x4)*(x4)*(x4));
    double x16 = -0.16326530612244899*x14 + 0.046647230320699708*x15;
    double x17 = x16 + 3.0*x3 - 0.081632653061224497*x8;
    double x18 = 3.0*x2;
    double x19 = 0.081632653061224497*x7;
    double x20 = x18*x9 - x19*x9;
    double x21 = x10*x18 - x10*x19;
    double x22 = x11*x18 - x11*x19 - 0.5714285714285714*x14;
    double x23 = 0.16326530612244899*x15 + x22;
    double x24 = x12*x18 - x12*x19;
    double x25 = x2*x9;
    double x26 = x7*x9;
    double x27 = x16 + x20;
    double x28 = x10*x2;
    double x29 = x10*x7;
    double x30 = x12*x2;
    double x31 = x12*x7;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x16 + 6.0*x3 - 0.16326530612244899*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x17 + x20;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 + x21;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x23 + 10.5*x3 - 0.2857142857142857*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 + x24;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x16 + 6.0*x25 - 0.16326530612244899*x26;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x21 + x27;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x23 + 10.5*x25 - 0.2857142857142857*x26;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x24 + x27;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x16 + 6.0*x28 - 0.16326530612244899*x29;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x23 + 10.5*x28 - 0.2857142857142857*x29;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x16 + x21 + x24;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 21.0*x11*x2 - 0.5714285714285714*x11*x7 - 2.0*x14 + 0.5714285714285714*x15;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = 0.16326530612244897*x15 + x22 + 10.5*x30 - 0.2857142857142857*x31;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x16 + 6.0*x30 - 0.16326530612244899*x31;
}
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x2 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = pow(x2, -3);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = (*endmember[1].d3mu0dT2dP)(T, P);
    double x10 = (*endmember[2].d3mu0dT2dP)(T, P);
    double x11 = (*endmember[3].d3mu0dT2dP)(T, P);
    double x12 = (*endmember[4].d3mu0dT2dP)(T, P);
    double x13 = n1*x1 + n2*x9 + n3*x10 + n4*x11 + n5*x12;
    double x14 = x13*x5;
    double x15 = x13*x6/((x2)*(x2)*(x2)*(x2));
    double x16 = 0.13994169096209913*x14 - 0.039983340274885461*x15;
    double x17 = x16 - 0.32653061224489799*x4 + 0.093294460641399415*x8;
    double x18 = 0.16326530612244899*x3;
    double x19 = 0.046647230320699708*x7;
    double x20 = -x18*x9 + x19*x9;
    double x21 = -x10*x18 + x10*x19;
    double x22 = -x11*x18 + x11*x19 + 0.48979591836734693*x14;
    double x23 = -0.13994169096209913*x15 + x22;
    double x24 = -x12*x18 + x12*x19;
    double x25 = x16 - 0.16326530612244899*x4 + 0.046647230320699708*x8;
    double x26 = x3*x9;
    double x27 = x7*x9;
    double x28 = -0.32653061224489799*x26 + 0.093294460641399415*x27;
    double x29 = x20 + x25;
    double x30 = x23 - 0.5714285714285714*x4;
    double x31 = x30 + 0.16326530612244899*x8;
    double x32 = -0.5714285714285714*x26;
    double x33 = 0.16326530612244899*x27 + x32;
    double x34 = x10*x3;
    double x35 = x10*x7;
    double x36 = -0.32653061224489799*x34 + 0.093294460641399415*x35;
    double x37 = -0.5714285714285714*x34;
    double x38 = 0.16326530612244899*x35 + x37;
    double x39 = x21 + x24;
    double x40 = x11*x3;
    double x41 = -1.1428571428571428*x40;
    double x42 = x11*x7;
    double x43 = 1.7142857142857144*x14 - 0.48979591836734698*x15 + x41 + 0.32653061224489799*x42;
    double x44 = x12*x3;
    double x45 = x12*x7;
    double x46 = -0.5714285714285714*x44 + 0.16326530612244899*x45;
    double x47 = -0.32653061224489799*x44 + 0.093294460641399415*x45;
    double x48 = x16 + x28;
    double x49 = x16 + x20;
    double x50 = x23 + x46;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x16 - 0.48979591836734698*x4 + 0.13994169096209913*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x17 + x20;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 + x21;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x23 - 1.1428571428571428*x4 + 0.32653061224489799*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 + x24;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x25 + x28;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x21 + x29;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x31 + x33;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x24 + x29;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x25 + x36;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x31 + x38;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x25 + x39;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = -2.0*x4 + x43 + 0.5714285714285714*x8;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = x30 + x46 + 0.16326530612244897*x8;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x25 + x47;
}
if (x0) {
   result[15] = 0;
}
else {
   result[15] = x16 - 0.48979591836734698*x26 + 0.13994169096209913*x27;
}
if (x0) {
   result[16] = 0;
}
else {
   result[16] = x21 + x48;
}
if (x0) {
   result[17] = 0;
}
else {
   result[17] = x23 - 1.1428571428571428*x26 + 0.32653061224489799*x27;
}
if (x0) {
   result[18] = 0;
}
else {
   result[18] = x24 + x48;
}
if (x0) {
   result[19] = 0;
}
else {
   result[19] = x36 + x49;
}
if (x0) {
   result[20] = 0;
}
else {
   result[20] = x23 + x33 + x38;
}
if (x0) {
   result[21] = 0;
}
else {
   result[21] = x39 + x49;
}
if (x0) {
   result[22] = 0;
}
else {
   result[22] = -2.0*x26 + 0.5714285714285714*x27 + x43;
}
if (x0) {
   result[23] = 0;
}
else {
   result[23] = 0.16326530612244897*x27 + x32 + x50;
}
if (x0) {
   result[24] = 0;
}
else {
   result[24] = x47 + x49;
}
if (x0) {
   result[25] = 0;
}
else {
   result[25] = x16 - 0.48979591836734698*x34 + 0.13994169096209913*x35;
}
if (x0) {
   result[26] = 0;
}
else {
   result[26] = x23 - 1.1428571428571428*x34 + 0.32653061224489799*x35;
}
if (x0) {
   result[27] = 0;
}
else {
   result[27] = x16 + x24 + x36;
}
if (x0) {
   result[28] = 0;
}
else {
   result[28] = -2.0*x34 + 0.5714285714285714*x35 + x43;
}
if (x0) {
   result[29] = 0;
}
else {
   result[29] = 0.16326530612244897*x35 + x37 + x50;
}
if (x0) {
   result[30] = 0;
}
else {
   result[30] = x16 + x21 + x47;
}
if (x0) {
   result[31] = 0;
}
else {
   result[31] = 6.0*x14 - 1.7142857142857142*x15 - 6.0*x40 + 1.7142857142857142*x42;
}
if (x0) {
   result[32] = 0;
}
else {
   result[32] = 1.7142857142857142*x14 - 0.48979591836734687*x15 + x41 + 0.32653061224489793*x42 - 2.0*x44 + 0.5714285714285714*x45;
}
if (x0) {
   result[33] = 0;
}
else {
   result[33] = -0.1399416909620991*x15 + x22 - 1.1428571428571428*x44 + 0.32653061224489793*x45;
}
if (x0) {
   result[34] = 0;
}
else {
   result[34] = x16 - 0.48979591836734698*x44 + 0.13994169096209913*x45;
}
}
        
static double coder_d3gdtdp2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P) + n3*(*endmember[2].d3mu0dTdP2)(T, P) + n4*(*endmember[3].d3mu0dTdP2)(T, P) + n5*(*endmember[4].d3mu0dTdP2)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d3mu0dTdP2)(T, P);
    double x6 = (*endmember[2].d3mu0dTdP2)(T, P);
    double x7 = (*endmember[3].d3mu0dTdP2)(T, P);
    double x8 = (*endmember[4].d3mu0dTdP2)(T, P);
    double x9 = n1*x0 + n2*x5 + n3*x6 + n4*x7 + n5*x8;
    double x10 = x2*x9;
    double x11 = x3*x9/((0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5)*(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5));
    double x12 = 3.0*x10 - 0.081632653061224497*x11;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x12;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x12 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x12 + x4*x6;
}
if (x1) {
   result[3] = x7;
}
else {
   result[3] = 10.5*x10 - 0.2857142857142857*x11 + x4*x7;
}
if (x1) {
   result[4] = x8;
}
else {
   result[4] = x12 + x4*x8;
}
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = x1*x2;
    double x4 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = (*endmember[1].d3mu0dTdP2)(T, P);
    double x10 = (*endmember[2].d3mu0dTdP2)(T, P);
    double x11 = (*endmember[3].d3mu0dTdP2)(T, P);
    double x12 = (*endmember[4].d3mu0dTdP2)(T, P);
    double x13 = n1*x1 + n2*x9 + n3*x10 + n4*x11 + n5*x12;
    double x14 = x13*x5;
    double x15 = x13*x6/((x4)*(x4)*(x4));
    double x16 = -0.16326530612244899*x14 + 0.046647230320699708*x15;
    double x17 = x16 + 3.0*x3 - 0.081632653061224497*x8;
    double x18 = 3.0*x2;
    double x19 = 0.081632653061224497*x7;
    double x20 = x18*x9 - x19*x9;
    double x21 = x10*x18 - x10*x19;
    double x22 = x11*x18 - x11*x19 - 0.5714285714285714*x14;
    double x23 = 0.16326530612244899*x15 + x22;
    double x24 = x12*x18 - x12*x19;
    double x25 = x2*x9;
    double x26 = x7*x9;
    double x27 = x16 + x20;
    double x28 = x10*x2;
    double x29 = x10*x7;
    double x30 = x12*x2;
    double x31 = x12*x7;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x16 + 6.0*x3 - 0.16326530612244899*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x17 + x20;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 + x21;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x23 + 10.5*x3 - 0.2857142857142857*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 + x24;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x16 + 6.0*x25 - 0.16326530612244899*x26;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x21 + x27;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x23 + 10.5*x25 - 0.2857142857142857*x26;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x24 + x27;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x16 + 6.0*x28 - 0.16326530612244899*x29;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x23 + 10.5*x28 - 0.2857142857142857*x29;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x16 + x21 + x24;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 21.0*x11*x2 - 0.5714285714285714*x11*x7 - 2.0*x14 + 0.5714285714285714*x15;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = 0.16326530612244897*x15 + x22 + 10.5*x30 - 0.2857142857142857*x31;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x16 + 6.0*x30 - 0.16326530612244899*x31;
}
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x2 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = pow(x2, -3);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = (*endmember[1].d3mu0dTdP2)(T, P);
    double x10 = (*endmember[2].d3mu0dTdP2)(T, P);
    double x11 = (*endmember[3].d3mu0dTdP2)(T, P);
    double x12 = (*endmember[4].d3mu0dTdP2)(T, P);
    double x13 = n1*x1 + n2*x9 + n3*x10 + n4*x11 + n5*x12;
    double x14 = x13*x5;
    double x15 = x13*x6/((x2)*(x2)*(x2)*(x2));
    double x16 = 0.13994169096209913*x14 - 0.039983340274885461*x15;
    double x17 = x16 - 0.32653061224489799*x4 + 0.093294460641399415*x8;
    double x18 = 0.16326530612244899*x3;
    double x19 = 0.046647230320699708*x7;
    double x20 = -x18*x9 + x19*x9;
    double x21 = -x10*x18 + x10*x19;
    double x22 = -x11*x18 + x11*x19 + 0.48979591836734693*x14;
    double x23 = -0.13994169096209913*x15 + x22;
    double x24 = -x12*x18 + x12*x19;
    double x25 = x16 - 0.16326530612244899*x4 + 0.046647230320699708*x8;
    double x26 = x3*x9;
    double x27 = x7*x9;
    double x28 = -0.32653061224489799*x26 + 0.093294460641399415*x27;
    double x29 = x20 + x25;
    double x30 = x23 - 0.5714285714285714*x4;
    double x31 = x30 + 0.16326530612244899*x8;
    double x32 = -0.5714285714285714*x26;
    double x33 = 0.16326530612244899*x27 + x32;
    double x34 = x10*x3;
    double x35 = x10*x7;
    double x36 = -0.32653061224489799*x34 + 0.093294460641399415*x35;
    double x37 = -0.5714285714285714*x34;
    double x38 = 0.16326530612244899*x35 + x37;
    double x39 = x21 + x24;
    double x40 = x11*x3;
    double x41 = -1.1428571428571428*x40;
    double x42 = x11*x7;
    double x43 = 1.7142857142857144*x14 - 0.48979591836734698*x15 + x41 + 0.32653061224489799*x42;
    double x44 = x12*x3;
    double x45 = x12*x7;
    double x46 = -0.5714285714285714*x44 + 0.16326530612244899*x45;
    double x47 = -0.32653061224489799*x44 + 0.093294460641399415*x45;
    double x48 = x16 + x28;
    double x49 = x16 + x20;
    double x50 = x23 + x46;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x16 - 0.48979591836734698*x4 + 0.13994169096209913*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x17 + x20;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 + x21;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x23 - 1.1428571428571428*x4 + 0.32653061224489799*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 + x24;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x25 + x28;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x21 + x29;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x31 + x33;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x24 + x29;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x25 + x36;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x31 + x38;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x25 + x39;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = -2.0*x4 + x43 + 0.5714285714285714*x8;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = x30 + x46 + 0.16326530612244897*x8;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x25 + x47;
}
if (x0) {
   result[15] = 0;
}
else {
   result[15] = x16 - 0.48979591836734698*x26 + 0.13994169096209913*x27;
}
if (x0) {
   result[16] = 0;
}
else {
   result[16] = x21 + x48;
}
if (x0) {
   result[17] = 0;
}
else {
   result[17] = x23 - 1.1428571428571428*x26 + 0.32653061224489799*x27;
}
if (x0) {
   result[18] = 0;
}
else {
   result[18] = x24 + x48;
}
if (x0) {
   result[19] = 0;
}
else {
   result[19] = x36 + x49;
}
if (x0) {
   result[20] = 0;
}
else {
   result[20] = x23 + x33 + x38;
}
if (x0) {
   result[21] = 0;
}
else {
   result[21] = x39 + x49;
}
if (x0) {
   result[22] = 0;
}
else {
   result[22] = -2.0*x26 + 0.5714285714285714*x27 + x43;
}
if (x0) {
   result[23] = 0;
}
else {
   result[23] = 0.16326530612244897*x27 + x32 + x50;
}
if (x0) {
   result[24] = 0;
}
else {
   result[24] = x47 + x49;
}
if (x0) {
   result[25] = 0;
}
else {
   result[25] = x16 - 0.48979591836734698*x34 + 0.13994169096209913*x35;
}
if (x0) {
   result[26] = 0;
}
else {
   result[26] = x23 - 1.1428571428571428*x34 + 0.32653061224489799*x35;
}
if (x0) {
   result[27] = 0;
}
else {
   result[27] = x16 + x24 + x36;
}
if (x0) {
   result[28] = 0;
}
else {
   result[28] = -2.0*x34 + 0.5714285714285714*x35 + x43;
}
if (x0) {
   result[29] = 0;
}
else {
   result[29] = 0.16326530612244897*x35 + x37 + x50;
}
if (x0) {
   result[30] = 0;
}
else {
   result[30] = x16 + x21 + x47;
}
if (x0) {
   result[31] = 0;
}
else {
   result[31] = 6.0*x14 - 1.7142857142857142*x15 - 6.0*x40 + 1.7142857142857142*x42;
}
if (x0) {
   result[32] = 0;
}
else {
   result[32] = 1.7142857142857142*x14 - 0.48979591836734687*x15 + x41 + 0.32653061224489793*x42 - 2.0*x44 + 0.5714285714285714*x45;
}
if (x0) {
   result[33] = 0;
}
else {
   result[33] = -0.1399416909620991*x15 + x22 - 1.1428571428571428*x44 + 0.32653061224489793*x45;
}
if (x0) {
   result[34] = 0;
}
else {
   result[34] = x16 - 0.48979591836734698*x44 + 0.13994169096209913*x45;
}
}
        
static double coder_d3gdp3(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P) + n3*(*endmember[2].d3mu0dP3)(T, P) + n4*(*endmember[3].d3mu0dP3)(T, P) + n5*(*endmember[4].d3mu0dP3)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].d3mu0dP3)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d3mu0dP3)(T, P);
    double x6 = (*endmember[2].d3mu0dP3)(T, P);
    double x7 = (*endmember[3].d3mu0dP3)(T, P);
    double x8 = (*endmember[4].d3mu0dP3)(T, P);
    double x9 = n1*x0 + n2*x5 + n3*x6 + n4*x7 + n5*x8;
    double x10 = x2*x9;
    double x11 = x3*x9/((0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5)*(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5));
    double x12 = 3.0*x10 - 0.081632653061224497*x11;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x12;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x12 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x12 + x4*x6;
}
if (x1) {
   result[3] = x7;
}
else {
   result[3] = 10.5*x10 - 0.2857142857142857*x11 + x4*x7;
}
if (x1) {
   result[4] = x8;
}
else {
   result[4] = x12 + x4*x8;
}
}
        
static void coder_d5gdn2dp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dP3)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = x1*x2;
    double x4 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = (*endmember[1].d3mu0dP3)(T, P);
    double x10 = (*endmember[2].d3mu0dP3)(T, P);
    double x11 = (*endmember[3].d3mu0dP3)(T, P);
    double x12 = (*endmember[4].d3mu0dP3)(T, P);
    double x13 = n1*x1 + n2*x9 + n3*x10 + n4*x11 + n5*x12;
    double x14 = x13*x5;
    double x15 = x13*x6/((x4)*(x4)*(x4));
    double x16 = -0.16326530612244899*x14 + 0.046647230320699708*x15;
    double x17 = x16 + 3.0*x3 - 0.081632653061224497*x8;
    double x18 = 3.0*x2;
    double x19 = 0.081632653061224497*x7;
    double x20 = x18*x9 - x19*x9;
    double x21 = x10*x18 - x10*x19;
    double x22 = x11*x18 - x11*x19 - 0.5714285714285714*x14;
    double x23 = 0.16326530612244899*x15 + x22;
    double x24 = x12*x18 - x12*x19;
    double x25 = x2*x9;
    double x26 = x7*x9;
    double x27 = x16 + x20;
    double x28 = x10*x2;
    double x29 = x10*x7;
    double x30 = x12*x2;
    double x31 = x12*x7;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x16 + 6.0*x3 - 0.16326530612244899*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x17 + x20;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 + x21;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x23 + 10.5*x3 - 0.2857142857142857*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 + x24;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x16 + 6.0*x25 - 0.16326530612244899*x26;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x21 + x27;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x23 + 10.5*x25 - 0.2857142857142857*x26;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x24 + x27;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x16 + 6.0*x28 - 0.16326530612244899*x29;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x23 + 10.5*x28 - 0.2857142857142857*x29;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x16 + x21 + x24;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 21.0*x11*x2 - 0.5714285714285714*x11*x7 - 2.0*x14 + 0.5714285714285714*x15;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = 0.16326530612244897*x15 + x22 + 10.5*x30 - 0.2857142857142857*x31;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x16 + 6.0*x30 - 0.16326530612244899*x31;
}
}
        
static void coder_d6gdn3dp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dP3)(T, P);
    double x2 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = pow(x2, -3);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = (*endmember[1].d3mu0dP3)(T, P);
    double x10 = (*endmember[2].d3mu0dP3)(T, P);
    double x11 = (*endmember[3].d3mu0dP3)(T, P);
    double x12 = (*endmember[4].d3mu0dP3)(T, P);
    double x13 = n1*x1 + n2*x9 + n3*x10 + n4*x11 + n5*x12;
    double x14 = x13*x5;
    double x15 = x13*x6/((x2)*(x2)*(x2)*(x2));
    double x16 = 0.13994169096209913*x14 - 0.039983340274885461*x15;
    double x17 = x16 - 0.32653061224489799*x4 + 0.093294460641399415*x8;
    double x18 = 0.16326530612244899*x3;
    double x19 = 0.046647230320699708*x7;
    double x20 = -x18*x9 + x19*x9;
    double x21 = -x10*x18 + x10*x19;
    double x22 = -x11*x18 + x11*x19 + 0.48979591836734693*x14;
    double x23 = -0.13994169096209913*x15 + x22;
    double x24 = -x12*x18 + x12*x19;
    double x25 = x16 - 0.16326530612244899*x4 + 0.046647230320699708*x8;
    double x26 = x3*x9;
    double x27 = x7*x9;
    double x28 = -0.32653061224489799*x26 + 0.093294460641399415*x27;
    double x29 = x20 + x25;
    double x30 = x23 - 0.5714285714285714*x4;
    double x31 = x30 + 0.16326530612244899*x8;
    double x32 = -0.5714285714285714*x26;
    double x33 = 0.16326530612244899*x27 + x32;
    double x34 = x10*x3;
    double x35 = x10*x7;
    double x36 = -0.32653061224489799*x34 + 0.093294460641399415*x35;
    double x37 = -0.5714285714285714*x34;
    double x38 = 0.16326530612244899*x35 + x37;
    double x39 = x21 + x24;
    double x40 = x11*x3;
    double x41 = -1.1428571428571428*x40;
    double x42 = x11*x7;
    double x43 = 1.7142857142857144*x14 - 0.48979591836734698*x15 + x41 + 0.32653061224489799*x42;
    double x44 = x12*x3;
    double x45 = x12*x7;
    double x46 = -0.5714285714285714*x44 + 0.16326530612244899*x45;
    double x47 = -0.32653061224489799*x44 + 0.093294460641399415*x45;
    double x48 = x16 + x28;
    double x49 = x16 + x20;
    double x50 = x23 + x46;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x16 - 0.48979591836734698*x4 + 0.13994169096209913*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x17 + x20;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 + x21;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x23 - 1.1428571428571428*x4 + 0.32653061224489799*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 + x24;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x25 + x28;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x21 + x29;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x31 + x33;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x24 + x29;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x25 + x36;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x31 + x38;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x25 + x39;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = -2.0*x4 + x43 + 0.5714285714285714*x8;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = x30 + x46 + 0.16326530612244897*x8;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x25 + x47;
}
if (x0) {
   result[15] = 0;
}
else {
   result[15] = x16 - 0.48979591836734698*x26 + 0.13994169096209913*x27;
}
if (x0) {
   result[16] = 0;
}
else {
   result[16] = x21 + x48;
}
if (x0) {
   result[17] = 0;
}
else {
   result[17] = x23 - 1.1428571428571428*x26 + 0.32653061224489799*x27;
}
if (x0) {
   result[18] = 0;
}
else {
   result[18] = x24 + x48;
}
if (x0) {
   result[19] = 0;
}
else {
   result[19] = x36 + x49;
}
if (x0) {
   result[20] = 0;
}
else {
   result[20] = x23 + x33 + x38;
}
if (x0) {
   result[21] = 0;
}
else {
   result[21] = x39 + x49;
}
if (x0) {
   result[22] = 0;
}
else {
   result[22] = -2.0*x26 + 0.5714285714285714*x27 + x43;
}
if (x0) {
   result[23] = 0;
}
else {
   result[23] = 0.16326530612244897*x27 + x32 + x50;
}
if (x0) {
   result[24] = 0;
}
else {
   result[24] = x47 + x49;
}
if (x0) {
   result[25] = 0;
}
else {
   result[25] = x16 - 0.48979591836734698*x34 + 0.13994169096209913*x35;
}
if (x0) {
   result[26] = 0;
}
else {
   result[26] = x23 - 1.1428571428571428*x34 + 0.32653061224489799*x35;
}
if (x0) {
   result[27] = 0;
}
else {
   result[27] = x16 + x24 + x36;
}
if (x0) {
   result[28] = 0;
}
else {
   result[28] = -2.0*x34 + 0.5714285714285714*x35 + x43;
}
if (x0) {
   result[29] = 0;
}
else {
   result[29] = 0.16326530612244897*x35 + x37 + x50;
}
if (x0) {
   result[30] = 0;
}
else {
   result[30] = x16 + x21 + x47;
}
if (x0) {
   result[31] = 0;
}
else {
   result[31] = 6.0*x14 - 1.7142857142857142*x15 - 6.0*x40 + 1.7142857142857142*x42;
}
if (x0) {
   result[32] = 0;
}
else {
   result[32] = 1.7142857142857142*x14 - 0.48979591836734687*x15 + x41 + 0.32653061224489793*x42 - 2.0*x44 + 0.5714285714285714*x45;
}
if (x0) {
   result[33] = 0;
}
else {
   result[33] = -0.1399416909620991*x15 + x22 - 1.1428571428571428*x44 + 0.32653061224489793*x45;
}
if (x0) {
   result[34] = 0;
}
else {
   result[34] = x16 - 0.48979591836734698*x44 + 0.13994169096209913*x45;
}
}
        
static double coder_s(double T, double P, double n[5]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[5]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[5]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[5]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[5]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[5]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[5]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[5]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[5]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[5]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[5]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[5]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[5]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[5]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

