#include <math.h>


static double coder_g(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n4 + n5;
    double x1 = n1 + n2 + n3;
    double x2 = x0 + x1;
    double x3 = 1.0/x2;
    double x4 = n1*(*endmember[0].mu0)(T, P);
    double x5 = n2*(*endmember[1].mu0)(T, P);
    double x6 = n3*(*endmember[2].mu0)(T, P);
    double x7 = n4*(*endmember[3].mu0)(T, P);
    double x8 = n5*(*endmember[4].mu0)(T, P);
    double x9 = 1.0*n4;
    double x10 = n5 + x1;
    double x11 = T*(3.0*n2*log(n2*x3) + 3.0*n3*log(n3*x3) + 1.9999999980000001*n5*(log(n5*x3) - 0.40546510910816402) + 1.0*x0*log(x0*x3) + 1.0*x1*log(x1*x3) + 1.0*x10*log(x10*x3) + x9*log(n4*x3) + (3.0*n1 + 3.0*n4 + 0.99999999900000003*n5)*log(x3*(1.0*n1 + 0.33333333300000001*n5 + x9)));
    double x12 = 0.82399999999999995*P + 168800.0;
    double x13 = 181600.0*n4 + 183200.0*n5;
    double x14 = 0.0625*n1*(n3*x12 + x13) + 0.0625*n2*(168800.0*n3 + x13) + 0.0625*n3*(n1*x12 + 168800.0*n2 + 488000.0*n4 + 485600.0*n5) + 0.0625*n4*(181600.0*n1 + 181600.0*n2 + 488000.0*n3 + 568000.0*n5) + 0.0625*n5*(183200.0*n1 + 183200.0*n2 + 485600.0*n3 + 568000.0*n4);
    double x15 = fmin(4, 1.0*sqrt(1 - 0.13333333333333333*T));

if (T >= 7.5) {
   result = x3*(x14 + 1.0*x2*(-n2*(40.14405*T - 200.72024999999999) + 8.3144626181532395*x11 + x4 + x5 + x6 + x7 + x8));
}
else {
   result = x3*(x14 + 0.33333333333333331*x2*(n2*(301.080375*((x15)*(x15)*(x15)) + (120.43215000000001*T - 903.24112500000001)*(x15 - 1) - 301.080375) + 24.943387854459719*x11 + 3*x4 + 3*x5 + 3*x6 + 3*x7 + 3*x8));
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n4 + n5;
    double x1 = n1 + n2 + n3;
    double x2 = x0 + x1;
    double x3 = pow(x2, -2);
    double x4 = (*endmember[0].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[1].mu0)(T, P);
    double x7 = n2*x6;
    double x8 = (*endmember[2].mu0)(T, P);
    double x9 = n3*x8;
    double x10 = (*endmember[3].mu0)(T, P);
    double x11 = n4*x10;
    double x12 = (*endmember[4].mu0)(T, P);
    double x13 = n5*x12;
    double x14 = 40.14405*T;
    double x15 = x14 - 200.72024999999999;
    double x16 = 1.0/x2;
    double x17 = n2*x16;
    double x18 = 3.0*log(x17);
    double x19 = n3*x16;
    double x20 = 3.0*log(x19);
    double x21 = log(n4*x16);
    double x22 = 1.0*n4;
    double x23 = n5*x16;
    double x24 = log(x23);
    double x25 = 1.0*log(x0*x16);
    double x26 = 1.0*log(x1*x16);
    double x27 = n5 + x1;
    double x28 = 1.0*log(x16*x27);
    double x29 = 3.0*n1 + 3.0*n4 + 0.99999999900000003*n5;
    double x30 = 1.0*n1;
    double x31 = 0.33333333300000001*n5 + x22 + x30;
    double x32 = log(x16*x31);
    double x33 = n2*x18 + n3*x20 + 1.9999999980000001*n5*(x24 - 0.40546510910816402) + x0*x25 + x1*x26 + x21*x22 + x27*x28 + x29*x32;
    double x34 = 8.3144626181532395*T;
    double x35 = x33*x34;
    double x36 = 1.0*x2;
    double x37 = 0.10299999999999999*P + 21100.0;
    double x38 = n3*x37;
    double x39 = 181600.0*n4 + 183200.0*n5;
    double x40 = 0.0625*n1;
    double x41 = n1*x37;
    double x42 = 0.0625*n3;
    double x43 = 0.0625*n2*(168800.0*n3 + x39) + 0.0625*n4*(181600.0*n1 + 181600.0*n2 + 488000.0*n3 + 568000.0*n5) + 0.0625*n5*(183200.0*n1 + 183200.0*n2 + 485600.0*n3 + 568000.0*n4) + x40*(8.0*x38 + x39) + x42*(168800.0*n2 + 488000.0*n4 + 485600.0*n5 + 8.0*x41);
    double x44 = -x3*(x36*(-n2*x15 + x11 + x13 + x35 + x5 + x7 + x9) + x43);
    double x45 = 1.0*n5;
    double x46 = x22 + x45;
    double x47 = 1.0*n2;
    double x48 = 1.0*n3;
    double x49 = x30 + x47 + x48;
    double x50 = x46 + x49;
    double x51 = -3.0*x17;
    double x52 = -3.0*x19;
    double x53 = -1.9999999980000001*x23;
    double x54 = -x3*x31;
    double x55 = x2*x29/x31;
    double x56 = 3.0*x32 + x51 + x52 + x53 + x55*(1.0*x16 + x54);
    double x57 = x45 + x49;
    double x58 = -x16*x22 + x2*x57*(x16 - x27*x3)/x27 + x28;
    double x59 = -x16*x46 + x26 + x58 + x2*x49*(-x1*x3 + x16)/x1;
    double x60 = x56 + x59;
    double x61 = x10*x22 + x12*x45 + x30*x4 + x35 + x47*x6 + x48*x8;
    double x62 = -x15*x47 + x61;
    double x63 = 0.82399999999999995*P + 168800.0;
    double x64 = 22700.0*n4 + 22900.0*n5;
    double x65 = 0.5*x38 + x42*x63 + x64;
    double x66 = T >= 7.5;
    double x67 = fmin(4, 1.0*sqrt(1 - 0.13333333333333333*T));
    double x68 = 301.080375*((x67)*(x67)*(x67)) + (120.43215000000001*T - 903.24112500000001)*(x67 - 1) - 301.080375;
    double x69 = 24.943387854459719*T;
    double x70 = -x3*(0.33333333333333331*x2*(n2*x68 + 3*x11 + 3*x13 + x33*x69 + 3*x5 + 3*x7 + 3*x9) + x43);
    double x71 = 0.33333333333333331*n2;
    double x72 = 0.33333333333333331*n1 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5 + x71;
    double x73 = x61 + x68*x71;
    double x74 = 3.0*x2;
    double x75 = -x16*x29 + x53 + x59;
    double x76 = x18 + x52 + x74*(-n2*x3 + x16) + x75;
    double x77 = 21100.0*n3 + x64;
    double x78 = x20 + x51 + x74*(-n3*x3 + x16) + x75;
    double x79 = 21100.0*n2 + 61000.0*n4 + 60700.0*n5 + x40*x63 + 0.5*x41;
    double x80 = -x16*x49 + x25 + x2*x46*(-x0*x3 + x16)/x0;
    double x81 = -x16*x57 + 1.0*x21 + x36*(-n4*x3 + x16) + x56 + x80;
    double x82 = 22700.0*n1 + 22700.0*n2 + 61000.0*n3 + 71000.0*n5;
    double x83 = 1.9999999980000001*x2*(-n5*x3 + x16) + 1.9999999980000001*x24 + 0.99999999900000003*x32 + x51 + x52 + x55*(0.33333333300000001*x16 + x54) + x58 + x80 - 0.81093021740539784;
    double x84 = 22900.0*n1 + 22900.0*n2 + 60700.0*n3 + 71000.0*n4;

if (x66) {
   result[0] = x16*(x50*(x34*x60 + x4) + x62 + x65) + x44;
}
else {
   result[0] = x16*(x65 + x72*(3*x4 + x60*x69) + x73) + x70;
}
if (x66) {
   result[1] = x16*(x50*(-x14 + x34*x76 + x6 + 200.72024999999999) + x62 + x77) + x44;
}
else {
   result[1] = x16*(x72*(3*x6 + x68 + x69*x76) + x73 + x77) + x70;
}
if (x66) {
   result[2] = x16*(x50*(x34*x78 + x8) + x62 + x79) + x44;
}
else {
   result[2] = x16*(x72*(x69*x78 + 3*x8) + x73 + x79) + x70;
}
if (x66) {
   result[3] = x16*(x50*(x10 + x34*x81) + x62 + x82) + x44;
}
else {
   result[3] = x16*(x72*(3*x10 + x69*x81) + x73 + x82) + x70;
}
if (x66) {
   result[4] = x16*(x50*(x12 + x34*x83) + x62 + x84) + x44;
}
else {
   result[4] = x16*(x72*(3*x12 + x69*x83) + x73 + x84) + x70;
}
}
        
static void coder_d2gdn2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n3*x4;
    double x6 = (*endmember[3].mu0)(T, P);
    double x7 = n4*x6;
    double x8 = (*endmember[4].mu0)(T, P);
    double x9 = n5*x8;
    double x10 = 40.14405*T;
    double x11 = x10 - 200.72024999999999;
    double x12 = n4 + n5;
    double x13 = n1 + n2 + n3;
    double x14 = x12 + x13;
    double x15 = 1.0/x14;
    double x16 = n2*x15;
    double x17 = 3.0*log(x16);
    double x18 = n3*x15;
    double x19 = 3.0*log(x18);
    double x20 = log(n4*x15);
    double x21 = 1.0*n4;
    double x22 = n5*x15;
    double x23 = log(x22);
    double x24 = 1.0*log(x12*x15);
    double x25 = 1.0*log(x13*x15);
    double x26 = n5 + x13;
    double x27 = 1.0*log(x15*x26);
    double x28 = 3.0*n1 + 3.0*n4 + 0.99999999900000003*n5;
    double x29 = 1.0*n1;
    double x30 = 0.33333333300000001*n5 + x21 + x29;
    double x31 = log(x15*x30);
    double x32 = T*(n2*x17 + n3*x19 + 1.9999999980000001*n5*(x23 - 0.40546510910816402) + x12*x24 + x13*x25 + x20*x21 + x26*x27 + x28*x31);
    double x33 = 8.3144626181532395*x32;
    double x34 = 1.0*x14;
    double x35 = 0.10299999999999999*P + 21100.0;
    double x36 = n3*x35;
    double x37 = 181600.0*n4 + 183200.0*n5;
    double x38 = 0.0625*n1;
    double x39 = n1*x35;
    double x40 = 0.0625*n3;
    double x41 = 0.0625*n2*(168800.0*n3 + x37) + 0.0625*n4*(181600.0*n1 + 181600.0*n2 + 488000.0*n3 + 568000.0*n5) + 0.0625*n5*(183200.0*n1 + 183200.0*n2 + 485600.0*n3 + 568000.0*n4) + x38*(8.0*x36 + x37) + x40*(168800.0*n2 + 488000.0*n4 + 485600.0*n5 + 8.0*x39);
    double x42 = pow(x14, -3);
    double x43 = 2*x42;
    double x44 = x43*(x34*(-n2*x11 + x1 + x3 + x33 + x5 + x7 + x9) + x41);
    double x45 = 1.0*n5;
    double x46 = x21 + x45;
    double x47 = 1.0*n2;
    double x48 = 1.0*n3;
    double x49 = x29 + x47 + x48;
    double x50 = x46 + x49;
    double x51 = -3.0*x16;
    double x52 = -3.0*x18;
    double x53 = -1.9999999980000001*x22;
    double x54 = 1.0*x15;
    double x55 = pow(x14, -2);
    double x56 = -x30*x55;
    double x57 = x54 + x56;
    double x58 = 1.0/x30;
    double x59 = x28*x58;
    double x60 = x57*x59;
    double x61 = x14*x60 + 3.0*x31 + x51 + x52 + x53;
    double x62 = 1.0/x13;
    double x63 = -x13*x55 + x15;
    double x64 = x62*x63;
    double x65 = x49*x64;
    double x66 = x45 + x49;
    double x67 = 1.0/x26;
    double x68 = x15 - x26*x55;
    double x69 = x67*x68;
    double x70 = x66*x69;
    double x71 = x14*x70 - x15*x21 + x27;
    double x72 = x14*x65 - x15*x46 + x25 + x71;
    double x73 = T*(x61 + x72);
    double x74 = 8.3144626181532395*x73;
    double x75 = x0*x29 + x2*x47 + x21*x6 + x33 + x4*x48 + x45*x8;
    double x76 = -x11*x47 + x75;
    double x77 = 0.82399999999999995*P + 168800.0;
    double x78 = 22700.0*n4 + 22900.0*n5;
    double x79 = 0.5*x36 + x40*x77 + x78;
    double x80 = x50*(x0 + x74) + x76 + x79;
    double x81 = 2*x55;
    double x82 = x14*x57;
    double x83 = x58*x82;
    double x84 = -2.0*x55;
    double x85 = x30*x43;
    double x86 = x14*x59;
    double x87 = x28/((x30)*(x30));
    double x88 = -x34*x57*x87 + 6.0*x83 + x86*(x84 + x85);
    double x89 = n2*x55;
    double x90 = 3.0*x89;
    double x91 = x60 + x90;
    double x92 = x46*x55;
    double x93 = n3*x55;
    double x94 = 3.0*x93;
    double x95 = n5*x55;
    double x96 = 1.9999999980000001*x95;
    double x97 = x94 + x96;
    double x98 = x21*x55;
    double x99 = x70 + x98;
    double x100 = x65 + x92 + x97 + x99;
    double x101 = 2.0*x14;
    double x102 = -x81;
    double x103 = x26*x43;
    double x104 = x14*x66;
    double x105 = x104*x67;
    double x106 = x101*x69 - x104*x68/((x26)*(x26)) + x105*(x102 + x103);
    double x107 = x100 + x106;
    double x108 = x13*x43;
    double x109 = x14*x49;
    double x110 = x109*x62;
    double x111 = x101*x64 - x109*x63/((x13)*(x13)) + x110*(x102 + x108);
    double x112 = x107 + x111;
    double x113 = x112 + x91;
    double x114 = T*(x113 + x88);
    double x115 = 8.3144626181532395*x50;
    double x116 = 2.0*x0 + 16.628925236306479*x73;
    double x117 = T >= 7.5;
    double x118 = fmin(4, 1.0*sqrt(1 - 0.13333333333333333*T));
    double x119 = ((x118)*(x118)*(x118));
    double x120 = (120.43215000000001*T - 903.24112500000001)*(x118 - 1);
    double x121 = 301.080375*x119 + x120 - 301.080375;
    double x122 = x43*(0.33333333333333331*x14*(n2*x121 + 3*x1 + 3*x3 + 24.943387854459719*x32 + 3*x5 + 3*x7 + 3*x9) + x41);
    double x123 = 0.33333333333333331*n2;
    double x124 = 0.33333333333333331*n1 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5 + x123;
    double x125 = x121*x123 + x75;
    double x126 = x124*(3*x0 + 24.943387854459719*x73) + x125 + x79;
    double x127 = 24.943387854459719*x124;
    double x128 = 1.0*x2;
    double x129 = 3.0*x14;
    double x130 = x129*(x15 - x89);
    double x131 = -x15*x28 + x53 + x72;
    double x132 = T*(x130 + x131 + x17 + x52);
    double x133 = 8.3144626181532395*x132;
    double x134 = -x10 + x133;
    double x135 = x134 + 200.72024999999999;
    double x136 = -1.0*x55;
    double x137 = T*(x113 - 6.0*x15 + x86*(x136 + x85));
    double x138 = 1.0*x0 + x74;
    double x139 = x115*x137 + x138;
    double x140 = 21100.0*n3 + x78;
    double x141 = x140 + x50*(x135 + x2) + x76;
    double x142 = -x141*x55;
    double x143 = x44 - x55*x80;
    double x144 = x127*x137 + x138;
    double x145 = 100.360125*x119 + 0.33333333333333331*x120 + x128 + x133;
    double x146 = x124*(x121 + 24.943387854459719*x132 + 3*x2) + x125 + x140;
    double x147 = -x146*x55;
    double x148 = x122 - x126*x55;
    double x149 = x129*(x15 - x93);
    double x150 = T*(x131 + x149 + x19 + x51);
    double x151 = 8.3144626181532395*x150;
    double x152 = x151 + 1.0*x4;
    double x153 = x152 + x35;
    double x154 = 21100.0*n2 + 61000.0*n4 + 60700.0*n5 + x38*x77 + 0.5*x39;
    double x155 = x154 + x50*(x151 + x4) + x76;
    double x156 = -x155*x55;
    double x157 = x124*(24.943387854459719*x150 + 3*x4) + x125 + x154;
    double x158 = -x157*x55;
    double x159 = -x55;
    double x160 = x105*(x103 + x159);
    double x161 = x100 + x160;
    double x162 = x110*(x108 + x159);
    double x163 = x162 + x91;
    double x164 = T*(-4.0*x15 + x161 + x163 + x88);
    double x165 = x34*(-n4*x55 + x15);
    double x166 = 1.0/x12;
    double x167 = -x12*x55 + x15;
    double x168 = x166*x167;
    double x169 = x168*x46;
    double x170 = x14*x169 - x15*x49 + x24;
    double x171 = T*(-x15*x66 + x165 + x170 + 1.0*x20 + x61);
    double x172 = 8.3144626181532395*x171;
    double x173 = x172 + 1.0*x6;
    double x174 = x138 + x173 + 22700.0;
    double x175 = 22700.0*n1 + 22700.0*n2 + 61000.0*n3 + 71000.0*n5;
    double x176 = x175 + x50*(x172 + x6) + x76;
    double x177 = -x176*x55;
    double x178 = x124*(24.943387854459719*x171 + 3*x6) + x125 + x175;
    double x179 = -x178*x55;
    double x180 = 0.33333333300000001*x15 + x56;
    double x181 = x180*x58;
    double x182 = 0.33333333300000001*x87;
    double x183 = x129*x181 - x182*x82 + 0.99999999900000003*x83 + x86*(-1.3333333330000001*x55 + x85);
    double x184 = T*(x107 - 3.9999999979999998*x15 + x163 + x183);
    double x185 = 1.9999999980000001*x14;
    double x186 = x185*(x15 - x95);
    double x187 = x180*x59;
    double x188 = T*(x14*x187 + x170 + x186 + 1.9999999980000001*x23 + 0.99999999900000003*x31 + x51 + x52 + x71 - 0.81093021740539784);
    double x189 = 8.3144626181532395*x188;
    double x190 = x189 + 1.0*x8;
    double x191 = x138 + x190 + 22900.0;
    double x192 = 22900.0*n1 + 22900.0*n2 + 60700.0*n3 + 71000.0*n4;
    double x193 = x192 + x50*(x189 + x8) + x76;
    double x194 = -x193*x55;
    double x195 = x124*(24.943387854459719*x188 + 3*x8) + x125 + x192;
    double x196 = -x195*x55;
    double x197 = x28*x55;
    double x198 = -x90;
    double x199 = 3.0*x15;
    double x200 = -6.0*x55;
    double x201 = 6.0*x42;
    double x202 = n2*x201;
    double x203 = T*(x112 + x14*(x200 + x202) + x197 + x198 + x199 + x130/n2);
    double x204 = 16.628925236306479*x132 + 2.0*x2;
    double x205 = -3.0*x55;
    double x206 = x14*(x202 + x205) + x198;
    double x207 = x107 + x206;
    double x208 = x111 + x197;
    double x209 = T*(-x199 + x207 + x208);
    double x210 = x128 + x134;
    double x211 = x142 + x44;
    double x212 = x122 + x147;
    double x213 = x162 + x197;
    double x214 = -7.0*x15 + x213;
    double x215 = T*(x161 + x206 + x214);
    double x216 = -4.9999999969999998*x15 + x213;
    double x217 = T*(x207 + x216);
    double x218 = n3*x201;
    double x219 = x90 + x99;
    double x220 = x219 + x65 + x92 - x94 + x96;
    double x221 = T*(x106 + x14*(x200 + x218) + x199 + x208 + x220 + x149/n3);
    double x222 = 16.628925236306479*x150 + 2.0*x4;
    double x223 = x14*(x205 + x218) + x220;
    double x224 = T*(x160 + x214 + x223);
    double x225 = x152 + x173 + 61000.0;
    double x226 = x156 + x44;
    double x227 = x122 + x158;
    double x228 = T*(x106 + x216 + x223);
    double x229 = x152 + x190 + 60700.0;
    double x230 = 2.0*n4*x42;
    double x231 = x14*x46;
    double x232 = x101*x168 + x166*x231*(x102 + x12*x43) + x169 + x49*x55 - x167*x231/((x12)*(x12));
    double x233 = x232 + x55*x66 + x91 + x97 - x98;
    double x234 = T*(x14*(x230 + x84) + x233 + x54 + x88 + x165/n4);
    double x235 = 16.628925236306479*x171 + 2.0*x6;
    double x236 = T*(x14*(x136 + x230) - 2.9999999979999998*x15 + x183 + x233);
    double x237 = x173 + x190 + 71000.0;
    double x238 = T*(x106 - x14*x180*x182 + x14*(3.9999999960000001*n5*x42 - 3.9999999960000001*x55) + 1.9999999980000001*x15 + x181*x185 + x187 + x219 + x232 + x86*(-0.66666666600000002*x55 + x85) + x94 - x96 + x186/n5);
    double x239 = 16.628925236306479*x188 + 2.0*x8;

if (x117) {
   result[0] = x15*(x114*x115 + x116) + x44 - x80*x81;
}
else {
   result[0] = x122 - x126*x81 + x15*(x114*x127 + x116);
}
if (x117) {
   result[1] = x142 + x143 + x15*(x128 + x135 + x139);
}
else {
   result[1] = x147 + x148 + x15*(x144 + x145 - 100.360125);
}
if (x117) {
   result[2] = x143 + x15*(x139 + x153) + x156;
}
else {
   result[2] = x148 + x15*(x144 + x153) + x158;
}
if (x117) {
   result[3] = x143 + x15*(x115*x164 + x174) + x177;
}
else {
   result[3] = x148 + x15*(x127*x164 + x174) + x179;
}
if (x117) {
   result[4] = x143 + x15*(x115*x184 + x191) + x194;
}
else {
   result[4] = x148 + x15*(x127*x184 + x191) + x196;
}
if (x117) {
   result[5] = -x141*x81 + x15*(-80.2881*T + x115*x203 + x204 + 401.44049999999999) + x44;
}
else {
   result[5] = x122 - x146*x81 + x15*(200.72024999999999*x119 + 0.66666666666666663*x120 + x127*x203 + x204 - 200.72024999999999);
}
if (x117) {
   result[6] = x15*(x115*x209 + x152 + x210 + 21300.720249999998) + x156 + x211;
}
else {
   result[6] = x15*(x127*x209 + x145 + x152 + 20999.639875000001) + x158 + x212;
}
if (x117) {
   result[7] = x15*(x115*x215 + x173 + x210 + 22900.720249999998) + x177 + x211;
}
else {
   result[7] = x15*(x127*x215 + x145 + x173 + 22599.639875000001) + x179 + x212;
}
if (x117) {
   result[8] = x15*(x115*x217 + x190 + x210 + 23100.720249999998) + x194 + x211;
}
else {
   result[8] = x15*(x127*x217 + x145 + x190 + 22799.639875000001) + x196 + x212;
}
if (x117) {
   result[9] = x15*(x115*x221 + x222) - x155*x81 + x44;
}
else {
   result[9] = x122 + x15*(x127*x221 + x222) - x157*x81;
}
if (x117) {
   result[10] = x15*(x115*x224 + x225) + x177 + x226;
}
else {
   result[10] = x15*(x127*x224 + x225) + x179 + x227;
}
if (x117) {
   result[11] = x15*(x115*x228 + x229) + x194 + x226;
}
else {
   result[11] = x15*(x127*x228 + x229) + x196 + x227;
}
if (x117) {
   result[12] = x15*(x115*x234 + x235) - x176*x81 + x44;
}
else {
   result[12] = x122 + x15*(x127*x234 + x235) - x178*x81;
}
if (x117) {
   result[13] = x15*(x115*x236 + x237) + x177 + x194 + x44;
}
else {
   result[13] = x122 + x15*(x127*x236 + x237) + x179 + x196;
}
if (x117) {
   result[14] = x15*(x115*x238 + x239) - x193*x81 + x44;
}
else {
   result[14] = x122 + x15*(x127*x238 + x239) - x195*x81;
}
}
        
static void coder_d3gdn3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n3*x4;
    double x6 = (*endmember[3].mu0)(T, P);
    double x7 = n4*x6;
    double x8 = (*endmember[4].mu0)(T, P);
    double x9 = n5*x8;
    double x10 = 40.14405*T;
    double x11 = x10 - 200.72024999999999;
    double x12 = n4 + n5;
    double x13 = n1 + n2 + n3;
    double x14 = x12 + x13;
    double x15 = 1.0/x14;
    double x16 = n2*x15;
    double x17 = 3.0*log(x16);
    double x18 = n3*x15;
    double x19 = 3.0*log(x18);
    double x20 = log(n4*x15);
    double x21 = 1.0*n4;
    double x22 = n5*x15;
    double x23 = log(x22);
    double x24 = 1.0*log(x12*x15);
    double x25 = 1.0*log(x13*x15);
    double x26 = n5 + x13;
    double x27 = 1.0*log(x15*x26);
    double x28 = 3.0*n1 + 3.0*n4 + 0.99999999900000003*n5;
    double x29 = 1.0*n1;
    double x30 = 0.33333333300000001*n5 + x21 + x29;
    double x31 = log(x15*x30);
    double x32 = n2*x17 + n3*x19 + 1.9999999980000001*n5*(x23 - 0.40546510910816402) + x12*x24 + x13*x25 + x20*x21 + x26*x27 + x28*x31;
    double x33 = 8.3144626181532395*T;
    double x34 = x32*x33;
    double x35 = 1.0*x14;
    double x36 = 0.10299999999999999*P + 21100.0;
    double x37 = 8.0*x36;
    double x38 = 181600.0*n4 + 183200.0*n5;
    double x39 = 0.0625*n1;
    double x40 = 0.0625*n3;
    double x41 = 0.0625*n2*(168800.0*n3 + x38) + 0.0625*n4*(181600.0*n1 + 181600.0*n2 + 488000.0*n3 + 568000.0*n5) + 0.0625*n5*(183200.0*n1 + 183200.0*n2 + 485600.0*n3 + 568000.0*n4) + x39*(n3*x37 + x38) + x40*(n1*x37 + 168800.0*n2 + 488000.0*n4 + 485600.0*n5);
    double x42 = pow(x14, -4);
    double x43 = 6*x42;
    double x44 = -x43*(x35*(-n2*x11 + x1 + x3 + x34 + x5 + x7 + x9) + x41);
    double x45 = 1.0*n5;
    double x46 = x21 + x45;
    double x47 = 1.0*n2;
    double x48 = 1.0*n3;
    double x49 = x29 + x47 + x48;
    double x50 = x46 + x49;
    double x51 = -3.0*x16;
    double x52 = -3.0*x18;
    double x53 = -1.9999999980000001*x22;
    double x54 = 1.0/x30;
    double x55 = 1.0*x15;
    double x56 = pow(x14, -2);
    double x57 = -x30*x56;
    double x58 = x55 + x57;
    double x59 = x54*x58;
    double x60 = x28*x59;
    double x61 = x14*x60 + 3.0*x31 + x51 + x52 + x53;
    double x62 = 1.0/x13;
    double x63 = -x13*x56 + x15;
    double x64 = x62*x63;
    double x65 = x49*x64;
    double x66 = x45 + x49;
    double x67 = 1.0/x26;
    double x68 = x15 - x26*x56;
    double x69 = x67*x68;
    double x70 = x66*x69;
    double x71 = x14*x70 - x15*x21 + x27;
    double x72 = x14*x65 - x15*x46 + x25 + x71;
    double x73 = x61 + x72;
    double x74 = x33*x73;
    double x75 = x0*x29 + x2*x47 + x21*x6 + x34 + x4*x48 + x45*x8;
    double x76 = -x11*x47 + x75;
    double x77 = 0.82399999999999995*P + 168800.0;
    double x78 = 0.5*x36;
    double x79 = 22700.0*n4 + 22900.0*n5;
    double x80 = n3*x78 + x40*x77 + x79;
    double x81 = x50*(x0 + x74) + x76 + x80;
    double x82 = pow(x14, -3);
    double x83 = 6*x82;
    double x84 = 6.0*x59;
    double x85 = 2.0*x56;
    double x86 = -x85;
    double x87 = 2*x82;
    double x88 = x30*x87;
    double x89 = x86 + x88;
    double x90 = x28*x54;
    double x91 = x89*x90;
    double x92 = pow(x30, -2);
    double x93 = x58*x92;
    double x94 = x28*x93;
    double x95 = x14*x84 + x14*x91 - x35*x94;
    double x96 = 3.0*x56;
    double x97 = n2*x96;
    double x98 = x60 + x97;
    double x99 = x46*x56;
    double x100 = n3*x96;
    double x101 = n5*x56;
    double x102 = 1.9999999980000001*x101;
    double x103 = x100 + x102;
    double x104 = x21*x56;
    double x105 = x104 + x70;
    double x106 = x103 + x105 + x65 + x99;
    double x107 = 2.0*x69;
    double x108 = 2*x56;
    double x109 = -x108;
    double x110 = x26*x87;
    double x111 = x109 + x110;
    double x112 = x66*x67;
    double x113 = x111*x112;
    double x114 = pow(x26, -2);
    double x115 = x114*x68;
    double x116 = x115*x66;
    double x117 = x107*x14 + x113*x14 - x116*x14;
    double x118 = x106 + x117;
    double x119 = 2.0*x64;
    double x120 = x13*x87;
    double x121 = x109 + x120;
    double x122 = x49*x62;
    double x123 = x121*x122;
    double x124 = pow(x13, -2);
    double x125 = x124*x63;
    double x126 = x125*x49;
    double x127 = x119*x14 + x123*x14 - x126*x14;
    double x128 = x118 + x127;
    double x129 = x128 + x98;
    double x130 = x129 + x95;
    double x131 = x130*x33;
    double x132 = 16.628925236306479*T;
    double x133 = 2.0*x0 + x132*x73;
    double x134 = x56*(x131*x50 + x133);
    double x135 = 24.943387854459719*T;
    double x136 = x130*x135;
    double x137 = 6.0*x82;
    double x138 = n2*x137;
    double x139 = -x138;
    double x140 = n3*x137;
    double x141 = -x140;
    double x142 = n5*x82;
    double x143 = 3.9999999960000001*x142;
    double x144 = -x143;
    double x145 = x141 + x144;
    double x146 = x139 + x145;
    double x147 = -x46*x87;
    double x148 = 2.0*x82;
    double x149 = n4*x148;
    double x150 = -x149;
    double x151 = x147 + x150;
    double x152 = x146 + x151;
    double x153 = 9.0*x14;
    double x154 = x54*x89;
    double x155 = -x30*x43;
    double x156 = x14*x90;
    double x157 = 2.0*x14;
    double x158 = x157*x28;
    double x159 = pow(x30, -3);
    double x160 = x159*x58;
    double x161 = x89*x92;
    double x162 = x153*x154 - x153*x93 + x156*(x137 + x155) + x158*x160 - x158*x161 + 9.0*x59 + 2*x91 - 2.0*x94;
    double x163 = 3.0*x14;
    double x164 = -x26*x43;
    double x165 = x112*x14;
    double x166 = x14*x66;
    double x167 = x114*x166;
    double x168 = x111*x163*x67 - 2*x111*x167 + 2*x113 - x115*x163 - 2*x116 + x165*(x164 + x83) + 2*x166*x68/((x26)*(x26)*(x26)) + 3.0*x69;
    double x169 = -x13*x43;
    double x170 = x122*x14;
    double x171 = x14*x49;
    double x172 = x124*x171;
    double x173 = x121*x163*x62 - 2*x121*x172 + 2*x123 - x125*x163 - 2*x126 + x170*(x169 + x83) + 3.0*x64 + 2*x171*x63/((x13)*(x13)*(x13));
    double x174 = x168 + x173;
    double x175 = x152 + x162 + x174;
    double x176 = x33*x50;
    double x177 = T >= 7.5;
    double x178 = fmin(4, 1.0*sqrt(1 - 0.13333333333333333*T));
    double x179 = ((x178)*(x178)*(x178));
    double x180 = (120.43215000000001*T - 903.24112500000001)*(x178 - 1);
    double x181 = 301.080375*x179 + x180 - 301.080375;
    double x182 = -x43*(0.33333333333333331*x14*(n2*x181 + 3*x1 + x135*x32 + 3*x3 + 3*x5 + 3*x7 + 3*x9) + x41);
    double x183 = 0.33333333333333331*n2;
    double x184 = 0.33333333333333331*n1 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5 + x183;
    double x185 = x181*x183 + x75;
    double x186 = x184*(3*x0 + x135*x73) + x185 + x80;
    double x187 = x56*(x133 + x136*x184);
    double x188 = x135*x184;
    double x189 = -n2*x56 + x15;
    double x190 = x163*x189;
    double x191 = -x15*x28 + x53 + x72;
    double x192 = x17 + x190 + x191 + x52;
    double x193 = x192*x33;
    double x194 = -x10 + x193;
    double x195 = x194 + 200.72024999999999;
    double x196 = 21100.0*n3 + x79;
    double x197 = x196 + x50*(x195 + x2) + x76;
    double x198 = x197*x87;
    double x199 = 1.0*x2;
    double x200 = -1.0*x56;
    double x201 = x200 + x88;
    double x202 = x201*x90;
    double x203 = x129 + x14*x202 - 6.0*x15;
    double x204 = x203*x33;
    double x205 = 1.0*x0 + x74;
    double x206 = x204*x50 + x205;
    double x207 = x195 + x199 + x206;
    double x208 = -x108*x207 + x44;
    double x209 = x201*x54;
    double x210 = 6.0*x14;
    double x211 = x174 + x96;
    double x212 = 4.0*x82;
    double x213 = x28*x35*x92;
    double x214 = x156*(x155 + x212) - x201*x213 + x202 + x91 - 1.0*x94;
    double x215 = x152 + x209*x210 + x211 + x214 + x84;
    double x216 = x132*x203;
    double x217 = x131 + x216;
    double x218 = 4*x82;
    double x219 = -x134 + x218*x81;
    double x220 = x15*(x176*x215 + x217) + x219;
    double x221 = x184*(x135*x192 + x181 + 3*x2) + x185 + x196;
    double x222 = x221*x87;
    double x223 = x188*x203 + x205;
    double x224 = 100.360125*x179 + 0.33333333333333331*x180 + x193 + x199;
    double x225 = x223 + x224 - 100.360125;
    double x226 = -x108*x225 + x182;
    double x227 = x186*x218 - x187;
    double x228 = x15*(x188*x215 + x217) + x227;
    double x229 = -n3*x56 + x15;
    double x230 = x163*x229;
    double x231 = x19 + x191 + x230 + x51;
    double x232 = x231*x33;
    double x233 = n1*x78 + 21100.0*n2 + 61000.0*n4 + 60700.0*n5 + x39*x77;
    double x234 = x233 + x50*(x232 + x4) + x76;
    double x235 = x234*x87;
    double x236 = x232 + 1.0*x4;
    double x237 = x236 + x36;
    double x238 = x206 + x237;
    double x239 = -x108*x238 + x44;
    double x240 = x184*(x135*x231 + 3*x4) + x185 + x233;
    double x241 = x240*x87;
    double x242 = x223 + x237;
    double x243 = -x108*x242 + x182;
    double x244 = -x56;
    double x245 = x110 + x244;
    double x246 = x245*x67;
    double x247 = x112*x245;
    double x248 = x113 - x116 + x165*(x164 + x218) - x167*x245 + x247;
    double x249 = x107 + x157*x246 + x248;
    double x250 = x120 + x244;
    double x251 = x122*x250;
    double x252 = x119 + x123 - x126 + x157*x250*x62 + x170*(x169 + x218) - x172*x250 + x251;
    double x253 = x152 + x252;
    double x254 = x249 + x253;
    double x255 = x162 + x254 + x85;
    double x256 = x14*x247;
    double x257 = x106 + x256;
    double x258 = x14*x251;
    double x259 = x258 + x98;
    double x260 = -4.0*x15 + x257 + x259 + x95;
    double x261 = x132*x260;
    double x262 = x131 + x261;
    double x263 = x260*x33;
    double x264 = -n4*x56 + x15;
    double x265 = x264*x35;
    double x266 = 1.0/x12;
    double x267 = -x12*x56 + x15;
    double x268 = x266*x267;
    double x269 = x268*x46;
    double x270 = x14*x269 - x15*x49 + x24;
    double x271 = -x15*x66 + 1.0*x20 + x265 + x270 + x61;
    double x272 = x271*x33;
    double x273 = x272 + 1.0*x6;
    double x274 = x205 + x273 + 22700.0;
    double x275 = x263*x50 + x274;
    double x276 = -x108*x275;
    double x277 = 22700.0*n1 + 22700.0*n2 + 61000.0*n3 + 71000.0*n5;
    double x278 = x277 + x50*(x272 + x6) + x76;
    double x279 = x278*x87;
    double x280 = x219 + x44;
    double x281 = x188*x260 + x274;
    double x282 = -x108*x281;
    double x283 = x184*(x135*x271 + 3*x6) + x185 + x277;
    double x284 = x283*x87;
    double x285 = x182 + x227;
    double x286 = -1.3333333330000001*x56 + x88;
    double x287 = x286*x90;
    double x288 = x286*x54;
    double x289 = 0.99999999900000003*x14;
    double x290 = x14*x93;
    double x291 = 0.66666666600000002*x28;
    double x292 = x14*x160;
    double x293 = 0.33333333300000001*x28;
    double x294 = x14*x293;
    double x295 = x154*x289 + x156*(x155 + 4.6666666660000002*x82) - x161*x294 + x210*x288 - x213*x286 + x287 - 2.9999999970000002*x290 + x291*x292 + 6.9999999989999999*x59 + x91 - 1.3333333330000001*x94;
    double x296 = x168 + x253;
    double x297 = x295 + x296 + 2.9999999979999998*x56;
    double x298 = 0.33333333300000001*x15 + x57;
    double x299 = x298*x54;
    double x300 = 0.99999999900000003*x59;
    double x301 = 0.33333333300000001*x94;
    double x302 = x14*x287 + x14*x300 - x14*x301 + x163*x299;
    double x303 = x118 - 3.9999999979999998*x15 + x259 + x302;
    double x304 = x132*x303;
    double x305 = x131 + x304;
    double x306 = x303*x33;
    double x307 = -1.9999999980000001*x101 + 1.9999999980000001*x15;
    double x308 = x14*x307;
    double x309 = x298*x90;
    double x310 = x14*x309 + 1.9999999980000001*x23 + x270 + x308 + 0.99999999900000003*x31 + x51 + x52 + x71 - 0.81093021740539784;
    double x311 = x310*x33;
    double x312 = x311 + 1.0*x8;
    double x313 = x205 + x312 + 22900.0;
    double x314 = x306*x50 + x313;
    double x315 = -x108*x314;
    double x316 = 22900.0*n1 + 22900.0*n2 + 60700.0*n3 + 71000.0*n4;
    double x317 = x316 + x50*(x311 + x8) + x76;
    double x318 = x317*x87;
    double x319 = x188*x303 + x313;
    double x320 = -x108*x319;
    double x321 = x184*(x135*x310 + 3*x8) + x185 + x316;
    double x322 = x321*x87;
    double x323 = 9.0*x56;
    double x324 = x145 + x323;
    double x325 = x139 + x168;
    double x326 = x151 + x156*(x148 + x155) + x173 + 2*x202 + x324 + x325;
    double x327 = x176*x326;
    double x328 = x28*x56;
    double x329 = -x97;
    double x330 = 3.0*x15;
    double x331 = 6.0*x56;
    double x332 = -x331;
    double x333 = 1.0/n2;
    double x334 = x128 + x14*(x138 + x332) + x190*x333 + x328 + x329 + x330;
    double x335 = x33*x334;
    double x336 = x216 + x335;
    double x337 = x81*x87;
    double x338 = x132*x192 + 2.0*x2;
    double x339 = x56*(-80.2881*T + x335*x50 + x338 + 401.44049999999999);
    double x340 = x197*x218 - x339;
    double x341 = x188*x326;
    double x342 = x186*x87;
    double x343 = x135*x334;
    double x344 = x56*(200.72024999999999*x179 + 0.66666666666666663*x180 + x184*x343 + x338 - 200.72024999999999);
    double x345 = x218*x221 - x344;
    double x346 = -x96;
    double x347 = x14*(x138 + x346) + x329;
    double x348 = x118 + x347;
    double x349 = x127 + x328;
    double x350 = -x330 + x348 + x349;
    double x351 = x33*x350;
    double x352 = x216 + x351;
    double x353 = -x238*x56;
    double x354 = x194 + x199;
    double x355 = x236 + x351*x50 + x354 + 21300.720249999998;
    double x356 = x235 - x355*x56;
    double x357 = x337 + x44;
    double x358 = x198 - x207*x56 + x357;
    double x359 = -x242*x56;
    double x360 = x188*x350 + x224 + x236 + 20999.639875000001;
    double x361 = x241 - x360*x56;
    double x362 = x182 + x342;
    double x363 = x222 - x225*x56 + x362;
    double x364 = x163*x209 + x214 + x254 + 8.0*x56 + 3.0*x59;
    double x365 = x176*x364;
    double x366 = x258 + x328;
    double x367 = -7.0*x15 + x366;
    double x368 = x257 + x347 + x367;
    double x369 = x33*x368;
    double x370 = x204 + x263;
    double x371 = x369 + x370;
    double x372 = x273 + x354 + x369*x50 + 22900.720249999998;
    double x373 = -x372*x56;
    double x374 = -x275*x56 + x279;
    double x375 = x188*x364;
    double x376 = x188*x368 + x224 + x273 + 22599.639875000001;
    double x377 = -x376*x56;
    double x378 = -x281*x56 + x284;
    double x379 = x156*(x155 + 2.6666666660000002*x82) - x201*x294*x92 + x202 + x209*x289 + x287 + x296 + x300 - x301 + 8.9999999979999998*x56;
    double x380 = x176*x379;
    double x381 = -4.9999999969999998*x15 + x366;
    double x382 = x348 + x381;
    double x383 = x33*x382;
    double x384 = x204 + x306;
    double x385 = x383 + x384;
    double x386 = x312 + x354 + x383*x50 + 23100.720249999998;
    double x387 = -x386*x56;
    double x388 = -x314*x56 + x318;
    double x389 = x188*x379;
    double x390 = x188*x382 + x224 + x312 + 22799.639875000001;
    double x391 = -x390*x56;
    double x392 = -x319*x56 + x322;
    double x393 = 1.0/n3;
    double x394 = x105 + x97;
    double x395 = -x100 + x102 + x394 + x65 + x99;
    double x396 = x117 + x14*(x140 + x332) + x230*x393 + x330 + x349 + x395;
    double x397 = x33*x396;
    double x398 = x216 + x397;
    double x399 = x132*x231 + 2.0*x4;
    double x400 = x56*(x397*x50 + x399);
    double x401 = x218*x234 - x400;
    double x402 = x135*x396;
    double x403 = x56*(x184*x402 + x399);
    double x404 = x218*x240 - x403;
    double x405 = x14*(x140 + x346) + x395;
    double x406 = x256 + x367 + x405;
    double x407 = x33*x406;
    double x408 = x370 + x407;
    double x409 = x236 + x273 + 61000.0;
    double x410 = x407*x50 + x409;
    double x411 = -x410*x56;
    double x412 = x357 + x374;
    double x413 = x235 + x353;
    double x414 = x188*x406 + x409;
    double x415 = -x414*x56;
    double x416 = x362 + x378;
    double x417 = x241 + x359;
    double x418 = x117 + x381 + x405;
    double x419 = x33*x418;
    double x420 = x384 + x419;
    double x421 = x236 + x312 + 60700.0;
    double x422 = x419*x50 + x421;
    double x423 = -x422*x56;
    double x424 = x188*x418 + x421;
    double x425 = -x424*x56;
    double x426 = x165*(x164 + x87) + 2*x247;
    double x427 = 2*x251;
    double x428 = x170*(x169 + x87);
    double x429 = x152 + x427 + x428;
    double x430 = x162 + x331 + x426 + x429;
    double x431 = 1.0/n4;
    double x432 = x14*x46;
    double x433 = x109 + x12*x87;
    double x434 = x266*x433;
    double x435 = pow(x12, -2);
    double x436 = x267*x435;
    double x437 = x157*x268 + x269 + x432*x434 - x432*x436 + x49*x56;
    double x438 = x103 - x104 + x437 + x56*x66 + x98;
    double x439 = x14*(x149 + x86) + x265*x431 + x438 + x55 + x95;
    double x440 = x33*x439;
    double x441 = x261 + x440;
    double x442 = x132*x271 + 2.0*x6;
    double x443 = x56*(x440*x50 + x442);
    double x444 = x218*x278 - x443;
    double x445 = x135*x439;
    double x446 = x56*(x184*x445 + x442);
    double x447 = x218*x283 - x446;
    double x448 = x246*x35 + x248 + 1.0*x69;
    double x449 = x295 + x429 + x448 + 6.9999999979999998*x56;
    double x450 = x14*(x149 + x200) - 2.9999999979999998*x15 + x302 + x438;
    double x451 = x33*x450;
    double x452 = x263 + x306 + x451;
    double x453 = x273 + x312 + 71000.0;
    double x454 = x451*x50 + x453;
    double x455 = -x454*x56;
    double x456 = x188*x450 + x453;
    double x457 = -x456*x56;
    double x458 = -0.66666666600000002*x56 + x88;
    double x459 = x458*x54;
    double x460 = 1.9999999980000001*x14;
    double x461 = x298*x92;
    double x462 = 0.22222222177777778*x28;
    double x463 = x14*x291*x92;
    double x464 = x156*(x155 + 3.3333333320000005*x82) + x163*x459 - x286*x463 + 2*x287 + x288*x460 - x289*x461 - 0.66666666533333341*x290 + x292*x462 + 3.0*x299 + 1.9999999980000001*x59 - 0.66666666600000002*x94;
    double x465 = x168 + x429 + x464 + 6.9999999959999997*x56;
    double x466 = 1.0/n5;
    double x467 = x14*x461;
    double x468 = x100 - x102 + x117 + x14*(x143 - 3.9999999960000001*x56) + 1.9999999980000001*x15 + x156*x458 - x293*x467 + x299*x460 + x308*x466 + x309 + x394 + x437;
    double x469 = x33*x468;
    double x470 = x304 + x469;
    double x471 = x132*x310 + 2.0*x8;
    double x472 = x56*(x469*x50 + x471);
    double x473 = x218*x317 - x472;
    double x474 = x135*x468;
    double x475 = x56*(x184*x474 + x471);
    double x476 = x218*x321 - x475;
    double x477 = 18.0*x82;
    double x478 = 18.0*x42;
    double x479 = -n2*x478;
    double x480 = n2*x87;
    double x481 = x163*x333;
    double x482 = 12.0*x82;
    double x483 = n2*x482;
    double x484 = x145 + 3.0*x189*x333 + x483;
    double x485 = x147 + x150 - x28*x87;
    double x486 = x174 + x485;
    double x487 = x486 - 12.0*x56;
    double x488 = x14*(x477 + x479) + x481*(x109 + x480) + x484 + x487 - x190/((n2)*(n2));
    double x489 = x14*(x479 + x482) + x481*(x244 + x480) + x484;
    double x490 = x332 + x486 + x489;
    double x491 = x132*x350;
    double x492 = x335 + x491;
    double x493 = -x108*x355;
    double x494 = x340 + x44;
    double x495 = -x108*x360;
    double x496 = x182 + x345;
    double x497 = -4.0*x56;
    double x498 = x252 + x485;
    double x499 = x249 + x497 + x498;
    double x500 = x489 + x499;
    double x501 = x132*x368;
    double x502 = x335 + x501;
    double x503 = -x108*x372;
    double x504 = -x108*x376;
    double x505 = x168 + x498 - 5.0000000030000002*x56;
    double x506 = x489 + x505;
    double x507 = x132*x382;
    double x508 = x335 + x507;
    double x509 = -x108*x386;
    double x510 = -x108*x390;
    double x511 = x14*(x137 + x479) + x483;
    double x512 = x145 + x511;
    double x513 = x485 + x512;
    double x514 = x211 + x513;
    double x515 = x397 + x491;
    double x516 = x198 + x44;
    double x517 = x182 + x222;
    double x518 = x252 + x513;
    double x519 = x249 + x518 + 5.0*x56;
    double x520 = x351 + x369 + x407;
    double x521 = x356 + x516;
    double x522 = x279 + x411;
    double x523 = x361 + x517;
    double x524 = x284 + x415;
    double x525 = x168 + x518 + 3.9999999969999998*x56;
    double x526 = x351 + x383 + x419;
    double x527 = x318 + x387;
    double x528 = x322 + x391;
    double x529 = x427 + x428 + x485;
    double x530 = x426 + x529;
    double x531 = x324 + x511 + x530;
    double x532 = x440 + x501;
    double x533 = x512 + x529;
    double x534 = x448 + 7.9999999969999998*x56;
    double x535 = x533 + x534;
    double x536 = x369 + x383 + x451;
    double x537 = x168 + 5.9999999939999995*x56;
    double x538 = x533 + x537;
    double x539 = x469 + x507;
    double x540 = -n3*x478;
    double x541 = n3*x87;
    double x542 = x163*x393;
    double x543 = n3*x482 + x139 + x144;
    double x544 = 3.0*x229*x393 + x543;
    double x545 = x14*(x477 + x540) + x487 + x542*(x109 + x541) + x544 - x230/((n3)*(n3));
    double x546 = x14*(x482 + x540) + x542*(x244 + x541) + x544;
    double x547 = x499 + x546;
    double x548 = x132*x406;
    double x549 = x397 + x548;
    double x550 = -x108*x410;
    double x551 = x401 + x44;
    double x552 = -x108*x414;
    double x553 = x182 + x404;
    double x554 = x505 + x546;
    double x555 = x132*x418;
    double x556 = x397 + x555;
    double x557 = -x108*x422;
    double x558 = -x108*x424;
    double x559 = x14*(x137 + x540) + x543;
    double x560 = x323 + x530 + x559;
    double x561 = x440 + x548;
    double x562 = x235 + x44;
    double x563 = x182 + x241;
    double x564 = x529 + x559;
    double x565 = x534 + x564;
    double x566 = x407 + x419 + x451;
    double x567 = x537 + x564;
    double x568 = x469 + x555;
    double x569 = -6.0*n4*x42;
    double x570 = n4*x87;
    double x571 = x35*x431;
    double x572 = 2*x46;
    double x573 = 2*x432;
    double x574 = x163*x434 - x163*x436 + x266*x432*(-x12*x43 + x83) + 3.0*x268 - x433*x435*x573 + x434*x572 - x436*x572 - x49*x87 + x267*x573/((x12)*(x12)*(x12));
    double x575 = n4*x212 + x146 + x574 - x66*x87;
    double x576 = 1.0*x264*x431 + x575;
    double x577 = x14*(x137 + x569) + x162 + x497 + x571*(x109 + x570) + x576 - x265/((n4)*(n4));
    double x578 = x14*(x212 + x569) + x295 - 1.9999999434361371e-9*x56 + x571*(x244 + x570) + x576;
    double x579 = x132*x450;
    double x580 = x440 + x579;
    double x581 = -x108*x454 + x44;
    double x582 = -x108*x456 + x182;
    double x583 = x14*(x148 + x569) + x464 + 4.9999999959999997*x56 + x575;
    double x584 = x469 + x579;
    double x585 = x14*x159*x298*x462 + 2.9999999970000002*x14*x459 + x14*(-11.999999988000001*n5*x42 + 11.999999988000001*x82) + x141 + 7.9999999920000002*x142 + x150 + x156*(x155 + 1.9999999980000001*x82) - x291*x461 + 2.9999999970000002*x299 + x307*x466 + x325 - x458*x463 + 2*x458*x90 + x460*x466*(n5*x87 + x109) - 0.99999999800000006*x467 - 7.9999999920000002*x56 + x574 - x308/((n5)*(n5));

if (x177) {
   result[0] = -3*x134 + x15*(x136 + x175*x176) + x44 + x81*x83;
}
else {
   result[0] = x15*(x136 + x175*x188) + x182 + x186*x83 - 3*x187;
}
if (x177) {
   result[1] = x198 + x208 + x220;
}
else {
   result[1] = x222 + x226 + x228;
}
if (x177) {
   result[2] = x220 + x235 + x239;
}
else {
   result[2] = x228 + x241 + x243;
}
if (x177) {
   result[3] = x15*(x176*x255 + x262) + x276 + x279 + x280;
}
else {
   result[3] = x15*(x188*x255 + x262) + x282 + x284 + x285;
}
if (x177) {
   result[4] = x15*(x176*x297 + x305) + x280 + x315 + x318;
}
else {
   result[4] = x15*(x188*x297 + x305) + x285 + x320 + x322;
}
if (x177) {
   result[5] = x15*(x327 + x336) + x208 + x337 + x340;
}
else {
   result[5] = x15*(x336 + x341) + x226 + x342 + x345;
}
if (x177) {
   result[6] = x15*(x327 + x352) + x353 + x356 + x358;
}
else {
   result[6] = x15*(x341 + x352) + x359 + x361 + x363;
}
if (x177) {
   result[7] = x15*(x365 + x371) + x358 + x373 + x374;
}
else {
   result[7] = x15*(x371 + x375) + x363 + x377 + x378;
}
if (x177) {
   result[8] = x15*(x380 + x385) + x358 + x387 + x388;
}
else {
   result[8] = x15*(x385 + x389) + x363 + x391 + x392;
}
if (x177) {
   result[9] = x15*(x327 + x398) + x239 + x337 + x401;
}
else {
   result[9] = x15*(x341 + x398) + x243 + x342 + x404;
}
if (x177) {
   result[10] = x15*(x365 + x408) + x411 + x412 + x413;
}
else {
   result[10] = x15*(x375 + x408) + x415 + x416 + x417;
}
if (x177) {
   result[11] = x15*(x380 + x420) + x357 + x388 + x413 + x423;
}
else {
   result[11] = x15*(x389 + x420) + x362 + x392 + x417 + x425;
}
if (x177) {
   result[12] = x15*(x176*x430 + x441) + x276 + x357 + x444;
}
else {
   result[12] = x15*(x188*x430 + x441) + x282 + x362 + x447;
}
if (x177) {
   result[13] = x15*(x176*x449 + x452) + x388 + x412 + x455;
}
else {
   result[13] = x15*(x188*x449 + x452) + x392 + x416 + x457;
}
if (x177) {
   result[14] = x15*(x176*x465 + x470) + x315 + x357 + x473;
}
else {
   result[14] = x15*(x188*x465 + x470) + x320 + x362 + x476;
}
if (x177) {
   result[15] = x15*(x176*x488 + x343) + x197*x83 - 3*x339 + x44;
}
else {
   result[15] = x15*(x188*x488 + x343) + x182 + x221*x83 - 3*x344;
}
if (x177) {
   result[16] = x15*(x176*x490 + x492) + x235 + x493 + x494;
}
else {
   result[16] = x15*(x188*x490 + x492) + x241 + x495 + x496;
}
if (x177) {
   result[17] = x15*(x176*x500 + x502) + x279 + x494 + x503;
}
else {
   result[17] = x15*(x188*x500 + x502) + x284 + x496 + x504;
}
if (x177) {
   result[18] = x15*(x176*x506 + x508) + x318 + x494 + x509;
}
else {
   result[18] = x15*(x188*x506 + x508) + x322 + x496 + x510;
}
if (x177) {
   result[19] = x15*(x176*x514 + x515) + x401 + x493 + x516;
}
else {
   result[19] = x15*(x188*x514 + x515) + x404 + x495 + x517;
}
if (x177) {
   result[20] = x15*(x176*x519 + x520) + x373 + x521 + x522;
}
else {
   result[20] = x15*(x188*x519 + x520) + x377 + x523 + x524;
}
if (x177) {
   result[21] = x15*(x176*x525 + x526) + x423 + x521 + x527;
}
else {
   result[21] = x15*(x188*x525 + x526) + x425 + x523 + x528;
}
if (x177) {
   result[22] = x15*(x176*x531 + x532) + x444 + x503 + x516;
}
else {
   result[22] = x15*(x188*x531 + x532) + x447 + x504 + x517;
}
if (x177) {
   result[23] = x15*(x176*x535 + x536) + x279 + x373 + x455 + x516 + x527;
}
else {
   result[23] = x15*(x188*x535 + x536) + x284 + x377 + x457 + x517 + x528;
}
if (x177) {
   result[24] = x15*(x176*x538 + x539) + x473 + x509 + x516;
}
else {
   result[24] = x15*(x188*x538 + x539) + x476 + x510 + x517;
}
if (x177) {
   result[25] = x15*(x176*x545 + x402) + x234*x83 - 3*x400 + x44;
}
else {
   result[25] = x15*(x188*x545 + x402) + x182 + x240*x83 - 3*x403;
}
if (x177) {
   result[26] = x15*(x176*x547 + x549) + x279 + x550 + x551;
}
else {
   result[26] = x15*(x188*x547 + x549) + x284 + x552 + x553;
}
if (x177) {
   result[27] = x15*(x176*x554 + x556) + x318 + x551 + x557;
}
else {
   result[27] = x15*(x188*x554 + x556) + x322 + x553 + x558;
}
if (x177) {
   result[28] = x15*(x176*x560 + x561) + x444 + x550 + x562;
}
else {
   result[28] = x15*(x188*x560 + x561) + x447 + x552 + x563;
}
if (x177) {
   result[29] = x15*(x176*x565 + x566) + x318 + x423 + x455 + x522 + x562;
}
else {
   result[29] = x15*(x188*x565 + x566) + x322 + x425 + x457 + x524 + x563;
}
if (x177) {
   result[30] = x15*(x176*x567 + x568) + x473 + x557 + x562;
}
else {
   result[30] = x15*(x188*x567 + x568) + x476 + x558 + x563;
}
if (x177) {
   result[31] = x15*(x176*x577 + x445) + x278*x83 + x44 - 3*x443;
}
else {
   result[31] = x15*(x188*x577 + x445) + x182 + x283*x83 - 3*x446;
}
if (x177) {
   result[32] = x15*(x176*x578 + x580) + x318 + x444 + x581;
}
else {
   result[32] = x15*(x188*x578 + x580) + x322 + x447 + x582;
}
if (x177) {
   result[33] = x15*(x176*x583 + x584) + x279 + x473 + x581;
}
else {
   result[33] = x15*(x188*x583 + x584) + x284 + x476 + x582;
}
if (x177) {
   result[34] = x15*(x176*x585 + x474) + x317*x83 + x44 - 3*x472;
}
else {
   result[34] = x15*(x188*x585 + x474) + x182 + x321*x83 - 3*x475;
}
}
        
static double coder_dgdt(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n4 + n5;
    double x1 = n1 + n2 + n3;
    double x2 = 1.0/(x0 + x1);
    double x3 = 1.0*n1 + 1.0*n4;
    double x4 = n1*(*endmember[0].dmu0dT)(T, P);
    double x5 = n2*(*endmember[1].dmu0dT)(T, P);
    double x6 = n3*(*endmember[2].dmu0dT)(T, P);
    double x7 = n4*(*endmember[3].dmu0dT)(T, P);
    double x8 = n5*(*endmember[4].dmu0dT)(T, P);
    double x9 = n2*log(n2*x2);
    double x10 = n3*log(n3*x2);
    double x11 = n4*log(n4*x2);
    double x12 = n5*(log(n5*x2) - 0.40546510910816402);
    double x13 = x0*log(x0*x2);
    double x14 = x1*log(x1*x2);
    double x15 = n5 + x1;
    double x16 = x15*log(x15*x2);
    double x17 = (3.0*n1 + 3.0*n4 + 0.99999999900000003*n5)*log(x2*(0.33333333300000001*n5 + x3));
    double x18 = sqrt(1 - 0.13333333333333333*T);
    double x19 = 1.0*x18;
    double x20 = fmin(4, x19);
    double x21 = (4 - x19 >= 0. ? 1. : 0.)/x18;

if (T >= 7.5) {
   result = x2*(1.0*n2 + 1.0*n3 + 1.0*n5 + x3)*(-40.14405*n2 + 24.943387854459719*x10 + 8.3144626181532395*x11 + 16.628925219677555*x12 + 8.3144626181532395*x13 + 8.3144626181532395*x14 + 8.3144626181532395*x16 + 8.3144626181532395*x17 + x4 + x5 + x6 + x7 + x8 + 24.943387854459719*x9);
}
else {
   result = x2*(0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5)*(n2*(-60.216075000000004*((x20)*(x20))*x21 + 120.43215000000001*x20 - 0.066666666666666666*x21*(120.43215000000001*T - 903.24112500000001) - 120.43215000000001) + 74.830163563379159*x10 + 24.943387854459719*x11 + 49.886775659032665*x12 + 24.943387854459719*x13 + 24.943387854459719*x14 + 24.943387854459719*x16 + 24.943387854459719*x17 + 3*x4 + 3*x5 + 3*x6 + 3*x7 + 3*x8 + 74.830163563379159*x9);
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = n4 + n5;
    double x2 = n1 + n2 + n3;
    double x3 = x1 + x2;
    double x4 = 1.0/x3;
    double x5 = 1.0*n1 + 1.0*n4;
    double x6 = 0.33333333300000001*n5 + x5;
    double x7 = log(x4*x6);
    double x8 = 24.943387854459719*x7;
    double x9 = n5*x4;
    double x10 = -16.628925219677555*x9;
    double x11 = n2*x4;
    double x12 = -24.943387854459719*x11;
    double x13 = n3*x4;
    double x14 = -24.943387854459719*x13;
    double x15 = 24.943387854459719*n1;
    double x16 = 24.943387854459719*n4;
    double x17 = 8.3144626098387775*n5 + x15 + x16;
    double x18 = 1.0*x4;
    double x19 = pow(x3, -2);
    double x20 = -x19*x6;
    double x21 = x3/x6;
    double x22 = x21*(x18 + x20);
    double x23 = x10 + x12 + x14 + x17*x22 + x8;
    double x24 = log(x2*x4);
    double x25 = 8.3144626181532395*x24;
    double x26 = 8.3144626181532395*n4;
    double x27 = 8.3144626181532395*n5;
    double x28 = x26 + x27;
    double x29 = 8.3144626181532395*n1 + 8.3144626181532395*n2 + 8.3144626181532395*n3;
    double x30 = x3*(-x19*x2 + x4)/x2;
    double x31 = n5 + x2;
    double x32 = log(x31*x4);
    double x33 = 8.3144626181532395*x32;
    double x34 = n4*x4;
    double x35 = x27 + x29;
    double x36 = x3*(-x19*x31 + x4)/x31;
    double x37 = x33 - 8.3144626181532395*x34 + x35*x36;
    double x38 = x25 - x28*x4 + x29*x30 + x37;
    double x39 = 1.0*n2 + 1.0*n3 + 1.0*n5 + x5;
    double x40 = x39*x4;
    double x41 = n1*x0;
    double x42 = (*endmember[1].dmu0dT)(T, P);
    double x43 = n2*x42;
    double x44 = (*endmember[2].dmu0dT)(T, P);
    double x45 = n3*x44;
    double x46 = (*endmember[3].dmu0dT)(T, P);
    double x47 = n4*x46;
    double x48 = (*endmember[4].dmu0dT)(T, P);
    double x49 = n5*x48;
    double x50 = log(x11);
    double x51 = 24.943387854459719*n2;
    double x52 = log(x13);
    double x53 = 24.943387854459719*n3;
    double x54 = log(x34);
    double x55 = log(x9);
    double x56 = n5*(x55 - 0.40546510910816402);
    double x57 = log(x1*x4);
    double x58 = 8.3144626181532395*x57;
    double x59 = 3.0*n1 + 3.0*n4 + 0.99999999900000003*n5;
    double x60 = -40.14405*n2 + x1*x58 + x2*x25 + x26*x54 + x31*x33 + x41 + x43 + x45 + x47 + x49 + x50*x51 + x52*x53 + 16.628925219677555*x56 + 8.3144626181532395*x59*x7;
    double x61 = x18*x60 - x19*x39*x60;
    double x62 = T >= 7.5;
    double x63 = -74.830163563379159*x11;
    double x64 = -74.830163563379159*x13;
    double x65 = -49.886775659032665*x9;
    double x66 = 74.830163563379159*n1 + 74.830163563379159*n4 + 24.943387829516332*n5;
    double x67 = x22*x66 + x63 + x64 + x65 + 74.830163563379159*x7;
    double x68 = 24.943387854459719*x24;
    double x69 = 24.943387854459719*n5;
    double x70 = x16 + x69;
    double x71 = x15 + x51 + x53;
    double x72 = 24.943387854459719*x32;
    double x73 = x69 + x71;
    double x74 = -24.943387854459719*x34 + x36*x73 + x72;
    double x75 = x30*x71 - x4*x70 + x68 + x74;
    double x76 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5;
    double x77 = x4*x76;
    double x78 = 74.830163563379159*x50;
    double x79 = 74.830163563379159*x52;
    double x80 = 24.943387854459719*x57;
    double x81 = sqrt(1 - 0.13333333333333333*T);
    double x82 = 1.0*x81;
    double x83 = fmin(4, x82);
    double x84 = (4 - x82 >= 0. ? 1. : 0.)/x81;
    double x85 = -60.216075000000004*((x83)*(x83))*x84 + 120.43215000000001*x83 - 0.066666666666666666*x84*(120.43215000000001*T - 903.24112500000001) - 120.43215000000001;
    double x86 = n2*x78 + n2*x85 + n3*x79 + x1*x80 + x16*x54 + x2*x68 + x31*x72 + 3*x41 + 3*x43 + 3*x45 + 3*x47 + 3*x49 + 49.886775659032665*x56 + x59*x8;
    double x87 = -x19*x76*x86 + 0.33333333333333331*x4*x86;
    double x88 = x3*(-n2*x19 + x4);
    double x89 = x10 - x17*x4 + x38;
    double x90 = -x4*x66 + x65 + x75;
    double x91 = x3*(-n3*x19 + x4);
    double x92 = x3*(-n4*x19 + x4);
    double x93 = x3*(-x1*x19 + x4)/x1;
    double x94 = x28*x93 - x29*x4 + x58;
    double x95 = -x4*x71 + x70*x93 + x80;
    double x96 = x3*(-n5*x19 + x4);
    double x97 = x21*(x20 + 0.33333333300000001*x4);

if (x62) {
   result[0] = x40*(x0 + x23 + x38) + x61;
}
else {
   result[0] = x77*(3*x0 + x67 + x75) + x87;
}
if (x62) {
   result[1] = x40*(x14 + x42 + 24.943387854459719*x50 + 24.943387854459719*x88 + x89 - 40.14405) + x61;
}
else {
   result[1] = x77*(3*x42 + x64 + x78 + x85 + 74.830163563379159*x88 + x90) + x87;
}
if (x62) {
   result[2] = x40*(x12 + x44 + 24.943387854459719*x52 + x89 + 24.943387854459719*x91) + x61;
}
else {
   result[2] = x77*(3*x44 + x63 + x79 + x90 + 74.830163563379159*x91) + x87;
}
if (x62) {
   result[3] = x40*(x23 - x35*x4 + x46 + 8.3144626181532395*x54 + 8.3144626181532395*x92 + x94) + x61;
}
else {
   result[3] = x77*(-x4*x73 + 3*x46 + 24.943387854459719*x54 + x67 + 24.943387854459719*x92 + x95) + x87;
}
if (x62) {
   result[4] = x40*(x12 + x14 + x17*x97 + x37 + x48 + 16.628925219677555*x55 + 8.3144626098387775*x7 + x94 + 16.628925219677555*x96 - 6.7424489785480599) + x61;
}
else {
   result[4] = x77*(3*x48 + 49.886775659032665*x55 + x63 + x64 + x66*x97 + 24.943387829516332*x7 + x74 + x95 + 49.886775659032665*x96 - 20.227346935644182) + x87;
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = n4 + n5;
    double x2 = n1 + n2 + n3;
    double x3 = x1 + x2;
    double x4 = 1.0/x3;
    double x5 = 1.0*n1 + 1.0*n4;
    double x6 = 0.33333333300000001*n5 + x5;
    double x7 = log(x4*x6);
    double x8 = 24.943387854459719*x7;
    double x9 = n5*x4;
    double x10 = -16.628925219677555*x9;
    double x11 = n2*x4;
    double x12 = -24.943387854459719*x11;
    double x13 = n3*x4;
    double x14 = -24.943387854459719*x13;
    double x15 = 24.943387854459719*n1;
    double x16 = 24.943387854459719*n4;
    double x17 = 8.3144626098387775*n5 + x15 + x16;
    double x18 = 1.0/x6;
    double x19 = 1.0*x4;
    double x20 = pow(x3, -2);
    double x21 = -x20*x6;
    double x22 = x19 + x21;
    double x23 = x18*x22;
    double x24 = x17*x23;
    double x25 = x10 + x12 + x14 + x24*x3 + x8;
    double x26 = log(x2*x4);
    double x27 = 8.3144626181532395*x26;
    double x28 = 8.3144626181532395*n4;
    double x29 = 8.3144626181532395*n5;
    double x30 = x28 + x29;
    double x31 = 8.3144626181532395*n1 + 8.3144626181532395*n2 + 8.3144626181532395*n3;
    double x32 = 1.0/x2;
    double x33 = -x2*x20 + x4;
    double x34 = x32*x33;
    double x35 = x31*x34;
    double x36 = n5 + x2;
    double x37 = log(x36*x4);
    double x38 = 8.3144626181532395*x37;
    double x39 = x29 + x31;
    double x40 = 1.0/x36;
    double x41 = -x20*x36 + x4;
    double x42 = x40*x41;
    double x43 = x39*x42;
    double x44 = -x28*x4 + x3*x43 + x38;
    double x45 = x27 + x3*x35 - x30*x4 + x44;
    double x46 = x0 + x25 + x45;
    double x47 = 2.0*x4;
    double x48 = x23*x3;
    double x49 = 2.0*x20;
    double x50 = pow(x3, -3);
    double x51 = 2*x50;
    double x52 = x51*x6;
    double x53 = x18*x3;
    double x54 = x53*(-x49 + x52);
    double x55 = x3/((x6)*(x6));
    double x56 = x22*x55;
    double x57 = 1.0*x56;
    double x58 = x17*x54 - x17*x57 + 49.886775708919437*x48;
    double x59 = 24.943387854459719*n2;
    double x60 = x20*x59;
    double x61 = x24 + x60;
    double x62 = x20*x30;
    double x63 = n5*x20;
    double x64 = 16.628925219677555*x63;
    double x65 = 24.943387854459719*n3;
    double x66 = x20*x65;
    double x67 = x64 + x66;
    double x68 = x20*x28;
    double x69 = x43 + x68;
    double x70 = x35 + x62 + x67 + x69;
    double x71 = 16.628925236306479*x3;
    double x72 = x3*x39;
    double x73 = 2*x20;
    double x74 = -x73;
    double x75 = x36*x51;
    double x76 = x40*(x74 + x75);
    double x77 = x41/((x36)*(x36));
    double x78 = x42*x71 + x72*x76 - x72*x77;
    double x79 = x70 + x78;
    double x80 = x3*x31;
    double x81 = x2*x51;
    double x82 = x32*(x74 + x81);
    double x83 = x33/((x2)*(x2));
    double x84 = x34*x71 + x80*x82 - x80*x83;
    double x85 = x79 + x84;
    double x86 = x61 + x85;
    double x87 = 1.0*n2 + 1.0*n3 + 1.0*n5 + x5;
    double x88 = x4*x87;
    double x89 = x73*x87;
    double x90 = n1*x0;
    double x91 = (*endmember[1].dmu0dT)(T, P);
    double x92 = n2*x91;
    double x93 = (*endmember[2].dmu0dT)(T, P);
    double x94 = n3*x93;
    double x95 = (*endmember[3].dmu0dT)(T, P);
    double x96 = n4*x95;
    double x97 = (*endmember[4].dmu0dT)(T, P);
    double x98 = n5*x97;
    double x99 = log(x11);
    double x100 = log(x13);
    double x101 = log(n4*x4);
    double x102 = log(x9);
    double x103 = n5*(x102 - 0.40546510910816402);
    double x104 = log(x1*x4);
    double x105 = 8.3144626181532395*x104;
    double x106 = 3.0*n1 + 3.0*n4 + 0.99999999900000003*n5;
    double x107 = -40.14405*n2 + x1*x105 + x100*x65 + x101*x28 + 16.628925219677555*x103 + 8.3144626181532395*x106*x7 + x2*x27 + x36*x38 + x59*x99 + x90 + x92 + x94 + x96 + x98;
    double x108 = -x107*x49 + x107*x51*x87;
    double x109 = T >= 7.5;
    double x110 = -74.830163563379159*x11;
    double x111 = -74.830163563379159*x13;
    double x112 = -49.886775659032665*x9;
    double x113 = 74.830163563379159*n1 + 74.830163563379159*n4 + 24.943387829516332*n5;
    double x114 = x113*x23;
    double x115 = x110 + x111 + x112 + x114*x3 + 74.830163563379159*x7;
    double x116 = 24.943387854459719*x26;
    double x117 = 24.943387854459719*n5;
    double x118 = x117 + x16;
    double x119 = x15 + x59 + x65;
    double x120 = x119*x34;
    double x121 = 24.943387854459719*x37;
    double x122 = x117 + x119;
    double x123 = x122*x42;
    double x124 = x121 + x123*x3 - x16*x4;
    double x125 = x116 - x118*x4 + x120*x3 + x124;
    double x126 = 3*x0 + x115 + x125;
    double x127 = x126*x4;
    double x128 = x113*x54 - x113*x57 + 149.66032712675832*x48;
    double x129 = n2*x20;
    double x130 = 74.830163563379159*x129;
    double x131 = x114 + x130;
    double x132 = x118*x20;
    double x133 = n3*x20;
    double x134 = 74.830163563379159*x133;
    double x135 = 49.886775659032665*x63;
    double x136 = x134 + x135;
    double x137 = x16*x20;
    double x138 = x123 + x137;
    double x139 = x120 + x132 + x136 + x138;
    double x140 = 49.886775708919437*x3;
    double x141 = x122*x3;
    double x142 = x140*x42 + x141*x76 - x141*x77;
    double x143 = x139 + x142;
    double x144 = x119*x3;
    double x145 = x140*x34 + x144*x82 - x144*x83;
    double x146 = x143 + x145;
    double x147 = x131 + x146;
    double x148 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5;
    double x149 = x148*x4;
    double x150 = x148*x73;
    double x151 = 74.830163563379159*x99;
    double x152 = 74.830163563379159*x100;
    double x153 = 24.943387854459719*x104;
    double x154 = sqrt(1 - 0.13333333333333333*T);
    double x155 = 1.0*x154;
    double x156 = fmin(4, x155);
    double x157 = (4 - x155 >= 0. ? 1. : 0.)/x154;
    double x158 = -60.216075000000004*((x156)*(x156))*x157 + 120.43215000000001*x156 - 0.066666666666666666*x157*(120.43215000000001*T - 903.24112500000001) - 120.43215000000001;
    double x159 = n2*x151 + n2*x158 + n3*x152 + x1*x153 + x101*x16 + 49.886775659032665*x103 + x106*x8 + x116*x2 + x121*x36 + 3*x90 + 3*x92 + 3*x94 + 3*x96 + 3*x98;
    double x160 = x148*x159*x51 - 0.66666666666666663*x159*x20;
    double x161 = x3*(-x129 + x4);
    double x162 = 24.943387854459719*x161;
    double x163 = x10 - x17*x4 + x45;
    double x164 = x14 + x162 + x163 + x91 + 24.943387854459719*x99 - 40.14405;
    double x165 = x20*x87;
    double x166 = -x164*x165 + x164*x19;
    double x167 = x53*(-1.0*x20 + x52);
    double x168 = x108 - x165*x46 + x19*x46;
    double x169 = x168 + x88*(x167*x17 - 49.886775708919437*x4 + x86);
    double x170 = 74.830163563379159*x161;
    double x171 = x112 - x113*x4 + x125;
    double x172 = x111 + x151 + x158 + x170 + x171 + 3*x91;
    double x173 = 0.33333333333333331*x4;
    double x174 = x148*x20;
    double x175 = x172*x173 - x172*x174;
    double x176 = -x126*x174 + 0.33333333333333331*x127 + x160;
    double x177 = x149*(x113*x167 + x147 - 149.66032712675832*x4) + x176;
    double x178 = x3*(-x133 + x4);
    double x179 = 24.943387854459719*x178;
    double x180 = 24.943387854459719*x100 + x12 + x163 + x179 + x93;
    double x181 = -x165*x180 + x180*x19;
    double x182 = 74.830163563379159*x178;
    double x183 = x110 + x152 + x171 + x182 + 3*x93;
    double x184 = x173*x183 - x174*x183;
    double x185 = -x20;
    double x186 = x40*(x185 + x75);
    double x187 = x186*x72;
    double x188 = x187 + x70;
    double x189 = x32*(x185 + x81);
    double x190 = x189*x80;
    double x191 = x190 + x61;
    double x192 = x3*(-n4*x20 + x4);
    double x193 = 8.3144626181532395*x192;
    double x194 = 1.0/x1;
    double x195 = -x1*x20 + x4;
    double x196 = x194*x195;
    double x197 = x196*x30;
    double x198 = x105 + x197*x3 - x31*x4;
    double x199 = 8.3144626181532395*x101 + x193 + x198 + x25 - x39*x4 + x95;
    double x200 = -x165*x199 + x19*x199;
    double x201 = x141*x186;
    double x202 = x139 + x201;
    double x203 = x144*x189;
    double x204 = x131 + x203;
    double x205 = 24.943387854459719*x192;
    double x206 = x118*x196;
    double x207 = -x119*x4 + x153 + x206*x3;
    double x208 = 24.943387854459719*x101 + x115 - x122*x4 + x205 + x207 + 3*x95;
    double x209 = x173*x208 - x174*x208;
    double x210 = x21 + 0.33333333300000001*x4;
    double x211 = x18*x210;
    double x212 = x211*x3;
    double x213 = x53*(-1.3333333330000001*x20 + x52);
    double x214 = 0.33333333300000001*x56;
    double x215 = x17*x213 - x17*x214 + 24.943387854459719*x212 + 8.3144626098387775*x48;
    double x216 = x3*(x4 - x63);
    double x217 = 16.628925219677555*x216;
    double x218 = x17*x211;
    double x219 = 16.628925219677555*x102 + x12 + x14 + x198 + x217 + x218*x3 + x44 + 8.3144626098387775*x7 + x97 - 6.7424489785480599;
    double x220 = -x165*x219 + x19*x219;
    double x221 = x113*x213 - x113*x214 + 74.830163563379159*x212 + 24.943387829516332*x48;
    double x222 = 49.886775659032665*x216;
    double x223 = x113*x211;
    double x224 = 49.886775659032665*x102 + x110 + x111 + x124 + x207 + x222 + x223*x3 + 24.943387829516332*x7 + 3*x97 - 20.227346935644182;
    double x225 = x173*x224 - x174*x224;
    double x226 = x17*x20;
    double x227 = -x60;
    double x228 = 24.943387854459719*x4;
    double x229 = -49.886775708919437*x20;
    double x230 = n2*x50;
    double x231 = 49.886775708919437*x230;
    double x232 = 1.0/n2;
    double x233 = 0.66666666666666663*x4;
    double x234 = x113*x20;
    double x235 = -x130;
    double x236 = 74.830163563379159*x4;
    double x237 = -149.66032712675832*x20;
    double x238 = 149.66032712675832*x230;
    double x239 = -24.943387854459719*x20;
    double x240 = x227 + x3*(x231 + x239);
    double x241 = x240 + x79;
    double x242 = x226 + x84;
    double x243 = x108 + x166;
    double x244 = -74.830163563379159*x20;
    double x245 = x235 + x3*(x238 + x244);
    double x246 = x143 + x245;
    double x247 = x145 + x234;
    double x248 = x160 + x175;
    double x249 = x190 + x226;
    double x250 = x249 - 58.201238327072687*x4;
    double x251 = x203 + x234;
    double x252 = x251 - 174.60371498121805*x4;
    double x253 = x249 - 41.572313065822811*x4;
    double x254 = x251 - 124.71693919746842*x4;
    double x255 = n3*x50;
    double x256 = 49.886775708919437*x255;
    double x257 = 1.0/n3;
    double x258 = x60 + x69;
    double x259 = x258 + x35 + x62 + x64 - x66;
    double x260 = 149.66032712675832*x255;
    double x261 = x130 + x138;
    double x262 = x120 + x132 - x134 + x135 + x261;
    double x263 = x259 + x3*(x239 + x256);
    double x264 = x108 + x181;
    double x265 = x262 + x3*(x244 + x260);
    double x266 = x160 + x184;
    double x267 = n4*x50;
    double x268 = 16.628925236306479*x267;
    double x269 = 1.0/n4;
    double x270 = x3*x30;
    double x271 = x194*(x1*x51 + x74);
    double x272 = x195/((x1)*(x1));
    double x273 = x196*x71 + x197 + x20*x31 + x270*x271 - x270*x272;
    double x274 = x20*x39 + x273 + x61 + x67 - x68;
    double x275 = 49.886775708919437*x267;
    double x276 = x118*x3;
    double x277 = x119*x20 + x140*x196 + x206 + x271*x276 - x272*x276;
    double x278 = x122*x20 + x131 + x136 - x137 + x277;
    double x279 = n5*x50;
    double x280 = 1.0/n5;
    double x281 = x53*(-0.66666666600000002*x20 + x52);
    double x282 = 0.33333333300000001*x210*x55;

if (x109) {
   result[0] = x108 + x46*x47 - x46*x89 + x88*(x58 + x86);
}
else {
   result[0] = -x126*x150 + 0.66666666666666663*x127 + x149*(x128 + x147) + x160;
}
if (x109) {
   result[1] = x166 + x169;
}
else {
   result[1] = x175 + x177;
}
if (x109) {
   result[2] = x169 + x181;
}
else {
   result[2] = x177 + x184;
}
if (x109) {
   result[3] = x168 + x200 + x88*(x188 + x191 - 33.257850472612958*x4 + x58);
}
else {
   result[3] = x149*(x128 + x202 + x204 - 99.773551417838874*x4) + x176 + x209;
}
if (x109) {
   result[4] = x168 + x220 + x88*(x191 + x215 - 33.257850455984034*x4 + x79);
}
else {
   result[4] = x149*(x143 + x204 + x221 - 99.773551367952109*x4) + x176 + x225;
}
if (x109) {
   result[5] = x108 + x164*x47 - x164*x89 + x88*(x162*x232 + x226 + x227 + x228 + x3*(x229 + x231) + x85);
}
else {
   result[5] = x149*(x146 + x170*x232 + x234 + x235 + x236 + x3*(x237 + x238)) - x150*x172 + x160 + x172*x233;
}
if (x109) {
   result[6] = x181 + x243 + x88*(-x228 + x241 + x242);
}
else {
   result[6] = x149*(-x236 + x246 + x247) + x184 + x248;
}
if (x109) {
   result[7] = x200 + x243 + x88*(x188 + x240 + x250);
}
else {
   result[7] = x149*(x202 + x245 + x252) + x209 + x248;
}
if (x109) {
   result[8] = x220 + x243 + x88*(x241 + x253);
}
else {
   result[8] = x149*(x246 + x254) + x225 + x248;
}
if (x109) {
   result[9] = x108 + x180*x47 - x180*x89 + x88*(x179*x257 + x228 + x242 + x259 + x3*(x229 + x256) + x78);
}
else {
   result[9] = x149*(x142 + x182*x257 + x236 + x247 + x262 + x3*(x237 + x260)) - x150*x183 + x160 + x183*x233;
}
if (x109) {
   result[10] = x200 + x264 + x88*(x187 + x250 + x263);
}
else {
   result[10] = x149*(x201 + x252 + x265) + x209 + x266;
}
if (x109) {
   result[11] = x220 + x264 + x88*(x253 + x263 + x78);
}
else {
   result[11] = x149*(x142 + x254 + x265) + x225 + x266;
}
if (x109) {
   result[12] = x108 + x199*x47 - x199*x89 + x88*(x193*x269 + x274 + x3*(-16.628925236306479*x20 + x268) + 8.3144626181532395*x4 + x58);
}
else {
   result[12] = x149*(x128 + x205*x269 + x228 + x278 + x3*(x229 + x275)) - x150*x208 + x160 + x208*x233;
}
if (x109) {
   result[13] = x108 + x200 + x220 + x88*(x215 + x274 + x3*(-8.3144626181532395*x20 + x268) - 24.943387837830794*x4);
}
else {
   result[13] = x149*(x221 + x278 + x3*(x239 + x275) - 74.83016351349238*x4) + x160 + x209 + x225;
}
if (x109) {
   result[14] = x108 + x219*x47 - x219*x89 + x88*(x17*x281 - x17*x282 + 16.628925219677555*x212 + x217*x280 + x218 + x258 + x273 + x3*(-33.25785043935511*x20 + 33.25785043935511*x279) + 16.628925219677555*x4 - x64 + x66 + x78);
}
else {
   result[14] = x149*(x113*x281 - x113*x282 + x134 - x135 + x142 + 49.886775659032665*x212 + x222*x280 + x223 + x261 + x277 + x3*(-99.77355131806533*x20 + 99.77355131806533*x279) + 49.886775659032665*x4) - x150*x224 + x160 + x224*x233;
}
}
        
static void coder_d4gdn3dt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n4 + n5;
    double x1 = n1 + n2 + n3;
    double x2 = x0 + x1;
    double x3 = 1.0*n1 + 1.0*n4;
    double x4 = 0.33333333300000001*n5 + x3;
    double x5 = 1.0/x4;
    double x6 = 1.0/x2;
    double x7 = 1.0*x6;
    double x8 = pow(x2, -2);
    double x9 = -x4*x8;
    double x10 = x7 + x9;
    double x11 = x10*x5;
    double x12 = 49.886775708919437*x11;
    double x13 = 2.0*x8;
    double x14 = pow(x2, -3);
    double x15 = 2*x14;
    double x16 = x15*x4;
    double x17 = -x13 + x16;
    double x18 = 24.943387854459719*n1;
    double x19 = 24.943387854459719*n4;
    double x20 = 8.3144626098387775*n5 + x18 + x19;
    double x21 = x20*x5;
    double x22 = x17*x21;
    double x23 = pow(x4, -2);
    double x24 = x10*x23;
    double x25 = 1.0*x24;
    double x26 = x20*x25;
    double x27 = x12*x2 + x2*x22 - x2*x26;
    double x28 = 24.943387854459719*n2;
    double x29 = x28*x8;
    double x30 = x11*x20;
    double x31 = x29 + x30;
    double x32 = 8.3144626181532395*n4;
    double x33 = 8.3144626181532395*n5;
    double x34 = x32 + x33;
    double x35 = x34*x8;
    double x36 = 8.3144626181532395*n1 + 8.3144626181532395*n2 + 8.3144626181532395*n3;
    double x37 = 1.0/x1;
    double x38 = -x1*x8 + x6;
    double x39 = x37*x38;
    double x40 = x36*x39;
    double x41 = n5*x8;
    double x42 = 16.628925219677555*x41;
    double x43 = 24.943387854459719*n3;
    double x44 = x43*x8;
    double x45 = x42 + x44;
    double x46 = x32*x8;
    double x47 = x33 + x36;
    double x48 = n5 + x1;
    double x49 = 1.0/x48;
    double x50 = -x48*x8 + x6;
    double x51 = x49*x50;
    double x52 = x47*x51;
    double x53 = x46 + x52;
    double x54 = x35 + x40 + x45 + x53;
    double x55 = 16.628925236306479*x51;
    double x56 = 2*x8;
    double x57 = -x56;
    double x58 = x15*x48;
    double x59 = x57 + x58;
    double x60 = x47*x49;
    double x61 = x59*x60;
    double x62 = pow(x48, -2);
    double x63 = x50*x62;
    double x64 = x47*x63;
    double x65 = x2*x55 + x2*x61 - x2*x64;
    double x66 = x54 + x65;
    double x67 = 16.628925236306479*x39;
    double x68 = x1*x15;
    double x69 = x57 + x68;
    double x70 = x36*x37;
    double x71 = x69*x70;
    double x72 = pow(x1, -2);
    double x73 = x38*x72;
    double x74 = x36*x73;
    double x75 = x2*x67 + x2*x71 - x2*x74;
    double x76 = x66 + x75;
    double x77 = x31 + x76;
    double x78 = x27 + x77;
    double x79 = 3.0*x6;
    double x80 = (*endmember[0].dmu0dT)(T, P);
    double x81 = log(x4*x6);
    double x82 = 24.943387854459719*x81;
    double x83 = n5*x6;
    double x84 = -16.628925219677555*x83;
    double x85 = n2*x6;
    double x86 = -24.943387854459719*x85;
    double x87 = n3*x6;
    double x88 = -24.943387854459719*x87;
    double x89 = x2*x30 + x82 + x84 + x86 + x88;
    double x90 = log(x1*x6);
    double x91 = 8.3144626181532395*x90;
    double x92 = log(x48*x6);
    double x93 = 8.3144626181532395*x92;
    double x94 = x2*x52 - x32*x6 + x93;
    double x95 = x2*x40 - x34*x6 + x91 + x94;
    double x96 = x80 + x89 + x95;
    double x97 = x8*x96;
    double x98 = 74.830163563379159*x11;
    double x99 = 74.830163563379159*x2;
    double x100 = x17*x5;
    double x101 = 2.0*x24;
    double x102 = 6.0*x14;
    double x103 = pow(x2, -4);
    double x104 = 6*x103;
    double x105 = -x104*x4;
    double x106 = x2*(x102 + x105);
    double x107 = 2.0*x2;
    double x108 = x107*x20;
    double x109 = pow(x4, -3);
    double x110 = x10*x109;
    double x111 = x17*x23;
    double x112 = x100*x99 - x101*x20 + x106*x21 + x108*x110 - x108*x111 + 2*x22 - x24*x99 + x98;
    double x113 = 49.886775708919437*x14;
    double x114 = n2*x113;
    double x115 = -x114;
    double x116 = -x15*x34;
    double x117 = 16.628925236306479*x14;
    double x118 = n4*x117;
    double x119 = -x118;
    double x120 = n5*x14;
    double x121 = 33.25785043935511*x120;
    double x122 = -x121;
    double x123 = n3*x113;
    double x124 = -x123;
    double x125 = x122 + x124;
    double x126 = x116 + x119 + x125;
    double x127 = x115 + x126;
    double x128 = 24.943387854459719*x51;
    double x129 = 24.943387854459719*x2;
    double x130 = x49*x59;
    double x131 = 6*x14;
    double x132 = -x104*x48;
    double x133 = x2*(x131 + x132);
    double x134 = x2*x47;
    double x135 = 2*x134;
    double x136 = x59*x62;
    double x137 = x50/((x48)*(x48)*(x48));
    double x138 = x128 + x129*x130 - x129*x63 + x133*x60 - x135*x136 + x135*x137 + 2*x61 - 2*x64;
    double x139 = x127 + x138;
    double x140 = x37*x69;
    double x141 = -x1*x104;
    double x142 = x2*(x131 + x141);
    double x143 = x2*x36;
    double x144 = 2*x143;
    double x145 = x69*x72;
    double x146 = x38/((x1)*(x1)*(x1));
    double x147 = x129*x140 - x129*x73 + x142*x70 - x144*x145 + x144*x146 + 24.943387854459719*x39 + 2*x71 - 2*x74;
    double x148 = x139 + x147;
    double x149 = 1.0*n2 + 1.0*n3 + 1.0*n5 + x3;
    double x150 = x149*x6;
    double x151 = x149*x8;
    double x152 = x151*x78;
    double x153 = x149*x96;
    double x154 = n1*x80;
    double x155 = (*endmember[1].dmu0dT)(T, P);
    double x156 = n2*x155;
    double x157 = (*endmember[2].dmu0dT)(T, P);
    double x158 = n3*x157;
    double x159 = (*endmember[3].dmu0dT)(T, P);
    double x160 = n4*x159;
    double x161 = (*endmember[4].dmu0dT)(T, P);
    double x162 = n5*x161;
    double x163 = log(x85);
    double x164 = log(x87);
    double x165 = log(n4*x6);
    double x166 = log(x83);
    double x167 = n5*(x166 - 0.40546510910816402);
    double x168 = log(x0*x6);
    double x169 = 8.3144626181532395*x168;
    double x170 = 3.0*n1 + 3.0*n4 + 0.99999999900000003*n5;
    double x171 = -40.14405*n2 + x0*x169 + x1*x91 + x154 + x156 + x158 + x160 + x162 + x163*x28 + x164*x43 + x165*x32 + 16.628925219677555*x167 + 8.3144626181532395*x170*x81 + x48*x93;
    double x172 = x102*x171 - x104*x149*x171;
    double x173 = T >= 7.5;
    double x174 = 149.66032712675832*x11;
    double x175 = 74.830163563379159*n1 + 74.830163563379159*n4 + 24.943387829516332*n5;
    double x176 = x175*x5;
    double x177 = x17*x176;
    double x178 = x175*x25;
    double x179 = x174*x2 + x177*x2 - x178*x2;
    double x180 = n2*x8;
    double x181 = 74.830163563379159*x180;
    double x182 = x11*x175;
    double x183 = x181 + x182;
    double x184 = 24.943387854459719*n5;
    double x185 = x184 + x19;
    double x186 = x185*x8;
    double x187 = x18 + x28 + x43;
    double x188 = x187*x39;
    double x189 = 74.830163563379159*x8;
    double x190 = n3*x189;
    double x191 = 49.886775659032665*x41;
    double x192 = x190 + x191;
    double x193 = x19*x8;
    double x194 = x184 + x187;
    double x195 = x194*x51;
    double x196 = x193 + x195;
    double x197 = x186 + x188 + x192 + x196;
    double x198 = 49.886775708919437*x51;
    double x199 = x194*x49;
    double x200 = x199*x59;
    double x201 = x194*x63;
    double x202 = x198*x2 + x2*x200 - x2*x201;
    double x203 = x197 + x202;
    double x204 = 49.886775708919437*x39;
    double x205 = x187*x37;
    double x206 = x205*x69;
    double x207 = x187*x73;
    double x208 = x2*x204 + x2*x206 - x2*x207;
    double x209 = x203 + x208;
    double x210 = x183 + x209;
    double x211 = x179 + x210;
    double x212 = -74.830163563379159*x85;
    double x213 = -74.830163563379159*x87;
    double x214 = -49.886775659032665*x83;
    double x215 = x182*x2 + x212 + x213 + x214 + 74.830163563379159*x81;
    double x216 = 24.943387854459719*x90;
    double x217 = 24.943387854459719*x92;
    double x218 = -x19*x6 + x195*x2 + x217;
    double x219 = -x185*x6 + x188*x2 + x216 + x218;
    double x220 = x215 + x219 + 3*x80;
    double x221 = 149.66032712675832*x14;
    double x222 = n2*x221;
    double x223 = -x222;
    double x224 = n3*x221;
    double x225 = -x224;
    double x226 = 99.77355131806533*x14;
    double x227 = n5*x226;
    double x228 = -x227;
    double x229 = x225 + x228;
    double x230 = x223 + x229;
    double x231 = -x15*x185;
    double x232 = n4*x113;
    double x233 = -x232;
    double x234 = x231 + x233;
    double x235 = x230 + x234;
    double x236 = 224.49049069013748*x2;
    double x237 = x107*x175;
    double x238 = x100*x236 - x101*x175 + x106*x176 + 224.49049069013748*x11 + x110*x237 - x111*x237 + 2*x177 - x236*x24;
    double x239 = x194*x2;
    double x240 = 2*x239;
    double x241 = x130*x99 + x133*x199 - x136*x240 + x137*x240 + 2*x200 - 2*x201 + 74.830163563379159*x51 - x63*x99;
    double x242 = x187*x2;
    double x243 = 2*x242;
    double x244 = x140*x99 + x142*x205 - x145*x243 + x146*x243 + 2*x206 - 2*x207 + 74.830163563379159*x39 - x73*x99;
    double x245 = x241 + x244;
    double x246 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5;
    double x247 = x246*x6;
    double x248 = x246*x8;
    double x249 = x211*x248;
    double x250 = x220*x246;
    double x251 = 74.830163563379159*x163;
    double x252 = 74.830163563379159*x164;
    double x253 = 24.943387854459719*x168;
    double x254 = sqrt(1 - 0.13333333333333333*T);
    double x255 = 1.0*x254;
    double x256 = fmin(4, x255);
    double x257 = (4 - x255 >= 0. ? 1. : 0.)/x254;
    double x258 = -60.216075000000004*((x256)*(x256))*x257 + 120.43215000000001*x256 - 0.066666666666666666*x257*(120.43215000000001*T - 903.24112500000001) - 120.43215000000001;
    double x259 = n2*x251 + n2*x258 + n3*x252 + x0*x253 + x1*x216 + 3*x154 + 3*x156 + 3*x158 + 3*x160 + 3*x162 + x165*x19 + 49.886775659032665*x167 + x170*x82 + x217*x48;
    double x260 = 2.0*x14;
    double x261 = -x104*x246*x259 + x259*x260;
    double x262 = x16 - 1.0*x8;
    double x263 = x21*x262;
    double x264 = x2*x263 - 49.886775708919437*x6 + x77;
    double x265 = 2.0*x6;
    double x266 = x149*x56;
    double x267 = x172 + x264*x265 - x264*x266;
    double x268 = -x180 + x6;
    double x269 = x2*x268;
    double x270 = 24.943387854459719*x269;
    double x271 = -x20*x6 + x84 + x95;
    double x272 = x155 + 24.943387854459719*x163 + x270 + x271 + x88 - 40.14405;
    double x273 = x149*x15;
    double x274 = -x13*x272 + x272*x273;
    double x275 = x267 + x274;
    double x276 = 24.943387854459719*x8;
    double x277 = 49.886775708919437*x2;
    double x278 = x262*x5;
    double x279 = x2*(x105 + 4.0*x14);
    double x280 = x2*x20;
    double x281 = 1.0*x23;
    double x282 = x262*x281;
    double x283 = x21*x279 + x22 - x26 - x280*x282;
    double x284 = 4*x14;
    double x285 = -x152 + x153*x284 + x7*x78 - 4.0*x97;
    double x286 = x150*(x12 + x148 + x263 + x276 + x277*x278 + x283) + x285;
    double x287 = x176*x262;
    double x288 = x2*x287 + x210 - 149.66032712675832*x6;
    double x289 = 0.66666666666666663*x6;
    double x290 = x246*x56;
    double x291 = x261 + x288*x289 - x288*x290;
    double x292 = 74.830163563379159*x269;
    double x293 = -x175*x6 + x214 + x219;
    double x294 = 3*x155 + x213 + x251 + x258 + x292 + x293;
    double x295 = 0.66666666666666663*x8;
    double x296 = x15*x246;
    double x297 = -x294*x295 + x294*x296;
    double x298 = x291 + x297;
    double x299 = 149.66032712675832*x2;
    double x300 = x189 + x245;
    double x301 = x175*x2;
    double x302 = x176*x279 + x177 - x178 - x282*x301 + x287;
    double x303 = 0.33333333333333331*x6;
    double x304 = 1.3333333333333333*x8;
    double x305 = x211*x303 - x220*x304 - x249 + x250*x284;
    double x306 = x247*(x174 + x235 + x278*x299 + x300 + x302) + x305;
    double x307 = -n3*x8 + x6;
    double x308 = x2*x307;
    double x309 = 24.943387854459719*x308;
    double x310 = x157 + 24.943387854459719*x164 + x271 + x309 + x86;
    double x311 = -x13*x310 + x273*x310;
    double x312 = 74.830163563379159*x308;
    double x313 = 3*x157 + x212 + x252 + x293 + x312;
    double x314 = -x295*x313 + x296*x313;
    double x315 = 16.628925236306479*x8;
    double x316 = -x8;
    double x317 = x316 + x68;
    double x318 = x317*x70;
    double x319 = 16.628925236306479*x2;
    double x320 = x317*x37;
    double x321 = x2*(x141 + x284);
    double x322 = x317*x72;
    double x323 = -x143*x322 + x318 + x319*x320 + x321*x70 + x67 + x71 - x74;
    double x324 = x316 + x58;
    double x325 = x324*x49;
    double x326 = x324*x60;
    double x327 = x2*(x132 + x284);
    double x328 = x324*x62;
    double x329 = -x134*x328 + x326 + x327*x60 + x61 - x64;
    double x330 = x319*x325 + x329 + x55;
    double x331 = x127 + x330;
    double x332 = x172 + x285;
    double x333 = x2*x326;
    double x334 = x333 + x54;
    double x335 = x2*x318;
    double x336 = x31 + x335;
    double x337 = x27 + x334 + x336 - 33.257850472612958*x6;
    double x338 = x265*x337 - x266*x337;
    double x339 = -n4*x8 + x6;
    double x340 = x2*x339;
    double x341 = 8.3144626181532395*x340;
    double x342 = 1.0/x0;
    double x343 = -x0*x8 + x6;
    double x344 = x342*x343;
    double x345 = x34*x344;
    double x346 = x169 + x2*x345 - x36*x6;
    double x347 = x159 + 8.3144626181532395*x165 + x341 + x346 - x47*x6 + x89;
    double x348 = -x13*x347 + x273*x347;
    double x349 = 49.886775708919437*x8;
    double x350 = x199*x324;
    double x351 = x199*x327 + x200 - x201 - x239*x328 + x350;
    double x352 = x198 + x277*x325 + x351;
    double x353 = x205*x317;
    double x354 = x204 + x205*x321 + x206 - x207 - x242*x322 + x277*x320 + x353;
    double x355 = x235 + x354;
    double x356 = x352 + x355;
    double x357 = x261 + x305;
    double x358 = x2*x350;
    double x359 = x197 + x358;
    double x360 = x2*x353;
    double x361 = x183 + x360;
    double x362 = x179 + x359 + x361 - 99.773551417838874*x6;
    double x363 = x289*x362 - x290*x362;
    double x364 = 24.943387854459719*x340;
    double x365 = x185*x344;
    double x366 = -x187*x6 + x2*x365 + x253;
    double x367 = 3*x159 + 24.943387854459719*x165 - x194*x6 + x215 + x364 + x366;
    double x368 = -x295*x367 + x296*x367;
    double x369 = x16 - 1.3333333330000001*x8;
    double x370 = x21*x369;
    double x371 = x100*x2;
    double x372 = x369*x5;
    double x373 = 1.3333333330000001*x24;
    double x374 = x2*x24;
    double x375 = x2*(x105 + 4.6666666660000002*x14);
    double x376 = 0.66666666600000002*x110;
    double x377 = x281*x369;
    double x378 = 0.33333333300000001*x111;
    double x379 = 58.201238318758215*x11 - x20*x373 + x21*x375 + x22 + x277*x372 + x280*x376 - x280*x377 - x280*x378 + x370 + 8.3144626098387775*x371 - 24.943387829516332*x374;
    double x380 = 8.3144626098387775*x11;
    double x381 = 0.33333333300000001*x6 + x9;
    double x382 = x381*x5;
    double x383 = 24.943387854459719*x382;
    double x384 = 0.33333333300000001*x374;
    double x385 = x2*x370 + x2*x380 + x2*x383 - x20*x384;
    double x386 = x336 + x385 - 33.257850455984034*x6 + x66;
    double x387 = x265*x386 - x266*x386;
    double x388 = -x41 + x6;
    double x389 = x2*x388;
    double x390 = 16.628925219677555*x389;
    double x391 = x21*x381;
    double x392 = x161 + 16.628925219677555*x166 + x2*x391 + x346 + x390 + 8.3144626098387775*x81 + x86 + x88 + x94 - 6.7424489785480599;
    double x393 = -x13*x392 + x273*x392;
    double x394 = x176*x369;
    double x395 = 174.60371495627464*x11 - x175*x373 + x176*x375 + x177 + x299*x372 + x301*x376 - x301*x377 - x301*x378 + 24.943387829516332*x371 - 74.830163488549005*x374 + x394;
    double x396 = x241 + x355;
    double x397 = 74.830163563379159*x382;
    double x398 = 24.943387829516332*x11;
    double x399 = -x175*x384 + x2*x394 + x2*x397 + x2*x398;
    double x400 = x203 + x361 + x399 - 99.773551367952109*x6;
    double x401 = x289*x400 - x290*x400;
    double x402 = 49.886775659032665*x389;
    double x403 = x176*x381;
    double x404 = 3*x161 + 49.886775659032665*x166 + x2*x403 + x212 + x213 + x218 + x366 + x402 + 24.943387829516332*x81 - 20.227346935644182;
    double x405 = -x295*x404 + x296*x404;
    double x406 = x2*(x105 + x260);
    double x407 = -x13*x96 + x15*x153;
    double x408 = x150*(x148 + x189 + x21*x406 + 2*x263) + x407;
    double x409 = x267 + x408;
    double x410 = x20*x8;
    double x411 = -x29;
    double x412 = 24.943387854459719*x6;
    double x413 = -x349;
    double x414 = 1.0/n2;
    double x415 = x2*(x114 + x413) + x270*x414 + x410 + x411 + x412 + x76;
    double x416 = 4.0*x8;
    double x417 = x151*x415;
    double x418 = x149*x284;
    double x419 = -x272*x416 + x272*x418 + x415*x7 - x417;
    double x420 = 224.49049069013748*x8;
    double x421 = x229 + x420;
    double x422 = x223 + x241;
    double x423 = x15*x250 - x220*x295;
    double x424 = x247*(x176*x406 + x234 + x244 + 2*x287 + x421 + x422) + x423;
    double x425 = x291 + x424;
    double x426 = x175*x8;
    double x427 = -x181;
    double x428 = 74.830163563379159*x6;
    double x429 = 149.66032712675832*x8;
    double x430 = -x429;
    double x431 = x2*(x222 + x430) + x209 + x292*x414 + x426 + x427 + x428;
    double x432 = x248*x431;
    double x433 = x246*x284;
    double x434 = -x294*x304 + x294*x433 + x303*x431 - x432;
    double x435 = -x276;
    double x436 = x2*(x114 + x435) + x411;
    double x437 = x436 + x66;
    double x438 = x410 + x75;
    double x439 = -x412 + x437 + x438;
    double x440 = -x151*x439 + x311 + x439*x7;
    double x441 = -x189;
    double x442 = x2*(x222 + x441) + x427;
    double x443 = x203 + x442;
    double x444 = x208 + x426;
    double x445 = -x428 + x443 + x444;
    double x446 = -x248*x445 + x303*x445 + x314;
    double x447 = x335 + x410;
    double x448 = x447 - 58.201238327072687*x6;
    double x449 = x334 + x436 + x448;
    double x450 = -x151*x449 + x348 + x449*x7;
    double x451 = x172 + x407;
    double x452 = -x151*x264 + x264*x7 + x451;
    double x453 = x274 + x452;
    double x454 = x263 + x323;
    double x455 = -x151*x337 + x337*x7;
    double x456 = x150*(24.943387854459719*x11 + x129*x278 + x283 + x331 + x454 + 66.515700945225916*x8) + x455;
    double x457 = x360 + x426;
    double x458 = x457 - 174.60371498121805*x6;
    double x459 = x359 + x442 + x458;
    double x460 = -x248*x459 + x303*x459 + x368;
    double x461 = x261 + x423;
    double x462 = -x248*x288 + x288*x303 + x461;
    double x463 = x297 + x462;
    double x464 = -x248*x362 + x303*x362;
    double x465 = x247*(x278*x99 + x302 + x356 + 199.54710283567778*x8 + x98) + x464;
    double x466 = x447 - 41.572313065822811*x6;
    double x467 = x437 + x466;
    double x468 = -x151*x467 + x467*x7;
    double x469 = x2*x278;
    double x470 = 0.33333333300000001*x24;
    double x471 = x2*(x105 + 2.6666666660000002*x14);
    double x472 = x23*x280;
    double x473 = 0.33333333300000001*x262;
    double x474 = -x151*x386 + x386*x7 + x393;
    double x475 = x150*(x139 - x20*x470 + x21*x471 + x370 + x380 + x454 + 8.3144626098387775*x469 - x472*x473 + 74.830163546750228*x8) + x474;
    double x476 = x457 - 124.71693919746842*x6;
    double x477 = x443 + x476;
    double x478 = -x248*x477 + x303*x477;
    double x479 = x23*x301;
    double x480 = -x248*x400 + x303*x400 + x405;
    double x481 = x247*(-x175*x470 + x176*x471 + x287 + x394 + x396 + x398 + 24.943387829516332*x469 - x473*x479 + 224.4904906402507*x8) + x480;
    double x482 = 1.0/n3;
    double x483 = x29 + x53;
    double x484 = x35 + x40 + x42 - x44 + x483;
    double x485 = x2*(x123 + x413) + x309*x482 + x412 + x438 + x484 + x65;
    double x486 = x151*x485;
    double x487 = -x310*x416 + x310*x418 + x485*x7 - x486;
    double x488 = x181 + x196;
    double x489 = x186 + x188 - x190 + x191 + x488;
    double x490 = x2*(x224 + x430) + x202 + x312*x482 + x428 + x444 + x489;
    double x491 = x248*x490;
    double x492 = x303*x490 - x304*x313 + x313*x433 - x491;
    double x493 = x311 + x452;
    double x494 = x2*(x123 + x435) + x484;
    double x495 = x333 + x448 + x494;
    double x496 = -x151*x495 + x495*x7;
    double x497 = x348 + x496;
    double x498 = x314 + x462;
    double x499 = x2*(x224 + x441) + x489;
    double x500 = x358 + x458 + x499;
    double x501 = -x248*x500 + x303*x500;
    double x502 = x368 + x501;
    double x503 = x466 + x494 + x65;
    double x504 = -x151*x503 + x503*x7;
    double x505 = x202 + x476 + x499;
    double x506 = -x248*x505 + x303*x505;
    double x507 = 49.886775708919444*x8;
    double x508 = x2*(x132 + x15);
    double x509 = 2*x326 + x508*x60;
    double x510 = 2*x318;
    double x511 = x2*(x141 + x15);
    double x512 = x511*x70;
    double x513 = x127 + x510 + x512;
    double x514 = 1.0/n4;
    double x515 = x2*x34;
    double x516 = x0*x15 + x57;
    double x517 = x342*x516;
    double x518 = pow(x0, -2);
    double x519 = x343*x518;
    double x520 = x319*x344 + x345 + x36*x8 + x515*x517 - x515*x519;
    double x521 = x31 + x45 - x46 + x47*x8 + x520;
    double x522 = x2*(x118 - x315) + x27 + x341*x514 + x521 + 8.3144626181532395*x6;
    double x523 = x151*x522;
    double x524 = -x347*x416 + x347*x418 + x522*x7 - x523;
    double x525 = x199*x508 + 2*x350;
    double x526 = 2*x353;
    double x527 = x205*x511;
    double x528 = x235 + x526 + x527;
    double x529 = x185*x2;
    double x530 = x187*x8 + x277*x344 + x365 + x517*x529 - x519*x529;
    double x531 = x183 + x192 - x193 + x194*x8 + x530;
    double x532 = x179 + x2*(x232 + x413) + x364*x514 + x412 + x531;
    double x533 = x248*x532;
    double x534 = x303*x532 - x304*x367 + x367*x433 - x533;
    double x535 = 8.3144626181532395*x2;
    double x536 = x325*x535 + x329 + 8.3144626181532395*x51;
    double x537 = x2*(x118 - 8.3144626181532395*x8) + x385 + x521 - 24.943387837830794*x6;
    double x538 = -x151*x537 + x537*x7;
    double x539 = x128 + x129*x325 + x351;
    double x540 = x2*(x232 + x435) + x399 + x531 - 74.83016351349238*x6;
    double x541 = -x248*x540 + x303*x540;
    double x542 = 16.628925219677555*x2;
    double x543 = x16 - 0.66666666600000002*x8;
    double x544 = x5*x543;
    double x545 = x23*x381;
    double x546 = x2*x545;
    double x547 = 0.66666666600000002*x24;
    double x548 = x105 + 3.3333333320000005*x14;
    double x549 = x2*x21;
    double x550 = 0.22222222177777778*x110;
    double x551 = 0.66666666600000002*x369;
    double x552 = 16.628925219677555*x11 + x129*x544 - x20*x547 + x280*x550 + 2*x370 + x372*x542 - 5.5429750676828764*x374 + x383 - x472*x551 - 8.3144626098387775*x546 + x548*x549;
    double x553 = 1.0/n5;
    double x554 = 0.33333333300000001*x546;
    double x555 = x2*(x121 - 33.25785043935511*x8) - x20*x554 + x382*x542 + x390*x553 + x391 - x42 + x44 + x483 + x520 + x543*x549 + 16.628925219677555*x6 + x65;
    double x556 = x151*x555;
    double x557 = -x392*x416 + x392*x418 + x555*x7 - x556;
    double x558 = 49.886775659032665*x2;
    double x559 = x176*x2;
    double x560 = 49.886775659032665*x11 - x175*x547 + x301*x550 + x372*x558 - 16.628925203048631*x374 + 2*x394 + x397 - x479*x551 + x544*x99 - 24.943387829516332*x546 + x548*x559;
    double x561 = -x175*x554 + x190 - x191 + x2*(x227 - 99.77355131806533*x8) + x202 + x382*x558 + x402*x553 + x403 + x488 + x530 + x543*x559 + 49.886775659032665*x6;
    double x562 = x248*x561;
    double x563 = x303*x561 - x304*x404 + x404*x433 - x562;
    double x564 = 6.0*x8;
    double x565 = n2*x103;
    double x566 = -149.66032712675832*x565;
    double x567 = n2*x15;
    double x568 = x414*(x567 + x57);
    double x569 = pow(n2, -2);
    double x570 = x268*x414;
    double x571 = 99.773551417838874*x14;
    double x572 = n2*x571 + x126;
    double x573 = 24.943387854459719*x570 + x572;
    double x574 = -99.773551417838874*x8;
    double x575 = -x15*x20;
    double x576 = x138 + x147;
    double x577 = x575 + x576;
    double x578 = x574 + x577;
    double x579 = x131*x149;
    double x580 = 448.98098138027495*x14;
    double x581 = -448.98098138027495*x565;
    double x582 = 299.32065425351664*x14;
    double x583 = n2*x582;
    double x584 = x229 + 74.830163563379159*x570 + x583;
    double x585 = -x15*x175 + x231 + x233;
    double x586 = x245 + x585;
    double x587 = x586 - 299.32065425351664*x8;
    double x588 = x131*x246;
    double x589 = x414*(x316 + x567);
    double x590 = x129*x589 + x2*(x566 + x571) + x573;
    double x591 = x172 + x419;
    double x592 = x265*x439 - x266*x439;
    double x593 = x2*(x581 + x582) + x584 + x589*x99;
    double x594 = x261 + x434;
    double x595 = x289*x445 - x290*x445;
    double x596 = -33.257850472612958*x8;
    double x597 = x323 + x575;
    double x598 = x330 + x596 + x597;
    double x599 = x265*x449 - x266*x449;
    double x600 = x354 + x585;
    double x601 = x352 + x600 - 99.773551417838888*x8;
    double x602 = x289*x459 - x290*x459;
    double x603 = x138 + x597 - 41.572313115709584*x8;
    double x604 = x265*x467 - x266*x467;
    double x605 = x241 + x600 - 124.71693934712876*x8;
    double x606 = x289*x477 - x290*x477;
    double x607 = x2*(x113 + x566) + x572;
    double x608 = x575 + x607;
    double x609 = x172 + x274;
    double x610 = x2*(x221 + x581) + x583;
    double x611 = x229 + x610;
    double x612 = x585 + x611;
    double x613 = x261 + x297;
    double x614 = x323 + x608;
    double x615 = x440 + x609;
    double x616 = x354 + x612;
    double x617 = x446 + x613;
    double x618 = x393 + x468;
    double x619 = x405 + x478;
    double x620 = x510 + x512 + x575;
    double x621 = x509 + x620 + 74.830163563379173*x8;
    double x622 = x526 + x527 + x585;
    double x623 = x525 + x622;
    double x624 = x607 + x620;
    double x625 = x536 + 66.515700920282541*x8;
    double x626 = x611 + x622;
    double x627 = x539 + 199.54710276084762*x8;
    double x628 = x138 + 49.886775659032665*x8;
    double x629 = x241 + 149.66032697709795*x8;
    double x630 = n3*x103;
    double x631 = -149.66032712675832*x630;
    double x632 = n3*x15;
    double x633 = x482*(x57 + x632);
    double x634 = pow(n3, -2);
    double x635 = x307*x482;
    double x636 = x115 + x119;
    double x637 = n3*x571 + x116 + x122 + x636;
    double x638 = 24.943387854459719*x635 + x637;
    double x639 = -448.98098138027495*x630;
    double x640 = n3*x582 + x223 + x228;
    double x641 = 74.830163563379159*x635 + x640;
    double x642 = x482*(x316 + x632);
    double x643 = x129*x642 + x2*(x571 + x631) + x638;
    double x644 = x172 + x487;
    double x645 = x265*x495 - x266*x495;
    double x646 = x2*(x582 + x639) + x641 + x642*x99;
    double x647 = x261 + x492;
    double x648 = x289*x500 - x290*x500;
    double x649 = x265*x503 - x266*x503;
    double x650 = x289*x505 - x290*x505;
    double x651 = x2*(x113 + x631) + x637;
    double x652 = x172 + x311;
    double x653 = x2*(x221 + x639) + x640;
    double x654 = x261 + x314;
    double x655 = x620 + x651;
    double x656 = x622 + x653;
    double x657 = n4*x103;
    double x658 = -49.886775708919437*x657;
    double x659 = n4*x15;
    double x660 = x514*(x57 + x659);
    double x661 = pow(n4, -2);
    double x662 = x339*x514;
    double x663 = 33.257850472612958*x14;
    double x664 = 2*x34;
    double x665 = x342*(-x0*x104 + x131);
    double x666 = 2*x515;
    double x667 = x516*x518;
    double x668 = x343/((x0)*(x0)*(x0));
    double x669 = x129*x517 - x129*x519 - x15*x36 + 24.943387854459719*x344 + x515*x665 + x517*x664 - x519*x664 - x666*x667 + x666*x668;
    double x670 = n4*x663 + x115 + x125 - x15*x47 + x669;
    double x671 = 8.3144626181532395*x662 + x670;
    double x672 = -149.66032712675832*x657;
    double x673 = 2*x185;
    double x674 = 2*x529;
    double x675 = -x15*x187 + 74.830163563379159*x344 + x517*x673 + x517*x99 - x519*x673 - x519*x99 + x529*x665 - x667*x674 + x668*x674;
    double x676 = n4*x571 - x15*x194 + x230 + x675;
    double x677 = 24.943387854459719*x662 + x676;
    double x678 = x514*(x316 + x659);
    double x679 = x172 + x265*x537 - x266*x537;
    double x680 = x261 + x289*x540 - x290*x540;
    double x681 = n5*x103;
    double x682 = x388*x553;
    double x683 = 2*x543;
    double x684 = x553*(n5*x15 + x57);
    double x685 = x2*x544;
    double x686 = pow(n5, -2);
    double x687 = 0.66666666600000002*x545;
    double x688 = x105 + 1.9999999980000001*x14;
    double x689 = 0.22222222177777778*x109*x381;
    double x690 = 0.66666666600000002*x543;

if (x173) {
   result[0] = x131*x153 + x150*(x112 + x148) - 3*x152 + x172 + x78*x79 - 6.0*x97;
}
else {
   result[0] = -x13*x220 + x131*x250 + x211*x7 + x247*(x235 + x238 + x245) - 3*x249 + x261;
}
if (x173) {
   result[1] = x275 + x286;
}
else {
   result[1] = x298 + x306;
}
if (x173) {
   result[2] = x267 + x286 + x311;
}
else {
   result[2] = x291 + x306 + x314;
}
if (x173) {
   result[3] = x150*(x112 + x315 + x323 + x331) + x332 + x338 + x348;
}
else {
   result[3] = x247*(x238 + x349 + x356) + x357 + x363 + x368;
}
if (x173) {
   result[4] = x150*(x139 + x323 + x379 + 24.943387837830794*x8) + x332 + x387 + x393;
}
else {
   result[4] = x247*(x395 + x396 + 74.83016351349238*x8) + x357 + x401 + x405;
}
if (x173) {
   result[5] = x409 + x419;
}
else {
   result[5] = x425 + x434;
}
if (x173) {
   result[6] = x275 + x408 + x440;
}
else {
   result[6] = x298 + x424 + x446;
}
if (x173) {
   result[7] = x450 + x453 + x456;
}
else {
   result[7] = x460 + x463 + x465;
}
if (x173) {
   result[8] = x453 + x468 + x475;
}
else {
   result[8] = x463 + x478 + x481;
}
if (x173) {
   result[9] = x409 + x487;
}
else {
   result[9] = x425 + x492;
}
if (x173) {
   result[10] = x456 + x493 + x497;
}
else {
   result[10] = x465 + x498 + x502;
}
if (x173) {
   result[11] = x475 + x493 + x504;
}
else {
   result[11] = x481 + x498 + x506;
}
if (x173) {
   result[12] = x150*(x112 + x507 + x509 + x513) + x338 + x451 + x524;
}
else {
   result[12] = x247*(x238 + x429 + x525 + x528) + x363 + x461 + x534;
}
if (x173) {
   result[13] = x150*(x379 + x513 + x536 + 58.201238310443756*x8) + x348 + x451 + x455 + x474 + x538;
}
else {
   result[13] = x247*(x395 + x528 + x539 + 174.60371493133124*x8) + x368 + x461 + x464 + x480 + x541;
}
if (x173) {
   result[14] = x150*(x138 + x513 + x552 + 58.201238293814825*x8) + x387 + x451 + x557;
}
else {
   result[14] = x247*(x241 + x528 + x560 + 174.60371488144449*x8) + x401 + x461 + x563;
}
if (x173) {
   result[15] = x150*(x129*x568 + x2*(x221 + x566) - x270*x569 + x573 + x578) + x172 - x272*x564 + x272*x579 + x415*x79 - 3*x417;
}
else {
   result[15] = -x13*x294 + x247*(x2*(x580 + x581) - x292*x569 + x568*x99 + x584 + x587) + x261 + x294*x588 + x431*x7 - 3*x432;
}
if (x173) {
   result[16] = x150*(-x507 + x577 + x590) + x311 + x591 + x592;
}
else {
   result[16] = x247*(x430 + x586 + x593) + x314 + x594 + x595;
}
if (x173) {
   result[17] = x150*(x590 + x598) + x348 + x591 + x599;
}
else {
   result[17] = x247*(x593 + x601) + x368 + x594 + x602;
}
if (x173) {
   result[18] = x150*(x590 + x603) + x393 + x591 + x604;
}
else {
   result[18] = x247*(x593 + x605) + x405 + x594 + x606;
}
if (x173) {
   result[19] = x150*(x276 + x576 + x608) + x487 + x592 + x609;
}
else {
   result[19] = x247*(x300 + x612) + x492 + x595 + x613;
}
if (x173) {
   result[20] = x150*(x330 + x614 + 41.572313090766201*x8) + x450 + x496 + x615;
}
else {
   result[20] = x247*(x352 + x616 + 124.7169392722986*x8) + x460 + x501 + x617;
}
if (x173) {
   result[21] = x150*(x138 + x614 + 33.257850447669568*x8) + x504 + x615 + x618;
}
else {
   result[21] = x247*(x241 + x616 + 99.77355134300872*x8) + x506 + x617 + x619;
}
if (x173) {
   result[22] = x150*(x607 + x621) + x524 + x599 + x609;
}
else {
   result[22] = x247*(x421 + x610 + x623) + x534 + x602 + x613;
}
if (x173) {
   result[23] = x150*(x624 + x625) + x450 + x538 + x609 + x618;
}
else {
   result[23] = x247*(x626 + x627) + x460 + x541 + x613 + x619;
}
if (x173) {
   result[24] = x150*(x624 + x628) + x557 + x604 + x609;
}
else {
   result[24] = x247*(x626 + x629) + x563 + x606 + x613;
}
if (x173) {
   result[25] = x150*(x129*x633 + x2*(x221 + x631) - x309*x634 + x578 + x638) + x172 - x310*x564 + x310*x579 + x485*x79 - 3*x486;
}
else {
   result[25] = -x13*x313 + x247*(x2*(x580 + x639) - x312*x634 + x587 + x633*x99 + x641) + x261 + x313*x588 + x490*x7 - 3*x491;
}
if (x173) {
   result[26] = x150*(x598 + x643) + x348 + x644 + x645;
}
else {
   result[26] = x247*(x601 + x646) + x368 + x647 + x648;
}
if (x173) {
   result[27] = x150*(x603 + x643) + x393 + x644 + x649;
}
else {
   result[27] = x247*(x605 + x646) + x405 + x647 + x650;
}
if (x173) {
   result[28] = x150*(x621 + x651) + x524 + x645 + x652;
}
else {
   result[28] = x247*(x420 + x623 + x653) + x534 + x648 + x654;
}
if (x173) {
   result[29] = x150*(x625 + x655) + x393 + x497 + x504 + x538 + x652;
}
else {
   result[29] = x247*(x627 + x656) + x405 + x502 + x506 + x541 + x654;
}
if (x173) {
   result[30] = x150*(x628 + x655) + x557 + x649 + x652;
}
else {
   result[30] = x247*(x629 + x656) + x563 + x650 + x654;
}
if (x173) {
   result[31] = x150*(x112 + x2*(x113 + x658) - x341*x661 + x535*x660 + x596 + x671) + x172 - x347*x564 + x347*x579 + x522*x79 - 3*x523;
}
else {
   result[31] = -x13*x367 + x247*(x129*x660 + x2*(x221 + x672) + x238 - x364*x661 + x574 + x677) + x261 + x367*x588 + x532*x7 - 3*x533;
}
if (x173) {
   result[32] = x150*(x2*(x658 + x663) + x379 + x535*x678 + x671 - 1.6628924015549273e-8*x8) + x393 + x524 + x679;
}
else {
   result[32] = x247*(x129*x678 + x2*(x571 + x672) + x395 + x677 - 4.988677204664782e-8*x8) + x405 + x534 + x680;
}
if (x173) {
   result[33] = x150*(x2*(x117 + x658) + x552 + x670 + 41.572313057508353*x8) + x348 + x557 + x679;
}
else {
   result[33] = x247*(x2*(x113 + x672) + x560 + x676 + 124.71693917252504*x8) + x368 + x563 + x680;
}
if (x173) {
   result[34] = x150*(66.51570087871022*x120 + x124 + x138 + x2*(x226 - 99.77355131806533*x681) - x20*x687 + x21*x683 + x280*x689 + 24.943387829516332*x382 - x390*x686 - x472*x690 + x542*x684 - 8.3144626015243155*x546 + x549*x688 + x636 + x669 + 16.628925219677555*x682 + 24.943387829516332*x685 - 66.51570087871022*x8) + x172 - x392*x564 + x392*x579 + x555*x79 - 3*x556;
}
else {
   result[34] = -x13*x404 + x247*(199.54710263613066*x120 - x175*x687 + x176*x683 + x2*(299.32065395419602*x14 - 299.32065395419602*x681) + x225 + x233 + x301*x689 + 74.830163488549005*x382 - x402*x686 + x422 - x479*x690 - 24.943387804572946*x546 + x558*x684 + x559*x688 + x675 + 49.886775659032665*x682 + 74.830163488549005*x685 - 199.54710263613066*x8) + x261 + x404*x588 + x561*x7 - 3*x562;
}
}
        
static double coder_dgdp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = 1.0/(n1 + n2 + n3 + n4 + n5);
    double x1 = 0.10299999999999999*n1*n3;
    double x2 = n1*(*endmember[0].dmu0dP)(T, P);
    double x3 = n2*(*endmember[1].dmu0dP)(T, P);
    double x4 = n3*(*endmember[2].dmu0dP)(T, P);
    double x5 = n4*(*endmember[3].dmu0dP)(T, P);
    double x6 = n5*(*endmember[4].dmu0dP)(T, P);

if (T >= 7.5) {
   result = x0*(x1 + (1.0*n1 + 1.0*n2 + 1.0*n3 + 1.0*n4 + 1.0*n5)*(x2 + x3 + x4 + x5 + x6));
}
else {
   result = x0*(x1 + (0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5)*(3*x2 + 3*x3 + 3*x4 + 3*x5 + 3*x6));
}
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n1 + n2 + n3 + n4 + n5;
    double x1 = pow(x0, -2);
    double x2 = 0.10299999999999999*n3;
    double x3 = n1*x2;
    double x4 = 1.0*n1;
    double x5 = 1.0*n2;
    double x6 = 1.0*n3;
    double x7 = 1.0*n4;
    double x8 = 1.0*n5;
    double x9 = x4 + x5 + x6 + x7 + x8;
    double x10 = (*endmember[0].dmu0dP)(T, P);
    double x11 = n1*x10;
    double x12 = (*endmember[1].dmu0dP)(T, P);
    double x13 = n2*x12;
    double x14 = (*endmember[2].dmu0dP)(T, P);
    double x15 = n3*x14;
    double x16 = (*endmember[3].dmu0dP)(T, P);
    double x17 = n4*x16;
    double x18 = (*endmember[4].dmu0dP)(T, P);
    double x19 = n5*x18;
    double x20 = -x1*(x3 + x9*(x11 + x13 + x15 + x17 + x19));
    double x21 = 1.0/x0;
    double x22 = x10*x4 + x12*x5 + x14*x6 + x16*x7 + x18*x8;
    double x23 = x2 + x22;
    double x24 = T >= 7.5;
    double x25 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5;
    double x26 = -x1*(x25*(3*x11 + 3*x13 + 3*x15 + 3*x17 + 3*x19) + x3);
    double x27 = 3*x25;
    double x28 = 0.10299999999999999*n1 + x22;

if (x24) {
   result[0] = x20 + x21*(x10*x9 + x23);
}
else {
   result[0] = x21*(x10*x27 + x23) + x26;
}
if (x24) {
   result[1] = x20 + x21*(x12*x9 + x22);
}
else {
   result[1] = x21*(x12*x27 + x22) + x26;
}
if (x24) {
   result[2] = x20 + x21*(x14*x9 + x28);
}
else {
   result[2] = x21*(x14*x27 + x28) + x26;
}
if (x24) {
   result[3] = x20 + x21*(x16*x9 + x22);
}
else {
   result[3] = x21*(x16*x27 + x22) + x26;
}
if (x24) {
   result[4] = x20 + x21*(x18*x9 + x22);
}
else {
   result[4] = x21*(x18*x27 + x22) + x26;
}
}
        
static void coder_d3gdn2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2 + n3 + n4 + n5;
    double x2 = 1.0/x1;
    double x3 = 2.0*x2;
    double x4 = x0*x3;
    double x5 = 0.10299999999999999*n3;
    double x6 = n1*x5;
    double x7 = 1.0*n1;
    double x8 = 1.0*n2;
    double x9 = 1.0*n3;
    double x10 = 1.0*n4;
    double x11 = 1.0*n5;
    double x12 = x10 + x11 + x7 + x8 + x9;
    double x13 = n1*x0;
    double x14 = (*endmember[1].dmu0dP)(T, P);
    double x15 = n2*x14;
    double x16 = (*endmember[2].dmu0dP)(T, P);
    double x17 = n3*x16;
    double x18 = (*endmember[3].dmu0dP)(T, P);
    double x19 = n4*x18;
    double x20 = (*endmember[4].dmu0dP)(T, P);
    double x21 = n5*x20;
    double x22 = 2/((x1)*(x1)*(x1));
    double x23 = x22*(x12*(x13 + x15 + x17 + x19 + x21) + x6);
    double x24 = pow(x1, -2);
    double x25 = x0*x7 + x10*x18 + x11*x20 + x14*x8 + x16*x9;
    double x26 = x25 + x5;
    double x27 = x24*(x0*x12 + x26);
    double x28 = T >= 7.5;
    double x29 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5;
    double x30 = x22*(x29*(3*x13 + 3*x15 + 3*x17 + 3*x19 + 3*x21) + x6);
    double x31 = 3*x29;
    double x32 = x24*(x0*x31 + x26);
    double x33 = 1.0*x0;
    double x34 = 1.0*x14;
    double x35 = x2*(x33 + x34);
    double x36 = x24*(x12*x14 + x25);
    double x37 = -x36;
    double x38 = x23 - x27;
    double x39 = x24*(x14*x31 + x25);
    double x40 = -x39;
    double x41 = x30 - x32;
    double x42 = 1.0*x16;
    double x43 = x2*(x33 + x42 + 0.10299999999999999);
    double x44 = 0.10299999999999999*n1 + x25;
    double x45 = x24*(x12*x16 + x44);
    double x46 = -x45;
    double x47 = x24*(x16*x31 + x44);
    double x48 = -x47;
    double x49 = 1.0*x18;
    double x50 = x2*(x33 + x49);
    double x51 = x24*(x12*x18 + x25);
    double x52 = -x51;
    double x53 = x24*(x18*x31 + x25);
    double x54 = -x53;
    double x55 = 1.0*x20;
    double x56 = x2*(x33 + x55);
    double x57 = x24*(x12*x20 + x25);
    double x58 = -x57;
    double x59 = x24*(x20*x31 + x25);
    double x60 = -x59;
    double x61 = x14*x3;
    double x62 = x2*(x34 + x42);
    double x63 = x23 + x37;
    double x64 = x30 + x40;
    double x65 = x2*(x34 + x49);
    double x66 = x2*(x34 + x55);
    double x67 = x16*x3;
    double x68 = x2*(x42 + x49);
    double x69 = x23 + x46;
    double x70 = x30 + x48;
    double x71 = x2*(x42 + x55);
    double x72 = x18*x3;
    double x73 = x2*(x49 + x55);
    double x74 = x20*x3;

if (x28) {
   result[0] = x23 - 2*x27 + x4;
}
else {
   result[0] = x30 - 2*x32 + x4;
}
if (x28) {
   result[1] = x35 + x37 + x38;
}
else {
   result[1] = x35 + x40 + x41;
}
if (x28) {
   result[2] = x38 + x43 + x46;
}
else {
   result[2] = x41 + x43 + x48;
}
if (x28) {
   result[3] = x38 + x50 + x52;
}
else {
   result[3] = x41 + x50 + x54;
}
if (x28) {
   result[4] = x38 + x56 + x58;
}
else {
   result[4] = x41 + x56 + x60;
}
if (x28) {
   result[5] = x23 - 2*x36 + x61;
}
else {
   result[5] = x30 - 2*x39 + x61;
}
if (x28) {
   result[6] = x46 + x62 + x63;
}
else {
   result[6] = x48 + x62 + x64;
}
if (x28) {
   result[7] = x52 + x63 + x65;
}
else {
   result[7] = x54 + x64 + x65;
}
if (x28) {
   result[8] = x58 + x63 + x66;
}
else {
   result[8] = x60 + x64 + x66;
}
if (x28) {
   result[9] = x23 - 2*x45 + x67;
}
else {
   result[9] = x30 - 2*x47 + x67;
}
if (x28) {
   result[10] = x52 + x68 + x69;
}
else {
   result[10] = x54 + x68 + x70;
}
if (x28) {
   result[11] = x58 + x69 + x71;
}
else {
   result[11] = x60 + x70 + x71;
}
if (x28) {
   result[12] = x23 - 2*x51 + x72;
}
else {
   result[12] = x30 - 2*x53 + x72;
}
if (x28) {
   result[13] = x23 + x52 + x58 + x73;
}
else {
   result[13] = x30 + x54 + x60 + x73;
}
if (x28) {
   result[14] = x23 - 2*x57 + x74;
}
else {
   result[14] = x30 - 2*x59 + x74;
}
}
        
static void coder_d4gdn3dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2 + n3 + n4 + n5;
    double x2 = pow(x1, -2);
    double x3 = x0*x2;
    double x4 = -6.0*x3;
    double x5 = 0.10299999999999999*n3;
    double x6 = n1*x5;
    double x7 = 1.0*n1;
    double x8 = 1.0*n2;
    double x9 = 1.0*n3;
    double x10 = 1.0*n4;
    double x11 = 1.0*n5;
    double x12 = x10 + x11 + x7 + x8 + x9;
    double x13 = n1*x0;
    double x14 = (*endmember[1].dmu0dP)(T, P);
    double x15 = n2*x14;
    double x16 = (*endmember[2].dmu0dP)(T, P);
    double x17 = n3*x16;
    double x18 = (*endmember[3].dmu0dP)(T, P);
    double x19 = n4*x18;
    double x20 = (*endmember[4].dmu0dP)(T, P);
    double x21 = n5*x20;
    double x22 = 6/((x1)*(x1)*(x1)*(x1));
    double x23 = -x22*(x12*(x13 + x15 + x17 + x19 + x21) + x6);
    double x24 = x0*x7 + x10*x18 + x11*x20 + x14*x8 + x16*x9;
    double x25 = x24 + x5;
    double x26 = x0*x12 + x25;
    double x27 = pow(x1, -3);
    double x28 = 6*x27;
    double x29 = T >= 7.5;
    double x30 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5;
    double x31 = -x22*(x30*(3*x13 + 3*x15 + 3*x17 + 3*x19 + 3*x21) + x6);
    double x32 = 3*x30;
    double x33 = x0*x32 + x25;
    double x34 = 4*x27;
    double x35 = x26*x34;
    double x36 = 1.0*x0;
    double x37 = 1.0*x14;
    double x38 = x2*(x36 + x37);
    double x39 = -2*x38;
    double x40 = -2.0*x3;
    double x41 = x39 + x40;
    double x42 = x12*x14 + x24;
    double x43 = 2*x27;
    double x44 = x23 + x42*x43;
    double x45 = x14*x32 + x24;
    double x46 = x43*x45;
    double x47 = x31 + x33*x34;
    double x48 = 1.0*x16;
    double x49 = x2*(x36 + x48 + 0.10299999999999999);
    double x50 = -2*x49;
    double x51 = x40 + x50;
    double x52 = 0.10299999999999999*n1 + x24;
    double x53 = x12*x16 + x52;
    double x54 = x43*x53;
    double x55 = x23 + x54;
    double x56 = x16*x32 + x52;
    double x57 = x43*x56;
    double x58 = 1.0*x18;
    double x59 = x2*(x36 + x58);
    double x60 = -2*x59;
    double x61 = x40 + x60;
    double x62 = x12*x18 + x24;
    double x63 = x43*x62;
    double x64 = x23 + x63;
    double x65 = x18*x32 + x24;
    double x66 = x43*x65;
    double x67 = 1.0*x20;
    double x68 = x2*(x36 + x67);
    double x69 = -2*x68;
    double x70 = x40 + x69;
    double x71 = x12*x20 + x24;
    double x72 = x43*x71;
    double x73 = x23 + x72;
    double x74 = x20*x32 + x24;
    double x75 = x43*x74;
    double x76 = x34*x42;
    double x77 = 2.0*x2;
    double x78 = -x14*x77;
    double x79 = x39 + x78;
    double x80 = x26*x43;
    double x81 = x23 + x80;
    double x82 = x34*x45;
    double x83 = x31 + x33*x43;
    double x84 = -x49;
    double x85 = x80 + x84;
    double x86 = -x38;
    double x87 = x2*(x37 + x48);
    double x88 = -x87;
    double x89 = x86 + x88;
    double x90 = x44 + x54;
    double x91 = x46 + x83;
    double x92 = x57 + x84;
    double x93 = -x59;
    double x94 = x63 + x93;
    double x95 = x2*(x37 + x58);
    double x96 = -x95;
    double x97 = x86 + x96;
    double x98 = x44 + x80;
    double x99 = x66 + x93;
    double x100 = -x68;
    double x101 = x100 + x72;
    double x102 = x2*(x37 + x67);
    double x103 = -x102;
    double x104 = x103 + x86;
    double x105 = x100 + x75;
    double x106 = x34*x53;
    double x107 = -x16*x77;
    double x108 = x107 + x50;
    double x109 = x34*x56;
    double x110 = x2*(x48 + x58);
    double x111 = -x110;
    double x112 = x55 + x85;
    double x113 = x83 + x92;
    double x114 = x2*(x48 + x67);
    double x115 = -x114;
    double x116 = x34*x62;
    double x117 = -x18*x77;
    double x118 = x117 + x60;
    double x119 = x34*x65;
    double x120 = x2*(x58 + x67);
    double x121 = -x120;
    double x122 = x34*x71;
    double x123 = -x20*x77;
    double x124 = x123 + x69;
    double x125 = x34*x74;
    double x126 = 6.0*x2;
    double x127 = -x126*x14;
    double x128 = -2*x87;
    double x129 = x128 + x78;
    double x130 = x31 + x82;
    double x131 = -2*x95;
    double x132 = x131 + x78;
    double x133 = -2*x102;
    double x134 = x133 + x78;
    double x135 = x107 + x128;
    double x136 = x31 + x46;
    double x137 = x88 + x90;
    double x138 = x63 + x96;
    double x139 = x111 + x66;
    double x140 = x136 + x57 + x88;
    double x141 = x103 + x115;
    double x142 = x117 + x131;
    double x143 = x103 + x121;
    double x144 = x123 + x133;
    double x145 = -x126*x16;
    double x146 = -2*x110;
    double x147 = x107 + x146;
    double x148 = x109 + x31;
    double x149 = -2*x114;
    double x150 = x107 + x149;
    double x151 = x117 + x146;
    double x152 = x31 + x57;
    double x153 = x115 + x121;
    double x154 = x123 + x149;
    double x155 = -x126*x18;
    double x156 = -2*x120;
    double x157 = x117 + x156;
    double x158 = x123 + x156;
    double x159 = -x126*x20;

if (x29) {
   result[0] = x23 + x26*x28 + x4;
}
else {
   result[0] = x28*x33 + x31 + x4;
}
if (x29) {
   result[1] = x35 + x41 + x44;
}
else {
   result[1] = x41 + x46 + x47;
}
if (x29) {
   result[2] = x35 + x51 + x55;
}
else {
   result[2] = x47 + x51 + x57;
}
if (x29) {
   result[3] = x35 + x61 + x64;
}
else {
   result[3] = x47 + x61 + x66;
}
if (x29) {
   result[4] = x35 + x70 + x73;
}
else {
   result[4] = x47 + x70 + x75;
}
if (x29) {
   result[5] = x76 + x79 + x81;
}
else {
   result[5] = x79 + x82 + x83;
}
if (x29) {
   result[6] = x85 + x89 + x90;
}
else {
   result[6] = x89 + x91 + x92;
}
if (x29) {
   result[7] = x94 + x97 + x98;
}
else {
   result[7] = x91 + x97 + x99;
}
if (x29) {
   result[8] = x101 + x104 + x98;
}
else {
   result[8] = x104 + x105 + x91;
}
if (x29) {
   result[9] = x106 + x108 + x81;
}
else {
   result[9] = x108 + x109 + x83;
}
if (x29) {
   result[10] = x111 + x112 + x94;
}
else {
   result[10] = x111 + x113 + x99;
}
if (x29) {
   result[11] = x101 + x112 + x115;
}
else {
   result[11] = x105 + x113 + x115;
}
if (x29) {
   result[12] = x116 + x118 + x81;
}
else {
   result[12] = x118 + x119 + x83;
}
if (x29) {
   result[13] = x101 + x121 + x64 + x80 + x93;
}
else {
   result[13] = x105 + x121 + x83 + x99;
}
if (x29) {
   result[14] = x122 + x124 + x81;
}
else {
   result[14] = x124 + x125 + x83;
}
if (x29) {
   result[15] = x127 + x23 + x28*x42;
}
else {
   result[15] = x127 + x28*x45 + x31;
}
if (x29) {
   result[16] = x129 + x55 + x76;
}
else {
   result[16] = x129 + x130 + x57;
}
if (x29) {
   result[17] = x132 + x64 + x76;
}
else {
   result[17] = x130 + x132 + x66;
}
if (x29) {
   result[18] = x134 + x73 + x76;
}
else {
   result[18] = x130 + x134 + x75;
}
if (x29) {
   result[19] = x106 + x135 + x44;
}
else {
   result[19] = x109 + x135 + x136;
}
if (x29) {
   result[20] = x111 + x137 + x138;
}
else {
   result[20] = x139 + x140 + x96;
}
if (x29) {
   result[21] = x137 + x141 + x72;
}
else {
   result[21] = x140 + x141 + x75;
}
if (x29) {
   result[22] = x116 + x142 + x44;
}
else {
   result[22] = x119 + x136 + x142;
}
if (x29) {
   result[23] = x138 + x143 + x44 + x72;
}
else {
   result[23] = x136 + x143 + x66 + x75 + x96;
}
if (x29) {
   result[24] = x122 + x144 + x44;
}
else {
   result[24] = x125 + x136 + x144;
}
if (x29) {
   result[25] = x145 + x23 + x28*x53;
}
else {
   result[25] = x145 + x28*x56 + x31;
}
if (x29) {
   result[26] = x106 + x147 + x64;
}
else {
   result[26] = x147 + x148 + x66;
}
if (x29) {
   result[27] = x106 + x150 + x73;
}
else {
   result[27] = x148 + x150 + x75;
}
if (x29) {
   result[28] = x116 + x151 + x55;
}
else {
   result[28] = x119 + x151 + x152;
}
if (x29) {
   result[29] = x111 + x153 + x55 + x63 + x72;
}
else {
   result[29] = x139 + x152 + x153 + x75;
}
if (x29) {
   result[30] = x122 + x154 + x55;
}
else {
   result[30] = x125 + x152 + x154;
}
if (x29) {
   result[31] = x155 + x23 + x28*x62;
}
else {
   result[31] = x155 + x28*x65 + x31;
}
if (x29) {
   result[32] = x116 + x157 + x73;
}
else {
   result[32] = x119 + x157 + x31 + x75;
}
if (x29) {
   result[33] = x122 + x158 + x64;
}
else {
   result[33] = x125 + x158 + x31 + x66;
}
if (x29) {
   result[34] = x159 + x23 + x28*x71;
}
else {
   result[34] = x159 + x28*x74 + x31;
}
}
        
static double coder_d2gdt2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = 1.0*n1*(*endmember[0].d2mu0dT2)(T, P) + 1.0*n2*(*endmember[1].d2mu0dT2)(T, P) + 1.0*n3*(*endmember[2].d2mu0dT2)(T, P) + 1.0*n4*(*endmember[3].d2mu0dT2)(T, P) + 1.0*n5*(*endmember[4].d2mu0dT2)(T, P);
    double x1 = 0.13333333333333333*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 0.53525400000000001*T - 4.014405;
    double x7 = 1.0/(x1 - 1);
    double x8 = x7*0;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = 4.014405*((x10)*(x10));

if (T >= 7.5) {
   result = x0;
}
else {
   result = -0.33333333333333331*n2*(8.02881*x10*((x5)*(x5))*x7 - x11*x8 + x11*x9 - x6*x8 + x6*x9 + 16.05762*x5/x3) + x0;
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = 1.0*(*endmember[1].d2mu0dT2)(T, P);
    double x1 = 0.13333333333333333*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 1.0/(x1 - 1);
    double x7 = x6*0;
    double x8 = 0.17841799999999999*T - 1.3381349999999999;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = 1.3381349999999999*((x10)*(x10));

result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
if (T >= 7.5) {
   result[1] = x0;
}
else {
   result[1] = x0 - 2.6762699999999997*x10*((x5)*(x5))*x6 + x11*x7 - x11*x9 + x7*x8 - x8*x9 - 5.3525399999999994*x5/x3;
}
result[2] = 1.0*(*endmember[2].d2mu0dT2)(T, P);
result[3] = 1.0*(*endmember[3].d2mu0dT2)(T, P);
result[4] = 1.0*(*endmember[4].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dTdP)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dTdP)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dTdP)(T, P);
    double x3 = n4*(*endmember[3].d2mu0dTdP)(T, P);
    double x4 = n5*(*endmember[4].d2mu0dTdP)(T, P);

if (T >= 7.5) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3 + 1.0*x4;
}
else {
   result = x0 + x1 + x2 + x3 + x4;
}
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dTdP)(T, P);
result[3] = 1.0*(*endmember[3].d2mu0dTdP)(T, P);
result[4] = 1.0*(*endmember[4].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dP2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dP2)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dP2)(T, P);
    double x3 = n4*(*endmember[3].d2mu0dP2)(T, P);
    double x4 = n5*(*endmember[4].d2mu0dP2)(T, P);

if (T >= 7.5) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3 + 1.0*x4;
}
else {
   result = x0 + x1 + x2 + x3 + x4;
}
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dP2)(T, P);
result[3] = 1.0*(*endmember[3].d2mu0dP2)(T, P);
result[4] = 1.0*(*endmember[4].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = 1.0*n1*(*endmember[0].d3mu0dT3)(T, P) + 1.0*n2*(*endmember[1].d3mu0dT3)(T, P) + 1.0*n3*(*endmember[2].d3mu0dT3)(T, P) + 1.0*n4*(*endmember[3].d3mu0dT3)(T, P) + 1.0*n5*(*endmember[4].d3mu0dT3)(T, P);
    double x1 = 0.13333333333333333*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = pow(x3, -3.0/2.0);
    double x8 = (4 - x4 >= 0. ? 1. : 0.);
    double x9 = 1.6057619999999999*x7*x8;
    double x10 = pow(x2, -2);
    double x11 = x10*x6;
    double x12 = 120.43215000000001*T - 903.24112500000001;
    double x13 = 0.00088888888888888893*x12;
    double x14 = x8/pow(x3, 5.0/2.0);
    double x15 = x7*0;
    double x16 = fmin(4, x4);
    double x17 = ((x16)*(x16));

if (T >= 7.5) {
   result = x0;
}
else {
   result = -0.33333333333333331*n2*(-1.6057619999999999*x10*x16*((x8)*(x8)) + x11*x13 + 0.80288099999999996*x11*x17 - 0.00029629629629629629*x12*x15 + x13*x14 + 0.80288100000000007*x14*x17 - 0.267627*x15*x17 - x16*x6*x9 + 0.53525400000000001*x7*((x8)*(x8)*(x8)) + x9 - 1.6057619999999999*x6/x2) + x0;
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = 1.0*(*endmember[1].d3mu0dT3)(T, P);
    double x1 = 0.13333333333333333*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = 0.5352539999999999*x6;
    double x8 = pow(x3, -3.0/2.0);
    double x9 = (4 - x4 >= 0. ? 1. : 0.);
    double x10 = x8*x9;
    double x11 = pow(x2, -2);
    double x12 = x11*x6;
    double x13 = 120.43215000000001*T - 903.24112500000001;
    double x14 = 0.00029629629629629629*x13;
    double x15 = x9/pow(x3, 5.0/2.0);
    double x16 = x8*0;
    double x17 = fmin(4, x4);
    double x18 = ((x17)*(x17));

result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
if (T >= 7.5) {
   result[1] = x0;
}
else {
   result[1] = x0 + x10*x17*x7 - 0.5352539999999999*x10 + 0.5352539999999999*x11*x17*((x9)*(x9)) - x12*x14 - 0.26762699999999995*x12*x18 + 9.8765432098765426e-5*x13*x16 - x14*x15 - 0.267627*x15*x18 + 0.089208999999999997*x16*x18 - 0.17841799999999999*x8*((x9)*(x9)*(x9)) + x7/x2;
}
result[2] = 1.0*(*endmember[2].d3mu0dT3)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dT3)(T, P);
result[4] = 1.0*(*endmember[4].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT2dP)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT2dP)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dT2dP)(T, P);
    double x3 = n4*(*endmember[3].d3mu0dT2dP)(T, P);
    double x4 = n5*(*endmember[4].d3mu0dT2dP)(T, P);

if (T >= 7.5) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3 + 1.0*x4;
}
else {
   result = x0 + x1 + x2 + x3 + x4;
}
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dT2dP)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dT2dP)(T, P);
result[4] = 1.0*(*endmember[4].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dTdP2)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dTdP2)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dTdP2)(T, P);
    double x3 = n4*(*endmember[3].d3mu0dTdP2)(T, P);
    double x4 = n5*(*endmember[4].d3mu0dTdP2)(T, P);

if (T >= 7.5) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3 + 1.0*x4;
}
else {
   result = x0 + x1 + x2 + x3 + x4;
}
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dTdP2)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dTdP2)(T, P);
result[4] = 1.0*(*endmember[4].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dP3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dP3)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dP3)(T, P);
    double x3 = n4*(*endmember[3].d3mu0dP3)(T, P);
    double x4 = n5*(*endmember[4].d3mu0dP3)(T, P);

if (T >= 7.5) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3 + 1.0*x4;
}
else {
   result = x0 + x1 + x2 + x3 + x4;
}
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dP3)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dP3)(T, P);
result[4] = 1.0*(*endmember[4].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_s(double T, double P, double n[5]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[5]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[5]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[5]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[5]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[5]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[5]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[5]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[5]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[5]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[5]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[5]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[5]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[5]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

