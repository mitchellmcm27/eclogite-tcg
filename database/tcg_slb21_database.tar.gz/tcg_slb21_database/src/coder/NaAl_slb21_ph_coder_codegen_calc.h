#include <math.h>


static double coder_g(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1 + n2 + n3;
    double x1 = 1.0/x0;
    double x2 = n1*(*endmember[0].mu0)(T, P);
    double x3 = n2*(*endmember[1].mu0)(T, P);
    double x4 = n3*(*endmember[2].mu0)(T, P);
    double x5 = T*(2.0*n1*log(n1*x1) + 2.0*n2*log(n2*x1) + 2.0*n3*log(n3*x1) + (0.99999999900000003*n1 + 0.99999999900000003*n2 + 3*n3)*log(x1*(0.33333333300000001*n1 + 0.33333333300000001*n2 + n3)) + (5.0*n1 + 5.0*n2 + 3.0*n3)*log(x1*(1.0*n1 + 1.0*n2 + 0.59999999999999998*n3)));
    double x6 = -30500.0*n1*n3 - 30400.0*n2*n3 - 0.25*n3*(122000.0*n1 + 121600.0*n2);
    double x7 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));

if (T >= 5.0) {
   result = x1*(1.0*x0*(-n2*(26.762699999999999*T - 89.209000000000003) + x2 + x3 + x4 + 8.3144626181532395*x5) + x6);
}
else {
   result = x1*(0.33333333333333331*x0*(n2*(133.8135*((x7)*(x7)*(x7)) + (80.2881*T - 401.44049999999999)*(x7 - 1) - 133.8135) + 3*x2 + 3*x3 + 3*x4 + 24.943387854459719*x5) + x6);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = pow(x0, -2);
    double x2 = (*endmember[0].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[1].mu0)(T, P);
    double x5 = n2*x4;
    double x6 = (*endmember[2].mu0)(T, P);
    double x7 = 26.762699999999999*T;
    double x8 = x7 - 89.209000000000003;
    double x9 = 1.0/x0;
    double x10 = n1*x9;
    double x11 = 2.0*log(x10);
    double x12 = n2*x9;
    double x13 = 2.0*log(x12);
    double x14 = n3*x9;
    double x15 = 2.0*log(x14);
    double x16 = 3*n3;
    double x17 = 0.99999999900000003*n1 + 0.99999999900000003*n2 + x16;
    double x18 = 0.33333333300000001*n1 + 0.33333333300000001*n2 + n3;
    double x19 = log(x18*x9);
    double x20 = 5.0*n1 + 5.0*n2 + 3.0*n3;
    double x21 = 1.0*n1;
    double x22 = 1.0*n2;
    double x23 = x21 + x22;
    double x24 = 0.59999999999999998*n3 + x23;
    double x25 = log(x24*x9);
    double x26 = n1*x11 + n2*x13 + n3*x15 + x17*x19 + x20*x25;
    double x27 = 8.3144626181532395*T;
    double x28 = x26*x27;
    double x29 = -30500.0*n1*n3 - 30400.0*n2*n3 - 0.25*n3*(122000.0*n1 + 121600.0*n2);
    double x30 = -x1*(1.0*x0*(-n2*x8 + n3*x6 + x28 + x3 + x5) + x29);
    double x31 = 1.0*n3;
    double x32 = x23 + x31;
    double x33 = 2.0*x0;
    double x34 = -2.0*x12;
    double x35 = -x1*x18;
    double x36 = x0*x17/x18;
    double x37 = -x1*x24;
    double x38 = x0*x20/x24;
    double x39 = -2.0*x14 + 0.99999999900000003*x19 + 5.0*x25 + x36*(x35 + 0.33333333300000001*x9) + x38*(x37 + 1.0*x9);
    double x40 = x11 + x33*(-n1*x1 + x9) + x34 + x39;
    double x41 = -x22*x8;
    double x42 = x2*x21 + x22*x4 + x28 + x31*x6;
    double x43 = -61000.0*n3 + x42;
    double x44 = T >= 5.0;
    double x45 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));
    double x46 = 133.8135*((x45)*(x45)*(x45)) + (80.2881*T - 401.44049999999999)*(x45 - 1) - 133.8135;
    double x47 = 24.943387854459719*T;
    double x48 = -x1*(0.33333333333333331*x0*(n2*x46 + x16*x6 + x26*x47 + 3*x3 + 3*x5) + x29);
    double x49 = 0.33333333333333331*n2;
    double x50 = 0.33333333333333331*n1 + 0.33333333333333331*n3 + x49;
    double x51 = x46*x49;
    double x52 = -2.0*x10;
    double x53 = x13 + x33*(-n2*x1 + x9) + x39 + x52;
    double x54 = -60800.0*n3 + x42;
    double x55 = x15 + 3*x19 + 3.0*x25 + x33*(-n3*x1 + x9) + x34 + x36*(x35 + x9) + x38*(x37 + 0.59999999999999998*x9) + x52;
    double x56 = -61000.0*n1 - 60800.0*n2 + x42;

if (x44) {
   result[0] = x30 + x9*(x32*(x2 + x27*x40) + x41 + x43);
}
else {
   result[0] = x48 + x9*(x43 + x50*(3*x2 + x40*x47) + x51);
}
if (x44) {
   result[1] = x30 + x9*(x32*(x27*x53 + x4 - x7 + 89.209000000000003) + x41 + x54);
}
else {
   result[1] = x48 + x9*(x50*(3*x4 + x46 + x47*x53) + x51 + x54);
}
if (x44) {
   result[2] = x30 + x9*(x32*(x27*x55 + x6) + x41 + x56);
}
else {
   result[2] = x48 + x9*(x50*(x47*x55 + 3*x6) + x51 + x56);
}
}
        
static void coder_d2gdn2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = 26.762699999999999*T;
    double x6 = x5 - 89.209000000000003;
    double x7 = n1 + n2 + n3;
    double x8 = 1.0/x7;
    double x9 = n1*x8;
    double x10 = 2.0*log(x9);
    double x11 = 2.0*log(n2*x8);
    double x12 = 2.0*log(n3*x8);
    double x13 = 3*n3;
    double x14 = 0.99999999900000003*n1 + 0.99999999900000003*n2 + x13;
    double x15 = 0.33333333300000001*n1 + 0.33333333300000001*n2 + n3;
    double x16 = log(x15*x8);
    double x17 = 5.0*n1 + 5.0*n2 + 3.0*n3;
    double x18 = 1.0*n1;
    double x19 = 1.0*n2;
    double x20 = x18 + x19;
    double x21 = 0.59999999999999998*n3 + x20;
    double x22 = log(x21*x8);
    double x23 = T*(n1*x10 + n2*x11 + n3*x12 + x14*x16 + x17*x22);
    double x24 = 8.3144626181532395*x23;
    double x25 = 1.0*x7;
    double x26 = -30500.0*n1*n3 - 30400.0*n2*n3 - 0.25*n3*(122000.0*n1 + 121600.0*n2);
    double x27 = pow(x7, -3);
    double x28 = 2*x27;
    double x29 = x28*(x25*(-n2*x6 + n3*x4 + x1 + x24 + x3) + x26);
    double x30 = pow(x7, -2);
    double x31 = 1.0*n3;
    double x32 = x20 + x31;
    double x33 = n1*x30;
    double x34 = 2.0*x7;
    double x35 = x34*(-x33 + x8);
    double x36 = 2.0*x8;
    double x37 = -n2*x36;
    double x38 = -x15*x30;
    double x39 = x38 + 0.33333333300000001*x8;
    double x40 = 1.0/x15;
    double x41 = x14*x40;
    double x42 = x39*x41;
    double x43 = -x21*x30;
    double x44 = x43 + 1.0*x8;
    double x45 = 1.0/x21;
    double x46 = x17*x45;
    double x47 = x44*x46;
    double x48 = -n3*x36 + 0.99999999900000003*x16 + 5.0*x22 + x42*x7 + x47*x7;
    double x49 = T*(x10 + x35 + x37 + x48);
    double x50 = 8.3144626181532395*x49;
    double x51 = -x19*x6;
    double x52 = x0*x18 + x19*x2 + x24 + x31*x4;
    double x53 = -61000.0*n3 + x52;
    double x54 = x30*(x32*(x0 + x50) + x51 + x53);
    double x55 = 2.0*x33;
    double x56 = -x55;
    double x57 = -4.0*x30;
    double x58 = 4.0*x27;
    double x59 = n1*x58;
    double x60 = 2.0*x30;
    double x61 = n2*x60;
    double x62 = x36 + x61;
    double x63 = n3*x60;
    double x64 = x45*x7;
    double x65 = x44*x64;
    double x66 = x40*x7;
    double x67 = x39*x66;
    double x68 = x15*x28;
    double x69 = x41*x7;
    double x70 = -x60;
    double x71 = x21*x28;
    double x72 = x46*x7;
    double x73 = x17/((x21)*(x21));
    double x74 = x44*x73;
    double x75 = x14*x7/((x15)*(x15));
    double x76 = x39*x75;
    double x77 = -x25*x74 + 10.0*x65 + 1.9999999980000001*x67 + x69*(-0.66666666600000002*x30 + x68) + x72*(x70 + x71) - 0.33333333300000001*x76;
    double x78 = x42 + x47 + x63 + x77;
    double x79 = T*(x56 + x62 + x7*(x57 + x59) + x78 + x35/n1);
    double x80 = 8.3144626181532395*x32;
    double x81 = 2.0*x0 + 16.628925236306479*x49;
    double x82 = T >= 5.0;
    double x83 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));
    double x84 = ((x83)*(x83)*(x83));
    double x85 = (80.2881*T - 401.44049999999999)*(x83 - 1);
    double x86 = 133.8135*x84 + x85 - 133.8135;
    double x87 = x28*(x26 + 0.33333333333333331*x7*(n2*x86 + 3*x1 + x13*x4 + 24.943387854459719*x23 + 3*x3));
    double x88 = 0.33333333333333331*n2;
    double x89 = 0.33333333333333331*n1 + 0.33333333333333331*n3 + x88;
    double x90 = x86*x88;
    double x91 = x30*(x53 + x89*(3*x0 + 24.943387854459719*x49) + x90);
    double x92 = 24.943387854459719*x89;
    double x93 = -x36 + x42 + x47 + x63;
    double x94 = x56 + x61 + x7*(x59 + x70) + x93;
    double x95 = T*(x77 + x94);
    double x96 = x34*(-n2*x30 + x8);
    double x97 = -2.0*x9;
    double x98 = T*(x11 + x48 + x96 + x97);
    double x99 = 8.3144626181532395*x98;
    double x100 = -x5 + x99;
    double x101 = x100 + 89.209000000000003;
    double x102 = 1.0*x2;
    double x103 = 1.0*x0 + x50;
    double x104 = x102 + x103;
    double x105 = -60800.0*n3 + x52;
    double x106 = x30*(x105 + x32*(x101 + x2) + x51);
    double x107 = -x106;
    double x108 = x29 - x54;
    double x109 = 44.604500000000002*x84 + 0.33333333333333331*x85 + x99;
    double x110 = x30*(x105 + x89*(3*x2 + x86 + 24.943387854459719*x98) + x90);
    double x111 = -x110;
    double x112 = x87 - x91;
    double x113 = x43 + 0.59999999999999998*x8;
    double x114 = x113*x64;
    double x115 = x38 + x8;
    double x116 = x115*x66;
    double x117 = 0.59999999999999998*x7;
    double x118 = 5.0*x114 + 0.99999999900000003*x116 - x117*x74 + 3.0*x65 + 3*x67 + x69*(-1.3333333330000001*x30 + x68) + x72*(-1.6000000000000001*x30 + x71) - x76;
    double x119 = T*(x118 + x94);
    double x120 = x34*(-n3*x30 + x8);
    double x121 = x115*x41;
    double x122 = x113*x46;
    double x123 = T*(x12 + x120 + x121*x7 + x122*x7 + 3*x16 + 3.0*x22 + x37 + x97);
    double x124 = 8.3144626181532395*x123;
    double x125 = x124 + 1.0*x4;
    double x126 = x103 + x125 - 61000.0;
    double x127 = -61000.0*n1 - 60800.0*n2 + x52;
    double x128 = x30*(x127 + x32*(x124 + x4) + x51);
    double x129 = -x128;
    double x130 = x30*(x127 + x89*(24.943387854459719*x123 + 3*x4) + x90);
    double x131 = -x130;
    double x132 = n2*x58;
    double x133 = x55 - x61;
    double x134 = T*(x133 + x36 + x7*(x132 + x57) + x78 + x96/n2);
    double x135 = 2.0*x2 + 16.628925236306479*x98;
    double x136 = T*(x118 + x133 + x7*(x132 + x70) + x93);
    double x137 = x102 + x125;
    double x138 = T*(-x113*x117*x73 + 6.0*x114 - x115*x75 + 6*x116 + x121 + x122 + x55 + x62 - x63 + x69*(-2*x30 + x68) + x7*(n3*x58 + x57) + x72*(-1.2*x30 + x71) + x120/n3);
    double x139 = 16.628925236306479*x123 + 2.0*x4;

if (x82) {
   result[0] = x29 - 2*x54 + x8*(x79*x80 + x81);
}
else {
   result[0] = x8*(x79*x92 + x81) + x87 - 2*x91;
}
if (x82) {
   result[1] = x107 + x108 + x8*(x101 + x104 + x80*x95);
}
else {
   result[1] = x111 + x112 + x8*(x104 + x109 + x92*x95 - 44.604500000000002);
}
if (x82) {
   result[2] = x108 + x129 + x8*(x119*x80 + x126);
}
else {
   result[2] = x112 + x131 + x8*(x119*x92 + x126);
}
if (x82) {
   result[3] = -2*x106 + x29 + x8*(-53.525399999999998*T + x134*x80 + x135 + 178.41800000000001);
}
else {
   result[3] = -2*x110 + x8*(x134*x92 + x135 + 89.209000000000003*x84 + 0.66666666666666663*x85 - 89.209000000000003) + x87;
}
if (x82) {
   result[4] = x107 + x129 + x29 + x8*(x100 + x136*x80 + x137 - 60710.790999999997);
}
else {
   result[4] = x111 + x131 + x8*(x109 + x136*x92 + x137 - 60844.604500000001) + x87;
}
if (x82) {
   result[5] = -2*x128 + x29 + x8*(x138*x80 + x139);
}
else {
   result[5] = -2*x130 + x8*(x138*x92 + x139) + x87;
}
}
        
static void coder_d3gdn3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = 26.762699999999999*T;
    double x6 = x5 - 89.209000000000003;
    double x7 = n1 + n2 + n3;
    double x8 = 1.0/x7;
    double x9 = 2.0*log(n1*x8);
    double x10 = 2.0*log(n2*x8);
    double x11 = 2.0*log(n3*x8);
    double x12 = 3*n3;
    double x13 = 0.99999999900000003*n1 + 0.99999999900000003*n2 + x12;
    double x14 = 0.33333333300000001*n1 + 0.33333333300000001*n2 + n3;
    double x15 = log(x14*x8);
    double x16 = 5.0*n1 + 5.0*n2 + 3.0*n3;
    double x17 = 1.0*n1;
    double x18 = 1.0*n2;
    double x19 = x17 + x18;
    double x20 = 0.59999999999999998*n3 + x19;
    double x21 = log(x20*x8);
    double x22 = n1*x9 + n2*x10 + n3*x11 + x13*x15 + x16*x21;
    double x23 = 8.3144626181532395*T;
    double x24 = x22*x23;
    double x25 = 1.0*x7;
    double x26 = -30500.0*n1*n3 - 30400.0*n2*n3 - 0.25*n3*(122000.0*n1 + 121600.0*n2);
    double x27 = pow(x7, -4);
    double x28 = 6*x27;
    double x29 = -x28*(x25*(-n2*x6 + n3*x4 + x1 + x24 + x3) + x26);
    double x30 = 1.0*n3;
    double x31 = x19 + x30;
    double x32 = pow(x7, -2);
    double x33 = n1*x32;
    double x34 = -2.0*x33 + 2.0*x8;
    double x35 = x34*x7;
    double x36 = 2.0*x8;
    double x37 = -n2*x36;
    double x38 = 1.0/x14;
    double x39 = -x14*x32;
    double x40 = x39 + 0.33333333300000001*x8;
    double x41 = x38*x40;
    double x42 = x13*x41;
    double x43 = 1.0/x20;
    double x44 = -x20*x32;
    double x45 = x44 + 1.0*x8;
    double x46 = x43*x45;
    double x47 = x16*x46;
    double x48 = -n3*x36 + 0.99999999900000003*x15 + 5.0*x21 + x42*x7 + x47*x7;
    double x49 = x35 + x37 + x48 + x9;
    double x50 = x23*x49;
    double x51 = -x18*x6;
    double x52 = x0*x17 + x18*x2 + x24 + x30*x4;
    double x53 = -61000.0*n3 + x52;
    double x54 = x31*(x0 + x50) + x51 + x53;
    double x55 = pow(x7, -3);
    double x56 = 6*x55;
    double x57 = 2.0*x33;
    double x58 = -x57;
    double x59 = -4.0*x32;
    double x60 = 4.0*x55;
    double x61 = n1*x60;
    double x62 = 1.0/n1;
    double x63 = x34*x62;
    double x64 = 2.0*x32;
    double x65 = n2*x64;
    double x66 = x36 + x65;
    double x67 = n3*x64;
    double x68 = x46*x7;
    double x69 = x41*x7;
    double x70 = 2*x55;
    double x71 = x14*x70;
    double x72 = -0.66666666600000002*x32 + x71;
    double x73 = x13*x38;
    double x74 = x72*x73;
    double x75 = -x64;
    double x76 = x20*x70;
    double x77 = x75 + x76;
    double x78 = x16*x43;
    double x79 = x77*x78;
    double x80 = pow(x20, -2);
    double x81 = x45*x80;
    double x82 = x16*x81;
    double x83 = pow(x14, -2);
    double x84 = x40*x83;
    double x85 = x13*x84;
    double x86 = x7*x85;
    double x87 = -x25*x82 + 10.0*x68 + 1.9999999980000001*x69 + x7*x74 + x7*x79 - 0.33333333300000001*x86;
    double x88 = x42 + x47 + x67 + x87;
    double x89 = x58 + x63*x7 + x66 + x7*(x59 + x61) + x88;
    double x90 = x23*x89;
    double x91 = 16.628925236306479*T;
    double x92 = 2.0*x0 + x49*x91;
    double x93 = x32*(x31*x90 + x92);
    double x94 = 24.943387854459719*T;
    double x95 = x89*x94;
    double x96 = -8.0*x32;
    double x97 = 12.0*x55;
    double x98 = 12.0*x27;
    double x99 = -n1*x98;
    double x100 = 2*x32;
    double x101 = -x100;
    double x102 = n1*x70;
    double x103 = 2.0*x7;
    double x104 = x103*x62;
    double x105 = 8.0*x55;
    double x106 = n2*x60;
    double x107 = -x106;
    double x108 = n1*x105 + x107;
    double x109 = n3*x60;
    double x110 = -x109;
    double x111 = 15.0*x7;
    double x112 = x43*x77;
    double x113 = x38*x7;
    double x114 = x113*x72;
    double x115 = x7*x84;
    double x116 = -x14*x28;
    double x117 = x7*x73;
    double x118 = -x20*x28;
    double x119 = x7*x78;
    double x120 = x103*x16;
    double x121 = pow(x20, -3);
    double x122 = x121*x45;
    double x123 = x7/((x14)*(x14)*(x14));
    double x124 = x123*x40;
    double x125 = x124*x13;
    double x126 = x77*x80;
    double x127 = x7*x83;
    double x128 = x127*x13;
    double x129 = x128*x72;
    double x130 = x111*x112 - x111*x81 + 2.9999999970000002*x114 - 0.99999999800000006*x115 + x117*(x116 + 1.9999999980000001*x55) + x119*(x118 + 6.0*x55) + x120*x122 - x120*x126 + 0.22222222177777778*x125 - 0.66666666600000002*x129 + 2.9999999970000002*x41 + 15.0*x46 + 2*x74 + 2*x79 - 2.0*x82 - 0.66666666600000002*x85;
    double x131 = x110 + x130;
    double x132 = x108 + x131 + x63;
    double x133 = x104*(x101 + x102) + x132 + x7*(x97 + x99) + x96 - x35/((n1)*(n1));
    double x134 = x23*x31;
    double x135 = T >= 5.0;
    double x136 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));
    double x137 = ((x136)*(x136)*(x136));
    double x138 = (80.2881*T - 401.44049999999999)*(x136 - 1);
    double x139 = 133.8135*x137 + x138 - 133.8135;
    double x140 = -x28*(x26 + 0.33333333333333331*x7*(n2*x139 + 3*x1 + x12*x4 + x22*x94 + 3*x3));
    double x141 = 0.33333333333333331*n2;
    double x142 = 0.33333333333333331*n1 + 0.33333333333333331*n3 + x141;
    double x143 = x139*x141;
    double x144 = x142*(3*x0 + x49*x94) + x143 + x53;
    double x145 = x32*(x142*x95 + x92);
    double x146 = x142*x94;
    double x147 = -x32;
    double x148 = x104*(x102 + x147) + x59 + x7*(x105 + x99);
    double x149 = x132 + x148;
    double x150 = -x36 + x42 + x47 + x67;
    double x151 = x150 + x58 + x65 + x7*(x61 + x75);
    double x152 = x151 + x87;
    double x153 = x152*x91;
    double x154 = x153 + x90;
    double x155 = -n2*x32 + x8;
    double x156 = x103*x155;
    double x157 = -n1*x36;
    double x158 = x10 + x156 + x157 + x48;
    double x159 = x158*x23;
    double x160 = x159 - x5;
    double x161 = x160 + 89.209000000000003;
    double x162 = -60800.0*n3 + x52;
    double x163 = x162 + x31*(x161 + x2) + x51;
    double x164 = x163*x70;
    double x165 = x152*x23;
    double x166 = 1.0*x2;
    double x167 = 1.0*x0 + x50;
    double x168 = x166 + x167;
    double x169 = x161 + x165*x31 + x168;
    double x170 = -x100*x169 + x29;
    double x171 = 4*x55;
    double x172 = x171*x54 - x93;
    double x173 = x142*(x139 + x158*x94 + 3*x2) + x143 + x162;
    double x174 = x173*x70;
    double x175 = 44.604500000000002*x137 + 0.33333333333333331*x138 + x159;
    double x176 = x146*x152 + x168 + x175 - 44.604500000000002;
    double x177 = -x100*x176 + x140;
    double x178 = x144*x171 - x145;
    double x179 = -1.3333333330000001*x32 + x71;
    double x180 = x179*x73;
    double x181 = -1.6000000000000001*x32 + x76;
    double x182 = x181*x78;
    double x183 = 3.0*x7;
    double x184 = x43*x7;
    double x185 = x181*x184;
    double x186 = x113*x179;
    double x187 = x7*x81;
    double x188 = 1.2*x16;
    double x189 = x122*x7;
    double x190 = x181*x80;
    double x191 = x128*x179;
    double x192 = 0.59999999999999998*x7;
    double x193 = x112*x183 + 3*x114 - 2.9999999970000002*x115 + x117*(x116 + 3.333333332*x55) + x119*(x118 + 5.2000000000000002*x55) + 0.66666666600000002*x125 - x126*x16*x192 - x129 - x16*x190*x25 + x180 + x182 + 10.0*x185 + 1.9999999980000001*x186 - 9.0*x187 + x188*x189 - 0.33333333300000001*x191 + 4.9999999979999998*x41 + 13.0*x46 + x74 + x79 - 1.6000000000000001*x82 - 1.3333333330000001*x85;
    double x194 = x110 + x193;
    double x195 = x108 + x148 + x194 + x63;
    double x196 = x44 + 0.59999999999999998*x8;
    double x197 = x196*x43;
    double x198 = 5.0*x197;
    double x199 = x39 + x8;
    double x200 = x199*x38;
    double x201 = 0.99999999900000003*x200;
    double x202 = x180*x7 + x182*x7 - x192*x82 + x198*x7 + x201*x7 + 3.0*x68 + 3*x69 - x86;
    double x203 = x151 + x202;
    double x204 = x203*x91;
    double x205 = x204 + x90;
    double x206 = -n3*x32 + x8;
    double x207 = x103*x206;
    double x208 = x199*x73;
    double x209 = x196*x78;
    double x210 = x11 + 3*x15 + x157 + x207 + x208*x7 + x209*x7 + 3.0*x21 + x37;
    double x211 = x210*x23;
    double x212 = -61000.0*n1 - 60800.0*n2 + x52;
    double x213 = x212 + x31*(x211 + x4) + x51;
    double x214 = x213*x70;
    double x215 = x203*x23;
    double x216 = x211 + 1.0*x4;
    double x217 = x167 + x216 - 61000.0;
    double x218 = x215*x31 + x217;
    double x219 = -x100*x218 + x29;
    double x220 = x142*(x210*x94 + 3*x4) + x143 + x212;
    double x221 = x220*x70;
    double x222 = x146*x203 + x217;
    double x223 = -x100*x222 + x140;
    double x224 = x110 + x64;
    double x225 = x108 + x224 + x7*(x60 + x99);
    double x226 = x130 + x225;
    double x227 = 1.0/n2;
    double x228 = x57 - x65;
    double x229 = x156*x227 + x228 + x36 + x7*(x106 + x59) + x88;
    double x230 = x229*x23;
    double x231 = x153 + x230;
    double x232 = x54*x70;
    double x233 = x158*x91 + 2.0*x2;
    double x234 = x32*(-53.525399999999998*T + x230*x31 + x233 + 178.41800000000001);
    double x235 = x163*x171 - x234;
    double x236 = x144*x70;
    double x237 = x229*x94;
    double x238 = x32*(89.209000000000003*x137 + 0.66666666666666663*x138 + x142*x237 + x233 - 89.209000000000003);
    double x239 = x171*x173 - x238;
    double x240 = x150 + x202 + x228 + x7*(x106 + x75);
    double x241 = x23*x240;
    double x242 = x166 + x216;
    double x243 = x160 + x241*x31 + x242 - 60710.790999999997;
    double x244 = x193 + x225;
    double x245 = x165 + x215 + x241;
    double x246 = x146*x240 + x175 + x242 - 60844.604500000001;
    double x247 = -1.2*x32 + x76;
    double x248 = x184*x247;
    double x249 = x101 + x71;
    double x250 = x113*x249;
    double x251 = x196*x80;
    double x252 = x127*x199;
    double x253 = 2*x13;
    double x254 = 0.71999999999999997*x16;
    double x255 = x188*x7;
    double x256 = -6*x115 + x117*(x116 + 4.6666666660000002*x55) + x119*(x118 + 4.4000000000000004*x55) + x124*x253 + 2*x180 + 2*x182 - x183*x251 + 6.0*x185 + 6*x186 - 3.5999999999999996*x187 + x189*x254 - x190*x255 - 2*x191 + x198 + x201 + 5.0*x248 + 0.99999999900000003*x250 - 0.99999999900000003*x252 + 6*x41 + 6.0*x46 - 1.2*x82 - 2*x85;
    double x257 = x225 + x256;
    double x258 = 1.0/n3;
    double x259 = x251*x7;
    double x260 = x117*x249 + x119*x247 - x128*x199 - 0.59999999999999998*x16*x259 + 6.0*x197*x7 + 6*x200*x7 + x207*x258 + x208 + x209 + x57 + x66 - x67 + x7*(x109 + x59);
    double x261 = x23*x260;
    double x262 = x204 + x261;
    double x263 = x210*x91 + 2.0*x4;
    double x264 = x32*(x261*x31 + x263);
    double x265 = x171*x213 - x264;
    double x266 = x260*x94;
    double x267 = x32*(x142*x266 + x263);
    double x268 = x171*x220 - x267;
    double x269 = -n2*x98;
    double x270 = n2*x70;
    double x271 = x103*x227;
    double x272 = -x61;
    double x273 = x272 + x96;
    double x274 = n2*x105;
    double x275 = 2.0*x155*x227 + x274;
    double x276 = x131 + x271*(x101 + x270) + x273 + x275 + x7*(x269 + x97) - x156/((n2)*(n2));
    double x277 = x194 + x271*(x147 + x270) + x272 + x275 + x59 + x7*(x105 + x269);
    double x278 = x240*x91;
    double x279 = x230 + x278;
    double x280 = -x100*x243 + x29;
    double x281 = -x100*x246 + x140;
    double x282 = x224 + x256 + x272 + x274 + x7*(x269 + x60);
    double x283 = x261 + x278;
    double x284 = x199*x253;
    double x285 = 2*x249;
    double x286 = n3*x105 + x103*x258*(n3*x70 + x101) + x107 + x117*(x116 + x56) + x119*(x118 + 3.5999999999999996*x55) + x121*x196*x254*x7 + x123*x284 - x128*x285 - x188*x251 + 9.0*x197 + 9*x200 + 2.0*x206*x258 - x247*x255*x80 + 2*x247*x78 + 9.0*x248 + 9*x250 - 9*x252 - 5.3999999999999995*x259 + x273 - x284*x83 + x285*x73 + x7*(-n3*x98 + x97) - x207/((n3)*(n3));

if (x135) {
   result[0] = x29 + x54*x56 + x8*(x133*x134 + x95) - 3*x93;
}
else {
   result[0] = x140 + x144*x56 - 3*x145 + x8*(x133*x146 + x95);
}
if (x135) {
   result[1] = x164 + x170 + x172 + x8*(x134*x149 + x154);
}
else {
   result[1] = x174 + x177 + x178 + x8*(x146*x149 + x154);
}
if (x135) {
   result[2] = x172 + x214 + x219 + x8*(x134*x195 + x205);
}
else {
   result[2] = x178 + x221 + x223 + x8*(x146*x195 + x205);
}
if (x135) {
   result[3] = x170 + x232 + x235 + x8*(x134*x226 + x231);
}
else {
   result[3] = x177 + x236 + x239 + x8*(x146*x226 + x231);
}
if (x135) {
   result[4] = x164 - x169*x32 + x214 - x218*x32 + x232 - x243*x32 + x29 + x8*(x134*x244 + x245);
}
else {
   result[4] = x140 + x174 - x176*x32 + x221 - x222*x32 + x236 - x246*x32 + x8*(x146*x244 + x245);
}
if (x135) {
   result[5] = x219 + x232 + x265 + x8*(x134*x257 + x262);
}
else {
   result[5] = x223 + x236 + x268 + x8*(x146*x257 + x262);
}
if (x135) {
   result[6] = x163*x56 - 3*x234 + x29 + x8*(x134*x276 + x237);
}
else {
   result[6] = x140 + x173*x56 - 3*x238 + x8*(x146*x276 + x237);
}
if (x135) {
   result[7] = x214 + x235 + x280 + x8*(x134*x277 + x279);
}
else {
   result[7] = x221 + x239 + x281 + x8*(x146*x277 + x279);
}
if (x135) {
   result[8] = x164 + x265 + x280 + x8*(x134*x282 + x283);
}
else {
   result[8] = x174 + x268 + x281 + x8*(x146*x282 + x283);
}
if (x135) {
   result[9] = x213*x56 - 3*x264 + x29 + x8*(x134*x286 + x266);
}
else {
   result[9] = x140 + x220*x56 - 3*x267 + x8*(x146*x286 + x266);
}
}
        
static double coder_dgdt(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = 1.0/(n1 + n2 + n3);
    double x1 = 1.0*n1 + 1.0*n2;
    double x2 = n1*(*endmember[0].dmu0dT)(T, P);
    double x3 = n2*(*endmember[1].dmu0dT)(T, P);
    double x4 = n3*(*endmember[2].dmu0dT)(T, P);
    double x5 = n1*log(n1*x0);
    double x6 = n2*log(n2*x0);
    double x7 = n3*log(n3*x0);
    double x8 = (0.99999999900000003*n1 + 0.99999999900000003*n2 + 3*n3)*log(x0*(0.33333333300000001*n1 + 0.33333333300000001*n2 + n3));
    double x9 = (5.0*n1 + 5.0*n2 + 3.0*n3)*log(x0*(0.59999999999999998*n3 + x1));
    double x10 = sqrt(1 - 0.19999999999999998*T);
    double x11 = 1.0000000000000002*x10;
    double x12 = fmin(4, x11);
    double x13 = (4 - x11 >= 0. ? 1. : 0.)/x10;

if (T >= 5.0) {
   result = x0*(1.0*n3 + x1)*(-26.762699999999999*n2 + x2 + x3 + x4 + 16.628925236306479*x5 + 16.628925236306479*x6 + 16.628925236306479*x7 + 8.3144626181532395*x8 + 8.3144626181532395*x9);
}
else {
   result = x0*(0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3)*(n2*(-40.144050000000007*((x12)*(x12))*x13 + 80.2881*x12 - 0.10000000000000002*x13*(80.2881*T - 401.44049999999999) - 80.2881) + 3*x2 + 3*x3 + 3*x4 + 49.886775708919437*x5 + 49.886775708919437*x6 + 49.886775708919437*x7 + 24.943387854459719*x8 + 24.943387854459719*x9);
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = 1.0/x0;
    double x2 = n1*x1;
    double x3 = log(x2);
    double x4 = 16.628925236306479*x3;
    double x5 = pow(x0, -2);
    double x6 = x0*(-n1*x5 + x1);
    double x7 = n2*x1;
    double x8 = -16.628925236306479*x7;
    double x9 = (*endmember[0].dmu0dT)(T, P);
    double x10 = 0.33333333300000001*n1 + 0.33333333300000001*n2 + n3;
    double x11 = log(x1*x10);
    double x12 = 1.0*n1 + 1.0*n2;
    double x13 = 0.59999999999999998*n3 + x12;
    double x14 = log(x1*x13);
    double x15 = n3*x1;
    double x16 = 24.943387854459719*n3;
    double x17 = 8.3144626098387775*n1 + 8.3144626098387775*n2 + x16;
    double x18 = -x10*x5;
    double x19 = x0/x10;
    double x20 = x19*(0.33333333300000001*x1 + x18);
    double x21 = 41.572313090766201*n1 + 41.572313090766201*n2 + x16;
    double x22 = 1.0*x1;
    double x23 = -x13*x5;
    double x24 = x0/x13;
    double x25 = x24*(x22 + x23);
    double x26 = 8.3144626098387775*x11 + 41.572313090766201*x14 - 16.628925236306479*x15 + x17*x20 + x21*x25;
    double x27 = 1.0*n3 + x12;
    double x28 = x1*x27;
    double x29 = n1*x9;
    double x30 = (*endmember[1].dmu0dT)(T, P);
    double x31 = n2*x30;
    double x32 = (*endmember[2].dmu0dT)(T, P);
    double x33 = n3*x32;
    double x34 = log(x7);
    double x35 = 16.628925236306479*x34;
    double x36 = log(x15);
    double x37 = 16.628925236306479*x36;
    double x38 = 0.99999999900000003*n1 + 0.99999999900000003*n2 + 3*n3;
    double x39 = 5.0*n1 + 5.0*n2 + 3.0*n3;
    double x40 = n1*x4 + n2*x35 - 26.762699999999999*n2 + n3*x37 + 8.3144626181532395*x11*x38 + 8.3144626181532395*x14*x39 + x29 + x31 + x33;
    double x41 = x22*x40 - x27*x40*x5;
    double x42 = T >= 5.0;
    double x43 = 49.886775708919437*x3;
    double x44 = -49.886775708919437*x7;
    double x45 = 74.830163563379159*n3;
    double x46 = 24.943387829516332*n1 + 24.943387829516332*n2 + x45;
    double x47 = 124.71693927229859*n1 + 124.71693927229859*n2 + x45;
    double x48 = 24.943387829516332*x11 + 124.71693927229859*x14 - 49.886775708919437*x15 + x20*x46 + x25*x47;
    double x49 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3;
    double x50 = x1*x49;
    double x51 = 49.886775708919437*x34;
    double x52 = 49.886775708919437*x36;
    double x53 = 24.943387854459719*x11;
    double x54 = 24.943387854459719*x14;
    double x55 = sqrt(1 - 0.19999999999999998*T);
    double x56 = 1.0000000000000002*x55;
    double x57 = fmin(4, x56);
    double x58 = (4 - x56 >= 0. ? 1. : 0.)/x55;
    double x59 = -40.144050000000007*((x57)*(x57))*x58 + 80.2881*x57 - 0.10000000000000002*x58*(80.2881*T - 401.44049999999999) - 80.2881;
    double x60 = n1*x43 + n2*x51 + n2*x59 + n3*x52 + 3*x29 + 3*x31 + 3*x33 + x38*x53 + x39*x54;
    double x61 = 0.33333333333333331*x1*x60 - x49*x5*x60;
    double x62 = -16.628925236306479*x2;
    double x63 = x0*(-n2*x5 + x1);
    double x64 = -49.886775708919437*x2;
    double x65 = x0*(-n3*x5 + x1);
    double x66 = x19*(x1 + x18);
    double x67 = x24*(0.59999999999999998*x1 + x23);

if (x42) {
   result[0] = x28*(x26 + x4 + 16.628925236306479*x6 + x8 + x9) + x41;
}
else {
   result[0] = x50*(x43 + x44 + x48 + 49.886775708919437*x6 + 3*x9) + x61;
}
if (x42) {
   result[1] = x28*(x26 + x30 + x35 + x62 + 16.628925236306479*x63 - 26.762699999999999) + x41;
}
else {
   result[1] = x50*(3*x30 + x48 + x51 + x59 + 49.886775708919437*x63 + x64) + x61;
}
if (x42) {
   result[2] = x28*(x17*x66 + x21*x67 + x32 + x37 + x53 + x54 + x62 + 16.628925236306479*x65 + x8) + x41;
}
else {
   result[2] = x50*(74.830163563379159*x11 + 74.830163563379159*x14 + 3*x32 + x44 + x46*x66 + x47*x67 + x52 + x64 + 49.886775708919437*x65) + x61;
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = 1.0/x0;
    double x2 = n1*x1;
    double x3 = log(x2);
    double x4 = 16.628925236306479*x3;
    double x5 = pow(x0, -2);
    double x6 = n1*x5;
    double x7 = x0*(x1 - x6);
    double x8 = 16.628925236306479*x7;
    double x9 = n2*x1;
    double x10 = -16.628925236306479*x9;
    double x11 = (*endmember[0].dmu0dT)(T, P);
    double x12 = 0.33333333300000001*n1 + 0.33333333300000001*n2 + n3;
    double x13 = log(x1*x12);
    double x14 = 1.0*n1 + 1.0*n2;
    double x15 = 0.59999999999999998*n3 + x14;
    double x16 = log(x1*x15);
    double x17 = n3*x1;
    double x18 = 24.943387854459719*n3;
    double x19 = 8.3144626098387775*n1 + 8.3144626098387775*n2 + x18;
    double x20 = 1.0/x12;
    double x21 = -x12*x5;
    double x22 = 0.33333333300000001*x1 + x21;
    double x23 = x20*x22;
    double x24 = x19*x23;
    double x25 = 41.572313090766201*n1 + 41.572313090766201*n2 + x18;
    double x26 = 1.0/x15;
    double x27 = 1.0*x1;
    double x28 = -x15*x5;
    double x29 = x27 + x28;
    double x30 = x26*x29;
    double x31 = x25*x30;
    double x32 = x0*x24 + x0*x31 + 8.3144626098387775*x13 + 41.572313090766201*x16 - 16.628925236306479*x17;
    double x33 = x10 + x11 + x32 + x4 + x8;
    double x34 = 2.0*x1;
    double x35 = 16.628925236306479*x6;
    double x36 = -x35;
    double x37 = -33.257850472612958*x5;
    double x38 = pow(x0, -3);
    double x39 = n1*x38;
    double x40 = 33.257850472612958*x39;
    double x41 = 1.0/n1;
    double x42 = n2*x5;
    double x43 = 16.628925236306479*x42;
    double x44 = 16.628925236306479*x1;
    double x45 = x43 + x44;
    double x46 = 16.628925236306479*x5;
    double x47 = n3*x46;
    double x48 = x0*x23;
    double x49 = x0*x30;
    double x50 = x0*x19;
    double x51 = 2*x38;
    double x52 = x12*x51;
    double x53 = x20*(-0.66666666600000002*x5 + x52);
    double x54 = 2.0*x5;
    double x55 = x15*x51;
    double x56 = x0*x26;
    double x57 = x56*(-x54 + x55);
    double x58 = x0/((x15)*(x15));
    double x59 = x29*x58;
    double x60 = 1.0*x59;
    double x61 = pow(x12, -2);
    double x62 = x22*x61;
    double x63 = x50*x62;
    double x64 = x25*x57 - x25*x60 + 16.628925219677555*x48 + 83.144626181532402*x49 + x50*x53 - 0.33333333300000001*x63;
    double x65 = x24 + x31 + x47 + x64;
    double x66 = 1.0*n3 + x14;
    double x67 = x1*x66;
    double x68 = 2*x5;
    double x69 = x66*x68;
    double x70 = n1*x11;
    double x71 = (*endmember[1].dmu0dT)(T, P);
    double x72 = n2*x71;
    double x73 = (*endmember[2].dmu0dT)(T, P);
    double x74 = n3*x73;
    double x75 = log(x9);
    double x76 = 16.628925236306479*x75;
    double x77 = log(x17);
    double x78 = 16.628925236306479*x77;
    double x79 = 0.99999999900000003*n1 + 0.99999999900000003*n2 + 3*n3;
    double x80 = 5.0*n1 + 5.0*n2 + 3.0*n3;
    double x81 = n1*x4 + n2*x76 - 26.762699999999999*n2 + n3*x78 + 8.3144626181532395*x13*x79 + 8.3144626181532395*x16*x80 + x70 + x72 + x74;
    double x82 = x51*x66*x81 - x54*x81;
    double x83 = T >= 5.0;
    double x84 = 49.886775708919437*x3;
    double x85 = 49.886775708919437*x7;
    double x86 = -49.886775708919437*x9;
    double x87 = 74.830163563379159*n3;
    double x88 = 24.943387829516332*n1 + 24.943387829516332*n2 + x87;
    double x89 = x23*x88;
    double x90 = 124.71693927229859*n1 + 124.71693927229859*n2 + x87;
    double x91 = x30*x90;
    double x92 = x0*x89 + x0*x91 + 24.943387829516332*x13 + 124.71693927229859*x16 - 49.886775708919437*x17;
    double x93 = 3*x11 + x84 + x85 + x86 + x92;
    double x94 = x1*x93;
    double x95 = 49.886775708919437*x6;
    double x96 = -x95;
    double x97 = -99.773551417838874*x5;
    double x98 = 99.773551417838874*x39;
    double x99 = 49.886775708919437*x42;
    double x100 = 49.886775708919437*x1;
    double x101 = x100 + x99;
    double x102 = 49.886775708919437*x5;
    double x103 = n3*x102;
    double x104 = x0*x88;
    double x105 = x104*x62;
    double x106 = x104*x53 - 0.33333333300000001*x105 + 49.886775659032665*x48 + 249.43387854459718*x49 + x57*x90 - x60*x90;
    double x107 = x103 + x106 + x89 + x91;
    double x108 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3;
    double x109 = x1*x108;
    double x110 = x108*x68;
    double x111 = 49.886775708919437*x75;
    double x112 = 49.886775708919437*x77;
    double x113 = 24.943387854459719*x13;
    double x114 = 24.943387854459719*x16;
    double x115 = sqrt(1 - 0.19999999999999998*T);
    double x116 = 1.0000000000000002*x115;
    double x117 = fmin(4, x116);
    double x118 = (4 - x116 >= 0. ? 1. : 0.)/x115;
    double x119 = -40.144050000000007*((x117)*(x117))*x118 + 80.2881*x117 - 0.10000000000000002*x118*(80.2881*T - 401.44049999999999) - 80.2881;
    double x120 = n1*x84 + n2*x111 + n2*x119 + n3*x112 + x113*x79 + x114*x80 + 3*x70 + 3*x72 + 3*x74;
    double x121 = x108*x120*x51 - 0.66666666666666663*x120*x5;
    double x122 = -x46;
    double x123 = x24 + x31 - x44 + x47;
    double x124 = x0*(x122 + x40) + x123 + x36 + x43;
    double x125 = x5*x66;
    double x126 = -x125*x33 + x27*x33 + x82;
    double x127 = -16.628925236306479*x2;
    double x128 = x0*(x1 - x42);
    double x129 = 16.628925236306479*x128;
    double x130 = x127 + x129 + x32 + x71 + x76 - 26.762699999999999;
    double x131 = -x125*x130 + x130*x27;
    double x132 = -x102;
    double x133 = -x100 + x103 + x89 + x91;
    double x134 = x0*(x132 + x98) + x133 + x96 + x99;
    double x135 = x108*x5;
    double x136 = x121 - x135*x93 + 0.33333333333333331*x94;
    double x137 = -49.886775708919437*x2;
    double x138 = 49.886775708919437*x128;
    double x139 = x111 + x119 + x137 + x138 + 3*x71 + x92;
    double x140 = 0.33333333333333331*x1;
    double x141 = -x135*x139 + x139*x140;
    double x142 = x1 + x21;
    double x143 = x142*x20;
    double x144 = x0*x143;
    double x145 = 0.59999999999999998*x1 + x28;
    double x146 = x145*x26;
    double x147 = x0*x146;
    double x148 = x20*(-1.3333333330000001*x5 + x52);
    double x149 = x56*(-1.6000000000000001*x5 + x55);
    double x150 = 0.59999999999999998*x59;
    double x151 = 8.3144626098387775*x144 + 41.572313090766201*x147 + x148*x50 + x149*x25 - x150*x25 + 24.943387854459719*x48 + 24.943387854459719*x49 - x63;
    double x152 = x0*(-n3*x5 + x1);
    double x153 = 16.628925236306479*x152;
    double x154 = x143*x19;
    double x155 = x146*x25;
    double x156 = x0*x154 + x0*x155 + x10 + x113 + x114 + x127 + x153 + x73 + x78;
    double x157 = -x125*x156 + x156*x27;
    double x158 = x104*x148 - x105 + 24.943387829516332*x144 + 124.71693927229859*x147 + x149*x90 - x150*x90 + 74.830163563379159*x48 + 74.830163563379159*x49;
    double x159 = 49.886775708919437*x152;
    double x160 = x143*x88;
    double x161 = x146*x90;
    double x162 = x0*x160 + x0*x161 + x112 + 74.830163563379159*x13 + x137 + x159 + 74.830163563379159*x16 + 3*x73 + x86;
    double x163 = -x135*x162 + x140*x162;
    double x164 = n2*x38;
    double x165 = 33.257850472612958*x164;
    double x166 = 1.0/n2;
    double x167 = x35 - x43;
    double x168 = 0.66666666666666663*x1;
    double x169 = 99.773551417838874*x164;
    double x170 = x95 - x99;
    double x171 = n3*x38;
    double x172 = 1.0/n3;
    double x173 = x20*(x52 - x68);
    double x174 = x56*(-1.2*x5 + x55);
    double x175 = x142*x61;
    double x176 = 0.59999999999999998*x145*x58;

if (x83) {
   result[0] = x33*x34 - x33*x69 + x67*(x0*(x37 + x40) + x36 + x41*x8 + x45 + x65) + x82;
}
else {
   result[0] = x109*(x0*(x97 + x98) + x101 + x107 + x41*x85 + x96) - x110*x93 + x121 + 0.66666666666666663*x94;
}
if (x83) {
   result[1] = x126 + x131 + x67*(x124 + x64);
}
else {
   result[1] = x109*(x106 + x134) + x136 + x141;
}
if (x83) {
   result[2] = x126 + x157 + x67*(x124 + x151);
}
else {
   result[2] = x109*(x134 + x158) + x136 + x163;
}
if (x83) {
   result[3] = x130*x34 - x130*x69 + x67*(x0*(x165 + x37) + x129*x166 + x167 + x44 + x65) + x82;
}
else {
   result[3] = x109*(x0*(x169 + x97) + x100 + x107 + x138*x166 + x170) - x110*x139 + x121 + x139*x168;
}
if (x83) {
   result[4] = x131 + x157 + x67*(x0*(x122 + x165) + x123 + x151 + x167) + x82;
}
else {
   result[4] = x109*(x0*(x132 + x169) + x133 + x158 + x170) + x121 + x141 + x163;
}
if (x83) {
   result[5] = x156*x34 - x156*x69 + x67*(x0*(33.257850472612958*x171 + x37) + 49.886775708919437*x144 + 49.886775708919437*x147 + x153*x172 + x154 + x155 + x173*x50 + x174*x25 - x175*x50 - x176*x25 + x35 + x45 - x47) + x82;
}
else {
   result[5] = x109*(x0*(99.773551417838874*x171 + x97) + x101 - x103 + x104*x173 - x104*x175 + 149.66032712675832*x144 + 149.66032712675832*x147 + x159*x172 + x160 + x161 + x174*x90 - x176*x90 + x95) - x110*x162 + x121 + x162*x168;
}
}
        
static void coder_d4gdn3dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = pow(x0, -2);
    double x2 = n1*x1;
    double x3 = 16.628925236306479*x2;
    double x4 = -x3;
    double x5 = -33.257850472612958*x1;
    double x6 = pow(x0, -3);
    double x7 = 33.257850472612958*x6;
    double x8 = n1*x7;
    double x9 = 1.0/n1;
    double x10 = 1.0/x0;
    double x11 = x10 - x2;
    double x12 = 16.628925236306479*x11;
    double x13 = x0*x12;
    double x14 = 16.628925236306479*x1;
    double x15 = n2*x14;
    double x16 = 16.628925236306479*x10;
    double x17 = x15 + x16;
    double x18 = n3*x14;
    double x19 = 24.943387854459719*n3;
    double x20 = 8.3144626098387775*n1 + 8.3144626098387775*n2 + x19;
    double x21 = 0.33333333300000001*n1 + 0.33333333300000001*n2 + n3;
    double x22 = 1.0/x21;
    double x23 = -x1*x21;
    double x24 = 0.33333333300000001*x10 + x23;
    double x25 = x22*x24;
    double x26 = x20*x25;
    double x27 = 41.572313090766201*n1 + 41.572313090766201*n2 + x19;
    double x28 = 1.0*n1 + 1.0*n2;
    double x29 = 0.59999999999999998*n3 + x28;
    double x30 = 1.0/x29;
    double x31 = 1.0*x10;
    double x32 = -x1*x29;
    double x33 = x31 + x32;
    double x34 = x30*x33;
    double x35 = x27*x34;
    double x36 = x0*x25;
    double x37 = x0*x34;
    double x38 = 2*x6;
    double x39 = x21*x38;
    double x40 = -0.66666666600000002*x1 + x39;
    double x41 = x20*x22;
    double x42 = x40*x41;
    double x43 = 2.0*x1;
    double x44 = x29*x38;
    double x45 = -x43 + x44;
    double x46 = x27*x30;
    double x47 = x45*x46;
    double x48 = pow(x29, -2);
    double x49 = x33*x48;
    double x50 = x0*x49;
    double x51 = 1.0*x50;
    double x52 = pow(x21, -2);
    double x53 = x24*x52;
    double x54 = x0*x53;
    double x55 = x20*x54;
    double x56 = x0*x42 + x0*x47 - x27*x51 + 16.628925219677555*x36 + 83.144626181532402*x37 - 0.33333333300000001*x55;
    double x57 = x18 + x26 + x35 + x56;
    double x58 = x0*(x5 + x8) + x13*x9 + x17 + x4 + x57;
    double x59 = 3.0*x10;
    double x60 = n1*x10;
    double x61 = log(x60);
    double x62 = 16.628925236306479*x61;
    double x63 = -n2*x16;
    double x64 = (*endmember[0].dmu0dT)(T, P);
    double x65 = log(x10*x21);
    double x66 = log(x10*x29);
    double x67 = -n3*x16 + x0*x26 + x0*x35 + 8.3144626098387775*x65 + 41.572313090766201*x66;
    double x68 = x13 + x62 + x63 + x64 + x67;
    double x69 = x1*x68;
    double x70 = -66.515700945225916*x1;
    double x71 = 99.773551417838874*x6;
    double x72 = pow(x0, -4);
    double x73 = n1*x72;
    double x74 = -99.773551417838874*x73;
    double x75 = 2*x1;
    double x76 = -x75;
    double x77 = n1*x38;
    double x78 = x0*x9;
    double x79 = x78*(x76 + x77);
    double x80 = pow(n1, -2);
    double x81 = x12*x9;
    double x82 = 66.515700945225916*x6;
    double x83 = n2*x7;
    double x84 = -x83;
    double x85 = n1*x82 + x84;
    double x86 = n3*x7;
    double x87 = -x86;
    double x88 = x0*x22;
    double x89 = x40*x88;
    double x90 = 124.7169392722986*x0;
    double x91 = x30*x45;
    double x92 = 2.0*x49;
    double x93 = 0.66666666600000002*x53;
    double x94 = 6*x72;
    double x95 = -x21*x94;
    double x96 = x0*(1.9999999980000001*x6 + x95);
    double x97 = 6.0*x6;
    double x98 = -x29*x94;
    double x99 = x0*(x97 + x98);
    double x100 = 2.0*x0;
    double x101 = x100*x27;
    double x102 = pow(x29, -3);
    double x103 = x102*x33;
    double x104 = x0/((x21)*(x21)*(x21));
    double x105 = x104*x24;
    double x106 = 0.22222222177777778*x105;
    double x107 = x45*x48;
    double x108 = x0*x52;
    double x109 = x108*x40;
    double x110 = x109*x20;
    double x111 = x101*x103 - x101*x107 + x106*x20 - 0.66666666600000002*x110 - x20*x93 + 24.943387829516332*x25 - x27*x92 + 124.7169392722986*x34 + x41*x96 + 2*x42 + x46*x99 + 2*x47 - x49*x90 - 8.3144626015243155*x54 + 24.943387829516332*x89 + x90*x91;
    double x112 = x111 + x87;
    double x113 = x112 + x81 + x85;
    double x114 = 1.0*n3 + x28;
    double x115 = x10*x114;
    double x116 = x1*x114;
    double x117 = x116*x58;
    double x118 = 6*x6;
    double x119 = x114*x68;
    double x120 = n1*x64;
    double x121 = (*endmember[1].dmu0dT)(T, P);
    double x122 = n2*x121;
    double x123 = (*endmember[2].dmu0dT)(T, P);
    double x124 = n3*x123;
    double x125 = n2*x10;
    double x126 = log(x125);
    double x127 = 16.628925236306479*x126;
    double x128 = n3*x10;
    double x129 = log(x128);
    double x130 = 16.628925236306479*x129;
    double x131 = 0.99999999900000003*n1 + 0.99999999900000003*n2 + 3*n3;
    double x132 = 5.0*n1 + 5.0*n2 + 3.0*n3;
    double x133 = n1*x62 + n2*x127 - 26.762699999999999*n2 + n3*x130 + x120 + x122 + x124 + 8.3144626181532395*x131*x65 + 8.3144626181532395*x132*x66;
    double x134 = -x114*x133*x94 + x133*x97;
    double x135 = T >= 5.0;
    double x136 = 49.886775708919437*x2;
    double x137 = -x136;
    double x138 = -99.773551417838874*x1;
    double x139 = n1*x71;
    double x140 = 49.886775708919437*x11;
    double x141 = x0*x140;
    double x142 = n2*x1;
    double x143 = 49.886775708919437*x142;
    double x144 = 49.886775708919437*x10;
    double x145 = x143 + x144;
    double x146 = 49.886775708919437*x1;
    double x147 = n3*x146;
    double x148 = 74.830163563379159*n3;
    double x149 = 24.943387829516332*n1 + 24.943387829516332*n2 + x148;
    double x150 = x149*x25;
    double x151 = 124.71693927229859*n1 + 124.71693927229859*n2 + x148;
    double x152 = x151*x34;
    double x153 = x149*x22;
    double x154 = x153*x40;
    double x155 = x151*x30;
    double x156 = x155*x45;
    double x157 = x149*x54;
    double x158 = x0*x154 + x0*x156 - x151*x51 - 0.33333333300000001*x157 + 49.886775659032665*x36 + 249.43387854459718*x37;
    double x159 = x147 + x150 + x152 + x158;
    double x160 = x0*(x138 + x139) + x137 + x141*x9 + x145 + x159;
    double x161 = 49.886775708919437*x61;
    double x162 = -49.886775708919437*x125;
    double x163 = x0*x150 + x0*x152 - 49.886775708919437*x128 + 24.943387829516332*x65 + 124.71693927229859*x66;
    double x164 = x141 + x161 + x162 + x163 + 3*x64;
    double x165 = -199.54710283567775*x1;
    double x166 = 299.32065425351664*x6;
    double x167 = -299.32065425351664*x73;
    double x168 = x140*x9;
    double x169 = 199.54710283567775*x6;
    double x170 = n2*x71;
    double x171 = -x170;
    double x172 = n1*x169 + x171;
    double x173 = n3*x71;
    double x174 = -x173;
    double x175 = 374.15081781689577*x0;
    double x176 = x100*x151;
    double x177 = x109*x149;
    double x178 = x103*x176 + x106*x149 - x107*x176 - x149*x93 - x151*x92 + x153*x96 + 2*x154 + x155*x99 + 2*x156 - x175*x49 + x175*x91 - 0.66666666600000002*x177 + 74.830163488549005*x25 + 374.15081781689577*x34 - 24.943387804572946*x54 + 74.830163488549005*x89;
    double x179 = x174 + x178;
    double x180 = x168 + x172 + x179;
    double x181 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3;
    double x182 = x10*x181;
    double x183 = x1*x181;
    double x184 = x160*x183;
    double x185 = x164*x181;
    double x186 = 49.886775708919437*x126;
    double x187 = 49.886775708919437*x129;
    double x188 = 24.943387854459719*x65;
    double x189 = 24.943387854459719*x66;
    double x190 = sqrt(1 - 0.19999999999999998*T);
    double x191 = 1.0000000000000002*x190;
    double x192 = fmin(4, x191);
    double x193 = (4 - x191 >= 0. ? 1. : 0.)/x190;
    double x194 = -40.144050000000007*((x192)*(x192))*x193 + 80.2881*x192 - 0.10000000000000002*x193*(80.2881*T - 401.44049999999999) - 80.2881;
    double x195 = n1*x161 + n2*x186 + n2*x194 + n3*x187 + 3*x120 + 3*x122 + 3*x124 + x131*x188 + x132*x189;
    double x196 = -x181*x195*x94 + 2.0*x195*x6;
    double x197 = -x1;
    double x198 = x78*(x197 + x77);
    double x199 = x0*(x74 + x82) + 16.628925236306479*x198 + x5;
    double x200 = -x14;
    double x201 = -x16 + x18 + x26 + x35;
    double x202 = x0*(x200 + x8) + x15 + x201 + x4;
    double x203 = x202 + x56;
    double x204 = 2.0*x10;
    double x205 = x114*x75;
    double x206 = x134 + x203*x204 - x203*x205;
    double x207 = -n1*x16;
    double x208 = x10 - x142;
    double x209 = x0*x208;
    double x210 = 16.628925236306479*x209;
    double x211 = x121 + x127 + x207 + x210 + x67 - 26.762699999999999;
    double x212 = x114*x38;
    double x213 = x211*x212 - x211*x43;
    double x214 = 4*x6;
    double x215 = -x117 + x119*x214 + x31*x58 - 4.0*x69;
    double x216 = -99.773551417838888*x1;
    double x217 = x0*(x167 + x169) + 49.886775708919437*x198 + x216;
    double x218 = -x146;
    double x219 = -x144 + x147 + x150 + x152;
    double x220 = x0*(x139 + x218) + x137 + x143 + x219;
    double x221 = x158 + x220;
    double x222 = 0.66666666666666663*x10;
    double x223 = x181*x75;
    double x224 = x196 + x221*x222 - x221*x223;
    double x225 = -49.886775708919437*x60;
    double x226 = 49.886775708919437*x209;
    double x227 = 3*x121 + x163 + x186 + x194 + x225 + x226;
    double x228 = 0.66666666666666663*x1;
    double x229 = x181*x38;
    double x230 = -x227*x228 + x227*x229;
    double x231 = 0.33333333333333331*x10;
    double x232 = 1.3333333333333333*x1;
    double x233 = x160*x231 - x164*x232 - x184 + x185*x214;
    double x234 = -1.3333333330000001*x1 + x39;
    double x235 = x234*x41;
    double x236 = -1.6000000000000001*x1 + x44;
    double x237 = x236*x46;
    double x238 = x234*x88;
    double x239 = x0*x30;
    double x240 = x236*x239;
    double x241 = x0*x91;
    double x242 = 1.3333333330000001*x53;
    double x243 = 1.6000000000000001*x49;
    double x244 = x0*(3.333333332*x6 + x95);
    double x245 = x0*(5.2000000000000002*x6 + x98);
    double x246 = 0.66666666600000002*x105;
    double x247 = x0*x27;
    double x248 = 1.2*x103;
    double x249 = x236*x48;
    double x250 = 1.0*x249;
    double x251 = x108*x234;
    double x252 = 0.33333333300000001*x251;
    double x253 = 0.59999999999999998*x27;
    double x254 = x0*x107;
    double x255 = -x110 - x20*x242 + x20*x246 - x20*x252 + x235 + x237 + 16.628925219677555*x238 + 83.144626181532402*x240 + 24.943387854459719*x241 - x243*x27 + x244*x41 + x245*x46 + x247*x248 - x247*x250 + 41.57231307413727*x25 - x253*x254 + 108.08801403599212*x34 + x42 + x47 - 74.830163563379159*x50 - 24.943387829516332*x54 + 24.943387854459719*x89;
    double x256 = x255 + x87;
    double x257 = x10 + x23;
    double x258 = x22*x257;
    double x259 = 8.3144626098387775*x258;
    double x260 = 0.59999999999999998*x10 + x32;
    double x261 = x260*x30;
    double x262 = 41.572313090766201*x261;
    double x263 = x0*x235 + x0*x237 + x0*x259 + x0*x262 - x253*x50 + 24.943387854459719*x36 + 24.943387854459719*x37 - x55;
    double x264 = x202 + x263;
    double x265 = x134 + x204*x264 - x205*x264;
    double x266 = -n3*x1 + x10;
    double x267 = x0*x266;
    double x268 = 16.628925236306479*x267;
    double x269 = x257*x41;
    double x270 = x260*x46;
    double x271 = x0*x269 + x0*x270 + x123 + x130 + x188 + x189 + x207 + x268 + x63;
    double x272 = x212*x271 - x271*x43;
    double x273 = x153*x234;
    double x274 = x155*x236;
    double x275 = x0*x151;
    double x276 = 0.59999999999999998*x151;
    double x277 = -x149*x242 + x149*x246 - x149*x252 - x151*x243 + x153*x244 + x154 + x155*x245 + x156 - x177 + 49.886775659032665*x238 + 249.43387854459718*x240 + 74.830163563379159*x241 + x248*x275 + 124.71693922241182*x25 - x250*x275 - x254*x276 + x273 + x274 + 324.26404210797637*x34 - 224.49049069013745*x50 - 74.830163488549005*x54 + 74.830163563379159*x89;
    double x278 = x174 + x277;
    double x279 = 124.71693927229859*x261;
    double x280 = 24.943387829516332*x258;
    double x281 = x0*x273 + x0*x274 + x0*x279 + x0*x280 - x157 - x276*x50 + 74.830163563379159*x36 + 74.830163563379159*x37;
    double x282 = x220 + x281;
    double x283 = x196 + x222*x282 - x223*x282;
    double x284 = 49.886775708919437*x267;
    double x285 = x153*x257;
    double x286 = x155*x260;
    double x287 = x0*x285 + x0*x286 + 3*x123 + x162 + x187 + x225 + x284 + 74.830163563379159*x65 + 74.830163563379159*x66;
    double x288 = -x228*x287 + x229*x287;
    double x289 = x14 + x87;
    double x290 = x0*(x7 + x74) + x289 + x85;
    double x291 = x119*x38 - x43*x68;
    double x292 = 1.0/n2;
    double x293 = -x15 + x3;
    double x294 = x0*(x5 + x83) + x16 + x210*x292 + x293 + x57;
    double x295 = 4.0*x1;
    double x296 = x116*x294;
    double x297 = x114*x214;
    double x298 = -x211*x295 + x211*x297 + x294*x31 - x296;
    double x299 = x146 + x174;
    double x300 = x0*(x167 + x71) + x172 + x299;
    double x301 = -x164*x228 + x185*x38;
    double x302 = x136 - x143;
    double x303 = x0*(x138 + x170) + x144 + x159 + x226*x292 + x302;
    double x304 = x183*x303;
    double x305 = x181*x214;
    double x306 = -x227*x232 + x227*x305 + x231*x303 - x304;
    double x307 = x0*(x200 + x83) + x201 + x263 + x293;
    double x308 = x134 + x272;
    double x309 = x0*(x170 + x218) + x219 + x281 + x302;
    double x310 = x196 + x288;
    double x311 = 2*x53;
    double x312 = x39 + x76;
    double x313 = x312*x88;
    double x314 = -1.2*x1 + x44;
    double x315 = x239*x314;
    double x316 = x108*x257;
    double x317 = 1.2*x49;
    double x318 = x260*x48;
    double x319 = x0*x318;
    double x320 = 4.6666666660000002*x6 + x95;
    double x321 = x0*x41;
    double x322 = 4.4000000000000004*x6 + x98;
    double x323 = x0*x46;
    double x324 = 2*x20;
    double x325 = 0.71999999999999997*x103;
    double x326 = 1.2*x249;
    double x327 = x105*x324 - x20*x311 + 2*x235 + 2*x237 + 49.886775708919437*x238 + 49.886775708919437*x240 + x247*x325 - x247*x326 + 49.886775708919437*x25 - x251*x324 + x259 + x262 - x27*x317 + 8.3144626098387775*x313 + 41.572313090766201*x315 - 8.3144626098387775*x316 - 24.943387854459719*x319 + x320*x321 + x322*x323 + 49.886775708919437*x34 - 29.932065425351659*x50 - 49.886775708919437*x54;
    double x328 = 1.0/n3;
    double x329 = 49.886775708919437*x0;
    double x330 = x0*(x5 + x86) + x17 - x18 - x20*x316 - x253*x319 + x258*x329 + x261*x329 + x268*x328 + x269 + x270 + x3 + x312*x321 + x314*x323;
    double x331 = x116*x330;
    double x332 = -x271*x295 + x271*x297 + x31*x330 - x331;
    double x333 = x0*x153;
    double x334 = x0*x155;
    double x335 = 2*x149;
    double x336 = x105*x335 - x149*x311 - x151*x317 + 149.66032712675832*x238 + 149.66032712675832*x240 + 149.66032712675832*x25 - x251*x335 + 2*x273 + 2*x274 + x275*x325 - x275*x326 + x279 + x280 + 24.943387829516332*x313 + 124.71693927229859*x315 - 24.943387829516332*x316 - 74.830163563379145*x319 + x320*x333 + x322*x334 + 149.66032712675832*x34 - 89.796196276054985*x50 - 149.66032712675832*x54;
    double x337 = 149.66032712675832*x0;
    double x338 = x0*(x138 + x173) + x136 + x145 - x147 - x149*x316 + x258*x337 + x261*x337 - x276*x319 + x284*x328 + x285 + x286 + x312*x333 + x314*x334;
    double x339 = x183*x338;
    double x340 = x231*x338 - x232*x287 + x287*x305 - x339;
    double x341 = 6.0*x1;
    double x342 = n2*x72;
    double x343 = -99.773551417838874*x342;
    double x344 = n2*x38;
    double x345 = x292*(x344 + x76);
    double x346 = 16.628925236306479*x0;
    double x347 = pow(n2, -2);
    double x348 = -x8;
    double x349 = x348 + x70;
    double x350 = x208*x292;
    double x351 = n2*x82;
    double x352 = 16.628925236306479*x350 + x351;
    double x353 = x114*x118;
    double x354 = -299.32065425351664*x342;
    double x355 = -x139;
    double x356 = x165 + x355;
    double x357 = n2*x169;
    double x358 = 49.886775708919437*x350 + x357;
    double x359 = x118*x181;
    double x360 = x292*(x197 + x344);
    double x361 = x204*x307 - x205*x307;
    double x362 = x222*x309 - x223*x309;
    double x363 = n3*x72;
    double x364 = x266*x328;
    double x365 = x257*x52;
    double x366 = 2*x312;
    double x367 = 2*x314;
    double x368 = x328*(n3*x38 + x76);
    double x369 = pow(n3, -2);
    double x370 = 1.2*x318;
    double x371 = x118 + x95;
    double x372 = 3.5999999999999996*x6 + x98;
    double x373 = x104*x257;
    double x374 = 0.71999999999999997*x102*x260;
    double x375 = 1.2*x314*x48;

if (x135) {
   result[0] = x115*(x0*(x71 + x74) + x113 - x13*x80 + x70 + 16.628925236306479*x79) - 3*x117 + x118*x119 + x134 + x58*x59 - 6.0*x69;
}
else {
   result[0] = x118*x185 + x160*x31 - x164*x43 + x182*(x0*(x166 + x167) - x141*x80 + x165 + x180 + 49.886775708919437*x79) - 3*x184 + x196;
}
if (x135) {
   result[1] = x115*(x113 + x199) + x206 + x213 + x215;
}
else {
   result[1] = x182*(x180 + x217) + x224 + x230 + x233;
}
if (x135) {
   result[2] = x115*(x199 + x256 + x81 + x85) + x215 + x265 + x272;
}
else {
   result[2] = x182*(x168 + x172 + x217 + x278) + x233 + x283 + x288;
}
if (x135) {
   result[3] = x115*(x111 + x290) + x206 + x291 + x298;
}
else {
   result[3] = x182*(x178 + x300) + x224 + x301 + x306;
}
if (x135) {
   result[4] = x115*(x255 + x290) - x116*x203 - x116*x264 - x116*x307 + x203*x31 + x213 + x264*x31 + x291 + x307*x31 + x308;
}
else {
   result[4] = x182*(x277 + x300) - x183*x221 - x183*x282 - x183*x309 + x221*x231 + x230 + x231*x282 + x231*x309 + x301 + x310;
}
if (x135) {
   result[5] = x115*(x290 + x327) + x265 + x291 + x332;
}
else {
   result[5] = x182*(x300 + x336) + x283 + x301 + x340;
}
if (x135) {
   result[6] = x115*(x0*(x343 + x71) + x112 - x210*x347 + x345*x346 + x349 + x352) + x134 - x211*x341 + x211*x353 + x294*x59 - 3*x296;
}
else {
   result[6] = x182*(x0*(x166 + x354) + x179 - x226*x347 + x329*x345 + x356 + x358) + x196 + x227*x359 - x227*x43 + x303*x31 - 3*x304;
}
if (x135) {
   result[7] = x115*(x0*(x343 + x82) + x256 + x346*x360 + x348 + x352 + x5) + x298 + x308 + x361;
}
else {
   result[7] = x182*(x0*(x169 + x354) + x216 + x278 + x329*x360 + x355 + x358) + x306 + x310 + x362;
}
if (x135) {
   result[8] = x115*(x0*(x343 + x7) + x289 + x327 + x348 + x351) + x134 + x213 + x332 + x361;
}
else {
   result[8] = x182*(x0*(x354 + x71) + x299 + x336 + x355 + x357) + x196 + x230 + x340 + x362;
}
if (x135) {
   result[9] = x115*(n3*x82 + x0*(-99.773551417838874*x363 + x71) - x108*x312*x324 + x247*x374 - x247*x375 + 74.830163563379159*x258 + 74.830163563379159*x261 - x268*x369 - x27*x370 + 74.830163563379159*x313 + 74.830163563379159*x315 - 74.830163563379159*x316 - 44.898098138027493*x319 + x321*x371 + x323*x372 - x324*x365 + x324*x373 + x346*x368 + x349 + 16.628925236306479*x364 + x366*x41 + x367*x46 + x84) + x134 - x271*x341 + x271*x353 + x330*x59 - 3*x331;
}
else {
   result[9] = x182*(n3*x169 + x0*(x166 - 299.32065425351664*x363) - x108*x149*x366 - x151*x370 + x153*x366 + x155*x367 + x171 + 224.49049069013748*x258 + 224.49049069013748*x261 + x275*x374 - x275*x375 - x284*x369 + 224.49049069013748*x313 + 224.49049069013748*x315 - 224.49049069013748*x316 - 134.69429441408249*x319 + x329*x368 + x333*x371 + x334*x372 - x335*x365 + x335*x373 + x356 + 49.886775708919437*x364) + x196 + x287*x359 - x287*x43 + x31*x338 - 3*x339;
}
}
        
static double coder_dgdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = 1.0/(n1 + n2 + n3);
    double x1 = n1*(*endmember[0].dmu0dP)(T, P);
    double x2 = n2*(*endmember[1].dmu0dP)(T, P);
    double x3 = n3*(*endmember[2].dmu0dP)(T, P);

if (T >= 5.0) {
   result = x0*(1.0*n1 + 1.0*n2 + 1.0*n3)*(x1 + x2 + x3);
}
else {
   result = x0*(0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3)*(3*x1 + 3*x2 + 3*x3);
}
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2 + n3;
    double x2 = 1.0/x1;
    double x3 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x4 = x2*x3;
    double x5 = n1*x0;
    double x6 = (*endmember[1].dmu0dP)(T, P);
    double x7 = n2*x6;
    double x8 = (*endmember[2].dmu0dP)(T, P);
    double x9 = n3*x8;
    double x10 = x5 + x7 + x9;
    double x11 = pow(x1, -2);
    double x12 = -x10*x11*x3 + 1.0*x10*x2;
    double x13 = T >= 5.0;
    double x14 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3;
    double x15 = 3*x14*x2;
    double x16 = 3*x5 + 3*x7 + 3*x9;
    double x17 = -x11*x14*x16 + 0.33333333333333331*x16*x2;

if (x13) {
   result[0] = x0*x4 + x12;
}
else {
   result[0] = x0*x15 + x17;
}
if (x13) {
   result[1] = x12 + x4*x6;
}
else {
   result[1] = x15*x6 + x17;
}
if (x13) {
   result[2] = x12 + x4*x8;
}
else {
   result[2] = x15*x8 + x17;
}
}
        
static void coder_d3gdn2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2 + n3;
    double x2 = 1.0/x1;
    double x3 = x0*x2;
    double x4 = 2.0*x3;
    double x5 = pow(x1, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x7 = x5*x6;
    double x8 = x0*x7;
    double x9 = n1*x0;
    double x10 = (*endmember[1].dmu0dP)(T, P);
    double x11 = n2*x10;
    double x12 = (*endmember[2].dmu0dP)(T, P);
    double x13 = n3*x12;
    double x14 = x11 + x13 + x9;
    double x15 = 2/((x1)*(x1)*(x1));
    double x16 = x14*x15*x6 - 2.0*x14*x5;
    double x17 = T >= 5.0;
    double x18 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3;
    double x19 = x18*x5;
    double x20 = x0*x19;
    double x21 = 3*x11 + 3*x13 + 3*x9;
    double x22 = x15*x18*x21 - 0.66666666666666663*x21*x5;
    double x23 = x10*x7;
    double x24 = -x23;
    double x25 = 1.0*x3;
    double x26 = 1.0*x2;
    double x27 = x10*x26;
    double x28 = x25 + x27;
    double x29 = x16 - x8;
    double x30 = 3*x19;
    double x31 = -x10*x30;
    double x32 = -3*x20 + x22;
    double x33 = x12*x7;
    double x34 = -x33;
    double x35 = x12*x26;
    double x36 = x25 + x35;
    double x37 = -x12*x30;
    double x38 = 2.0*x2;
    double x39 = x10*x38;
    double x40 = 6*x19;
    double x41 = x27 + x35;
    double x42 = x12*x38;

if (x17) {
   result[0] = x16 + x4 - 2*x8;
}
else {
   result[0] = -6*x20 + x22 + x4;
}
if (x17) {
   result[1] = x24 + x28 + x29;
}
else {
   result[1] = x28 + x31 + x32;
}
if (x17) {
   result[2] = x29 + x34 + x36;
}
else {
   result[2] = x32 + x36 + x37;
}
if (x17) {
   result[3] = x16 - 2*x23 + x39;
}
else {
   result[3] = -x10*x40 + x22 + x39;
}
if (x17) {
   result[4] = x16 + x24 + x34 + x41;
}
else {
   result[4] = x22 + x31 + x37 + x41;
}
if (x17) {
   result[5] = x16 - 2*x33 + x42;
}
else {
   result[5] = -x12*x40 + x22 + x42;
}
}
        
static void coder_d4gdn3dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2 + n3;
    double x2 = pow(x1, -2);
    double x3 = x0*x2;
    double x4 = -6.0*x3;
    double x5 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x6 = 6*x5;
    double x7 = pow(x1, -3);
    double x8 = x0*x7;
    double x9 = n1*x0;
    double x10 = (*endmember[1].dmu0dP)(T, P);
    double x11 = n2*x10;
    double x12 = (*endmember[2].dmu0dP)(T, P);
    double x13 = n3*x12;
    double x14 = x11 + x13 + x9;
    double x15 = pow(x1, -4);
    double x16 = -x14*x15*x6 + 6.0*x14*x7;
    double x17 = T >= 5.0;
    double x18 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3;
    double x19 = x18*x8;
    double x20 = 3*x11 + 3*x13 + 3*x9;
    double x21 = 6*x18;
    double x22 = -x15*x20*x21 + 2.0*x20*x7;
    double x23 = x10*x7;
    double x24 = 2*x5;
    double x25 = x23*x24;
    double x26 = 2.0*x2;
    double x27 = -x10*x26;
    double x28 = -4.0*x3;
    double x29 = x27 + x28;
    double x30 = 4*x5;
    double x31 = x16 + x30*x8;
    double x32 = x21*x23;
    double x33 = 12*x19 + x22;
    double x34 = x12*x7;
    double x35 = x24*x34;
    double x36 = -x12*x26;
    double x37 = x28 + x36;
    double x38 = x21*x34;
    double x39 = x23*x30;
    double x40 = -2.0*x3;
    double x41 = 4.0*x2;
    double x42 = -x10*x41;
    double x43 = x40 + x42;
    double x44 = x16 + x24*x8;
    double x45 = 12*x18;
    double x46 = x23*x45;
    double x47 = x21*x8 + x22;
    double x48 = x27 + x36 + x40;
    double x49 = x30*x34;
    double x50 = -x12*x41;
    double x51 = x40 + x50;
    double x52 = x34*x45;
    double x53 = 6.0*x2;
    double x54 = -x10*x53;
    double x55 = 18*x18;
    double x56 = x36 + x42;
    double x57 = x27 + x50;
    double x58 = -x12*x53;

if (x17) {
   result[0] = x16 + x4 + x6*x8;
}
else {
   result[0] = 18*x19 + x22 + x4;
}
if (x17) {
   result[1] = x25 + x29 + x31;
}
else {
   result[1] = x29 + x32 + x33;
}
if (x17) {
   result[2] = x31 + x35 + x37;
}
else {
   result[2] = x33 + x37 + x38;
}
if (x17) {
   result[3] = x39 + x43 + x44;
}
else {
   result[3] = x43 + x46 + x47;
}
if (x17) {
   result[4] = x25 + x35 + x44 + x48;
}
else {
   result[4] = x32 + x38 + x47 + x48;
}
if (x17) {
   result[5] = x44 + x49 + x51;
}
else {
   result[5] = x47 + x51 + x52;
}
if (x17) {
   result[6] = x16 + x23*x6 + x54;
}
else {
   result[6] = x22 + x23*x55 + x54;
}
if (x17) {
   result[7] = x16 + x35 + x39 + x56;
}
else {
   result[7] = x22 + x38 + x46 + x56;
}
if (x17) {
   result[8] = x16 + x25 + x49 + x57;
}
else {
   result[8] = x22 + x32 + x52 + x57;
}
if (x17) {
   result[9] = x16 + x34*x6 + x58;
}
else {
   result[9] = x22 + x34*x55 + x58;
}
}
        
static double coder_d2gdt2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = 1.0*n1*(*endmember[0].d2mu0dT2)(T, P) + 1.0*n2*(*endmember[1].d2mu0dT2)(T, P) + 1.0*n3*(*endmember[2].d2mu0dT2)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0000000000000002*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 80.2881*T - 401.44049999999999;
    double x7 = 1.0/(x1 - 1);
    double x8 = x7*0;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = ((x10)*(x10));

if (T >= 5.0) {
   result = x0;
}
else {
   result = -0.33333333333333331*n2*(8.0288100000000036*x10*((x5)*(x5))*x7 - 4.0144050000000018*x11*x8 + 4.014405*x11*x9 - 0.010000000000000004*x6*x8 + 0.010000000000000002*x6*x9 + 16.057620000000004*x5/x3) + x0;
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 1.0*(*endmember[1].d2mu0dT2)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0000000000000002*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 80.2881*T - 401.44049999999999;
    double x7 = 1.0/(x1 - 1);
    double x8 = x7*0;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = ((x10)*(x10));

result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
if (T >= 5.0) {
   result[1] = x0;
}
else {
   result[1] = x0 - 2.676270000000001*x10*((x5)*(x5))*x7 + 1.3381350000000005*x11*x8 - 1.3381349999999999*x11*x9 + 0.0033333333333333344*x6*x8 - 0.003333333333333334*x6*x9 - 5.3525400000000012*x5/x3;
}
result[2] = 1.0*(*endmember[2].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dTdP)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dTdP)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dTdP)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = x0 + x1 + x2;
}
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dP2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dP2)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dP2)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = x0 + x1 + x2;
}
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = 1.0*n1*(*endmember[0].d3mu0dT3)(T, P) + 1.0*n2*(*endmember[1].d3mu0dT3)(T, P) + 1.0*n3*(*endmember[2].d3mu0dT3)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0000000000000002*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = pow(x3, -3.0/2.0);
    double x8 = (4 - x4 >= 0. ? 1. : 0.);
    double x9 = x7*x8;
    double x10 = 80.2881*T - 401.44049999999999;
    double x11 = pow(x2, -2);
    double x12 = x11*x6;
    double x13 = x8/pow(x3, 5.0/2.0);
    double x14 = x7*0;
    double x15 = fmin(4, x4);
    double x16 = ((x15)*(x15));

if (T >= 5.0) {
   result = x0;
}
else {
   result = -0.33333333333333331*n2*(0.0030000000000000009*x10*x12 + 0.0030000000000000005*x10*x13 - 0.0010000000000000005*x10*x14 - 2.4086430000000005*x11*x15*((x8)*(x8)) + 1.2043215000000003*x12*x16 + 1.2043215*x13*x16 - 0.40144050000000026*x14*x16 - 2.4086430000000014*x15*x6*x9 + 0.80288100000000051*x7*((x8)*(x8)*(x8)) + 2.4086430000000005*x9 - 2.408643000000001*x6/x2) + x0;
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 1.0*(*endmember[1].d3mu0dT3)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0000000000000002*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = pow(x3, -3.0/2.0);
    double x8 = (4 - x4 >= 0. ? 1. : 0.);
    double x9 = x7*x8;
    double x10 = 80.2881*T - 401.44049999999999;
    double x11 = pow(x2, -2);
    double x12 = x11*x6;
    double x13 = x8/pow(x3, 5.0/2.0);
    double x14 = x7*0;
    double x15 = fmin(4, x4);
    double x16 = ((x15)*(x15));

result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
if (T >= 5.0) {
   result[1] = x0;
}
else {
   result[1] = x0 - 0.0010000000000000002*x10*x12 - 0.001*x10*x13 + 0.00033333333333333348*x10*x14 + 0.80288100000000018*x11*x15*((x8)*(x8)) - 0.40144050000000009*x12*x16 - 0.40144049999999998*x13*x16 + 0.13381350000000009*x14*x16 + 0.8028810000000004*x15*x6*x9 - 0.26762700000000017*x7*((x8)*(x8)*(x8)) - 0.80288100000000018*x9 + 0.80288100000000029*x6/x2;
}
result[2] = 1.0*(*endmember[2].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT2dP)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT2dP)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dT2dP)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = x0 + x1 + x2;
}
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dTdP2)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dTdP2)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dTdP2)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = x0 + x1 + x2;
}
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dP3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dP3)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dP3)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = x0 + x1 + x2;
}
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_s(double T, double P, double n[3]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[3]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[3]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[3]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[3]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[3]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

