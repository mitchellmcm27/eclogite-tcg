#include <math.h>


static double coder_g(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));

if (T >= 5.0) {
   result = n1*(-26.762699999999999*T + x0 + 89.209000000000003);
}
else {
   result = (1.0/3.0)*n1*(3*x0 + 133.8135*((x1)*(x1)*(x1)) + (80.2881*T - 401.44049999999999)*(x1 - 1) - 133.8135);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));

if (T >= 5.0) {
   result[0] = -26.762699999999999*T + x0 + 89.209000000000003;
}
else {
   result[0] = x0 + 44.604500000000002*((x1)*(x1)*(x1)) + (1.0/3.0)*(80.2881*T - 401.44049999999999)*(x1 - 1) - 44.604500000000002;
}
}
        
static void coder_d2gdn2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d3gdn3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_dgdt(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = sqrt(1 - 0.19999999999999998*T);
    double x2 = 1.0000000000000002*x1;
    double x3 = fmin(4, x2);
    double x4 = (4 - x2 >= 0. ? 1. : 0.)/x1;

if (T >= 5.0) {
   result = n1*(x0 - 26.762699999999999);
}
else {
   result = (1.0/3.0)*n1*(3*x0 - 40.144050000000007*((x3)*(x3))*x4 + 80.2881*x3 - 0.10000000000000002*x4*(80.2881*T - 401.44049999999999) - 80.2881);
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].dmu0dT)(T, P) - 26.762699999999999;
    double x1 = sqrt(1 - 0.19999999999999998*T);
    double x2 = 1.0000000000000002*x1;
    double x3 = fmin(4, x2);
    double x4 = (4 - x2 >= 0. ? 1. : 0.)/x1;

if (T >= 5.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - 13.381350000000001*((x3)*(x3))*x4 + 26.762699999999999*x3 - 0.03333333333333334*x4*(80.2881*T - 401.44049999999999);
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d4gdn3dt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_dgdp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].dmu0dP)(T, P);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].dmu0dP)(T, P);
}
        
static void coder_d3gdn2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0000000000000002*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 80.2881*T - 401.44049999999999;
    double x7 = 1.0/(x1 - 1);
    double x8 = x7*0;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = ((x10)*(x10));

if (T >= 5.0) {
   result = n1*x0;
}
else {
   result = -1.0/3.0*n1*(-3*x0 + 8.0288100000000036*x10*((x5)*(x5))*x7 - 4.0144050000000018*x11*x8 + 4.014405*x11*x9 - 0.010000000000000004*x6*x8 + 0.010000000000000002*x6*x9 + 16.057620000000004*x5/x3);
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0000000000000002*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 80.2881*T - 401.44049999999999;
    double x7 = 1.0/(x1 - 1);
    double x8 = x7*0;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = ((x10)*(x10));

if (T >= 5.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - 2.676270000000001*x10*((x5)*(x5))*x7 + 1.3381350000000005*x11*x8 - 1.3381349999999999*x11*x9 + 0.0033333333333333344*x6*x8 - 0.003333333333333334*x6*x9 - 5.3525400000000012*x5/x3;
}
}
        
static void coder_d4gdn2dt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d2mu0dTdP)(T, P);
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d2mu0dP2)(T, P);
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0000000000000002*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = pow(x3, -3.0/2.0);
    double x8 = (4 - x4 >= 0. ? 1. : 0.);
    double x9 = x7*x8;
    double x10 = 80.2881*T - 401.44049999999999;
    double x11 = pow(x2, -2);
    double x12 = x11*x6;
    double x13 = x8/pow(x3, 5.0/2.0);
    double x14 = x7*0;
    double x15 = fmin(4, x4);
    double x16 = ((x15)*(x15));

if (T >= 5.0) {
   result = n1*x0;
}
else {
   result = -1.0/3.0*n1*(-3*x0 + 0.0030000000000000009*x10*x12 + 0.0030000000000000005*x10*x13 - 0.0010000000000000005*x10*x14 - 2.4086430000000005*x11*x15*((x8)*(x8)) + 1.2043215000000003*x12*x16 + 1.2043215*x13*x16 - 0.40144050000000026*x14*x16 - 2.4086430000000014*x15*x6*x9 + 0.80288100000000051*x7*((x8)*(x8)*(x8)) + 2.4086430000000005*x9 - 2.408643000000001*x6/x2);
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0000000000000002*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = pow(x3, -3.0/2.0);
    double x8 = (4 - x4 >= 0. ? 1. : 0.);
    double x9 = x7*x8;
    double x10 = 80.2881*T - 401.44049999999999;
    double x11 = pow(x2, -2);
    double x12 = x11*x6;
    double x13 = x8/pow(x3, 5.0/2.0);
    double x14 = x7*0;
    double x15 = fmin(4, x4);
    double x16 = ((x15)*(x15));

if (T >= 5.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - 0.0010000000000000002*x10*x12 - 0.001*x10*x13 + 0.00033333333333333348*x10*x14 + 0.80288100000000018*x11*x15*((x8)*(x8)) - 0.40144050000000009*x12*x16 - 0.40144049999999998*x13*x16 + 0.13381350000000009*x14*x16 + 0.8028810000000004*x15*x6*x9 - 0.26762700000000017*x7*((x8)*(x8)*(x8)) - 0.80288100000000018*x9 + 0.80288100000000029*x6/x2;
}
}
        
static void coder_d5gdn2dt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d3mu0dT2dP)(T, P);
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d3mu0dTdP2)(T, P);
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d3mu0dP3)(T, P);
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_s(double T, double P, double n[1]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[1]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[1]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[1]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[1]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[1]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[1]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[1]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[1]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[1]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[1]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[1]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[1]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[1]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

