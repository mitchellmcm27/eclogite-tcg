#include <math.h>


static double coder_g(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1 + n2 + n3;
    double x1 = 1.0/x0;
    double x2 = n1*(*endmember[0].mu0)(T, P);
    double x3 = n2*(*endmember[1].mu0)(T, P);
    double x4 = n3*(*endmember[2].mu0)(T, P);
    double x5 = T*(2.0*n1*log(n1*x1) + 2.0*n2*log(n2*x1) + 2.0*n3*log(n3*x1) + (0.99999999900000003*n1 + 0.99999999900000003*n2 + 3*n3)*log(x1*(0.33333333300000001*n1 + 0.33333333300000001*n2 + n3)) + (5.0*n1 + 5.0*n2 + 3.0*n3)*log(x1*(1.0*n1 + 1.0*n2 + 0.59999999999999998*n3)));
    double x6 = 30500.0*n1*n3 + 30400.0*n2*n3 + 0.25*n3*(122000.0*n1 + 121600.0*n2);
    double x7 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));

if (T >= 5.0) {
   result = x1*(1.0*x0*(-n2*(26.762699999999999*T - 89.209000000000003) + x2 + x3 + x4 + 8.3144626181532395*x5) - x6);
}
else {
   result = x1*(0.33333333333333331*x0*(n2*(133.8135*((x7)*(x7)*(x7)) + (80.2881*T - 401.44049999999999)*(x7 - 1) - 133.8135) + 3*x2 + 3*x3 + 3*x4 + 24.943387854459719*x5) - x6);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = pow(x0, -2);
    double x2 = (*endmember[0].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[1].mu0)(T, P);
    double x5 = n2*x4;
    double x6 = (*endmember[2].mu0)(T, P);
    double x7 = n3*x6;
    double x8 = 26.762699999999999*T;
    double x9 = x8 - 89.209000000000003;
    double x10 = 1.0/x0;
    double x11 = n1*x10;
    double x12 = 2.0*log(x11);
    double x13 = n2*x10;
    double x14 = 2.0*log(x13);
    double x15 = n3*x10;
    double x16 = 2.0*log(x15);
    double x17 = 3*n3;
    double x18 = 0.99999999900000003*n1 + 0.99999999900000003*n2 + x17;
    double x19 = 0.33333333300000001*n1 + 0.33333333300000001*n2 + n3;
    double x20 = log(x10*x19);
    double x21 = 5.0*n1 + 5.0*n2 + 3.0*n3;
    double x22 = 1.0*n1;
    double x23 = 1.0*n2;
    double x24 = 0.59999999999999998*n3 + x22 + x23;
    double x25 = log(x10*x24);
    double x26 = n1*x12 + n2*x14 + n3*x16 + x18*x20 + x21*x25;
    double x27 = 8.3144626181532395*T;
    double x28 = x26*x27;
    double x29 = 30500.0*n1*n3 + 30400.0*n2*n3 + 0.25*n3*(122000.0*n1 + 121600.0*n2);
    double x30 = -x1*(1.0*x0*(-n2*x9 + x28 + x3 + x5 + x7) - x29);
    double x31 = -x10;
    double x32 = 2.0*x0;
    double x33 = -2.0*x13;
    double x34 = x1*x19;
    double x35 = x0*x18/x19;
    double x36 = x1*x24;
    double x37 = x0*x21/x24;
    double x38 = -2.0*x15 + 0.99999999900000003*x20 + 5.0*x25 + x35*(0.33333333300000001*x10 - x34) + x37*(1.0*x10 - x36);
    double x39 = x12 + x32*(-n1*x1 - x31) + x33 + x38;
    double x40 = 1.0*x0;
    double x41 = -x23*x9;
    double x42 = x2*x22 + x23*x4 + x28 + 1.0*x7;
    double x43 = -61000.0*n3 + x42;
    double x44 = T >= 5.0;
    double x45 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));
    double x46 = 133.8135*((x45)*(x45)*(x45)) + (80.2881*T - 401.44049999999999)*(x45 - 1) - 133.8135;
    double x47 = n2*x46;
    double x48 = 24.943387854459719*T;
    double x49 = -x1*(0.33333333333333331*x0*(x17*x6 + x26*x48 + 3*x3 + x47 + 3*x5) - x29);
    double x50 = 0.33333333333333331*x47;
    double x51 = 0.33333333333333331*x0;
    double x52 = -2.0*x11;
    double x53 = x14 + x32*(-n2*x1 - x31) + x38 + x52;
    double x54 = -60800.0*n3 + x42;
    double x55 = x16 + 3*x20 + 3.0*x25 + x32*(-n3*x1 - x31) + x33 + x35*(-x31 - x34) + x37*(0.59999999999999998*x10 - x36) + x52;
    double x56 = -61000.0*n1 - 60800.0*n2 + x42;

if (x44) {
   result[0] = x10*(x40*(x2 + x27*x39) + x41 + x43) + x30;
}
else {
   result[0] = x10*(x43 + x50 + x51*(3*x2 + x39*x48)) + x49;
}
if (x44) {
   result[1] = x10*(x40*(x27*x53 + x4 - x8 + 89.209000000000003) + x41 + x54) + x30;
}
else {
   result[1] = x10*(x50 + x51*(3*x4 + x46 + x48*x53) + x54) + x49;
}
if (x44) {
   result[2] = x10*(x40*(x27*x55 + x6) + x41 + x56) + x30;
}
else {
   result[2] = x10*(x50 + x51*(x48*x55 + 3*x6) + x56) + x49;
}
}
        
static void coder_d2gdn2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = (*endmember[0].mu0)(T, P);
    double x2 = n1*x1;
    double x3 = (*endmember[1].mu0)(T, P);
    double x4 = n2*x3;
    double x5 = (*endmember[2].mu0)(T, P);
    double x6 = n3*x5;
    double x7 = 26.762699999999999*T;
    double x8 = x7 - 89.209000000000003;
    double x9 = 1.0/x0;
    double x10 = n1*x9;
    double x11 = 2.0*log(x10);
    double x12 = 2.0*log(n2*x9);
    double x13 = 2.0*log(n3*x9);
    double x14 = 3*n3;
    double x15 = 0.99999999900000003*n1 + 0.99999999900000003*n2 + x14;
    double x16 = 0.33333333300000001*n1 + 0.33333333300000001*n2 + n3;
    double x17 = log(x16*x9);
    double x18 = 5.0*n1 + 5.0*n2 + 3.0*n3;
    double x19 = 1.0*n1;
    double x20 = 1.0*n2;
    double x21 = 0.59999999999999998*n3 + x19 + x20;
    double x22 = log(x21*x9);
    double x23 = T*(n1*x11 + n2*x12 + n3*x13 + x15*x17 + x18*x22);
    double x24 = 8.3144626181532395*x23;
    double x25 = 30500.0*n1*n3 + 30400.0*n2*n3 + 0.25*n3*(122000.0*n1 + 121600.0*n2);
    double x26 = 2/((x0)*(x0)*(x0));
    double x27 = x26*(1.0*x0*(-n2*x8 + x2 + x24 + x4 + x6) - x25);
    double x28 = pow(x0, -2);
    double x29 = n1*x28;
    double x30 = -x9;
    double x31 = 2.0*x0;
    double x32 = x31*(-x29 - x30);
    double x33 = 2.0*x9;
    double x34 = -n2*x33;
    double x35 = x16*x28;
    double x36 = -x35 + 0.33333333300000001*x9;
    double x37 = 1.0/x16;
    double x38 = x15*x37;
    double x39 = x36*x38;
    double x40 = x21*x28;
    double x41 = -x40 + 1.0*x9;
    double x42 = 1.0/x21;
    double x43 = x18*x42;
    double x44 = x41*x43;
    double x45 = -n3*x33 + x0*x39 + x0*x44 + 0.99999999900000003*x17 + 5.0*x22;
    double x46 = T*(x11 + x32 + x34 + x45);
    double x47 = 8.3144626181532395*x46;
    double x48 = 1.0*x0;
    double x49 = -x20*x8;
    double x50 = x1*x19 + x20*x3 + x24 + 1.0*x6;
    double x51 = -61000.0*n3 + x50;
    double x52 = x48*(x1 + x47) + x49 + x51;
    double x53 = 2*x28;
    double x54 = 2.0*x29;
    double x55 = -x54;
    double x56 = -x53;
    double x57 = n1*x26;
    double x58 = 2.0*x28;
    double x59 = n2*x58;
    double x60 = x33 + x59;
    double x61 = n3*x58;
    double x62 = x0*x42;
    double x63 = x41*x62;
    double x64 = x0*x37;
    double x65 = x36*x64;
    double x66 = x16*x26;
    double x67 = x0*x38;
    double x68 = x21*x26;
    double x69 = x0*x43;
    double x70 = x18/((x21)*(x21));
    double x71 = x41*x70;
    double x72 = x0*x15/((x16)*(x16));
    double x73 = x36*x72;
    double x74 = -x48*x71 + 10.0*x63 + 1.9999999980000001*x65 + x67*(-0.66666666600000002*x28 + x66) + x69*(-x58 + x68) - 0.33333333300000001*x73;
    double x75 = x39 + x44 + x61 + x74;
    double x76 = 8.3144626181532395*T*x0;
    double x77 = x9*(2.0*x1 + 16.628925236306479*x46 + x76*(x31*(x56 + x57) + x55 + x60 + x75 + x32/n1));
    double x78 = T >= 5.0;
    double x79 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));
    double x80 = ((x79)*(x79)*(x79));
    double x81 = (80.2881*T - 401.44049999999999)*(x79 - 1);
    double x82 = 133.8135*x80 + x81 - 133.8135;
    double x83 = n2*x82;
    double x84 = x26*(0.33333333333333331*x0*(x14*x5 + 3*x2 + 24.943387854459719*x23 + 3*x4 + x83) - x25);
    double x85 = 0.33333333333333331*x83;
    double x86 = 0.33333333333333331*x0;
    double x87 = x51 + x85 + x86*(3*x1 + 24.943387854459719*x46);
    double x88 = x31*(-n2*x28 - x30);
    double x89 = -2.0*x10;
    double x90 = T*(x12 + x45 + x88 + x89);
    double x91 = 8.3144626181532395*x90;
    double x92 = -x7 + x91;
    double x93 = x92 + 89.209000000000003;
    double x94 = 1.0*x3;
    double x95 = -x28;
    double x96 = -x33 + x39 + x44 + x61;
    double x97 = x31*(x57 + x95) + x55 + x59 + x96;
    double x98 = 1.0*x1 + x47;
    double x99 = x76*(x74 + x97) + x94 + x98;
    double x100 = -60800.0*n3 + x50;
    double x101 = x100 + x48*(x3 + x93) + x49;
    double x102 = -x101*x28;
    double x103 = x27 - x28*x52;
    double x104 = 44.604500000000002*x80 + 0.33333333333333331*x81 + x91;
    double x105 = x100 + x85 + x86*(3*x3 + x82 + 24.943387854459719*x90);
    double x106 = -x105*x28;
    double x107 = -x28*x87 + x84;
    double x108 = -x40 + 0.59999999999999998*x9;
    double x109 = x108*x62;
    double x110 = -x30 - x35;
    double x111 = x110*x64;
    double x112 = 0.59999999999999998*x0;
    double x113 = 5.0*x109 + 0.99999999900000003*x111 - x112*x71 + 3.0*x63 + 3*x65 + x67*(-1.3333333330000001*x28 + x66) + x69*(-1.6000000000000001*x28 + x68) - x73;
    double x114 = x31*(-n3*x28 - x30);
    double x115 = x110*x38;
    double x116 = x108*x43;
    double x117 = T*(x0*x115 + x0*x116 + x114 + x13 + 3*x17 + 3.0*x22 + x34 + x89);
    double x118 = 8.3144626181532395*x117;
    double x119 = x118 + 1.0*x5;
    double x120 = x9*(x119 + x76*(x113 + x97) + x98 - 61000.0);
    double x121 = -61000.0*n1 - 60800.0*n2 + x50;
    double x122 = x121 + x48*(x118 + x5) + x49;
    double x123 = -x122*x28;
    double x124 = x121 + x85 + x86*(24.943387854459719*x117 + 3*x5);
    double x125 = -x124*x28;
    double x126 = n2*x26;
    double x127 = x54 - x59;
    double x128 = 2.0*x3 + x76*(x127 + x31*(x126 + x56) + x33 + x75 + x88/n2) + 16.628925236306479*x90;
    double x129 = x119 + x76*(x113 + x127 + x31*(x126 + x95) + x96) + x94;
    double x130 = x9*(16.628925236306479*x117 + 2.0*x5 + x76*(-x108*x112*x70 + 6.0*x109 - x110*x72 + 6*x111 + x115 + x116 + x31*(n3*x26 + x56) + x54 + x60 - x61 + x67*(x56 + x66) + x69*(-1.2*x28 + x68) + x114/n3));

if (x78) {
   result[0] = x27 - x52*x53 + x77;
}
else {
   result[0] = -x53*x87 + x77 + x84;
}
if (x78) {
   result[1] = x102 + x103 + x9*(x93 + x99);
}
else {
   result[1] = x106 + x107 + x9*(x104 + x99 - 44.604500000000002);
}
if (x78) {
   result[2] = x103 + x120 + x123;
}
else {
   result[2] = x107 + x120 + x125;
}
if (x78) {
   result[3] = -x101*x53 + x27 + x9*(-53.525399999999998*T + x128 + 178.41800000000001);
}
else {
   result[3] = -x105*x53 + x84 + x9*(x128 + 89.209000000000003*x80 + 0.66666666666666663*x81 - 89.209000000000003);
}
if (x78) {
   result[4] = x102 + x123 + x27 + x9*(x129 + x92 - 60710.790999999997);
}
else {
   result[4] = x106 + x125 + x84 + x9*(x104 + x129 - 60844.604500000001);
}
if (x78) {
   result[5] = -x122*x53 + x130 + x27;
}
else {
   result[5] = -x124*x53 + x130 + x84;
}
}
        
static void coder_d3gdn3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = (*endmember[0].mu0)(T, P);
    double x2 = n1*x1;
    double x3 = (*endmember[1].mu0)(T, P);
    double x4 = n2*x3;
    double x5 = (*endmember[2].mu0)(T, P);
    double x6 = n3*x5;
    double x7 = 26.762699999999999*T;
    double x8 = x7 - 89.209000000000003;
    double x9 = 1.0/x0;
    double x10 = 2.0*log(n1*x9);
    double x11 = 2.0*log(n2*x9);
    double x12 = 2.0*log(n3*x9);
    double x13 = 3*n3;
    double x14 = 0.99999999900000003*n1 + 0.99999999900000003*n2 + x13;
    double x15 = 0.33333333300000001*n1 + 0.33333333300000001*n2 + n3;
    double x16 = log(x15*x9);
    double x17 = 5.0*n1 + 5.0*n2 + 3.0*n3;
    double x18 = 1.0*n1;
    double x19 = 1.0*n2;
    double x20 = 0.59999999999999998*n3 + x18 + x19;
    double x21 = log(x20*x9);
    double x22 = n1*x10 + n2*x11 + n3*x12 + x14*x16 + x17*x21;
    double x23 = 8.3144626181532395*T;
    double x24 = x22*x23;
    double x25 = 30500.0*n1*n3 + 30400.0*n2*n3 + 0.25*n3*(122000.0*n1 + 121600.0*n2);
    double x26 = 6/((x0)*(x0)*(x0)*(x0));
    double x27 = -x26*(1.0*x0*(-n2*x8 + x2 + x24 + x4 + x6) - x25);
    double x28 = pow(x0, -2);
    double x29 = n1*x28;
    double x30 = -x9;
    double x31 = -x29 - x30;
    double x32 = 2.0*x0;
    double x33 = x31*x32;
    double x34 = 2.0*x9;
    double x35 = -n2*x34;
    double x36 = 1.0/x15;
    double x37 = x15*x28;
    double x38 = -x37 + 0.33333333300000001*x9;
    double x39 = x36*x38;
    double x40 = x14*x39;
    double x41 = 1.0/x20;
    double x42 = x20*x28;
    double x43 = -x42 + 1.0*x9;
    double x44 = x41*x43;
    double x45 = x17*x44;
    double x46 = -n3*x34 + x0*x40 + x0*x45 + 0.99999999900000003*x16 + 5.0*x21;
    double x47 = x10 + x33 + x35 + x46;
    double x48 = x23*x47;
    double x49 = 1.0*x0;
    double x50 = -x19*x8;
    double x51 = x1*x18 + x19*x3 + x24 + 1.0*x6;
    double x52 = -61000.0*n3 + x51;
    double x53 = x49*(x1 + x48) + x50 + x52;
    double x54 = pow(x0, -3);
    double x55 = 6*x54;
    double x56 = 2.0*x29;
    double x57 = -x56;
    double x58 = 2*x28;
    double x59 = -x58;
    double x60 = 2*x54;
    double x61 = n1*x60;
    double x62 = x32*(x59 + x61);
    double x63 = 1.0/n1;
    double x64 = x31*x63;
    double x65 = 2.0*x28;
    double x66 = n2*x65;
    double x67 = x34 + x66;
    double x68 = n3*x65;
    double x69 = x0*x44;
    double x70 = x0*x39;
    double x71 = x15*x60;
    double x72 = -0.66666666600000002*x28 + x71;
    double x73 = x14*x36;
    double x74 = x72*x73;
    double x75 = x20*x60;
    double x76 = -x65 + x75;
    double x77 = x17*x41;
    double x78 = x76*x77;
    double x79 = pow(x20, -2);
    double x80 = x43*x79;
    double x81 = x17*x80;
    double x82 = pow(x15, -2);
    double x83 = x38*x82;
    double x84 = x14*x83;
    double x85 = x0*x84;
    double x86 = x0*x74 + x0*x78 - x49*x81 + 10.0*x69 + 1.9999999980000001*x70 - 0.33333333300000001*x85;
    double x87 = x40 + x45 + x68 + x86;
    double x88 = x32*x64 + x57 + x62 + x67 + x87;
    double x89 = 24.943387854459719*T;
    double x90 = -8.0*x28;
    double x91 = -6*x54;
    double x92 = n1*x26;
    double x93 = 2.0*x64;
    double x94 = 8.0*x54;
    double x95 = 4.0*x54;
    double x96 = -n2*x95;
    double x97 = n1*x94 + x96;
    double x98 = -n3*x95;
    double x99 = 15.0*x0;
    double x100 = x41*x76;
    double x101 = x0*x36;
    double x102 = x101*x72;
    double x103 = x0*x83;
    double x104 = x15*x26;
    double x105 = x0*x73;
    double x106 = x20*x26;
    double x107 = x0*x77;
    double x108 = x17*x32;
    double x109 = pow(x20, -3);
    double x110 = x109*x43;
    double x111 = x0/((x15)*(x15)*(x15));
    double x112 = x111*x38;
    double x113 = x112*x14;
    double x114 = x76*x79;
    double x115 = x0*x82;
    double x116 = x115*x14;
    double x117 = x116*x72;
    double x118 = x100*x99 + 2.9999999970000002*x102 - 0.99999999800000006*x103 + x105*(-x104 + 1.9999999980000001*x54) + x107*(-x106 + 6.0*x54) + x108*x110 - x108*x114 + 0.22222222177777778*x113 - 0.66666666600000002*x117 + 2.9999999970000002*x39 + 15.0*x44 + 2*x74 + 2*x78 - x80*x99 - 2.0*x81 - 0.66666666600000002*x84;
    double x119 = x118 + x98;
    double x120 = x119 + x93 + x97;
    double x121 = x0*x23;
    double x122 = 16.628925236306479*T;
    double x123 = x23*x88;
    double x124 = x28*(x0*x123 + 2.0*x1 + x122*x47);
    double x125 = -3*x124 + x9*(x121*(x120 + x32*(-x91 - x92) + x62*x63 + x90 - x33/((n1)*(n1))) + x88*x89);
    double x126 = T >= 5.0;
    double x127 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));
    double x128 = ((x127)*(x127)*(x127));
    double x129 = (80.2881*T - 401.44049999999999)*(x127 - 1);
    double x130 = 133.8135*x128 + x129 - 133.8135;
    double x131 = n2*x130;
    double x132 = -x26*(0.33333333333333331*x0*(x13*x5 + x131 + 3*x2 + x22*x89 + 3*x4) - x25);
    double x133 = 0.33333333333333331*x131;
    double x134 = 0.33333333333333331*x0;
    double x135 = x133 + x134*(3*x1 + x47*x89) + x52;
    double x136 = -n2*x28 - x30;
    double x137 = x136*x32;
    double x138 = -n1*x34;
    double x139 = x11 + x137 + x138 + x46;
    double x140 = x139*x23;
    double x141 = x140 - x7;
    double x142 = x141 + 89.209000000000003;
    double x143 = -60800.0*n3 + x51;
    double x144 = x143 + x49*(x142 + x3) + x50;
    double x145 = x144*x60;
    double x146 = 4*x54;
    double x147 = x146*x53;
    double x148 = -x28;
    double x149 = x32*(x148 + x61);
    double x150 = -x34 + x40 + x45 + x68;
    double x151 = x149 + x150 + x57 + x66;
    double x152 = x151 + x86;
    double x153 = x122*x152;
    double x154 = -4.0*x28;
    double x155 = -4*x54;
    double x156 = x149*x63 + x154 + x32*(-x155 - x92);
    double x157 = -x124;
    double x158 = x157 + x9*(x121*(x120 + x156) + x123 + x153);
    double x159 = 1.0*x3;
    double x160 = x152*x23;
    double x161 = 1.0*x1 + x48;
    double x162 = x0*x160 + x159 + x161;
    double x163 = x142 + x162;
    double x164 = -x163*x58 + x27;
    double x165 = 44.604500000000002*x128 + 0.33333333333333331*x129 + x140;
    double x166 = x162 + x165 - 44.604500000000002;
    double x167 = -x166*x58;
    double x168 = x133 + x134*(x130 + x139*x89 + 3*x3) + x143;
    double x169 = x168*x60;
    double x170 = x132 + x135*x146;
    double x171 = -n3*x28 - x30;
    double x172 = x171*x32;
    double x173 = -x30 - x37;
    double x174 = x173*x73;
    double x175 = -x42 + 0.59999999999999998*x9;
    double x176 = x175*x77;
    double x177 = x0*x174 + x0*x176 + x12 + x138 + 3*x16 + x172 + 3.0*x21 + x35;
    double x178 = x177*x23;
    double x179 = -61000.0*n1 - 60800.0*n2 + x51;
    double x180 = x179 + x49*(x178 + x5) + x50;
    double x181 = x180*x60;
    double x182 = x175*x41;
    double x183 = 5.0*x182;
    double x184 = x173*x36;
    double x185 = 0.99999999900000003*x184;
    double x186 = -1.3333333330000001*x28 + x71;
    double x187 = x186*x73;
    double x188 = -1.6000000000000001*x28 + x75;
    double x189 = x188*x77;
    double x190 = 0.59999999999999998*x0;
    double x191 = x0*x183 + x0*x185 + x0*x187 + x0*x189 - x190*x81 + 3.0*x69 + 3*x70 - x85;
    double x192 = x151 + x191;
    double x193 = x192*x23;
    double x194 = x178 + 1.0*x5;
    double x195 = x0*x193 + x161 + x194 - 61000.0;
    double x196 = -x195*x58;
    double x197 = x196 + x27;
    double x198 = x122*x192;
    double x199 = 3.0*x0;
    double x200 = x0*x41;
    double x201 = x188*x200;
    double x202 = x101*x186;
    double x203 = x0*x80;
    double x204 = 1.2*x17;
    double x205 = x0*x110;
    double x206 = x188*x79;
    double x207 = x116*x186;
    double x208 = x100*x199 + 3*x102 - 2.9999999970000002*x103 + x105*(-x104 + 3.333333332*x54) + x107*(-x106 + 5.2000000000000002*x54) + 0.66666666600000002*x113 - x114*x17*x190 - x117 - x17*x206*x49 + x187 + x189 + 10.0*x201 + 1.9999999980000001*x202 - 9.0*x203 + x204*x205 - 0.33333333300000001*x207 + 4.9999999979999998*x39 + 13.0*x44 + x74 + x78 - 1.6000000000000001*x81 - 1.3333333330000001*x84;
    double x209 = x208 + x98;
    double x210 = x157 + x9*(x121*(x156 + x209 + x93 + x97) + x123 + x198);
    double x211 = x133 + x134*(x177*x89 + 3*x5) + x179;
    double x212 = x211*x60;
    double x213 = n2*x60;
    double x214 = x32*(x213 + x59);
    double x215 = 1.0/n2;
    double x216 = x56 - x66;
    double x217 = x137*x215 + x214 + x216 + x34 + x87;
    double x218 = x217*x23;
    double x219 = -2*x54;
    double x220 = x65 + x98;
    double x221 = x220 + x32*(-x219 - x92) + x97;
    double x222 = x9*(x121*(x118 + x221) + x153 + x218);
    double x223 = x53*x60;
    double x224 = x0*x218 + x122*x139 + 2.0*x3;
    double x225 = x28*(-53.525399999999998*T + x224 + 178.41800000000001);
    double x226 = x144*x146 - x225;
    double x227 = x132 + x135*x60;
    double x228 = x28*(89.209000000000003*x128 + 0.66666666666666663*x129 + x224 - 89.209000000000003);
    double x229 = x146*x168 - x228;
    double x230 = x32*(x148 + x213);
    double x231 = x150 + x191 + x216 + x230;
    double x232 = x23*x231;
    double x233 = x0*x232 + x159 + x194;
    double x234 = x141 + x233 - 60710.790999999997;
    double x235 = -x195*x28 + x9*(x121*(x208 + x221) + x160 + x193 + x232);
    double x236 = x165 + x233 - 60844.604500000001;
    double x237 = x146*x180;
    double x238 = x32*(n3*x60 + x59);
    double x239 = 1.0/n3;
    double x240 = x59 + x71;
    double x241 = -1.2*x28 + x75;
    double x242 = x175*x79;
    double x243 = x0*x242;
    double x244 = 6.0*x0*x182 + 6*x0*x184 + x105*x240 + x107*x241 - x116*x173 - 0.59999999999999998*x17*x243 + x172*x239 + x174 + x176 + x238 + x56 + x67 - x68;
    double x245 = x23*x244;
    double x246 = x200*x241;
    double x247 = x101*x240;
    double x248 = x115*x173;
    double x249 = 2*x14;
    double x250 = 0.71999999999999997*x17;
    double x251 = x0*x204;
    double x252 = -6*x103 + x105*(-x104 + 4.6666666660000002*x54) + x107*(-x106 + 4.4000000000000004*x54) + x112*x249 + x183 + x185 + 2*x187 + 2*x189 - x199*x242 + 6.0*x201 + 6*x202 - 3.5999999999999996*x203 + x205*x250 - x206*x251 - 2*x207 + 5.0*x246 + 0.99999999900000003*x247 - 0.99999999900000003*x248 + 6*x39 + 6.0*x44 - 1.2*x81 - 2*x84;
    double x253 = x28*(x0*x245 + x122*x177 + 2.0*x5);
    double x254 = -x253;
    double x255 = x254 + x9*(x121*(x221 + x252) + x198 + x245);
    double x256 = x146*x211;
    double x257 = n2*x26;
    double x258 = -n1*x95;
    double x259 = x258 + x90;
    double x260 = n2*x94;
    double x261 = 2.0*x136*x215 + x260;
    double x262 = x9*(x121*(x119 + x214*x215 + x259 + x261 + x32*(-x257 - x91) - x137/((n2)*(n2))) + x217*x89);
    double x263 = x122*x231;
    double x264 = x9*(x121*(x154 + x209 + x215*x230 + x258 + x261 + x32*(-x155 - x257)) + x218 + x263);
    double x265 = -x234*x58 + x27;
    double x266 = x132 - x236*x58;
    double x267 = x254 + x9*(x121*(x220 + x252 + x258 + x260 + x32*(-x219 - x257)) + x245 + x263);
    double x268 = x173*x249;
    double x269 = 2*x240;
    double x270 = -3*x253 + x9*(x121*(n3*x94 + x0*x109*x175*x250 + x105*(-x104 - x91) + x107*(-x106 + 3.5999999999999996*x54) + x111*x268 - x116*x269 + 2.0*x171*x239 + 9.0*x182 + 9*x184 - x204*x242 + x238*x239 - x241*x251*x79 + 2*x241*x77 - 5.3999999999999995*x243 + 9.0*x246 + 9*x247 - 9*x248 + x259 - x268*x82 + x269*x73 + x32*(-n3*x26 - x91) + x96 - x172/((n3)*(n3))) + x244*x89);

if (x126) {
   result[0] = x125 + x27 + x53*x55;
}
else {
   result[0] = x125 + x132 + x135*x55;
}
if (x126) {
   result[1] = x145 + x147 + x158 + x164;
}
else {
   result[1] = x158 + x167 + x169 + x170;
}
if (x126) {
   result[2] = x147 + x181 + x197 + x210;
}
else {
   result[2] = x170 + x196 + x210 + x212;
}
if (x126) {
   result[3] = x164 + x222 + x223 + x226;
}
else {
   result[3] = x167 + x222 + x227 + x229;
}
if (x126) {
   result[4] = x145 - x163*x28 + x181 + x223 - x234*x28 + x235 + x27;
}
else {
   result[4] = -x166*x28 + x169 + x212 + x227 + x235 - x236*x28;
}
if (x126) {
   result[5] = x197 + x223 + x237 + x255;
}
else {
   result[5] = x196 + x227 + x255 + x256;
}
if (x126) {
   result[6] = x144*x55 - 3*x225 + x262 + x27;
}
else {
   result[6] = x132 + x168*x55 - 3*x228 + x262;
}
if (x126) {
   result[7] = x181 + x226 + x264 + x265;
}
else {
   result[7] = x212 + x229 + x264 + x266;
}
if (x126) {
   result[8] = x145 + x237 + x265 + x267;
}
else {
   result[8] = x169 + x256 + x266 + x267;
}
if (x126) {
   result[9] = x180*x55 + x27 + x270;
}
else {
   result[9] = x132 + x211*x55 + x270;
}
}
        
static double coder_dgdt(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = 1.0*n1;
    double x1 = 1.0*n2;
    double x2 = 1.0/(n1 + n2 + n3);
    double x3 = 16.628925236306479*n1*log(n1*x2) + 16.628925236306479*n2*log(n2*x2) + 16.628925236306479*n3*log(n3*x2) + 1.0*n3*(*endmember[2].dmu0dT)(T, P) + x0*(*endmember[0].dmu0dT)(T, P) + x1*(*endmember[1].dmu0dT)(T, P) + 8.3144626181532395*(0.99999999900000003*n1 + 0.99999999900000003*n2 + 3*n3)*log(x2*(0.33333333300000001*n1 + 0.33333333300000001*n2 + n3)) + 8.3144626181532395*(5.0*n1 + 5.0*n2 + 3.0*n3)*log(x2*(0.59999999999999998*n3 + x0 + x1));
    double x4 = sqrt(1 - 0.19999999999999998*T);
    double x5 = 1.0000000000000002*x4;
    double x6 = fmin(4, x5);
    double x7 = (4 - x5 >= 0. ? 1. : 0.)/x4;

if (T >= 5.0) {
   result = -26.762699999999999*n2 + x3;
}
else {
   result = 0.33333333333333331*n2*(-40.144050000000007*((x6)*(x6))*x7 + 80.2881*x6 - 0.10000000000000002*x7*(80.2881*T - 401.44049999999999) - 80.2881) + x3;
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = 1.0/x0;
    double x2 = n1*x1;
    double x3 = pow(x0, -2);
    double x4 = -x1;
    double x5 = 16.628925236306479*x0;
    double x6 = n2*x1;
    double x7 = -16.628925236306479*x6;
    double x8 = 0.33333333300000001*n1 + 0.33333333300000001*n2 + n3;
    double x9 = log(x1*x8);
    double x10 = 1.0*n1 + 1.0*n2 + 0.59999999999999998*n3;
    double x11 = log(x1*x10);
    double x12 = n3*x1;
    double x13 = x3*x8;
    double x14 = 8.3144626181532395*x0;
    double x15 = x14*(0.99999999900000003*n1 + 0.99999999900000003*n2 + 3*n3)/x8;
    double x16 = x10*x3;
    double x17 = x14*(5.0*n1 + 5.0*n2 + 3.0*n3)/x10;
    double x18 = 41.572313090766201*x11 - 16.628925236306479*x12 + x15*(0.33333333300000001*x1 - x13) + x17*(1.0*x1 - x16) + 8.3144626098387775*x9;
    double x19 = -16.628925236306479*x2;
    double x20 = x18 + x19 + x5*(-n2*x3 - x4) + 16.628925236306479*log(x6) + 1.0*(*endmember[1].dmu0dT)(T, P) - 26.762699999999999;
    double x21 = sqrt(1 - 0.19999999999999998*T);
    double x22 = 1.0000000000000002*x21;
    double x23 = fmin(4, x22);
    double x24 = (4 - x22 >= 0. ? 1. : 0.)/x21;

result[0] = x18 + x5*(-n1*x3 - x4) + x7 + 16.628925236306479*log(x2) + 1.0*(*endmember[0].dmu0dT)(T, P);
if (T >= 5.0) {
   result[1] = x20;
}
else {
   result[1] = x20 - 13.381350000000001*((x23)*(x23))*x24 + 26.762699999999999*x23 - 0.03333333333333334*x24*(80.2881*T - 401.44049999999999);
}
result[2] = 24.943387854459719*x11 + x15*(-x13 - x4) + x17*(0.59999999999999998*x1 - x16) + x19 + x5*(-n3*x3 - x4) + x7 + 24.943387854459719*x9 + 16.628925236306479*log(x12) + 1.0*(*endmember[2].dmu0dT)(T, P);
}
        
static void coder_d3gdn2dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = pow(x0, -2);
    double x2 = n1*x1;
    double x3 = 16.628925236306479*x2;
    double x4 = -x3;
    double x5 = -2*x1;
    double x6 = 2/((x0)*(x0)*(x0));
    double x7 = n1*x6;
    double x8 = 16.628925236306479*x0;
    double x9 = 1.0/x0;
    double x10 = -x9;
    double x11 = n2*x1;
    double x12 = 16.628925236306479*x11;
    double x13 = 16.628925236306479*x9;
    double x14 = x12 + x13;
    double x15 = n3*x1;
    double x16 = 16.628925236306479*x15;
    double x17 = 0.33333333300000001*n1 + 0.33333333300000001*n2 + n3;
    double x18 = 1.0/x17;
    double x19 = x1*x17;
    double x20 = -x19 + 0.33333333300000001*x9;
    double x21 = x18*x20;
    double x22 = 0.99999999900000003*n1 + 0.99999999900000003*n2 + 3*n3;
    double x23 = 8.3144626181532395*x22;
    double x24 = x21*x23;
    double x25 = 1.0*n1 + 1.0*n2 + 0.59999999999999998*n3;
    double x26 = 1.0/x25;
    double x27 = x1*x25;
    double x28 = -x27 + 1.0*x9;
    double x29 = x26*x28;
    double x30 = 5.0*n1 + 5.0*n2 + 3.0*n3;
    double x31 = 8.3144626181532395*x30;
    double x32 = x29*x31;
    double x33 = x0*x21;
    double x34 = x0*x29;
    double x35 = x17*x6;
    double x36 = x0*x23;
    double x37 = x18*x36;
    double x38 = x25*x6;
    double x39 = x0*x31;
    double x40 = x26*x39;
    double x41 = pow(x25, -2);
    double x42 = x28*x41;
    double x43 = pow(x17, -2);
    double x44 = x20*x43;
    double x45 = -2.7714875366129257*x0*x22*x44 + 16.628925219677555*x33 + 83.144626181532402*x34 + x37*(-0.66666666600000002*x1 + x35) - x39*x42 + x40*(-2.0*x1 + x38);
    double x46 = x16 + x24 + x32 + x45;
    double x47 = -x1;
    double x48 = -x13 + x16 + x24 + x32;
    double x49 = x12 + x4 + x48 + x8*(x47 + x7);
    double x50 = -x10 - x19;
    double x51 = x18*x50;
    double x52 = x0*x51;
    double x53 = -x27 + 0.59999999999999998*x9;
    double x54 = x26*x53;
    double x55 = x0*x54;
    double x56 = 4.9886775708919435*x0*x30;
    double x57 = 24.943387854459719*x33 + 24.943387854459719*x34 - x36*x44 + x37*(-1.3333333330000001*x1 + x35) + x40*(-1.6000000000000001*x1 + x38) - x42*x56 + 8.3144626098387775*x52 + 41.572313090766201*x55;
    double x58 = n2*x6;
    double x59 = -x12 + x3;

result[0] = x14 + x4 + x46 + x8*(x5 + x7) + x8*(-x10 - x2)/n1;
result[1] = x45 + x49;
result[2] = x49 + x57;
result[3] = x13 + x46 + x59 + x8*(x5 + x58) + x8*(-x10 - x11)/n2;
result[4] = x48 + x57 + x59 + x8*(x47 + x58);
result[5] = x14 - x16 + x23*x51 + x3 + x31*x54 - x36*x43*x50 + x37*(x35 + x5) + x40*(-1.2*x1 + x38) - x41*x53*x56 + 49.886775708919437*x52 + 49.886775708919437*x55 + x8*(n3*x6 + x5) + x8*(-x10 - x15)/n3;
}
        
static void coder_d4gdn3dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = pow(x0, -2);
    double x2 = -66.515700945225916*x1;
    double x3 = pow(x0, -3);
    double x4 = -6*x3;
    double x5 = 6/((x0)*(x0)*(x0)*(x0));
    double x6 = n1*x5;
    double x7 = 16.628925236306479*x0;
    double x8 = -2*x1;
    double x9 = 2*x3;
    double x10 = n1*x9;
    double x11 = 16.628925236306479/n1;
    double x12 = x0*x11;
    double x13 = 1.0/x0;
    double x14 = -x13;
    double x15 = -n1*x1 - x14;
    double x16 = x11*x15;
    double x17 = 66.515700945225916*x3;
    double x18 = 33.257850472612958*x3;
    double x19 = -n2*x18;
    double x20 = n1*x17 + x19;
    double x21 = -n3*x18;
    double x22 = 0.33333333300000001*n1 + 0.33333333300000001*n2 + n3;
    double x23 = 1.0/x22;
    double x24 = x1*x22;
    double x25 = 0.33333333300000001*x13 - x24;
    double x26 = x23*x25;
    double x27 = 1.0*n1 + 1.0*n2 + 0.59999999999999998*n3;
    double x28 = 1.0/x27;
    double x29 = x1*x27;
    double x30 = 1.0*x13 - x29;
    double x31 = x28*x30;
    double x32 = x22*x9;
    double x33 = -0.66666666600000002*x1 + x32;
    double x34 = x23*x33;
    double x35 = 0.99999999900000003*n1 + 0.99999999900000003*n2 + 3*n3;
    double x36 = 16.628925236306479*x35;
    double x37 = x27*x9;
    double x38 = -2.0*x1 + x37;
    double x39 = x28*x38;
    double x40 = 5.0*n1 + 5.0*n2 + 3.0*n3;
    double x41 = 16.628925236306479*x40;
    double x42 = x0*x34;
    double x43 = 124.7169392722986*x0;
    double x44 = pow(x22, -2);
    double x45 = x25*x44;
    double x46 = x0*x45;
    double x47 = pow(x27, -2);
    double x48 = x30*x47;
    double x49 = x35*x45;
    double x50 = x22*x5;
    double x51 = 8.3144626181532395*x35;
    double x52 = x0*x51;
    double x53 = x23*x52;
    double x54 = x27*x5;
    double x55 = 8.3144626181532395*x40;
    double x56 = x0*x55;
    double x57 = x28*x56;
    double x58 = x40*x7;
    double x59 = pow(x27, -3);
    double x60 = x30*x59;
    double x61 = x0*x35;
    double x62 = pow(x22, -3);
    double x63 = x25*x62;
    double x64 = x61*x63;
    double x65 = x38*x47;
    double x66 = x33*x44;
    double x67 = 24.943387829516332*x26 + 124.7169392722986*x31 + x34*x36 + x39*x41 + x39*x43 - x41*x48 + 24.943387829516332*x42 - x43*x48 - 8.3144626015243155*x46 - 5.5429750732258514*x49 + x53*(1.9999999980000001*x3 - x50) + x57*(6.0*x3 - x54) + x58*x60 - x58*x65 - 5.5429750732258514*x61*x66 + 1.8476583558942921*x64;
    double x68 = x21 + x67;
    double x69 = x16 + x20 + x68;
    double x70 = -33.257850472612958*x1;
    double x71 = -4*x3;
    double x72 = -x1;
    double x73 = x12*(x10 + x72) + x7*(-x6 - x71) + x70;
    double x74 = -1.3333333330000001*x1 + x32;
    double x75 = x23*x74;
    double x76 = x0*x75;
    double x77 = -1.6000000000000001*x1 + x37;
    double x78 = x28*x77;
    double x79 = x0*x78;
    double x80 = 24.943387854459719*x0;
    double x81 = x0*x48;
    double x82 = x40*x48;
    double x83 = 9.977355141783887*x40;
    double x84 = x0*x60;
    double x85 = x47*x77;
    double x86 = x0*x40;
    double x87 = x44*x74;
    double x88 = 41.57231307413727*x26 + 108.08801403599212*x31 + x34*x51 + x39*x55 + x39*x80 + 24.943387854459719*x42 - 24.943387829516332*x46 - 11.085950154766165*x49 + x51*x75 - x52*x66 + x53*(3.333333332*x3 - x50) + x55*x78 - x56*x85 + x57*(5.2000000000000002*x3 - x54) - 2.7714875366129257*x61*x87 + 5.5429750732258514*x64 - 4.9886775708919435*x65*x86 + 16.628925219677555*x76 + 83.144626181532402*x79 - 74.830163563379159*x81 - 13.303140189045184*x82 + x83*x84;
    double x89 = x21 + x88;
    double x90 = -2*x3;
    double x91 = 16.628925236306479*x1 + x21;
    double x92 = x20 + x7*(-x6 - x90) + x91;
    double x93 = -x14 - x24;
    double x94 = x23*x93;
    double x95 = 0.59999999999999998*x13 - x29;
    double x96 = x28*x95;
    double x97 = 8.3144626098387775*x0;
    double x98 = x32 + x8;
    double x99 = x23*x98;
    double x100 = -1.2*x1 + x37;
    double x101 = x100*x28;
    double x102 = x0*x101;
    double x103 = x44*x93;
    double x104 = x47*x95;
    double x105 = x35*x7;
    double x106 = x0*x83;
    double x107 = 41.572313090766201*x102 - x103*x97 - x104*x80 + x105*x63 - x105*x87 - x106*x85 + 49.886775708919437*x26 + 49.886775708919437*x31 - x36*x45 + x36*x75 + 5.9864130850703319*x40*x84 + x41*x78 - 49.886775708919437*x46 + x53*(4.6666666660000002*x3 - x50) + x57*(4.4000000000000004*x3 - x54) + 49.886775708919437*x76 + 49.886775708919437*x79 - 29.932065425351659*x81 - 9.977355141783887*x82 + 8.3144626098387775*x94 + 41.572313090766201*x96 + x97*x99;
    double x108 = n2*x5;
    double x109 = n2*x9;
    double x110 = 1.0/n2;
    double x111 = x110*x7;
    double x112 = -n2*x1 - x14;
    double x113 = -n1*x18;
    double x114 = x113 + x2;
    double x115 = n2*x17;
    double x116 = 16.628925236306479*x110*x112 + x115;
    double x117 = 1.0/n3;
    double x118 = -n3*x1 - x14;
    double x119 = 74.830163563379159*x0;

result[0] = x12*(x10 + x8) + x2 + x69 + x7*(-x4 - x6) - x15*x7/((n1)*(n1));
result[1] = x69 + x73;
result[2] = x16 + x20 + x73 + x89;
result[3] = x67 + x92;
result[4] = x88 + x92;
result[5] = x107 + x92;
result[6] = x111*(x109 + x8) + x114 + x116 + x68 + x7*(-x108 - x4) - x112*x7/((n2)*(n2));
result[7] = x111*(x109 + x72) + x113 + x116 + x7*(-x108 - x71) + x70 + x89;
result[8] = x107 + x113 + x115 + x7*(-x108 - x90) + x91;
result[9] = n3*x17 - 44.898098138027493*x0*x104 - x100*x106*x47 + x101*x41 + 74.830163563379159*x102 - x103*x119 - x103*x36 - x104*x83 - x105*x44*x98 + x105*x62*x93 + x114 + 16.628925236306479*x117*x118 + x117*x7*(n3*x9 + x8) + x119*x99 + x19 + x36*x99 + x53*(-x4 - x50) + x57*(3.5999999999999996*x3 - x54) + 5.9864130850703319*x59*x86*x95 + x7*(-n3*x5 - x4) + 74.830163563379159*x94 + 74.830163563379159*x96 - x118*x7/((n3)*(n3));
}
        
static double coder_dgdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*n1*(*endmember[0].dmu0dP)(T, P) + 1.0*n2*(*endmember[1].dmu0dP)(T, P) + 1.0*n3*(*endmember[2].dmu0dP)(T, P);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].dmu0dP)(T, P);
result[1] = 1.0*(*endmember[1].dmu0dP)(T, P);
result[2] = 1.0*(*endmember[2].dmu0dP)(T, P);
}
        
static void coder_d3gdn2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dT2)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dT2)(T, P);
    double x3 = 0.19999999999999998*T - 1;
    double x4 = -x3;
    double x5 = sqrt(x4);
    double x6 = 1.0000000000000002*x5;
    double x7 = x6 - 4;
    double x8 = (-x7 >= 0. ? 1. : 0.);
    double x9 = 80.2881*T - 401.44049999999999;
    double x10 = 1.0/x3;
    double x11 = x10*0;
    double x12 = x8/pow(x4, 3.0/2.0);
    double x13 = fmin(4, x6);
    double x14 = ((x13)*(x13));

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = -0.33333333333333331*n2*(8.0288100000000036*x10*x13*((x8)*(x8)) - 4.0144050000000018*x11*x14 - 0.010000000000000004*x11*x9 + 4.014405*x12*x14 + 0.010000000000000002*x12*x9 + 16.057620000000004*x8/x5) + 1.0*x0 + 1.0*x1 + 1.0*x2;
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[1].d2mu0dT2)(T, P);
    double x1 = 0.19999999999999998*T - 1;
    double x2 = -x1;
    double x3 = sqrt(x2);
    double x4 = 1.0000000000000002*x3;
    double x5 = x4 - 4;
    double x6 = (-x5 >= 0. ? 1. : 0.);
    double x7 = 80.2881*T - 401.44049999999999;
    double x8 = 1.0/x1;
    double x9 = 0;
    double x10 = x6/pow(x2, 3.0/2.0);
    double x11 = fmin(4, x4);
    double x12 = ((x11)*(x11));

result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
if (T >= 5.0) {
   result[1] = 1.0*x0;
}
else {
   result[1] = 1.0*x0 - 1.3381349999999999*x10*x12 - 0.003333333333333334*x10*x7 - 2.676270000000001*x11*((x6)*(x6))*x8 + 1.3381350000000005*x12*x8*x9 + 0.0033333333333333344*x7*x8*x9 - 5.3525400000000012*x6/x3;
}
result[2] = 1.0*(*endmember[2].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P) + n3*(*endmember[2].d2mu0dTdP)(T, P));
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P) + n3*(*endmember[2].d2mu0dP2)(T, P));
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT3)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dT3)(T, P);
    double x3 = 0.19999999999999998*T - 1;
    double x4 = -x3;
    double x5 = 1.0000000000000002*sqrt(x4);
    double x6 = x5 - 4;
    double x7 = 0;
    double x8 = pow(x4, -3.0/2.0);
    double x9 = (-x6 >= 0. ? 1. : 0.);
    double x10 = x8*x9;
    double x11 = 80.2881*T - 401.44049999999999;
    double x12 = pow(x3, -2);
    double x13 = x12*x7;
    double x14 = x9/pow(x4, 5.0/2.0);
    double x15 = x8*0;
    double x16 = fmin(4, x5);
    double x17 = ((x16)*(x16));

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = -0.33333333333333331*n2*(-2.4086430000000014*x10*x16*x7 + 2.4086430000000005*x10 + 0.0030000000000000009*x11*x13 + 0.0030000000000000005*x11*x14 - 0.0010000000000000005*x11*x15 - 2.4086430000000005*x12*x16*((x9)*(x9)) + 1.2043215000000003*x13*x17 + 1.2043215*x14*x17 - 0.40144050000000026*x15*x17 + 0.80288100000000051*x8*((x9)*(x9)*(x9)) - 2.408643000000001*x7/x3) + 1.0*x0 + 1.0*x1 + 1.0*x2;
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 1.0*(*endmember[1].d3mu0dT3)(T, P);
    double x1 = 0.19999999999999998*T - 1;
    double x2 = -x1;
    double x3 = 1.0000000000000002*sqrt(x2);
    double x4 = x3 - 4;
    double x5 = 0;
    double x6 = pow(x2, -3.0/2.0);
    double x7 = (-x4 >= 0. ? 1. : 0.);
    double x8 = x6*x7;
    double x9 = 80.2881*T - 401.44049999999999;
    double x10 = pow(x1, -2);
    double x11 = x10*x5;
    double x12 = x7/pow(x2, 5.0/2.0);
    double x13 = x6*0;
    double x14 = fmin(4, x3);
    double x15 = ((x14)*(x14));

result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
if (T >= 5.0) {
   result[1] = x0;
}
else {
   result[1] = x0 + 0.80288100000000018*x10*x14*((x7)*(x7)) - 0.40144050000000009*x11*x15 - 0.0010000000000000002*x11*x9 - 0.40144049999999998*x12*x15 - 0.001*x12*x9 + 0.13381350000000009*x13*x15 + 0.00033333333333333348*x13*x9 + 0.8028810000000004*x14*x5*x8 - 0.26762700000000017*x6*((x7)*(x7)*(x7)) - 0.80288100000000018*x8 + 0.80288100000000029*x5/x1;
}
result[2] = 1.0*(*endmember[2].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P) + n3*(*endmember[2].d3mu0dT2dP)(T, P));
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P) + n3*(*endmember[2].d3mu0dTdP2)(T, P));
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P) + n3*(*endmember[2].d3mu0dP3)(T, P));
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_s(double T, double P, double n[3]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[3]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[3]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[3]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[3]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[3]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

