#include <math.h>


static double coder_g(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = n1 + n2;
    double x1 = 1.0/x0;
    double x2 = 500.0*n1*n2;
    double x3 = n1*(*endmember[0].mu0)(T, P);
    double x4 = n2*(*endmember[1].mu0)(T, P);
    double x5 = T*(4.0*n1*log(n1*x1) - 5.2635018685267303*n1 + 4.0*n2*log(n2*x1) - 5.2635018685267303*n2);
    double x6 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));

if (T >= 5.0) {
   result = x1*(1.0*x0*(-n2*(53.525399999999998*T - 178.41800000000001) + x3 + x4 + 8.3144626181532395*x5) - x2);
}
else {
   result = x1*(0.33333333333333331*x0*(n2*(267.62700000000001*((x6)*(x6)*(x6)) + (160.5762*T - 802.88099999999997)*(x6 - 1) - 267.62700000000001) + 3*x3 + 3*x4 + 24.943387854459719*x5) - x2);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = pow(x0, -2);
    double x2 = 500.0*n2;
    double x3 = n1*x2;
    double x4 = (*endmember[0].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[1].mu0)(T, P);
    double x7 = n2*x6;
    double x8 = 53.525399999999998*T;
    double x9 = n2*(x8 - 178.41800000000001);
    double x10 = 1.0/x0;
    double x11 = n1*x10;
    double x12 = log(x11);
    double x13 = n2*x10;
    double x14 = log(x13);
    double x15 = 4.0*n1*x12 - 5.2635018685267303*n1 + 4.0*n2*x14 - 5.2635018685267303*n2;
    double x16 = 8.3144626181532395*T;
    double x17 = x15*x16;
    double x18 = -x1*(1.0*x0*(x17 + x5 + x7 - x9) - x3);
    double x19 = -x10;
    double x20 = 4.0*x0*(-n1*x1 - x19) + 4.0*x12 - 4.0*x13 - 5.2635018685267303;
    double x21 = 1.0*x0;
    double x22 = -1.0*x9;
    double x23 = x17 + 1.0*x5 + 1.0*x7;
    double x24 = -x2 + x23;
    double x25 = T >= 5.0;
    double x26 = 24.943387854459719*T;
    double x27 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x28 = 267.62700000000001*((x27)*(x27)*(x27)) + (160.5762*T - 802.88099999999997)*(x27 - 1) - 267.62700000000001;
    double x29 = n2*x28;
    double x30 = -x1*(0.33333333333333331*x0*(x15*x26 + x29 + 3*x5 + 3*x7) - x3);
    double x31 = 0.33333333333333331*x29;
    double x32 = 0.33333333333333331*x0;
    double x33 = 4.0*x0*(-n2*x1 - x19) - 4.0*x11 + 4.0*x14 - 5.2635018685267303;
    double x34 = -500.0*n1 + x23;

if (x25) {
   result[0] = x10*(x21*(x16*x20 + x4) + x22 + x24) + x18;
}
else {
   result[0] = x10*(x24 + x31 + x32*(x20*x26 + 3*x4)) + x30;
}
if (x25) {
   result[1] = x10*(x21*(x16*x33 + x6 - x8 + 178.41800000000001) + x22 + x34) + x18;
}
else {
   result[1] = x10*(x31 + x32*(x26*x33 + x28 + 3*x6) + x34) + x30;
}
}
        
static void coder_d2gdn2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = 500.0*n2;
    double x1 = n1*x0;
    double x2 = n1 + n2;
    double x3 = (*endmember[0].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = n2*x5;
    double x7 = 53.525399999999998*T;
    double x8 = n2*(x7 - 178.41800000000001);
    double x9 = 1.0/x2;
    double x10 = n1*x9;
    double x11 = log(x10);
    double x12 = log(n2*x9);
    double x13 = T*(4.0*n1*x11 - 5.2635018685267303*n1 + 4.0*n2*x12 - 5.2635018685267303*n2);
    double x14 = 8.3144626181532395*x13;
    double x15 = 2/((x2)*(x2)*(x2));
    double x16 = x15*(-x1 + 1.0*x2*(x14 + x4 + x6 - x8));
    double x17 = 4.0*x9;
    double x18 = pow(x2, -2);
    double x19 = n1*x18;
    double x20 = -x9;
    double x21 = -x19 - x20;
    double x22 = T*(-n2*x17 + 4.0*x11 + 4.0*x2*x21 - 5.2635018685267303);
    double x23 = 8.3144626181532395*x22;
    double x24 = 1.0*x2;
    double x25 = -1.0*x8;
    double x26 = x14 + 1.0*x4 + 1.0*x6;
    double x27 = -x0 + x26;
    double x28 = x24*(x23 + x3) + x25 + x27;
    double x29 = 2*x18;
    double x30 = 4.0*x19;
    double x31 = n2*x18;
    double x32 = 4.0*x31;
    double x33 = -x29;
    double x34 = n1*x15;
    double x35 = 4.0*x2;
    double x36 = 8.3144626181532395*T*x2;
    double x37 = x9*(16.628925236306479*x22 + 2.0*x3 + x36*(x17 - x30 + x32 + x35*(x33 + x34) + x21*x35/n1));
    double x38 = T >= 5.0;
    double x39 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x40 = ((x39)*(x39)*(x39));
    double x41 = (160.5762*T - 802.88099999999997)*(x39 - 1);
    double x42 = 267.62700000000001*x40 + x41 - 267.62700000000001;
    double x43 = n2*x42;
    double x44 = x15*(-x1 + 0.33333333333333331*x2*(24.943387854459719*x13 + 3*x4 + x43 + 3*x6));
    double x45 = 0.33333333333333331*x43;
    double x46 = 0.33333333333333331*x2;
    double x47 = x27 + x45 + x46*(24.943387854459719*x22 + 3*x3);
    double x48 = -x20 - x31;
    double x49 = T*(-4.0*x10 + 4.0*x12 + 4.0*x2*x48 - 5.2635018685267303);
    double x50 = 8.3144626181532395*x49;
    double x51 = x50 - x7;
    double x52 = -500.0*n1 + x26;
    double x53 = x24*(x5 + x51 + 178.41800000000001) + x25 + x52;
    double x54 = x17 + x30 - x32;
    double x55 = x23 + 1.0*x3 + x36*(4.0*x2*(-x18 + x34) - x54) + 1.0*x5;
    double x56 = x45 + x46*(x42 + 24.943387854459719*x49 + 3*x5) + x52;
    double x57 = x36*(x35*(n2*x15 + x33) + x54 + x35*x48/n2) + 16.628925236306479*x49 + 2.0*x5;

if (x38) {
   result[0] = x16 - x28*x29 + x37;
}
else {
   result[0] = -x29*x47 + x37 + x44;
}
if (x38) {
   result[1] = x16 - x18*x28 - x18*x53 + x9*(x51 + x55 - 321.58199999999999);
}
else {
   result[1] = -x18*x47 - x18*x56 + x44 + x9*(89.209000000000003*x40 + 0.33333333333333331*x41 + x50 + x55 - 589.20900000000006);
}
if (x38) {
   result[2] = x16 - x29*x53 + x9*(-107.0508*T + x57 + 356.83600000000001);
}
else {
   result[2] = -x29*x56 + x44 + x9*(178.41800000000001*x40 + 0.66666666666666663*x41 + x57 - 178.41800000000001);
}
}
        
static void coder_d3gdn3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = 500.0*n2;
    double x1 = n1*x0;
    double x2 = n1 + n2;
    double x3 = (*endmember[0].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = n2*x5;
    double x7 = 53.525399999999998*T;
    double x8 = n2*(x7 - 178.41800000000001);
    double x9 = 1.0/x2;
    double x10 = log(n1*x9);
    double x11 = log(n2*x9);
    double x12 = 4.0*n1*x10 - 5.2635018685267303*n1 + 4.0*n2*x11 - 5.2635018685267303*n2;
    double x13 = 8.3144626181532395*T;
    double x14 = x12*x13;
    double x15 = 6/((x2)*(x2)*(x2)*(x2));
    double x16 = -x15*(-x1 + 1.0*x2*(x14 + x4 + x6 - x8));
    double x17 = 4.0*x9;
    double x18 = pow(x2, -2);
    double x19 = n1*x18;
    double x20 = -x9;
    double x21 = -x19 - x20;
    double x22 = -n2*x17 + 4.0*x10 + 4.0*x2*x21 - 5.2635018685267303;
    double x23 = x13*x22;
    double x24 = 1.0*x2;
    double x25 = -1.0*x8;
    double x26 = x14 + 1.0*x4 + 1.0*x6;
    double x27 = -x0 + x26;
    double x28 = x24*(x23 + x3) + x25 + x27;
    double x29 = pow(x2, -3);
    double x30 = 6*x29;
    double x31 = 4.0*x19;
    double x32 = n2*x18;
    double x33 = 4.0*x32;
    double x34 = 2*x18;
    double x35 = -x34;
    double x36 = 2*x29;
    double x37 = n1*x36;
    double x38 = 4.0*x2;
    double x39 = x38*(x35 + x37);
    double x40 = 1.0/n1;
    double x41 = x21*x40;
    double x42 = x17 - x31 + x33 + x38*x41 + x39;
    double x43 = 24.943387854459719*T;
    double x44 = -16.0*x18;
    double x45 = -6*x29;
    double x46 = n1*x15;
    double x47 = 16.0*x29;
    double x48 = 8.0*x29;
    double x49 = n1*x47 - n2*x48;
    double x50 = 4.0*x41 + x49;
    double x51 = x13*x2;
    double x52 = 16.628925236306479*T;
    double x53 = x13*x42;
    double x54 = x18*(x2*x53 + x22*x52 + 2.0*x3);
    double x55 = -3*x54 + x9*(x42*x43 + x51*(x38*(-x45 - x46) + x39*x40 + x44 + x50 - x21*x38/((n1)*(n1))));
    double x56 = T >= 5.0;
    double x57 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x58 = ((x57)*(x57)*(x57));
    double x59 = (160.5762*T - 802.88099999999997)*(x57 - 1);
    double x60 = 267.62700000000001*x58 + x59 - 267.62700000000001;
    double x61 = n2*x60;
    double x62 = -x15*(-x1 + 0.33333333333333331*x2*(x12*x43 + 3*x4 + 3*x6 + x61));
    double x63 = 0.33333333333333331*x61;
    double x64 = 0.33333333333333331*x2;
    double x65 = x27 + x63 + x64*(x22*x43 + 3*x3);
    double x66 = -x20 - x32;
    double x67 = -n1*x17 + 4.0*x11 + 4.0*x2*x66 - 5.2635018685267303;
    double x68 = x13*x67;
    double x69 = x68 - x7;
    double x70 = -500.0*n1 + x26;
    double x71 = x24*(x5 + x69 + 178.41800000000001) + x25 + x70;
    double x72 = 4*x29;
    double x73 = -x18 + x37;
    double x74 = x17 + x31 - x33;
    double x75 = 4.0*x2*x73 - x74;
    double x76 = x52*x75;
    double x77 = -x54 + x9*(x51*(-8.0*x18 + x38*x40*x73 + x38*(4*x29 - x46) + x50) + x53 + x76);
    double x78 = x23 + 1.0*x3 + 1.0*x5 + x51*x75;
    double x79 = x16 - x34*(x69 + x78 - 321.58199999999999);
    double x80 = x63 + x64*(x43*x67 + 3*x5 + x60) + x70;
    double x81 = -x34*(89.209000000000003*x58 + 0.33333333333333331*x59 + x68 + x78 - 589.20900000000006) + x62;
    double x82 = x38*(n2*x36 + x35);
    double x83 = 1.0/n2;
    double x84 = x38*x66;
    double x85 = x74 + x82 + x83*x84;
    double x86 = x13*x85;
    double x87 = x9*(x51*(4.0*x18 + x38*(2*x29 - x46) + x49) + x76 + x86);
    double x88 = x2*x86 + 2.0*x5 + x52*x67;
    double x89 = x18*(-107.0508*T + x88 + 356.83600000000001);
    double x90 = x18*(178.41800000000001*x58 + 0.66666666666666663*x59 + x88 - 178.41800000000001);
    double x91 = x9*(x43*x85 + x51*(-n1*x48 + n2*x47 + x38*(-n2*x15 - x45) + x44 + 4.0*x66*x83 + x82*x83 - x84/((n2)*(n2))));

if (x56) {
   result[0] = x16 + x28*x30 + x55;
}
else {
   result[0] = x30*x65 + x55 + x62;
}
if (x56) {
   result[1] = x28*x72 + x36*x71 + x77 + x79;
}
else {
   result[1] = x36*x80 + x65*x72 + x77 + x81;
}
if (x56) {
   result[2] = x28*x36 + x71*x72 + x79 + x87 - x89;
}
else {
   result[2] = x36*x65 + x72*x80 + x81 + x87 - x90;
}
if (x56) {
   result[3] = x16 + x30*x71 - 3*x89 + x91;
}
else {
   result[3] = x30*x80 + x62 - 3*x90 + x91;
}
}
        
static double coder_dgdt(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = 1.0/(n1 + n2);
    double x1 = 33.257850472612958*n1*log(n1*x0) + 1.0*n1*(*endmember[0].dmu0dT)(T, P) - 43.763189526445224*n1 + 33.257850472612958*n2*log(n2*x0) + 1.0*n2*(*endmember[1].dmu0dT)(T, P);
    double x2 = sqrt(1 - 0.19999999999999998*T);
    double x3 = 1.0*x2;
    double x4 = fmin(4, x3);
    double x5 = (4 - x3 >= 0. ? 1. : 0.)/x2;

if (T >= 5.0) {
   result = -97.288589526445222*n2 + x1;
}
else {
   result = 0.33333333333333331*n2*(-80.2881*((x4)*(x4))*x5 + 160.5762*x4 - 0.099999999999999992*x5*(160.5762*T - 802.88099999999997) - 160.5762) - 43.763189526445224*n2 + x1;
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = 1.0/x0;
    double x2 = n2*x1;
    double x3 = n1*x1;
    double x4 = pow(x0, -2);
    double x5 = -x1;
    double x6 = 33.257850472612958*x0;
    double x7 = 33.257850472612958*x3;
    double x8 = (*endmember[1].dmu0dT)(T, P);
    double x9 = log(x2);
    double x10 = -n2*x4 - x5;
    double x11 = sqrt(1 - 0.19999999999999998*T);
    double x12 = 1.0*x11;
    double x13 = fmin(4, x12);
    double x14 = (4 - x12 >= 0. ? 1. : 0.)/x11;

result[0] = -33.257850472612958*x2 + x6*(-n1*x4 - x5) + 33.257850472612958*log(x3) + 1.0*(*endmember[0].dmu0dT)(T, P) - 43.763189526445224;
if (T >= 5.0) {
   result[1] = x10*x6 - x7 + 1.0*x8 + 33.257850472612958*x9 - 97.288589526445222;
}
else {
   result[1] = 33.257850472612958*x0*x10 - 26.762699999999999*((x13)*(x13))*x14 + 53.525399999999998*x13 - 0.033333333333333326*x14*(160.5762*T - 802.88099999999997) - x7 + 1.0*x8 + 33.257850472612958*x9 - 97.288589526445222;
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = 1.0/x0;
    double x2 = 33.257850472612958*x1;
    double x3 = pow(x0, -2);
    double x4 = n1*x3;
    double x5 = 33.257850472612958*x4;
    double x6 = n2*x3;
    double x7 = 33.257850472612958*x6;
    double x8 = -2*x3;
    double x9 = 2/((x0)*(x0)*(x0));
    double x10 = n1*x9;
    double x11 = 33.257850472612958*x0;
    double x12 = -x1;
    double x13 = x2 + x5 - x7;

result[0] = x11*(x10 + x8) + x2 - x5 + x7 + x11*(-x12 - x4)/n1;
result[1] = 33.257850472612958*x0*(x10 - x3) - x13;
result[2] = x11*(n2*x9 + x8) + x13 + x11*(-x12 - x6)/n2;
}
        
static void coder_d4gdn3dt(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = pow(x0, -2);
    double x2 = -133.03140189045183*x1;
    double x3 = pow(x0, -3);
    double x4 = -6*x3;
    double x5 = 6/((x0)*(x0)*(x0)*(x0));
    double x6 = n1*x5;
    double x7 = 33.257850472612958*x0;
    double x8 = -2*x1;
    double x9 = 2*x3;
    double x10 = n1*x9;
    double x11 = 33.257850472612958/n1;
    double x12 = x0*x11;
    double x13 = -1/x0;
    double x14 = -n1*x1 - x13;
    double x15 = 133.03140189045183*x3;
    double x16 = 66.515700945225916*x3;
    double x17 = n1*x15 - n2*x16;
    double x18 = x11*x14 + x17;
    double x19 = 1.0/n2;
    double x20 = -n2*x1 - x13;

result[0] = x12*(x10 + x8) + x18 + x2 + x7*(-x4 - x6) - x14*x7/((n1)*(n1));
result[1] = -66.515700945225916*x1 + x12*(-x1 + x10) + x18 + x7*(4*x3 - x6);
result[2] = 33.257850472612958*x1 + x17 + x7*(2*x3 - x6);
result[3] = -n1*x16 + n2*x15 + 33.257850472612958*x19*x20 + x19*x7*(n2*x9 + x8) + x2 + x7*(-n2*x5 - x4) - x20*x7/((n2)*(n2));
}
        
static double coder_dgdp(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*n1*(*endmember[0].dmu0dP)(T, P) + 1.0*n2*(*endmember[1].dmu0dP)(T, P);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].dmu0dP)(T, P);
result[1] = 1.0*(*endmember[1].dmu0dP)(T, P);
}
        
static void coder_d3gdn2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dT2)(T, P);
    double x2 = 0.19999999999999998*T - 1;
    double x3 = -x2;
    double x4 = sqrt(x3);
    double x5 = 1.0*x4;
    double x6 = x5 - 4;
    double x7 = (-x6 >= 0. ? 1. : 0.);
    double x8 = 1.6057619999999997*T - 8.0288099999999982;
    double x9 = 1.0/x2;
    double x10 = x9*0;
    double x11 = x7/pow(x3, 3.0/2.0);
    double x12 = fmin(4, x5);
    double x13 = 8.02881*((x12)*(x12));

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1;
}
else {
   result = -0.33333333333333331*n2*(-x10*x13 - x10*x8 + x11*x13 + x11*x8 + 16.05762*x12*((x7)*(x7))*x9 + 32.11524*x7/x4) + 1.0*x0 + 1.0*x1;
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = (*endmember[1].d2mu0dT2)(T, P);
    double x1 = 0.19999999999999998*T - 1;
    double x2 = -x1;
    double x3 = sqrt(x2);
    double x4 = 1.0*x3;
    double x5 = x4 - 4;
    double x6 = (-x5 >= 0. ? 1. : 0.);
    double x7 = 160.5762*T - 802.88099999999997;
    double x8 = 1.0/x1;
    double x9 = 0;
    double x10 = x6/pow(x2, 3.0/2.0);
    double x11 = fmin(4, x4);
    double x12 = ((x11)*(x11));

result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
if (T >= 5.0) {
   result[1] = 1.0*x0;
}
else {
   result[1] = 1.0*x0 - 2.6762699999999997*x10*x12 - 0.0033333333333333327*x10*x7 - 5.3525399999999994*x11*((x6)*(x6))*x8 + 2.6762699999999997*x12*x8*x9 + 0.0033333333333333327*x7*x8*x9 - 10.705079999999999*x6/x3;
}
}
        
static void coder_d4gdn2dt2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P));
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P));
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT3)(T, P);
    double x2 = 0.19999999999999998*T - 1;
    double x3 = -x2;
    double x4 = 1.0*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = pow(x3, -3.0/2.0);
    double x8 = (-x5 >= 0. ? 1. : 0.);
    double x9 = 4.8172859999999993*x7*x8;
    double x10 = 160.5762*T - 802.88099999999997;
    double x11 = pow(x2, -2);
    double x12 = x11*x6;
    double x13 = x8/pow(x3, 5.0/2.0);
    double x14 = x7*0;
    double x15 = fmin(4, x4);
    double x16 = ((x15)*(x15));

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1;
}
else {
   result = -0.33333333333333331*n2*(0.0029999999999999992*x10*x12 + 0.0029999999999999996*x10*x13 - 0.0009999999999999998*x10*x14 - 4.8172859999999993*x11*x15*((x8)*(x8)) + 2.4086429999999996*x12*x16 + 2.4086430000000001*x13*x16 - 0.80288099999999996*x14*x16 - x15*x6*x9 + 1.6057619999999999*x7*((x8)*(x8)*(x8)) + x9 - 4.8172859999999993*x6/x2) + 1.0*x0 + 1.0*x1;
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = 1.0*(*endmember[1].d3mu0dT3)(T, P);
    double x1 = 0.19999999999999998*T - 1;
    double x2 = -x1;
    double x3 = 1.0*sqrt(x2);
    double x4 = x3 - 4;
    double x5 = 0;
    double x6 = 1.6057619999999997*x5;
    double x7 = pow(x2, -3.0/2.0);
    double x8 = (-x4 >= 0. ? 1. : 0.);
    double x9 = x7*x8;
    double x10 = 160.5762*T - 802.88099999999997;
    double x11 = pow(x1, -2);
    double x12 = x11*x5;
    double x13 = x8/pow(x2, 5.0/2.0);
    double x14 = x7*0;
    double x15 = fmin(4, x3);
    double x16 = ((x15)*(x15));

result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
if (T >= 5.0) {
   result[1] = x0;
}
else {
   result[1] = x0 - 0.00099999999999999959*x10*x12 - 0.0009999999999999998*x10*x13 + 0.00033333333333333327*x10*x14 + 1.6057619999999997*x11*x15*((x8)*(x8)) - 0.80288099999999984*x12*x16 - 0.80288099999999996*x13*x16 + 0.26762699999999995*x14*x16 + x15*x6*x9 - 0.5352539999999999*x7*((x8)*(x8)*(x8)) - 1.6057619999999997*x9 + x6/x1;
}
}
        
static void coder_d5gdn2dt3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P));
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P));
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P));
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_s(double T, double P, double n[2]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[2]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[2]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[2]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[2]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[2]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[2]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[2]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[2]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[2]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[2]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[2]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[2]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[2]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

