#include <math.h>


static double coder_g(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = n1 + n2;
    double x1 = 1.0/x0;
    double x2 = -500.0*n1*n2;
    double x3 = n1*(*endmember[0].mu0)(T, P);
    double x4 = n2*(*endmember[1].mu0)(T, P);
    double x5 = log(x1*(0.25*n1 + 0.875*n2));
    double x6 = T*(2.0*n1*x5 + 4.0*n1*log(n1*x1) - 4.3287821201550702*n1 + 7.0*n2*x5 + 4.0*n2*log(n2*x1) - 4.3287821201550702*n2);
    double x7 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));

if (T >= 5.0) {
   result = x1*(1.0*x0*(-n2*(53.525399999999998*T - 178.41800000000001) + x3 + x4 + 8.3144626181532395*x6) + x2);
}
else {
   result = x1*(0.33333333333333331*x0*(n2*(267.62700000000001*((x7)*(x7)*(x7)) + (160.5762*T - 802.88099999999997)*(x7 - 1) - 267.62700000000001) + 3*x3 + 3*x4 + 24.943387854459719*x6) + x2);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = pow(x0, -2);
    double x2 = 500.0*n2;
    double x3 = -n1*x2;
    double x4 = (*endmember[0].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[1].mu0)(T, P);
    double x7 = n2*x6;
    double x8 = 53.525399999999998*T;
    double x9 = x8 - 178.41800000000001;
    double x10 = 1.0/x0;
    double x11 = n1*x10;
    double x12 = 4.0*log(x11);
    double x13 = n2*x10;
    double x14 = 4.0*log(x13);
    double x15 = 0.25*n1 + 0.875*n2;
    double x16 = log(x10*x15);
    double x17 = 2.0*x16;
    double x18 = 7.0*x16;
    double x19 = n1*x12 + n1*x17 - 4.3287821201550702*n1 + n2*x14 + n2*x18 - 4.3287821201550702*n2;
    double x20 = 8.3144626181532395*T;
    double x21 = x19*x20;
    double x22 = -x1*(1.0*x0*(-n2*x9 + x21 + x5 + x7) + x3);
    double x23 = 1.0*n1;
    double x24 = 1.0*n2;
    double x25 = x23 + x24;
    double x26 = 4.0*x0;
    double x27 = -x1*x15;
    double x28 = x0/x15;
    double x29 = x28*(0.25*x10 + x27);
    double x30 = 2.0*n1;
    double x31 = 7.0*n2;
    double x32 = x12 - 4.0*x13 + x17 + x26*(-n1*x1 + x10) + x29*x30 + x29*x31 - 4.3287821201550702;
    double x33 = -x24*x9;
    double x34 = x21 + x23*x4 + x24*x6;
    double x35 = -x2 + x34;
    double x36 = T >= 5.0;
    double x37 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x38 = 267.62700000000001*((x37)*(x37)*(x37)) + (160.5762*T - 802.88099999999997)*(x37 - 1) - 267.62700000000001;
    double x39 = 24.943387854459719*T;
    double x40 = -x1*(0.33333333333333331*x0*(n2*x38 + x19*x39 + 3*x5 + 3*x7) + x3);
    double x41 = 0.33333333333333331*n2;
    double x42 = 0.33333333333333331*n1 + x41;
    double x43 = x38*x41;
    double x44 = x28*(0.875*x10 + x27);
    double x45 = -4.0*x11 + x14 + x18 + x26*(-n2*x1 + x10) + x30*x44 + x31*x44 - 4.3287821201550702;
    double x46 = -500.0*n1 + x34;

if (x36) {
   result[0] = x10*(x25*(x20*x32 + x4) + x33 + x35) + x22;
}
else {
   result[0] = x10*(x35 + x42*(x32*x39 + 3*x4) + x43) + x40;
}
if (x36) {
   result[1] = x10*(x25*(x20*x45 + x6 - x8 + 178.41800000000001) + x33 + x46) + x22;
}
else {
   result[1] = x10*(x42*(x38 + x39*x45 + 3*x6) + x43 + x46) + x40;
}
}
        
static void coder_d2gdn2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = 500.0*n2;
    double x1 = -n1*x0;
    double x2 = n1 + n2;
    double x3 = (*endmember[0].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = n2*x5;
    double x7 = 53.525399999999998*T;
    double x8 = x7 - 178.41800000000001;
    double x9 = 1.0/x2;
    double x10 = n1*x9;
    double x11 = 4.0*log(x10);
    double x12 = log(n2*x9);
    double x13 = 4.0*n2;
    double x14 = 0.25*n1 + 0.875*n2;
    double x15 = log(x14*x9);
    double x16 = 2.0*x15;
    double x17 = 7.0*x15;
    double x18 = T*(n1*x11 + n1*x16 - 4.3287821201550702*n1 + n2*x17 - 4.3287821201550702*n2 + x12*x13);
    double x19 = 8.3144626181532395*x18;
    double x20 = 2/((x2)*(x2)*(x2));
    double x21 = x20*(x1 + 1.0*x2*(-n2*x8 + x19 + x4 + x6));
    double x22 = 1.0*n1;
    double x23 = 1.0*n2;
    double x24 = x22 + x23;
    double x25 = 4.0*x9;
    double x26 = pow(x2, -2);
    double x27 = n1*x26;
    double x28 = 4.0*x2;
    double x29 = x28*(-x27 + x9);
    double x30 = 1.0/x14;
    double x31 = -x14*x26;
    double x32 = x31 + 0.25*x9;
    double x33 = x30*x32;
    double x34 = 2.0*n1;
    double x35 = x33*x34;
    double x36 = 7.0*x33;
    double x37 = n2*x36;
    double x38 = T*(-n2*x25 + x11 + x16 + x2*x35 + x2*x37 + x29 - 4.3287821201550702);
    double x39 = 8.3144626181532395*x38;
    double x40 = -x23*x8;
    double x41 = x19 + x22*x3 + x23*x5;
    double x42 = -x0 + x41;
    double x43 = x24*(x3 + x39) + x40 + x42;
    double x44 = 2*x26;
    double x45 = 4.0*n1 + x13;
    double x46 = -x44;
    double x47 = n1*x20;
    double x48 = x14*x20;
    double x49 = x2*x30;
    double x50 = x49*(-0.5*x26 + x48);
    double x51 = 7.0*n2;
    double x52 = pow(0.2857142857142857*n1 + n2, -2);
    double x53 = x2*x32*x52;
    double x54 = 2.2857142857142856*x53;
    double x55 = x13*x26;
    double x56 = 4.0*x27;
    double x57 = x35 + x37 + x55 - x56;
    double x58 = T*(-0.65306122448979587*n1*x53 - n2*x54 + x25 + x28*x33 + x34*x50 + x45*(x46 + x47) + x50*x51 + x57 + x29/n1);
    double x59 = 8.3144626181532395*x24;
    double x60 = 2.0*x3 + 16.628925236306479*x38;
    double x61 = T >= 5.0;
    double x62 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x63 = ((x62)*(x62)*(x62));
    double x64 = (160.5762*T - 802.88099999999997)*(x62 - 1);
    double x65 = 267.62700000000001*x63 + x64 - 267.62700000000001;
    double x66 = x20*(x1 + 0.33333333333333331*x2*(n2*x65 + 24.943387854459719*x18 + 3*x4 + 3*x6));
    double x67 = 0.33333333333333331*n2;
    double x68 = 0.33333333333333331*n1 + x67;
    double x69 = x65*x67;
    double x70 = x42 + x68*(3*x3 + 24.943387854459719*x38) + x69;
    double x71 = 24.943387854459719*x68;
    double x72 = x28*(-n2*x26 + x9);
    double x73 = x31 + 0.875*x9;
    double x74 = x30*x73;
    double x75 = x2*x74;
    double x76 = T*(-4.0*x10 + 4.0*x12 + x17 + x34*x75 + x51*x75 + x72 - 4.3287821201550702);
    double x77 = 8.3144626181532395*x76;
    double x78 = -x7 + x77;
    double x79 = -500.0*n1 + x41;
    double x80 = x24*(x5 + x78 + 178.41800000000001) + x40 + x79;
    double x81 = x49*(-1.125*x26 + x48);
    double x82 = 7.9999999999999991*n2;
    double x83 = T*(-n1*x54 + x2*x36 - x25 + x34*x81 + x45*(-x26 + x47) + x51*x81 - x53*x82 + x57 + 2.0*x75);
    double x84 = 1.0*x3 + x39 + 1.0*x5;
    double x85 = x68*(3*x5 + x65 + 24.943387854459719*x76) + x69 + x79;
    double x86 = x2*x52*x73;
    double x87 = x49*(-1.75*x26 + x48);
    double x88 = T*(-2.2857142857142856*n1*x86 + x25 + x34*x74 + x34*x87 + x45*(n2*x20 + x46) + x51*x74 + x51*x87 - x55 + x56 + 14.0*x75 - x82*x86 + x72/n2);
    double x89 = 2.0*x5 + 16.628925236306479*x76;

if (x61) {
   result[0] = x21 - x43*x44 + x9*(x58*x59 + x60);
}
else {
   result[0] = -x44*x70 + x66 + x9*(x58*x71 + x60);
}
if (x61) {
   result[1] = x21 - x26*x43 - x26*x80 + x9*(x59*x83 + x78 + x84 - 321.58199999999999);
}
else {
   result[1] = -x26*x70 - x26*x85 + x66 + x9*(89.209000000000003*x63 + 0.33333333333333331*x64 + x71*x83 + x77 + x84 - 589.20900000000006);
}
if (x61) {
   result[2] = x21 - x44*x80 + x9*(-107.0508*T + x59*x88 + x89 + 356.83600000000001);
}
else {
   result[2] = -x44*x85 + x66 + x9*(178.41800000000001*x63 + 0.66666666666666663*x64 + x71*x88 + x89 - 178.41800000000001);
}
}
        
static void coder_d3gdn3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = 500.0*n2;
    double x1 = -n1*x0;
    double x2 = n1 + n2;
    double x3 = (*endmember[0].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = n2*x5;
    double x7 = 53.525399999999998*T;
    double x8 = x7 - 178.41800000000001;
    double x9 = 1.0/x2;
    double x10 = log(n1*x9);
    double x11 = 4.0*n1;
    double x12 = log(n2*x9);
    double x13 = 4.0*n2;
    double x14 = 0.25*n1 + 0.875*n2;
    double x15 = log(x14*x9);
    double x16 = 2.0*x15;
    double x17 = 7.0*x15;
    double x18 = n1*x16 - 4.3287821201550702*n1 + n2*x17 - 4.3287821201550702*n2 + x10*x11 + x12*x13;
    double x19 = 8.3144626181532395*T;
    double x20 = x18*x19;
    double x21 = 6/((x2)*(x2)*(x2)*(x2));
    double x22 = -x21*(x1 + 1.0*x2*(-n2*x8 + x20 + x4 + x6));
    double x23 = 1.0*n1;
    double x24 = 1.0*n2;
    double x25 = x23 + x24;
    double x26 = 4.0*x9;
    double x27 = pow(x2, -2);
    double x28 = -4.0*n1*x27 + 4.0*x9;
    double x29 = x2*x28;
    double x30 = 1.0/x14;
    double x31 = -x14*x27;
    double x32 = x31 + 0.25*x9;
    double x33 = x30*x32;
    double x34 = 2.0*n1;
    double x35 = x33*x34;
    double x36 = 7.0*x33;
    double x37 = n2*x36;
    double x38 = -n2*x26 + 4.0*x10 + x16 + x2*x35 + x2*x37 + x29 - 4.3287821201550702;
    double x39 = x19*x38;
    double x40 = -x24*x8;
    double x41 = x20 + x23*x3 + x24*x5;
    double x42 = -x0 + x41;
    double x43 = x25*(x3 + x39) + x40 + x42;
    double x44 = pow(x2, -3);
    double x45 = 6*x44;
    double x46 = x11 + x13;
    double x47 = 2*x27;
    double x48 = -x47;
    double x49 = 2*x44;
    double x50 = n1*x49;
    double x51 = x48 + x50;
    double x52 = 1.0/n1;
    double x53 = x28*x52;
    double x54 = 4.0*x2;
    double x55 = x14*x49;
    double x56 = -0.5*x27 + x55;
    double x57 = x30*x56;
    double x58 = x2*x57;
    double x59 = 7.0*n2;
    double x60 = 0.2857142857142857*n1 + n2;
    double x61 = pow(x60, -2);
    double x62 = x32*x61;
    double x63 = n2*x62;
    double x64 = 2.2857142857142856*x2;
    double x65 = x2*x62;
    double x66 = n1*x65;
    double x67 = x13*x27;
    double x68 = x11*x27;
    double x69 = x35 + x37 + x67 - x68;
    double x70 = x2*x53 + x26 + x33*x54 + x34*x58 + x46*x51 + x58*x59 - x63*x64 - 0.65306122448979587*x66 + x69;
    double x71 = x19*x70;
    double x72 = 16.628925236306479*T;
    double x73 = 2.0*x3 + x38*x72;
    double x74 = x27*(x25*x71 + x73);
    double x75 = 24.943387854459719*T;
    double x76 = x70*x75;
    double x77 = -16.0*x27;
    double x78 = -n1*x21;
    double x79 = x52*x54;
    double x80 = n2*x57;
    double x81 = n1*x62;
    double x82 = -x14*x21;
    double x83 = x2*x30;
    double x84 = x83*(1.5*x44 + x82);
    double x85 = n1*x2;
    double x86 = pow(x60, -3);
    double x87 = x32*x86;
    double x88 = x85*x87;
    double x89 = n2*x2;
    double x90 = x87*x89;
    double x91 = x56*x61;
    double x92 = x89*x91;
    double x93 = 16.0*x44;
    double x94 = 8.0*x44;
    double x95 = n1*x93 - n2*x94;
    double x96 = x53 + x95;
    double x97 = x11*x57 + 6.0*x33 + x34*x84 + x46*(x45 + x78) + x51*x79 + 6.0*x58 + x59*x84 - 4.5714285714285712*x63 - 1.9591836734693877*x65 + x77 + 14.0*x80 - 1.3061224489795917*x81 - 1.3061224489795917*x85*x91 + 0.37317784256559761*x88 + 1.3061224489795917*x90 - 4.5714285714285712*x92 + x96 - x29/((n1)*(n1));
    double x98 = x19*x25;
    double x99 = T >= 5.0;
    double x100 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x101 = ((x100)*(x100)*(x100));
    double x102 = (160.5762*T - 802.88099999999997)*(x100 - 1);
    double x103 = 267.62700000000001*x101 + x102 - 267.62700000000001;
    double x104 = -x21*(x1 + 0.33333333333333331*x2*(n2*x103 + x18*x75 + 3*x4 + 3*x6));
    double x105 = 0.33333333333333331*n2;
    double x106 = 0.33333333333333331*n1 + x105;
    double x107 = x103*x105;
    double x108 = x106*(3*x3 + x38*x75) + x107 + x42;
    double x109 = x27*(x106*x76 + x73);
    double x110 = x106*x75;
    double x111 = 4*x44;
    double x112 = -1.125*x27 + x55;
    double x113 = x112*x30;
    double x114 = x113*x34;
    double x115 = -x27 + x50;
    double x116 = x113*x59;
    double x117 = x83*(2.75*x44 + x82);
    double x118 = x112*x61;
    double x119 = -n1*x64*x91 - n2*x118*x64 + x113*x54 + x114 + x115*x79 + x116 + x117*x34 + x117*x59 - 0.65306122448979587*x118*x85 - 8.0*x27 + 11.0*x33 + x34*x57 + x46*(x111 + x78) + 7.0*x58 - 10.285714285714285*x63 - 6.8571428571428568*x65 + 7.0*x80 - 2.9387755102040813*x81 + 1.3061224489795917*x88 + 4.5714285714285712*x90 - 7.9999999999999991*x92 + x96;
    double x120 = x31 + 0.875*x9;
    double x121 = x120*x30;
    double x122 = 2.0*x121;
    double x123 = x122*x2;
    double x124 = x114*x2 + x115*x46 + x116*x2 + x123 + x2*x36 - 7.9999999999999991*x2*x63 - x26 - 2.2857142857142856*x66 + x69;
    double x125 = x124*x72;
    double x126 = x125 + x71;
    double x127 = -4.0*n2*x27 + 4.0*x9;
    double x128 = x127*x2;
    double x129 = x121*x59;
    double x130 = n1*x123 - n1*x26 + 4.0*x12 + x128 + x129*x2 + x17 - 4.3287821201550702;
    double x131 = x130*x19;
    double x132 = x131 - x7;
    double x133 = -500.0*n1 + x41;
    double x134 = x133 + x25*(x132 + x5 + 178.41800000000001) + x40;
    double x135 = 1.0*x3 + x39 + 1.0*x5;
    double x136 = x22 - x47*(x124*x98 + x132 + x135 - 321.58199999999999);
    double x137 = x106*(x103 + x130*x75 + 3*x5) + x107 + x133;
    double x138 = x104 - x47*(89.209000000000003*x101 + 0.33333333333333331*x102 + x110*x124 + x131 + x135 - 589.20900000000006);
    double x139 = -1.75*x27 + x55;
    double x140 = x139*x30;
    double x141 = x140*x2;
    double x142 = 14.0*n2;
    double x143 = 14.0*x2;
    double x144 = x120*x61;
    double x145 = x144*x64;
    double x146 = x83*(4.0*x44 + x82);
    double x147 = 4.5714285714285712*n1;
    double x148 = x2*x87;
    double x149 = 15.999999999999998*n2;
    double x150 = x118*x2;
    double x151 = x11*x113 + x113*x142 + x113*x143 + x122 + 2.0*x141 - x145 + x146*x34 + x146*x59 + x147*x148 - x147*x150 + x148*x149 - x149*x150 + 4.0*x27 + 14.0*x33 + x46*(x49 + x78) - 15.999999999999998*x63 - 15.999999999999998*x65 - 4.5714285714285712*x81 + x95;
    double x152 = 1.0/n2;
    double x153 = n2*x49 + x48;
    double x154 = x144*x2;
    double x155 = n1*x122 - n1*x145 - 7.9999999999999991*n2*x154 + x121*x143 + x128*x152 + x129 + x141*x34 + x141*x59 + x153*x46 + x26 - x67 + x68;
    double x156 = x155*x19;
    double x157 = x125 + x156;
    double x158 = x130*x72 + 2.0*x5;
    double x159 = x27*(-107.0508*T + x156*x25 + x158 + 356.83600000000001);
    double x160 = x155*x75;
    double x161 = x27*(178.41800000000001*x101 + 0.66666666666666663*x102 + x106*x160 + x158 - 178.41800000000001);
    double x162 = x147*x2;
    double x163 = x120*x86;
    double x164 = x139*x61;
    double x165 = x149*x2;
    double x166 = x83*(5.25*x44 + x82);
    double x167 = -n1*x94 + n2*x93 + x11*x140 + 21.0*x121 + x127*x152 + x140*x142 + 21.0*x141 - x144*x147 - x144*x149 + x152*x153*x54 - 23.999999999999996*x154 + x162*x163 - x162*x164 + x163*x165 - x164*x165 + x166*x34 + x166*x59 + x46*(-n2*x21 + x45) + x77 - x128/((n2)*(n2));

if (x99) {
   result[0] = x22 + x43*x45 - 3*x74 + x9*(x76 + x97*x98);
}
else {
   result[0] = x104 + x108*x45 - 3*x109 + x9*(x110*x97 + x76);
}
if (x99) {
   result[1] = x111*x43 + x134*x49 + x136 - x74 + x9*(x119*x98 + x126);
}
else {
   result[1] = x108*x111 - x109 + x137*x49 + x138 + x9*(x110*x119 + x126);
}
if (x99) {
   result[2] = x111*x134 + x136 - x159 + x43*x49 + x9*(x151*x98 + x157);
}
else {
   result[2] = x108*x49 + x111*x137 + x138 - x161 + x9*(x110*x151 + x157);
}
if (x99) {
   result[3] = x134*x45 - 3*x159 + x22 + x9*(x160 + x167*x98);
}
else {
   result[3] = x104 + x137*x45 - 3*x161 + x9*(x110*x167 + x160);
}
}
        
static double coder_dgdt(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = 1.0/(n1 + n2);
    double x1 = n1*(*endmember[0].dmu0dT)(T, P);
    double x2 = n2*(*endmember[1].dmu0dT)(T, P);
    double x3 = n1*log(n1*x0);
    double x4 = n2*log(n2*x0);
    double x5 = log(x0*(0.25*n1 + 0.875*n2));
    double x6 = n1*x5;
    double x7 = n2*x5;
    double x8 = sqrt(1 - 0.19999999999999998*T);
    double x9 = 1.0*x8;
    double x10 = fmin(4, x9);
    double x11 = (4 - x9 >= 0. ? 1. : 0.)/x8;

if (T >= 5.0) {
   result = x0*(1.0*n1 + 1.0*n2)*(-35.991497120159458*n1 - 89.516897120159456*n2 + x1 + x2 + 33.257850472612958*x3 + 33.257850472612958*x4 + 16.628925236306479*x6 + 58.201238327072673*x7);
}
else {
   result = x0*(0.33333333333333331*n1 + 0.33333333333333331*n2)*(-107.97449136047837*n1 + n2*(-80.2881*((x10)*(x10))*x11 + 160.5762*x10 - 0.099999999999999992*x11*(160.5762*T - 802.88099999999997) - 160.5762) - 107.97449136047837*n2 + 3*x1 + 3*x2 + 99.773551417838874*x3 + 99.773551417838874*x4 + 49.886775708919437*x6 + 174.60371498121802*x7);
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = n1 + n2;
    double x2 = 1.0/x1;
    double x3 = n2*x2;
    double x4 = n1*x2;
    double x5 = log(x4);
    double x6 = 33.257850472612958*x5;
    double x7 = 0.25*n1 + 0.875*n2;
    double x8 = log(x2*x7);
    double x9 = 16.628925236306479*x8;
    double x10 = pow(x1, -2);
    double x11 = x1*(-n1*x10 + x2);
    double x12 = -x10*x7;
    double x13 = x1/x7;
    double x14 = x13*(x12 + 0.25*x2);
    double x15 = n1*x14;
    double x16 = n2*x14;
    double x17 = 1.0*n1 + 1.0*n2;
    double x18 = x17*x2;
    double x19 = n1*x0;
    double x20 = (*endmember[1].dmu0dT)(T, P);
    double x21 = n2*x20;
    double x22 = log(x3);
    double x23 = 33.257850472612958*x22;
    double x24 = 58.201238327072673*x8;
    double x25 = n1*x6 + n1*x9 - 35.991497120159458*n1 + n2*x23 + n2*x24 - 89.516897120159456*n2 + x19 + x21;
    double x26 = -x10*x17*x25 + 1.0*x2*x25;
    double x27 = T >= 5.0;
    double x28 = 99.773551417838874*x5;
    double x29 = 49.886775708919437*x8;
    double x30 = 0.33333333333333331*n1 + 0.33333333333333331*n2;
    double x31 = x2*x30;
    double x32 = 99.773551417838874*x22;
    double x33 = 174.60371498121802*x8;
    double x34 = sqrt(1 - 0.19999999999999998*T);
    double x35 = 1.0*x34;
    double x36 = fmin(4, x35);
    double x37 = (4 - x35 >= 0. ? 1. : 0.)/x34;
    double x38 = -80.2881*((x36)*(x36))*x37 + 160.5762*x36 - 0.099999999999999992*x37*(160.5762*T - 802.88099999999997);
    double x39 = n1*x28 + n1*x29 - 107.97449136047837*n1 + n2*x32 + n2*x33 + n2*(x38 - 160.5762) - 107.97449136047837*n2 + 3*x19 + 3*x21;
    double x40 = -x10*x30*x39 + 0.33333333333333331*x2*x39;
    double x41 = x1*(-n2*x10 + x2);
    double x42 = x13*(x12 + 0.875*x2);
    double x43 = n1*x42;
    double x44 = n2*x42;

if (x27) {
   result[0] = x18*(x0 + 33.257850472612958*x11 + 16.628925236306479*x15 + 58.201238327072673*x16 - 33.257850472612958*x3 + x6 + x9 - 35.991497120159458) + x26;
}
else {
   result[0] = x31*(3*x0 + 99.773551417838874*x11 + 49.886775708919437*x15 + 174.60371498121802*x16 + x28 + x29 - 99.773551417838874*x3 - 107.97449136047837) + x40;
}
if (x27) {
   result[1] = x18*(x20 + x23 + x24 - 33.257850472612958*x4 + 33.257850472612958*x41 + 16.628925236306479*x43 + 58.201238327072673*x44 - 89.516897120159456) + x26;
}
else {
   result[1] = x31*(3*x20 + x32 + x33 + x38 - 99.773551417838874*x4 + 99.773551417838874*x41 + 49.886775708919437*x43 + 174.60371498121802*x44 - 268.55069136047837) + x40;
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = 1.0/x0;
    double x2 = (*endmember[0].dmu0dT)(T, P);
    double x3 = n2*x1;
    double x4 = n1*x1;
    double x5 = log(x4);
    double x6 = 33.257850472612958*x5;
    double x7 = 0.25*n1 + 0.875*n2;
    double x8 = log(x1*x7);
    double x9 = 16.628925236306479*x8;
    double x10 = pow(x0, -2);
    double x11 = n1*x10;
    double x12 = x0*(x1 - x11);
    double x13 = 33.257850472612958*x12;
    double x14 = 1.0/x7;
    double x15 = -x10*x7;
    double x16 = 0.25*x1 + x15;
    double x17 = x14*x16;
    double x18 = n1*x17;
    double x19 = 16.628925236306479*x18;
    double x20 = n2*x17;
    double x21 = 58.201238327072673*x20;
    double x22 = x0*x19 + x0*x21 + x13 + x2 - 33.257850472612958*x3 + x6 + x9 - 35.991497120159458;
    double x23 = x1*x22;
    double x24 = 33.257850472612958*x1;
    double x25 = 33.257850472612958*n2;
    double x26 = 33.257850472612958*n1 + x25;
    double x27 = 2*x10;
    double x28 = -x27;
    double x29 = 2/((x0)*(x0)*(x0));
    double x30 = n1*x29;
    double x31 = x28 + x30;
    double x32 = 1.0/n1;
    double x33 = x0*x17;
    double x34 = n2*x0;
    double x35 = x29*x7;
    double x36 = x14*(-0.5*x10 + x35);
    double x37 = x34*x36;
    double x38 = n1*x0;
    double x39 = x36*x38;
    double x40 = pow(0.2857142857142857*n1 + n2, -2);
    double x41 = x16*x40;
    double x42 = x34*x41;
    double x43 = x38*x41;
    double x44 = x10*x25;
    double x45 = 33.257850472612958*x11;
    double x46 = x19 + x21 + x44 - x45;
    double x47 = 1.0*n1 + 1.0*n2;
    double x48 = x1*x47;
    double x49 = x27*x47;
    double x50 = n1*x2;
    double x51 = (*endmember[1].dmu0dT)(T, P);
    double x52 = n2*x51;
    double x53 = log(x3);
    double x54 = 58.201238327072673*x8;
    double x55 = n1*x6 + n1*x9 - 35.991497120159458*n1 + n2*x54 - 89.516897120159456*n2 + x25*x53 + x50 + x52;
    double x56 = -2.0*x10*x55 + x29*x47*x55;
    double x57 = T >= 5.0;
    double x58 = 99.773551417838874*x5;
    double x59 = 49.886775708919437*x8;
    double x60 = 99.773551417838874*x12;
    double x61 = 49.886775708919437*x18;
    double x62 = 174.60371498121802*x20;
    double x63 = x0*x61 + x0*x62 + 3*x2 - 99.773551417838874*x3 + x58 + x59 + x60 - 107.97449136047837;
    double x64 = x1*x63;
    double x65 = 99.773551417838874*x1;
    double x66 = 99.773551417838874*n2;
    double x67 = 99.773551417838874*n1 + x66;
    double x68 = x10*x66;
    double x69 = 99.773551417838874*x11;
    double x70 = x61 + x62 + x68 - x69;
    double x71 = 0.33333333333333331*n1 + 0.33333333333333331*n2;
    double x72 = x1*x71;
    double x73 = x27*x71;
    double x74 = 174.60371498121802*x8;
    double x75 = sqrt(1 - 0.19999999999999998*T);
    double x76 = 1.0*x75;
    double x77 = fmin(4, x76);
    double x78 = (4 - x76 >= 0. ? 1. : 0.)/x75;
    double x79 = -80.2881*((x77)*(x77))*x78 + 160.5762*x77 - 0.099999999999999992*x78*(160.5762*T - 802.88099999999997);
    double x80 = n1*x58 + n1*x59 - 107.97449136047837*n1 + n2*x74 + n2*(x79 - 160.5762) - 107.97449136047837*n2 + 3*x50 + 3*x52 + x53*x66;
    double x81 = -0.66666666666666663*x10*x80 + x29*x71*x80;
    double x82 = x0*(-n2*x10 + x1);
    double x83 = 33.257850472612958*x82;
    double x84 = 0.875*x1 + x15;
    double x85 = x14*x84;
    double x86 = x0*x85;
    double x87 = 16.628925236306479*x86;
    double x88 = n2*x86;
    double x89 = n1*x87 - 33.257850472612958*x4 + x51 + 33.257850472612958*x53 + x54 + x83 + 58.201238327072673*x88 - 89.516897120159456;
    double x90 = x1*x89;
    double x91 = -x10 + x30;
    double x92 = x14*(-1.125*x10 + x35);
    double x93 = x34*x92;
    double x94 = x38*x92;
    double x95 = x10*x47;
    double x96 = 99.773551417838874*x82;
    double x97 = 49.886775708919437*x86;
    double x98 = n1*x97 - 99.773551417838874*x4 + 3*x51 + 99.773551417838874*x53 + x74 + x79 + 174.60371498121802*x88 + x96 - 268.55069136047837;
    double x99 = x1*x98;
    double x100 = x10*x71;
    double x101 = 1.0/n2;
    double x102 = n2*x29 + x28;
    double x103 = n1*x85;
    double x104 = n2*x85;
    double x105 = x40*x84;
    double x106 = x105*x38;
    double x107 = x105*x34;
    double x108 = x14*(-1.75*x10 + x35);
    double x109 = x108*x38;
    double x110 = x108*x34;

if (x57) {
   result[0] = -x22*x49 + 2.0*x23 + x48*(x13*x32 + x24 + x26*x31 + 33.257850472612958*x33 + 58.201238327072673*x37 + 16.628925236306479*x39 - 19.004485984350261*x42 - 5.4298531383857886*x43 + x46) + x56;
}
else {
   result[0] = -x63*x73 + 0.66666666666666663*x64 + x72*(x31*x67 + x32*x60 + 99.773551417838874*x33 + 174.60371498121802*x37 + 49.886775708919437*x39 - 57.013457953050775*x42 - 16.289559415157367*x43 + x65 + x70) + x81;
}
if (x57) {
   result[1] = -x22*x95 + 1.0*x23 + x48*(-x24 + x26*x91 + 58.201238327072673*x33 - 66.515700945225902*x42 - 19.004485984350261*x43 + x46 + x87 + 58.201238327072673*x93 + 16.628925236306479*x94) + x56 - x89*x95 + 1.0*x90;
}
else {
   result[1] = -x100*x63 - x100*x98 + 0.33333333333333331*x64 + x72*(174.60371498121802*x33 - 199.54710283567772*x42 - 57.013457953050775*x43 - x65 + x67*x91 + x70 + 174.60371498121802*x93 + 49.886775708919437*x94 + x97) + x81 + 0.33333333333333331*x99;
}
if (x57) {
   result[2] = x48*(x101*x83 + x102*x26 + 16.628925236306479*x103 + 58.201238327072673*x104 - 19.004485984350261*x106 - 66.515700945225902*x107 + 16.628925236306479*x109 + 58.201238327072673*x110 + x24 - x44 + x45 + 116.40247665414535*x86) - x49*x89 + x56 + 2.0*x90;
}
else {
   result[2] = x72*(x101*x96 + x102*x67 + 49.886775708919437*x103 + 174.60371498121802*x104 - 57.013457953050775*x106 - 199.54710283567772*x107 + 49.886775708919437*x109 + 174.60371498121802*x110 + x65 - x68 + x69 + 349.20742996243604*x86) - x73*x98 + x81 + 0.66666666666666663*x99;
}
}
        
static void coder_d4gdn3dt(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = 1.0/x0;
    double x2 = 33.257850472612958*x1;
    double x3 = 33.257850472612958*n1;
    double x4 = 33.257850472612958*n2;
    double x5 = x3 + x4;
    double x6 = pow(x0, -2);
    double x7 = 2*x6;
    double x8 = -x7;
    double x9 = pow(x0, -3);
    double x10 = 2*x9;
    double x11 = n1*x10;
    double x12 = x11 + x8;
    double x13 = 1.0/n1;
    double x14 = n1*x6;
    double x15 = x1 - x14;
    double x16 = 33.257850472612958*x15;
    double x17 = x0*x16;
    double x18 = 0.25*n1 + 0.875*n2;
    double x19 = 1.0/x18;
    double x20 = -x18*x6;
    double x21 = 0.25*x1 + x20;
    double x22 = x19*x21;
    double x23 = 33.257850472612958*x0;
    double x24 = x10*x18;
    double x25 = x24 - 0.5*x6;
    double x26 = x19*x25;
    double x27 = n2*x26;
    double x28 = 58.201238327072673*x27;
    double x29 = 16.628925236306479*n1;
    double x30 = x0*x26;
    double x31 = 0.2857142857142857*n1 + n2;
    double x32 = pow(x31, -2);
    double x33 = x21*x32;
    double x34 = n2*x33;
    double x35 = 19.004485984350261*x0;
    double x36 = x0*x33;
    double x37 = n1*x36;
    double x38 = x4*x6;
    double x39 = x3*x6;
    double x40 = n2*x22;
    double x41 = 58.201238327072673*x40;
    double x42 = x22*x29;
    double x43 = x38 - x39 + x41 + x42;
    double x44 = x0*x28 + x12*x5 + x13*x17 + x2 + x22*x23 + x29*x30 - x34*x35 - 5.4298531383857886*x37 + x43;
    double x45 = x1*x44;
    double x46 = (*endmember[0].dmu0dT)(T, P);
    double x47 = n1*x1;
    double x48 = log(x47);
    double x49 = log(x1*x18);
    double x50 = 16.628925236306479*x49;
    double x51 = -n2*x2 + x0*x41 + x0*x42 + x17 + x46 + 33.257850472612958*x48 + x50 - 35.991497120159458;
    double x52 = x51*x6;
    double x53 = -133.03140189045183*x6;
    double x54 = 6*x9;
    double x55 = 6/((x0)*(x0)*(x0)*(x0));
    double x56 = -n1*x55;
    double x57 = x54 + x56;
    double x58 = 49.886775708919437*x22;
    double x59 = x12*x13;
    double x60 = 49.886775708919437*x30;
    double x61 = pow(n1, -2);
    double x62 = 16.289559415157367*x36;
    double x63 = n1*x33;
    double x64 = n1*x0;
    double x65 = pow(x31, -3);
    double x66 = x21*x65;
    double x67 = x64*x66;
    double x68 = 58.201238327072673*n2;
    double x69 = -x18*x55;
    double x70 = x0*x19;
    double x71 = x70*(x69 + 1.5*x9);
    double x72 = n2*x0;
    double x73 = x66*x72;
    double x74 = x25*x32;
    double x75 = x72*x74;
    double x76 = x64*x74;
    double x77 = n1*x9;
    double x78 = n2*x9;
    double x79 = 133.03140189045183*x77 - 66.515700945225916*x78;
    double x80 = x13*x16 + x79;
    double x81 = 1.0*n1 + 1.0*n2;
    double x82 = x1*x81;
    double x83 = x6*x81;
    double x84 = x44*x83;
    double x85 = x51*x81;
    double x86 = n1*x46;
    double x87 = (*endmember[1].dmu0dT)(T, P);
    double x88 = n2*x87;
    double x89 = n2*x1;
    double x90 = log(x89);
    double x91 = 58.201238327072673*x49;
    double x92 = n1*x50 - 35.991497120159458*n1 + n2*x91 - 89.516897120159456*n2 + x3*x48 + x4*x90 + x86 + x88;
    double x93 = -x55*x81*x92 + 6.0*x9*x92;
    double x94 = T >= 5.0;
    double x95 = 99.773551417838874*x1;
    double x96 = 99.773551417838874*n1;
    double x97 = 99.773551417838874*n2;
    double x98 = x96 + x97;
    double x99 = 99.773551417838874*x15;
    double x100 = x0*x99;
    double x101 = 99.773551417838874*x0;
    double x102 = 174.60371498121802*x27;
    double x103 = x0*x34;
    double x104 = x6*x97;
    double x105 = 99.773551417838874*x14;
    double x106 = 174.60371498121802*x40;
    double x107 = n1*x58;
    double x108 = x104 - x105 + x106 + x107;
    double x109 = n1*x60 - n1*x62 + x0*x102 + x100*x13 + x101*x22 - 57.013457953050775*x103 + x108 + x12*x98 + x95;
    double x110 = x1*x109;
    double x111 = 49.886775708919437*x49;
    double x112 = x0*x106 + x0*x107 + x100 + x111 + 3*x46 + 99.773551417838874*x48 - 99.773551417838874*x89 - 107.97449136047837;
    double x113 = 2.0*x6;
    double x114 = -399.0942056713555*x6;
    double x115 = 174.60371498121802*n2;
    double x116 = 49.886775708919437*n1;
    double x117 = 399.0942056713555*x77 - 199.54710283567775*x78;
    double x118 = x117 + x13*x99;
    double x119 = 0.33333333333333331*n1 + 0.33333333333333331*n2;
    double x120 = x1*x119;
    double x121 = x119*x6;
    double x122 = x109*x121;
    double x123 = x112*x119;
    double x124 = 174.60371498121802*x49;
    double x125 = sqrt(1 - 0.19999999999999998*T);
    double x126 = 1.0*x125;
    double x127 = fmin(4, x126);
    double x128 = (4 - x126 >= 0. ? 1. : 0.)/x125;
    double x129 = -80.2881*((x127)*(x127))*x128 + 160.5762*x127 - 0.099999999999999992*x128*(160.5762*T - 802.88099999999997);
    double x130 = n1*x111 - 107.97449136047837*n1 + n2*x124 + n2*(x129 - 160.5762) - 107.97449136047837*n2 + x48*x96 + 3*x86 + 3*x88 + x90*x97;
    double x131 = -x119*x130*x55 + 2.0*x130*x9;
    double x132 = -n2*x6 + x1;
    double x133 = x0*x132;
    double x134 = 33.257850472612958*x133;
    double x135 = 0.875*x1 + x20;
    double x136 = x135*x19;
    double x137 = 16.628925236306479*x136;
    double x138 = x0*x137;
    double x139 = x136*x68;
    double x140 = n1*x138 - n1*x2 + x0*x139 + x134 + x87 + 33.257850472612958*x90 + x91 - 89.516897120159456;
    double x141 = 4*x9;
    double x142 = x141 + x56;
    double x143 = x24 - 1.125*x6;
    double x144 = x143*x19;
    double x145 = x144*x68;
    double x146 = x144*x29;
    double x147 = x11 - x6;
    double x148 = x13*x147;
    double x149 = x70*(x69 + 2.75*x9);
    double x150 = x143*x32;
    double x151 = x150*x64;
    double x152 = x140*x81;
    double x153 = x0*x22;
    double x154 = x0*x145 + x0*x146 - 66.515700945225902*x103 + x138 + x147*x5 + 58.201238327072673*x153 - x2 - 19.004485984350261*x37 + x43;
    double x155 = 2.0*x1*x154 - x154*x7*x81 + x93;
    double x156 = 99.773551417838874*x133;
    double x157 = 174.60371498121802*x136;
    double x158 = n2*x157;
    double x159 = 49.886775708919437*x136;
    double x160 = x0*x159;
    double x161 = n1*x160 + x0*x158 + x124 + x129 + x156 - 99.773551417838874*x47 + 3*x87 + 99.773551417838874*x90 - 268.55069136047837;
    double x162 = 0.66666666666666663*x6;
    double x163 = 1.3333333333333333*x6;
    double x164 = n2*x144;
    double x165 = 174.60371498121802*x164;
    double x166 = x116*x144;
    double x167 = x150*x72;
    double x168 = x119*x161;
    double x169 = x0*x165 + x0*x166 - 199.54710283567772*x103 + x108 + x147*x98 + 174.60371498121802*x153 + x160 - 57.013457953050775*x37 - x95;
    double x170 = 0.66666666666666663*x1*x169 - x119*x169*x7 + x131;
    double x171 = 1.0/n2;
    double x172 = n2*x10 + x8;
    double x173 = x135*x32;
    double x174 = x173*x35;
    double x175 = x0*x173;
    double x176 = 116.40247665414535*x0;
    double x177 = x24 - 1.75*x6;
    double x178 = x177*x19;
    double x179 = x0*x178;
    double x180 = n1*x137 - n1*x174 - 66.515700945225902*n2*x175 + x134*x171 + x136*x176 + x139 + x172*x5 + x179*x29 + x179*x68 + x2 - x38 + x39;
    double x181 = x1*x180;
    double x182 = x140*x6;
    double x183 = x10 + x56;
    double x184 = x70*(x69 + 4.0*x9);
    double x185 = x180*x83;
    double x186 = 57.013457953050775*x175;
    double x187 = 199.54710283567772*x175;
    double x188 = 349.20742996243604*x0;
    double x189 = 174.60371498121802*x179;
    double x190 = n1*x159 - n1*x186 - n2*x187 + n2*x189 - x104 + x105 + x116*x179 + x136*x188 + x156*x171 + x158 + x172*x98 + x95;
    double x191 = x1*x190;
    double x192 = x121*x190;
    double x193 = x132*x171;
    double x194 = pow(n2, -2);
    double x195 = -n2*x55 + x54;
    double x196 = x171*x172;
    double x197 = n1*x173;
    double x198 = n2*x173;
    double x199 = n2*x178;
    double x200 = x135*x65;
    double x201 = 38.008971968700521*x64;
    double x202 = x177*x32;
    double x203 = 133.0314018904518*x72;
    double x204 = x70*(x69 + 5.25*x9);
    double x205 = 114.02691590610155*x64;
    double x206 = 399.09420567135544*x72;

if (x94) {
   result[0] = 3.0*x45 - 6.0*x52 + x54*x85 + x82*(-x17*x61 + x23*x59 + x26*x3 + 116.40247665414535*x27 + x29*x71 - 38.008971968700521*x34 + x5*x57 + x53 + x58 + x60 - x62 - 10.859706276771577*x63 + 3.1027732219347364*x67 + x68*x71 + 10.859706276771577*x73 - 38.008971968700521*x75 - 10.859706276771577*x76 + x80) - 3*x84 + x93;
}
else {
   result[0] = 1.0*x110 - x112*x113 + x120*(-x100*x61 + x101*x59 + x114 + x115*x71 + x116*x71 + x118 + 149.66032712675832*x22 + x26*x96 + 349.20742996243604*x27 + 149.66032712675832*x30 - 114.02691590610155*x34 - 48.868678245472097*x36 + x57*x98 - 32.579118830314734*x63 + 9.3083196658042091*x67 + 32.579118830314727*x73 - 114.02691590610155*x75 - 32.579118830314734*x76) - 3*x122 + x123*x54 + x131;
}
if (x94) {
   result[1] = x10*x152 - x113*x140 + x141*x85 + x155 + 1.0*x45 - 4.0*x52 + x82*(-n1*x35*x74 - n2*x150*x35 + x142*x5 + x144*x23 + x145 + x146 + x148*x23 + x149*x29 + x149*x68 - 5.4298531383857886*x151 + 91.459088799685631*x22 + x26*x29 + x28 + 58.201238327072673*x30 - 85.52018692957617*x34 - 57.013457953050782*x36 - 66.515700945225916*x6 - 24.434339122736048*x63 + 10.859706276771577*x67 + 38.008971968700521*x73 - 66.515700945225902*x75 + x80) - x84;
}
else {
   result[1] = x10*x168 + 0.33333333333333331*x110 - x112*x163 + x120*(x101*x144 + x101*x148 + x102 + x115*x149 + x116*x149 + x116*x26 + x118 + x142*x98 - 16.289559415157367*x151 + x165 + x166 - 57.013457953050775*x167 + 274.37726639905691*x22 + 174.60371498121802*x30 - 256.56056078872848*x34 - 171.04037385915234*x36 - 199.54710283567778*x6 - 73.303017368208145*x63 + 32.579118830314734*x67 + 114.02691590610155*x73 - 199.54710283567772*x75 - 57.013457953050775*x76) - x122 + x123*x141 - x161*x162 + x170;
}
if (x94) {
   result[2] = x10*x85 + x141*x152 + x155 + 1.0*x181 - 4.0*x182 - x185 - 2.0*x52 + x82*(x137 + x144*x176 + x144*x3 - 38.008971968700521*x151 + 116.40247665414535*x164 - 133.0314018904518*x167 - x174 + 16.628925236306479*x179 + x183*x5 + x184*x29 + x184*x68 + 116.40247665414535*x22 - 133.0314018904518*x34 - 133.0314018904518*x36 + 33.257850472612958*x6 - 38.008971968700521*x63 + 38.008971968700521*x67 + 133.0314018904518*x73 + x79);
}
else {
   result[2] = x10*x123 - x112*x162 + x120*(x115*x184 + x116*x184 + x117 + x144*x188 + x144*x96 - 114.02691590610155*x151 + x159 + 349.20742996243604*x164 - 399.09420567135544*x167 + 49.886775708919437*x179 + x183*x98 - x186 + 349.20742996243604*x22 - 399.09420567135544*x34 - 399.09420567135544*x36 + 99.773551417838874*x6 - 114.02691590610155*x63 + 114.02691590610155*x67 + 399.09420567135544*x73) + x141*x168 - x161*x163 + x170 + 0.33333333333333331*x191 - x192;
}
if (x94) {
   result[3] = x152*x54 + 3.0*x181 - 6.0*x182 - 3*x185 + x82*(-x134*x194 + x157 + x178*x3 - x187 + x189 + 33.257850472612958*x193 + x195*x5 + x196*x23 - 38.008971968700521*x197 - 133.0314018904518*x198 + 116.40247665414535*x199 + x200*x201 + x200*x203 - x201*x202 - x202*x203 + x204*x29 + x204*x68 + x53 - 66.515700945225916*x77 + 133.03140189045183*x78) + x93;
}
else {
   result[3] = -x113*x161 + x120*(x101*x196 + x114 + x115*x204 + x116*x204 + 523.81114494365409*x136 - x156*x194 - 598.64130850703316*x175 + x178*x96 + 523.81114494365409*x179 + 99.773551417838874*x193 + x195*x98 - 114.02691590610155*x197 - 399.09420567135544*x198 + 349.20742996243604*x199 + x200*x205 + x200*x206 - x202*x205 - x202*x206 - 199.54710283567775*x77 + 399.0942056713555*x78) + x131 + x168*x54 + 1.0*x191 - 3*x192;
}
}
        
static double coder_dgdp(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = 1.0/(n1 + n2);
    double x1 = n1*(*endmember[0].dmu0dP)(T, P);
    double x2 = n2*(*endmember[1].dmu0dP)(T, P);

if (T >= 5.0) {
   result = x0*(1.0*n1 + 1.0*n2)*(x1 + x2);
}
else {
   result = x0*(0.33333333333333331*n1 + 0.33333333333333331*n2)*(3*x1 + 3*x2);
}
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2;
    double x2 = 1.0/x1;
    double x3 = 1.0*n1 + 1.0*n2;
    double x4 = x2*x3;
    double x5 = n1*x0;
    double x6 = (*endmember[1].dmu0dP)(T, P);
    double x7 = n2*x6;
    double x8 = x5 + x7;
    double x9 = pow(x1, -2);
    double x10 = 1.0*x2*x8 - x3*x8*x9;
    double x11 = T >= 5.0;
    double x12 = 0.33333333333333331*n1 + 0.33333333333333331*n2;
    double x13 = 3*x12*x2;
    double x14 = 3*x5 + 3*x7;
    double x15 = -x12*x14*x9 + 0.33333333333333331*x14*x2;

if (x11) {
   result[0] = x0*x4 + x10;
}
else {
   result[0] = x0*x13 + x15;
}
if (x11) {
   result[1] = x10 + x4*x6;
}
else {
   result[1] = x13*x6 + x15;
}
}
        
static void coder_d3gdn2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2;
    double x2 = 1.0/x1;
    double x3 = x0*x2;
    double x4 = 2.0*x3;
    double x5 = pow(x1, -2);
    double x6 = 1.0*n1 + 1.0*n2;
    double x7 = x5*x6;
    double x8 = x0*x7;
    double x9 = n1*x0;
    double x10 = (*endmember[1].dmu0dP)(T, P);
    double x11 = n2*x10;
    double x12 = x11 + x9;
    double x13 = 2/((x1)*(x1)*(x1));
    double x14 = x12*x13*x6 - 2.0*x12*x5;
    double x15 = T >= 5.0;
    double x16 = 0.33333333333333331*n1 + 0.33333333333333331*n2;
    double x17 = x16*x5;
    double x18 = x0*x17;
    double x19 = 3*x11 + 3*x9;
    double x20 = x13*x16*x19 - 0.66666666666666663*x19*x5;
    double x21 = x10*x7;
    double x22 = x10*x2;
    double x23 = 1.0*x22 + 1.0*x3;
    double x24 = x10*x17;
    double x25 = 2.0*x22;

if (x15) {
   result[0] = x14 + x4 - 2*x8;
}
else {
   result[0] = -6*x18 + x20 + x4;
}
if (x15) {
   result[1] = x14 - x21 + x23 - x8;
}
else {
   result[1] = -3*x18 + x20 + x23 - 3*x24;
}
if (x15) {
   result[2] = x14 - 2*x21 + x25;
}
else {
   result[2] = x20 - 6*x24 + x25;
}
}
        
static void coder_d4gdn3dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2;
    double x2 = pow(x1, -2);
    double x3 = x0*x2;
    double x4 = -6.0*x3;
    double x5 = 1.0*n1 + 1.0*n2;
    double x6 = 6*x5;
    double x7 = pow(x1, -3);
    double x8 = x0*x7;
    double x9 = n1*x0;
    double x10 = (*endmember[1].dmu0dP)(T, P);
    double x11 = n2*x10;
    double x12 = x11 + x9;
    double x13 = pow(x1, -4);
    double x14 = -x12*x13*x6 + 6.0*x12*x7;
    double x15 = T >= 5.0;
    double x16 = 0.33333333333333331*n1 + 0.33333333333333331*n2;
    double x17 = x16*x8;
    double x18 = 3*x11 + 3*x9;
    double x19 = 6*x16;
    double x20 = -x13*x18*x19 + 2.0*x18*x7;
    double x21 = x10*x7;
    double x22 = 2*x5;
    double x23 = 4*x5;
    double x24 = x10*x2;
    double x25 = -2.0*x24 - 4.0*x3;
    double x26 = -4.0*x24 - 2.0*x3;
    double x27 = x16*x21;
    double x28 = -6.0*x24;

if (x15) {
   result[0] = x14 + x4 + x6*x8;
}
else {
   result[0] = 18*x17 + x20 + x4;
}
if (x15) {
   result[1] = x14 + x21*x22 + x23*x8 + x25;
}
else {
   result[1] = 12*x17 + x19*x21 + x20 + x25;
}
if (x15) {
   result[2] = x14 + x21*x23 + x22*x8 + x26;
}
else {
   result[2] = x19*x8 + x20 + x26 + 12*x27;
}
if (x15) {
   result[3] = x14 + x21*x6 + x28;
}
else {
   result[3] = x20 + 18*x27 + x28;
}
}
        
static double coder_d2gdt2(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = 1.0*n1*(*endmember[0].d2mu0dT2)(T, P) + 1.0*n2*(*endmember[1].d2mu0dT2)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 1.6057619999999997*T - 8.0288099999999982;
    double x7 = 1.0/(x1 - 1);
    double x8 = x7*0;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = 8.02881*((x10)*(x10));

if (T >= 5.0) {
   result = x0;
}
else {
   result = -0.33333333333333331*n2*(16.05762*x10*((x5)*(x5))*x7 - x11*x8 + x11*x9 - x6*x8 + x6*x9 + 32.11524*x5/x3) + x0;
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = 1.0*(*endmember[1].d2mu0dT2)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 1.0/(x1 - 1);
    double x7 = x6*0;
    double x8 = 0.5352539999999999*T - 2.6762699999999993;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = 2.6762699999999997*((x10)*(x10));

result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
if (T >= 5.0) {
   result[1] = x0;
}
else {
   result[1] = x0 - 5.3525399999999994*x10*((x5)*(x5))*x6 + x11*x7 - x11*x9 + x7*x8 - x8*x9 - 10.705079999999999*x5/x3;
}
}
        
static void coder_d4gdn2dt2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dTdP)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dTdP)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1;
}
else {
   result = x0 + x1;
}
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dP2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dP2)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1;
}
else {
   result = x0 + x1;
}
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = 1.0*n1*(*endmember[0].d3mu0dT3)(T, P) + 1.0*n2*(*endmember[1].d3mu0dT3)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = pow(x3, -3.0/2.0);
    double x8 = (4 - x4 >= 0. ? 1. : 0.);
    double x9 = 4.8172859999999993*x7*x8;
    double x10 = 160.5762*T - 802.88099999999997;
    double x11 = pow(x2, -2);
    double x12 = x11*x6;
    double x13 = x8/pow(x3, 5.0/2.0);
    double x14 = x7*0;
    double x15 = fmin(4, x4);
    double x16 = ((x15)*(x15));

if (T >= 5.0) {
   result = x0;
}
else {
   result = -0.33333333333333331*n2*(0.0029999999999999992*x10*x12 + 0.0029999999999999996*x10*x13 - 0.0009999999999999998*x10*x14 - 4.8172859999999993*x11*x15*((x8)*(x8)) + 2.4086429999999996*x12*x16 + 2.4086430000000001*x13*x16 - 0.80288099999999996*x14*x16 - x15*x6*x9 + 1.6057619999999999*x7*((x8)*(x8)*(x8)) + x9 - 4.8172859999999993*x6/x2) + x0;
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = 1.0*(*endmember[1].d3mu0dT3)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = 1.6057619999999997*x6;
    double x8 = pow(x3, -3.0/2.0);
    double x9 = (4 - x4 >= 0. ? 1. : 0.);
    double x10 = x8*x9;
    double x11 = 160.5762*T - 802.88099999999997;
    double x12 = pow(x2, -2);
    double x13 = x12*x6;
    double x14 = x9/pow(x3, 5.0/2.0);
    double x15 = x8*0;
    double x16 = fmin(4, x4);
    double x17 = ((x16)*(x16));

result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
if (T >= 5.0) {
   result[1] = x0;
}
else {
   result[1] = x0 + x10*x16*x7 - 1.6057619999999997*x10 - 0.00099999999999999959*x11*x13 - 0.0009999999999999998*x11*x14 + 0.00033333333333333327*x11*x15 + 1.6057619999999997*x12*x16*((x9)*(x9)) - 0.80288099999999984*x13*x17 - 0.80288099999999996*x14*x17 + 0.26762699999999995*x15*x17 - 0.5352539999999999*x8*((x9)*(x9)*(x9)) + x7/x2;
}
}
        
static void coder_d5gdn2dt3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT2dP)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT2dP)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1;
}
else {
   result = x0 + x1;
}
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dTdP2)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dTdP2)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1;
}
else {
   result = x0 + x1;
}
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dP3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dP3)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1;
}
else {
   result = x0 + x1;
}
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_s(double T, double P, double n[2]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[2]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[2]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[2]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[2]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[2]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[2]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[2]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[2]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[2]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[2]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[2]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[2]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[2]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

