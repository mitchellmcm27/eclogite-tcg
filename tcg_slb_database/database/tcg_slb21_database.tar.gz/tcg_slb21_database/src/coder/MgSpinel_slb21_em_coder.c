
static char *identifier = "MgSpinel_slb21_em.emml:870d082e9563b97abc14b79e293d22ab07a2c7a0:Fri May 17 14:24:13 2024";



#include <math.h>
#include "coder_error.h"

#include <float.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

static double chebvalat(double x) {
    double c[17] = {
        2.707737068327440945 / 2.0, 0.340068135211091751, -0.12945150184440869e-01, 0.7963755380173816e-03,
        -0.546360009590824e-04, 0.39243019598805e-05, -0.2894032823539e-06, 0.217317613962e-07, -0.16542099950e-08,
        0.1272796189e-09, -0.987963460e-11, 0.7725074e-12, -0.607797e-13, 0.48076e-14, -0.3820e-15, 0.305e-16, -0.24e-17
    };
    double x2 = 2 * x;
    double c0 = c[17-2];
    double c1 = c[17-1];
    for (int i=3; i<18; i++) {
        double tmp = c0;
        c0 = c[17-i] - c1;
        c1 = tmp + c1 * x2;
    }
    return c0 + c1 * x;
}

static double Debye(double x) {
    //
    // returns D_3(x) = 3/x^3\int_0^x t^3/(e^t - 1) dt
    //
    
    double val_infinity = 19.4818182068004875;
    double sqrt_eps = sqrt(DBL_EPSILON);
    double log_eps = log(DBL_EPSILON);
    double xcut = -log_eps;

    //Check for negative x (was returning zero)
    assert(x >= 0.);

    if (x < (2.0*sqrt(2.0)*sqrt_eps)) return 1.0 - 3.0*x/8.0 + x*x/20.0;
    else if (x <= 4.0) {
        double t = x*x/8.0 - 1.0;
        double c = chebvalat(t);
        return c - 0.375*x;
    } else if (x < -(log(2.0)+log_eps)) {
        int nexp = (int)(floor(xcut / x));
        double ex = exp(-x);
        double xk = nexp * x;
        double rk = nexp;
        double sum = 0.0;
        for (int i=nexp; i>0; i--) {
            double xk_inv = 1.0/xk;
            sum *= ex;
            sum += (((6.0*xk_inv + 6.0)*xk_inv + 3.0)*xk_inv + 1.0)/rk;
            rk -= 1.0;
            xk -= x;
        }
        return val_infinity / (x * x * x) - 3.0 * sum * ex;
    } else if (x < xcut) {
        double x3 = x*x*x;
        double sum = 6.0 + 6.0*x + 3.0*x*x + x3;
        return (val_infinity - 3.0*sum*exp(-x))/x3;
    } else return ((val_infinity/x)/x)/x;
}

double born_B(double t, double p);
double born_Q(double t, double p);
double born_N(double t, double p);
double born_U(double t, double p);
double born_Y(double t, double p);
double born_X(double t, double p);
double born_dUdT(double t, double p);
double born_dUdP(double t, double p);
double born_dNdT(double t, double p);
double born_dNdP(double t, double p);
double born_dXdT(double t, double p);
double gSolvent(double t, double p);
double DgSolventDt(double t, double p);
double DgSolventDp(double t, double p);
double D2gSolventDt2(double t, double p);
double D2gSolventDtDp(double t, double p);
double D2gSolventDp2(double t, double p);
double D3gSolventDt3(double t, double p);
double D3gSolventDt2Dp(double t, double p);
double D3gSolventDtDp2(double t, double p);
double D3gSolventDp3(double t, double p);
double D4gSolventDt4(double t, double p);

static double coder_a(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/V;
    double x1 = pow(x0, 2.0/3.0);
    double x2 = pow(x0, 4.0/3.0);
    double x3 = sqrt(0.3924260459690001*x1 - x2 - 0.032930434361460002);
    double x4 = 44.483914034512026*x3;
    double x5 = 13345.174210353609*x3/T;

    result += 698.41485992487208*T*log(1 - exp(-x5)) - 232.80495330829069*T*Debye(x5) - 234097799.85697436*x1 + 83954892.936432242*x2 - 209524.45797746163*log(1 - exp(-x4)) + 69841.485992487214*Debye(x4) + 15297006.911863208 + 2767167400.8351049/((V)*(V));
    return result;
}

static double coder_dadt(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/V;
    double x1 = sqrt(-pow(x0, 4.0/3.0) + 0.3924260459690001*pow(x0, 2.0/3.0) - 0.032930434361460002);
    double x2 = x1/T;
    double x3 = 13345.174210353609*x2;
    double x4 = Debye(x3);
    double x5 = exp(-x3);
    double x6 = 1 - x5;

    result += -9320467.9767971318*x2*x5/x6 + 3106822.6589323771*x2*(-0.00022480036249152187*T*x4/x1 + 3/(exp(x3) - 1)) - 232.80495330829069*x4 + 698.41485992487208*log(x6);
    return result;
}

static double coder_dadv(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/V;
    double x1 = pow(x0, 2.0/3.0);
    double x2 = x0*x1;
    double x3 = pow(x0, 4.0/3.0);
    double x4 = x0*x3;
    double x5 = sqrt(0.3924260459690001*x1 - x3 - 0.032930434361460002);
    double x6 = 44.483914034512026*x5;
    double x7 = exp(-x6);
    double x8 = 1.0/x5;
    double x9 = x8*(-0.13080868198966669*x2 + (2.0/3.0)*x4);
    double x10 = 13345.174210353609*x5/T;
    double x11 = exp(-x10);
    double x12 = 3106822.6589323771*x9;

    result += 9320467.9767971318*x11*x9/(1 - x11) + x12*(-0.067440108747456567*x8*Debye(x6) + 3/(exp(x6) - 1)) - x12*(-0.00022480036249152187*T*x8*Debye(x10) + 3/(exp(x10) - 1)) + 156065199.90464956*x2 - 111939857.24857631*x4 - 9320467.97679713*x7*x9/(1 - x7) - 5534334801.6702099/((V)*(V)*(V));
    return result;
}

static double coder_d2adt2(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = 1.0/V;
    double x2 = pow(x1, 2.0/3.0);
    double x3 = pow(x1, 4.0/3.0);
    double x4 = sqrt(0.3924260459690001*x2 - x3 - 0.032930434361460002);
    double x5 = x0*x4;
    double x6 = 13345.174210353609*x5;
    double x7 = exp(-x6);
    double x8 = 1 - x7;
    double x9 = pow(T, -2);
    double x10 = x9*(-48811234388.287003*x2 + 124383268872.37976*x3 + 4095995071.2657328);
    double x11 = Debye(x6)/x4;
    double x12 = exp(x6);
    double x13 = x12 - 1;

    result += x0*(x10*x7/x8 + x10*exp(-26690.348420707218*x5)/((x8)*(x8)) - 3106822.6589323771*x4*(x0*(0.00067440108747456571*T*x11 - 9.0000000000000018/x13) + 0.00022480036249152187*x11 - 40035.522631060827*x12*x4*x9/((x13)*(x13))));
    return result;
}

static double coder_d2adtdv(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = 1.0/V;
    double x2 = pow(x1, 2.0/3.0);
    double x3 = 0.3924260459690001*x2;
    double x4 = pow(x1, 4.0/3.0);
    double x5 = x3 - x4 - 0.032930434361460002;
    double x6 = sqrt(x5);
    double x7 = x0*x6;
    double x8 = 13345.174210353609*x7;
    double x9 = exp(-x8);
    double x10 = 1 - x9;
    double x11 = 41461089624.126587*x0;
    double x12 = T*Debye(x8);
    double x13 = 1.0/x6;
    double x14 = exp(x8);
    double x15 = x14 - 1;

    result += x0*x1*x2*(2*x2 - 0.3924260459690001)*(-3106822.6589323771*x6*(13345.174210353609*x0*x13*x14/((x15)*(x15)) - 7.4933454163840618e-5*x12/pow(x5, 3.0/2.0) + (0.00022480036249152187*x12*x13 - 3/x15)/(-x3 + x4 + 0.032930434361460002)) + x11*x9/x10 + x11*exp(-26690.348420707218*x7)/((x10)*(x10)));
    return result;
}

static double coder_d2adv2(double T, double V) {
    double result = 0.0;
    double x0 = pow(V, -2);
    double x1 = 1.0/V;
    double x2 = pow(x1, 2.0/3.0);
    double x3 = pow(x1, 4.0/3.0);
    double x4 = 0.3924260459690001*x2;
    double x5 = -x3 + x4 - 0.032930434361460002;
    double x6 = sqrt(x5);
    double x7 = 44.483914034512026*x6;
    double x8 = exp(-x7);
    double x9 = 1 - x8;
    double x10 = 1.0/(x3 - x4 + 0.032930434361460002);
    double x11 = x3*((x2 - 0.19621302298450005)*(x2 - 0.19621302298450005));
    double x12 = x10*x11;
    double x13 = 184271509.44056255*x12;
    double x14 = x8/x9;
    double x15 = pow(x5, -3.0/2.0);
    double x16 = x11*x15;
    double x17 = 1.0/x6;
    double x18 = x17*x2*(14*x2 - 1.9621302298450003);
    double x19 = 4142430.2119098362*x11;
    double x20 = 1.0/T;
    double x21 = x20*x6;
    double x22 = 13345.174210353609*x21;
    double x23 = exp(-x22);
    double x24 = 1 - x23;
    double x25 = x23/x24;
    double x26 = 55281452832.168777*x12*x20;
    double x27 = exp(x7);
    double x28 = x27 - 1;
    double x29 = Debye(x7);
    double x30 = 0.067440108747456567*x17*x29 - 3/x28;
    double x31 = 1380810.0706366119*x16;
    double x32 = 345202.51765915297*x18;
    double x33 = exp(x22);
    double x34 = x33 - 1;
    double x35 = T*Debye(x22);
    double x36 = 0.00022480036249152187*x17*x35 - 3/x34;
    double x37 = x17*x19;

    result += x0*(16603004405.01063*x0 - x13*x14 - x13*exp(-88.967828069024051*x6)/((x9)*(x9)) + 4142430.2119098352*x14*x16 + 1035607.5529774588*x14*x18 - x15*x19*x25 - 1035607.552977459*x18*x25 - 260108666.50774926*x2 + x25*x26 + 261193000.24667805*x3 + x30*x31 + x30*x32 - x31*x36 - x32*x36 - x37*(x10*x30 - 0.022480036249152187*x15*x29 + 44.483914034512026*x17*x27/((x28)*(x28))) + x37*(x10*x36 - 7.4933454163840618e-5*x15*x35 + 13345.174210353609*x17*x20*x33/((x34)*(x34))) + x26*exp(-26690.348420707218*x21)/((x24)*(x24)));
    return result;
}

static double coder_d3adt3(double T, double V) {
    double result = 0.0;
    double x0 = pow(T, -2);
    double x1 = 1.0/V;
    double x2 = pow(x1, 2.0/3.0);
    double x3 = pow(x1, 4.0/3.0);
    double x4 = x0*(-146433703164.86099*x2 + 373149806617.13928*x3 + 12287985213.797199);
    double x5 = 1.0/T;
    double x6 = 0.3924260459690001*x2;
    double x7 = -x3 + x6 - 0.032930434361460002;
    double x8 = sqrt(x7);
    double x9 = x5*x8;
    double x10 = 13345.174210353609*x9;
    double x11 = exp(-x10);
    double x12 = 1 - x11;
    double x13 = 26690.348420707218*x9;
    double x14 = exp(-x13)/((x12)*(x12));
    double x15 = x11/x12;
    double x16 = pow(T, -3);
    double x17 = x16*pow(x7, 3.0/2.0);
    double x18 = Debye(x10)/x8;
    double x19 = exp(x10);
    double x20 = x19 - 1;
    double x21 = x19/((x20)*(x20));
    double x22 = x0*x21*x8;
    double x23 = 0.00067440108747456571*x18;
    double x24 = x5*(T*x23 - 9.0000000000000018/x20);
    double x25 = 3106822.6589323771*x8;
    double x26 = x16*(x3 - x6 + 0.032930434361460002);

    result += x0*(-4979749175865484.0*x14*x17 - x14*x4 - 1659916391955161.3*x15*x17 - x15*x4 + x25*(0.00022480036249152187*x18 - 40035.522631060827*x22 + x24) - x25*(-534281024.11406124*x21*x26 - 40035.522631060841*x22 + x23 + 3.0000000000000004*x24 + 1068562048.2281225*x26*exp(x13)/((x20)*(x20)*(x20))) - 3319832783910322.5*x17*exp(-40035.522631060827*x9)/((x12)*(x12)*(x12)));
    return result;
}

static double coder_d3adt2dv(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = 1.0/V;
    double x2 = pow(x1, 2.0/3.0);
    double x3 = pow(T, -2);
    double x4 = x3*(165844358496.50635*x2 - 32540822925.524666);
    double x5 = 0.3924260459690001*x2;
    double x6 = pow(x1, 4.0/3.0);
    double x7 = x5 - x6 - 0.032930434361460002;
    double x8 = sqrt(x7);
    double x9 = x0*x8;
    double x10 = 13345.174210353609*x9;
    double x11 = exp(-x10);
    double x12 = 1 - x11;
    double x13 = 26690.348420707218*x9;
    double x14 = exp(-x13)/((x12)*(x12));
    double x15 = x11/x12;
    double x16 = pow(T, -3);
    double x17 = 2*x2 - 0.3924260459690001;
    double x18 = x17*x8;
    double x19 = x16*x18;
    double x20 = 1.0/x8;
    double x21 = Debye(x10);
    double x22 = x20*x21;
    double x23 = 0.00022480036249152187*x22;
    double x24 = exp(x10);
    double x25 = x24 - 1;
    double x26 = x24/((x25)*(x25));
    double x27 = 1.0/x25;
    double x28 = x21/pow(x7, 3.0/2.0);
    double x29 = x20*x26;
    double x30 = 1.0/(-x5 + x6 + 0.032930434361460002);
    double x31 = T*x23;

    result += x0*x1*x2*(1659916391955161.3*x14*x19 - x14*x4 + 553305463985053.75*x15*x19 - x15*x4 - 1035607.552977459*x17*x20*(x0*(0.00067440108747456571*T*x22 - 9.0000000000000018*x27) + x23 - 40035.522631060827*x26*x3*x8) + 3106822.6589323771*x18*(-x0*x30*(-3.0*x27 + x31) - x0*(-0.0002248003624915219*T*x28 + 40035.522631060834*x0*x29 + 3.0000000000000004*x30*(-3*x27 + x31)) + 178093674.70468706*x16*x26 - 356187349.40937412*x16*exp(x13)/((x25)*(x25)*(x25)) + 7.4933454163840618e-5*x28 + 13345.174210353609*x29*x3) + 1106610927970107.5*x19*exp(-40035.522631060827*x9)/((x12)*(x12)*(x12)));
    return result;
}

static double coder_d3adtdv2(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = 1.0/V;
    double x2 = pow(x1, 2.0/3.0);
    double x3 = x0*(193485084912.59073*x2 - 27117352437.937218);
    double x4 = 0.3924260459690001*x2;
    double x5 = pow(x1, 4.0/3.0);
    double x6 = x4 - x5 - 0.032930434361460002;
    double x7 = sqrt(x6);
    double x8 = x0*x7;
    double x9 = 13345.174210353609*x8;
    double x10 = exp(-x9);
    double x11 = 1 - x10;
    double x12 = 26690.348420707218*x8;
    double x13 = exp(-x12)/((x11)*(x11));
    double x14 = x10/x11;
    double x15 = 1.0/x7;
    double x16 = ((x2 - 0.19621302298450005)*(x2 - 0.19621302298450005));
    double x17 = x16*x2;
    double x18 = x17/((T)*(T));
    double x19 = x15*x18;
    double x20 = pow(x6, -3.0/2.0);
    double x21 = T*Debye(x9);
    double x22 = x20*x21;
    double x23 = exp(x9);
    double x24 = x23 - 1;
    double x25 = x23/((x24)*(x24));
    double x26 = x0*x15*x25;
    double x27 = -x4 + x5 + 0.032930434361460002;
    double x28 = 1.0/x27;
    double x29 = 0.00022480036249152187*x15*x21 - 3/x24;
    double x30 = x28*x29;
    double x31 = x16*(-7.4933454163840618e-5*x22 + 13345.174210353609*x26 + x30);
    double x32 = 14*x2 - 1.9621302298450003;
    double x33 = x18*x28;
    double x34 = x0*x2;
    double x35 = x29/((x27)*(x27));
    double x36 = 4*x2;

    result += -x34*(2213221855940214.8*x13*x19 + x13*x3 + 737740618646738.25*x14*x19 + x14*x3 + 4142430.2119098362*x15*x2*x31 + 3106822.6589323771*x7*(-17793.565613804811*x16*x20*x25*x34 + 0.00029973381665536247*x17*x21/pow(x6, 5.0/2.0) + 1.3333333333333335*x17*x35 + 0.33333333333333337*x2*x35*(2*x2 - 0.3924260459690001)*(x36 - 0.78485209193800021) + 2.4977818054613539e-5*x22*x32 - 237458232.93958277*x25*x33 - 4448.3914034512027*x26*x32 + x28*x31*x36 - 0.33333333333333337*x30*x32 + 474916465.87916553*x33*exp(x12)/((x24)*(x24)*(x24))) + 1475481237293476.5*x19*exp(-40035.522631060827*x8)/((x11)*(x11)*(x11)))/((V)*(V));
    return result;
}

static double coder_d3adv3(double T, double V) {
    double result = 0.0;
    double x0 = pow(V, -2);
    double x1 = 1.0/V;
    double x2 = pow(x1, 2.0/3.0);
    double x3 = pow(x1, 4.0/3.0);
    double x4 = 0.3924260459690001*x2;
    double x5 = -x3 + x4 - 0.032930434361460002;
    double x6 = sqrt(x5);
    double x7 = 1.0/x6;
    double x8 = x7*(140*x2 - 15.697041838760001);
    double x9 = x2*x8;
    double x10 = 44.483914034512026*x6;
    double x11 = exp(-x10);
    double x12 = 1 - x11;
    double x13 = x11/x12;
    double x14 = 2*x2 - 0.3924260459690001;
    double x15 = x0*x14;
    double x16 = 88.967828069024051*x6;
    double x17 = exp(-x16)/((x12)*(x12));
    double x18 = x2 - 0.19621302298450005;
    double x19 = ((x18)*(x18));
    double x20 = x3 - x4 + 0.032930434361460002;
    double x21 = pow(x20, -2);
    double x22 = x19*x21;
    double x23 = 61423836.480187513*x22;
    double x24 = x17*x23;
    double x25 = 4*x2;
    double x26 = x25 - 0.78485209193800021;
    double x27 = x0*x26;
    double x28 = x13*x23;
    double x29 = 1.0/x20;
    double x30 = x17*x29;
    double x31 = 14*x2 - 1.9621302298450003;
    double x32 = x18*x3*x31;
    double x33 = 61423836.480187513*x32;
    double x34 = x13*x29;
    double x35 = 1.0/T;
    double x36 = x35*x6;
    double x37 = 13345.174210353609*x36;
    double x38 = exp(-x37);
    double x39 = 1 - x38;
    double x40 = x38/x39;
    double x41 = pow(x5, -3.0/2.0);
    double x42 = x15*x19;
    double x43 = x41*x42;
    double x44 = pow(x5, -5.0/2.0);
    double x45 = x42*x44;
    double x46 = x14*x3;
    double x47 = x31*x46;
    double x48 = 15355959.12004688*x47;
    double x49 = x41*x47;
    double x50 = 18427150944.056259*x22;
    double x51 = 26690.348420707218*x36;
    double x52 = exp(-x51)/((x39)*(x39));
    double x53 = x35*x52;
    double x54 = x50*x53;
    double x55 = x35*x40;
    double x56 = x50*x55;
    double x57 = x29*x53;
    double x58 = 18427150944.056259*x32;
    double x59 = x29*x55;
    double x60 = pow(T, -2);
    double x61 = x43*x60;
    double x62 = 4606787736.0140648*x47;
    double x63 = 115067.50588638433*x8;
    double x64 = exp(x10);
    double x65 = x64 - 1;
    double x66 = Debye(x10);
    double x67 = 0.067440108747456567*x66*x7 - 3/x65;
    double x68 = x2*x67;
    double x69 = exp(x37);
    double x70 = x69 - 1;
    double x71 = T*Debye(x37);
    double x72 = 0.00022480036249152187*x7*x71 - 3/x70;
    double x73 = x2*x72;
    double x74 = 1380810.0706366119*x45;
    double x75 = 345202.51765915303*x49;
    double x76 = x41*x66;
    double x77 = x64/((x65)*(x65));
    double x78 = x7*x77;
    double x79 = x29*x67;
    double x80 = -0.022480036249152187*x76 + 44.483914034512026*x78 + x79;
    double x81 = 2761620.1412732238*x43;
    double x82 = x46*x7;
    double x83 = 690405.03531830595*x31*x82;
    double x84 = x41*x71;
    double x85 = x69/((x70)*(x70));
    double x86 = x35*x85;
    double x87 = x7*x86;
    double x88 = x29*x72;
    double x89 = -7.4933454163840618e-5*x84 + 13345.174210353609*x87 + x88;
    double x90 = x19*x2;
    double x91 = x44*x90;
    double x92 = x19*x29;
    double x93 = x2*x92;
    double x94 = x41*x90;
    double x95 = 0.33333333333333337*x31;
    double x96 = 1.3333333333333335*x22;
    double x97 = 0.33333333333333337*x14*x21*x26;
    double x98 = x25*x92;
    double x99 = 1035607.552977459*x82;
    double x100 = x60*x93;

    result += (-66412017620.042519*x0 - 2732372661.6545849*x13*x43 - 4142430.2119098352*x13*x45 - 1035607.5529774588*x13*x49 - 345202.51765915292*x13*x9 - x15*x24 - x15*x28 + x15*x54 + x15*x56 - 8197117984.9637547*x17*x43 + 693623110.68733132*x2 - x24*x27 - x27*x28 + x27*x54 + x27*x56 - 870643334.15559351*x3 + x30*x33 + x30*x48 + x33*x34 + x34*x48 + 4142430.2119098362*x40*x45 + 1035607.5529774589*x40*x49 + 245913539548912.75*x40*x61 + 345202.51765915303*x40*x9 + 737740618646738.25*x52*x61 - x57*x58 - x57*x62 - x58*x59 - x59*x62 - x63*x68 + x63*x73 - x67*x74 - x67*x75 + x72*x74 + x72*x75 + x80*x81 + x80*x83 - x81*x89 - x83*x89 + x99*(-237458232.93958277*x100*x85 + 474916465.87916553*x100*exp(x51)/((x70)*(x70)*(x70)) + 2.4977818054613539e-5*x31*x84 - 4448.3914034512027*x31*x87 + 0.00029973381665536247*x71*x91 + x73*x96 + x73*x97 - 17793.565613804811*x86*x94 - x88*x95 + x89*x98) - x99*(0.0074933454163840629*x31*x76 - 14.827971344837341*x31*x78 + 0.089920144996608747*x66*x91 + x68*x96 + x68*x97 - 2638.4248104398075*x77*x93 - 59.311885379349363*x77*x94 - x79*x95 + x80*x98 + 5276.849620879615*x93*exp(x16)/((x65)*(x65)*(x65))) + 491827079097825.5*x61*exp(-40035.522631060827*x36)/((x39)*(x39)*(x39)) - 5464745323.3091698*x43*exp(-133.45174210353608*x6)/((x12)*(x12)*(x12)))/((V)*(V)*(V));
    return result;
}


static const double tol = 0.001;
static const int MAX_ITS = 200;
static double Told = 0.0;
static double Pold = 0.0;
static const double Vmin = 0.5*15.9048;
static const double Vmax = 1.15*15.9048;
static double V = 0.9*15.9048;

static void coder_solve_V(double T, double P) {
    // Newtsafe routine, newton + bisection with bracket check
    // Update if *either* T or P changes (was only if both changed)
    if ((T != Told) || (P != Pold)) {
        // check bracket
        double fa = -coder_dadv(T, Vmin) - P;
        double fb = -coder_dadv(T, Vmax) - P;
        if ( isnan(fa) ) {
            fprintf(stderr, "Error: lower bracket isnan for Vmin=%g\n",Vmin);
            coder_error_flag = CODER_ERR_NAN;
            return;
        }
        if ( isnan(fb) ) {
            fprintf(stderr, "Error: upper bracket isnan for Vmax=%g\n",Vmax);
            coder_error_flag = CODER_ERR_NAN;
            return;
        }
        if ( fa*fb > 0.) 
        {
            fprintf(stderr, "Error: improper  initial bracket in solve_V\n");
            coder_error_flag = CODER_ERR_BOUNDS;
            return;
        }
        //set up bisection parameters
        double a = Vmin;
        double b = Vmax;
        double c = 0.;
        double fc = 0.;
        Told = T;
        Pold = P;
        //start Newton step
        double f = 0.0;
        int iter = 0;
        do {
            //newton step
            f = -coder_dadv(T, V) - P;
            double df = -coder_d2adv2(T, V);
            V -= f/df;
            if (V < a || V > b || df == 0. || isnan(V) ) {
                //take a bisection step
                c = 0.5*(a + b);
                fc = -coder_dadv(T, c) - P;
                if ( fa*fc < 0 ) { // left bracket
                    b = c;
                    fb = fc;
                }
                else if ( fb*fc < 0 ) { //right bracket
                    a = c;
                    fa = fc;
                }
                //reset V to middle of new bracket and clear f
                V = 0.5*( a + b);
                f = 1.;
            }
            iter++;
        } while ((fabs(f) > tol) && (iter < MAX_ITS));
        if ( iter == MAX_ITS) {
            fprintf(stderr, "Error: max iterations exceeded in solve_V\n");
            coder_error_flag = CODER_ERR_MAXITS;
            return;
        }
    }
}

static double coder_g(double T, double P) {
    coder_solve_V(T, P);
    double A = coder_a(T, V);
    return A + P*V;
}

static double coder_dgdt(double T, double P) {
    coder_solve_V(T, P);
    double dAdT = coder_dadt(T, V);
    return dAdT;
}

static double coder_dgdp(double T, double P) {
    coder_solve_V(T, P);
    return V;
}

static double coder_d2gdt2(double T, double P) {
    coder_solve_V(T, P);
    double d2AdT2 = coder_d2adt2(T, V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    return d2AdT2 - d2AdTdV*d2AdTdV/d2AdV2;
}

static double coder_d2gdtdp(double T, double P) {
    coder_solve_V(T, P);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    return - d2AdTdV/d2AdV2;
}

static double coder_d2gdp2(double T, double P) {
    coder_solve_V(T, P);
    double d2AdV2 = coder_d2adv2(T, V);
    return - 1.0/d2AdV2;
}

static double coder_d3gdt3(double T, double P) {
    coder_solve_V(T, P);
    double d3AdT3 = coder_d3adt3(T, V);
    double d3AdT2dV = coder_d3adt2dv(T, V);
    double d3AdTdV2 = coder_d3adtdv2(T, V);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double dVdT = -d2AdTdV/d2AdV2;
    double d2VdT2 = (-d3AdT2dV - 2.0*d3AdTdV2*dVdT - d3AdV3*dVdT*dVdT)/d2AdV2;
    return d3AdT3 + 2.0*d3AdT2dV*dVdT + d3AdTdV2*dVdT*dVdT + d2AdTdV*d2VdT2;
}

static double coder_d3gdt2dp(double T, double P) {
    coder_solve_V(T, P);
    double d3AdT2dV = coder_d3adt2dv(T, V);
    double d3AdTdV2 = coder_d3adtdv2(T, V);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double dVdT = -d2AdTdV/d2AdV2;
    double dVdP = -1.0/d2AdV2;
    double d2VdTdP = (-d3AdTdV2*dVdP - d3AdV3*dVdT*dVdP)/d2AdV2;
    return d3AdT2dV*dVdP + d3AdTdV2*dVdT*dVdP + d2AdTdV*d2VdTdP;
}

static double coder_d3gdtdp2(double T, double P) {
    coder_solve_V(T, P);
    double d3AdTdV2 = coder_d3adtdv2(T, V);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double dVdT = -d2AdTdV/d2AdV2;
    return (d3AdTdV2 + d3AdV3*dVdT)/d2AdV2/d2AdV2;
}

static double coder_d3gdp3(double T, double P) {
    coder_solve_V(T, P);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdV2 = coder_d2adv2(T, V);
    double dVdP = -1.0/d2AdV2;
    return d3AdV3*dVdP/d2AdV2/d2AdV2;
}

static double coder_s(double T, double P) {
    double result = -coder_dgdt(T, P);
    return result;
}

static double coder_dsdt(double T, double P) {
    double result = -coder_d2gdt2(T, P);
    return result;
}

static double coder_dsdp(double T, double P) {
    double result = -coder_d2gdtdp(T, P);
    return result;
}

static double coder_v(double T, double P) {
    double result = coder_dgdp(T, P);
    return result;
}

static double coder_cv(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    double dvdt = coder_d2gdtdp(T, P);
    double dvdp = coder_d2gdp2(T, P);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    return result;
}

static double coder_dcpdt(double T, double P) {
    double result = -T*coder_d3gdt3(T, P) - coder_d2gdt2(T, P);
    return result;
}

static double coder_dcpdp(double T, double P) {
    double result = -T*coder_d3gdt2dp(T, P);
    return result;
}

static double coder_alpha(double T, double P) {
    double result = coder_d2gdtdp(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_dalphadt(double T, double P) {
    double dgdp = coder_dgdp(T, P);
    double d2gdtdp = coder_d2gdtdp(T, P);
    double result = coder_d3gdt2dp(T, P)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P) {
    double dgdp = coder_dgdp(T, P);
    double result = coder_d3gdtdp2(T, P)/dgdp - coder_d2gdp2(T, P)*coder_d2gdtdp(T, P)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P) {
    double result = -coder_d2gdp2(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_K(double T, double P) {
    double result = -coder_dgdp(T, P)/coder_d2gdp2(T, P);
    return result;
}

static double coder_Kp(double T, double P) {
    double result = coder_dgdp(T, P);
    result *= coder_d3gdp3(T, P);
    result /= pow(coder_d2gdp2(T, P), 2.0);
    return result - 1.0;
}


#include <math.h>

static double coder_dparam_a(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dadt(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dadv(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2adt2(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2adtdv(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2adv2(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3adt3(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3adt2dv(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3adtdv2(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3adv3(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}


static double coder_dparam_g(double T, double P, int index) {
    coder_solve_V(T, P);
    double dAdz = coder_dparam_a(T, V, index);
    return dAdz + P*V;
}

static double coder_dparam_dgdt(double T, double P, int index) {
    coder_solve_V(T, P);
    double dAdTdz = coder_dparam_dadt(T, V, index);
    return dAdTdz;
}

static double coder_dparam_dgdp(double T, double P, int index) {
    coder_solve_V(T, P);
    return 0.0; /* V; */
}

static double coder_dparam_d2gdt2(double T, double P, int index) {
    coder_solve_V(T, P);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double d2AdT2dz = coder_dparam_d2adt2(T, V, index);
    double d2AdTdVdz = coder_dparam_d2adtdv(T, V, index);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    /* return d2AdT2 - d2AdTdV*d2AdTdV/d2AdV2; */
    return d2AdT2dz - 2.0*d2AdTdV*d2AdTdVdz/d2AdV2 + d2AdTdV*d2AdTdV*d2AdV2dz/d2AdV2/d2AdV2;
}

static double coder_dparam_d2gdtdp(double T, double P, int index) {
    coder_solve_V(T, P);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double d2AdTdVdz = coder_dparam_d2adtdv(T, V, index);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    /* return - d2AdTdV/d2AdV2; */
    return - d2AdTdVdz/d2AdV2 + d2AdTdV*d2AdV2dz/d2AdV2/d2AdV2;
}

static double coder_dparam_d2gdp2(double T, double P, int index) {
    coder_solve_V(T, P);
    double d2AdV2 = coder_d2adv2(T, V);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    /* return - 1.0/d2AdV2; */
    return d2AdV2dz/d2AdV2/d2AdV2;
}

static double coder_dparam_d3gdt3(double T, double P, int index) {
    coder_solve_V(T, P);
    double d3AdT2dV = coder_d3adt2dv(T, V);
    double d3AdTdV2 = coder_d3adtdv2(T, V);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double d3AdT3dz = coder_dparam_d3adt3(T, V, index);
    double d3AdT2dVdz = coder_dparam_d3adt2dv(T, V, index);
    double d3AdTdV2dz = coder_dparam_d3adtdv2(T, V, index);
    double d3AdV3dz = coder_dparam_d3adv3(T, V, index);
    double d2AdTdVdz = coder_dparam_d2adtdv(T, V, index);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    double dVdT = - d2AdTdV/d2AdV2;
    double dVdTdz = - d2AdTdVdz/d2AdV2 + d2AdTdV*d2AdV2dz/d2AdV2/d2AdV2;
    double d2VdT2 = (-d3AdT2dV - 2.0*d3AdTdV2*dVdT - d3AdV3*dVdT*dVdT)/d2AdV2;
    double d2VdT2dz = (-d3AdT2dVdz - 2.0*d3AdTdV2dz*dVdT - 2.0*d3AdTdV2*dVdTdz
                        - d3AdV3dz*dVdT*dVdT - 2.0*d3AdV3*dVdT*dVdTdz)/d2AdV2
                    - (-d3AdT2dV - 2.0*d3AdTdV2*dVdT - d3AdV3*dVdT*dVdT)*d2AdV2dz/d2AdV2/d2AdV2;
    /* return d3AdT3 + 2.0*d3AdT2dV*dVdT + d3AdTdV2*dVdT*dVdT + d2AdTdV*d2VdT2; */
    return d3AdT3dz + 2.0*d3AdT2dVdz*dVdT + 2.0*d3AdT2dV*dVdTdz + d3AdTdV2dz*dVdT*dVdT
            + 2.0*d3AdTdV2*dVdT*dVdTdz + d2AdTdVdz*d2VdT2 + d2AdTdV*d2VdT2dz;
}

static double coder_dparam_d3gdt2dp(double T, double P, int index) {
    coder_solve_V(T, P);
    double d3AdT2dV = coder_d3adt2dv(T, V);
    double d3AdTdV2 = coder_d3adtdv2(T, V);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double d3AdT2dVdz = coder_dparam_d3adt2dv(T, V, index);
    double d3AdTdV2dz = coder_dparam_d3adtdv2(T, V, index);
    double d3AdV3dz = coder_dparam_d3adv3(T,V, index);
    double d2AdTdVdz = coder_dparam_d2adtdv(T, V, index);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    double dVdT = -d2AdTdV/d2AdV2;
    double dVdTdz = - d2AdTdVdz/d2AdV2 + d2AdTdV*d2AdV2dz/d2AdV2/d2AdV2;
    double dVdP = -1.0/d2AdV2;
    double dVdPdz = d2AdV2dz/d2AdV2/d2AdV2;
    double d2VdTdP = (-d3AdTdV2*dVdP - d3AdV3*dVdT*dVdP)/d2AdV2;
    double d2VdTdPdz = (-d3AdTdV2dz*dVdP -d3AdTdV2*dVdPdz
            - d3AdV3dz*dVdT*dVdP - d3AdV3*dVdTdz*dVdP - d3AdV3*dVdT*dVdPdz)/d2AdV2
            - (-d3AdTdV2*dVdP - d3AdV3*dVdT*dVdP)*d2AdV2dz/d2AdV2/d2AdV2;
    /* return d3AdT2dV*dVdP + d3AdTdV2*dVdT*dVdP + d2AdTdV*d2VdTdP; */
    return d3AdT2dVdz*dVdP + d3AdT2dV*dVdPdz + d3AdTdV2dz*dVdT*dVdP + d3AdTdV2*dVdTdz*dVdP
        + d3AdTdV2*dVdT*dVdPdz + d2AdTdVdz*d2VdTdP + d2AdTdV*d2VdTdPdz;
}

static double coder_dparam_d3gdtdp2(double T, double P, int index) {
    coder_solve_V(T, P);
    double d3AdTdV2 = coder_d3adtdv2(T, V);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double d3AdTdV2dz = coder_dparam_d3adtdv2(T, V, index);
    double d3AdV3dz = coder_dparam_d3adv3(T, V, index);
    double d2AdTdVdz = coder_dparam_d2adtdv(T, V, index);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    double dVdT = -d2AdTdV/d2AdV2;
    double dVdTdz = - d2AdTdVdz/d2AdV2 + d2AdTdV*d2AdV2dz/d2AdV2/d2AdV2;
    /* return (d3AdTdV2 + d3AdV3*dVdT)/d2AdV2/d2AdV2; */
    return (d3AdTdV2dz + d3AdV3dz*dVdT + d3AdV3*dVdTdz)/d2AdV2/d2AdV2
        - 2.0*(d3AdTdV2 + d3AdV3*dVdT)*d2AdV2dz/d2AdV2/d2AdV2/d2AdV2;
}

static double coder_dparam_d3gdp3(double T, double P, int index) {
    coder_solve_V(T, P);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdV2 = coder_d2adv2(T, V);
    double d3AdV3dz = coder_dparam_d3adv3(T, V, index);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    double dVdP = -1.0/d2AdV2;
    double dVdPdz = d2AdV2dz/d2AdV2/d2AdV2;
    /* return d3AdV3*dVdP/d2AdV2/d2AdV2; */
    return d3AdV3dz*dVdP/d2AdV2/d2AdV2 + d3AdV3*dVdPdz/d2AdV2/d2AdV2
        - 2.0*d3AdV3*dVdP*d2AdV2dz/d2AdV2/d2AdV2/d2AdV2;
}

static int coder_get_param_number(void) {
    return 0;
}

static const char *paramNames[0] = {  };

static const char *paramUnits[0] = {  };

static const char **coder_get_param_names(void) {
    return paramNames;
}

static const char **coder_get_param_units(void) {
    return paramUnits;
}

static void coder_get_param_values(double **values) {
}

static int coder_set_param_values(double *values) {
    return 1;
}

static double coder_get_param_value(int index) {
    double result = 0.0;
    switch (index) {
     default:
         break;
    }
    return result;
}

static int coder_set_param_value(int index, double value) {
    int result = 1;
    switch (index) {
     default:
         break;
    }
    return result;
}



const char *MgSpinel_slb21_em_coder_calib_identifier(void) {
    return identifier;
}

const char *MgSpinel_slb21_em_coder_calib_name(void) {
    return "MgSpinel_slb21_em";
}

const char *MgSpinel_slb21_em_coder_calib_formula(void) {
    return "Mg4Al8O16";
}

const double MgSpinel_slb21_em_coder_calib_mw(void) {
    return 569.06272;
}

static const double elmformula[106] = {
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,16.0,0.0,0.0,0.0,
        4.0,8.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0
    };

const double *MgSpinel_slb21_em_coder_calib_elements(void) {
    return elmformula;
}

double MgSpinel_slb21_em_coder_calib_g(double T, double P) {
    return coder_g(T, P);
}

double MgSpinel_slb21_em_coder_calib_dgdt(double T, double P) {
    return coder_dgdt(T, P);
}

double MgSpinel_slb21_em_coder_calib_dgdp(double T, double P) {
    return coder_dgdp(T, P);
}

double MgSpinel_slb21_em_coder_calib_d2gdt2(double T, double P) {
    return coder_d2gdt2(T, P);
}

double MgSpinel_slb21_em_coder_calib_d2gdtdp(double T, double P) {
    return coder_d2gdtdp(T, P);
}

double MgSpinel_slb21_em_coder_calib_d2gdp2(double T, double P) {
    return coder_d2gdp2(T, P);
}

double MgSpinel_slb21_em_coder_calib_d3gdt3(double T, double P) {
    return coder_d3gdt3(T, P);
}

double MgSpinel_slb21_em_coder_calib_d3gdt2dp(double T, double P) {
    return coder_d3gdt2dp(T, P);
}

double MgSpinel_slb21_em_coder_calib_d3gdtdp2(double T, double P) {
    return coder_d3gdtdp2(T, P);
}

double MgSpinel_slb21_em_coder_calib_d3gdp3(double T, double P) {
    return coder_d3gdp3(T, P);
}

double MgSpinel_slb21_em_coder_calib_s(double T, double P) {
    return coder_s(T, P);
}

double MgSpinel_slb21_em_coder_calib_dsdt(double T, double P) {
    return coder_dsdt(T, P);
}

double MgSpinel_slb21_em_coder_calib_dsdp(double T, double P) {
    return coder_dsdp(T, P);
}

double MgSpinel_slb21_em_coder_calib_v(double T, double P) {
    return coder_v(T, P);
}

double MgSpinel_slb21_em_coder_calib_cv(double T, double P) {
    return coder_cv(T, P);
}

double MgSpinel_slb21_em_coder_calib_cp(double T, double P) {
    return coder_cp(T, P);
}

double MgSpinel_slb21_em_coder_calib_dcpdt(double T, double P) {
    return coder_dcpdt(T, P);
}

double MgSpinel_slb21_em_coder_calib_dcpdp(double T, double P) {
    return coder_dcpdp(T, P);
}

double MgSpinel_slb21_em_coder_calib_alpha(double T, double P) {
    return coder_alpha(T, P);
}

double MgSpinel_slb21_em_coder_calib_dalphadt(double T, double P) {
    return coder_dalphadt(T, P);
}

double MgSpinel_slb21_em_coder_calib_dalphadp(double T, double P) {
    return coder_dalphadp(T, P);
}

double MgSpinel_slb21_em_coder_calib_beta(double T, double P) {
    return coder_beta(T, P);
}

double MgSpinel_slb21_em_coder_calib_K(double T, double P) {
    return coder_K(T, P);
}

double MgSpinel_slb21_em_coder_calib_Kp(double T, double P) {
    return coder_Kp(T, P);
}

int MgSpinel_slb21_em_coder_get_param_number(void) {
    return coder_get_param_number();
}

const char **MgSpinel_slb21_em_coder_get_param_names(void) {
    return coder_get_param_names();
}

const char **MgSpinel_slb21_em_coder_get_param_units(void) {
    return coder_get_param_units();
}

void MgSpinel_slb21_em_coder_get_param_values(double **values) {
    coder_get_param_values(values);
}

int MgSpinel_slb21_em_coder_set_param_values(double *values) {
    return coder_set_param_values(values);
}

double MgSpinel_slb21_em_coder_get_param_value(int index) {
    return coder_get_param_value(index);
}

int MgSpinel_slb21_em_coder_set_param_value(int index, double value) {
    return coder_set_param_value(index, value);
}

double MgSpinel_slb21_em_coder_dparam_g(double T, double P, int index) {
    return coder_dparam_g(T, P, index);
}

double MgSpinel_slb21_em_coder_dparam_dgdt(double T, double P, int index) {
    return coder_dparam_dgdt(T, P, index);
}

double MgSpinel_slb21_em_coder_dparam_dgdp(double T, double P, int index) {
    return coder_dparam_dgdp(T, P, index);
}

double MgSpinel_slb21_em_coder_dparam_d2gdt2(double T, double P, int index) {
    return coder_dparam_d2gdt2(T, P, index);
}

double MgSpinel_slb21_em_coder_dparam_d2gdtdp(double T, double P, int index) {
    return coder_dparam_d2gdtdp(T, P, index);
}

double MgSpinel_slb21_em_coder_dparam_d2gdp2(double T, double P, int index) {
    return coder_dparam_d2gdp2(T, P, index);
}

double MgSpinel_slb21_em_coder_dparam_d3gdt3(double T, double P, int index) {
    return coder_dparam_d3gdt3(T, P, index);
}

double MgSpinel_slb21_em_coder_dparam_d3gdt2dp(double T, double P, int index) {
    return coder_dparam_d3gdt2dp(T, P, index);
}

double MgSpinel_slb21_em_coder_dparam_d3gdtdp2(double T, double P, int index) {
    return coder_dparam_d3gdtdp2(T, P, index);
}

double MgSpinel_slb21_em_coder_dparam_d3gdp3(double T, double P, int index) {
    return coder_dparam_d3gdp3(T, P, index);
}

