#include <math.h>


static double coder_g(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n4 + n5;
    double x1 = n1 + n2 + n3;
    double x2 = x0 + x1;
    double x3 = 1.0/x2;
    double x4 = n1*(*endmember[0].mu0)(T, P);
    double x5 = n2*(*endmember[1].mu0)(T, P);
    double x6 = n3*(*endmember[2].mu0)(T, P);
    double x7 = n4*(*endmember[3].mu0)(T, P);
    double x8 = n5*(*endmember[4].mu0)(T, P);
    double x9 = 1.0*n4;
    double x10 = log(n5*x3);
    double x11 = T*(3.0*n2*log(n2*x3) + 3.0*n3*log(n3*x3) + 1.0*n5*x10 + 1.9999999980000001*n5*(x10 - 0.40546510910816402) + 1.0*x0*log(x0*x3) + 2.0*x1*log(x1*x3) + x9*log(n4*x3) + (3.0*n1 + 3.0*n4 + 0.99999999900000003*n5)*log(x3*(1.0*n1 + 0.33333333300000001*n5 + x9)));
    double x12 = 0.82399999999999995*P + 168800.0;
    double x13 = 181600.0*n4 + 183200.0*n5;
    double x14 = 0.0625*n1*(n3*x12 + x13) + 0.0625*n2*(168800.0*n3 + x13) + 0.0625*n3*(n1*x12 + 168800.0*n2 + 488000.0*n4 + 485600.0*n5) + 0.0625*n4*(181600.0*n1 + 181600.0*n2 + 488000.0*n3 + 568000.0*n5) + 0.0625*n5*(183200.0*n1 + 183200.0*n2 + 485600.0*n3 + 568000.0*n4);
    double x15 = fmin(4, 1.0*sqrt(1 - 0.13333333333333333*T));

if (T >= 7.5) {
   result = x3*(x14 + 1.0*x2*(-n2*(40.14405*T - 200.72024999999999) + 8.3144626181532395*x11 + x4 + x5 + x6 + x7 + x8));
}
else {
   result = x3*(x14 + 0.33333333333333331*x2*(n2*(301.080375*((x15)*(x15)*(x15)) + (120.43215000000001*T - 903.24112500000001)*(x15 - 1) - 301.080375) + 24.943387854459719*x11 + 3*x4 + 3*x5 + 3*x6 + 3*x7 + 3*x8));
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n4 + n5;
    double x1 = n1 + n2 + n3;
    double x2 = x0 + x1;
    double x3 = pow(x2, -2);
    double x4 = (*endmember[0].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[1].mu0)(T, P);
    double x7 = n2*x6;
    double x8 = (*endmember[2].mu0)(T, P);
    double x9 = n3*x8;
    double x10 = (*endmember[3].mu0)(T, P);
    double x11 = n4*x10;
    double x12 = (*endmember[4].mu0)(T, P);
    double x13 = n5*x12;
    double x14 = 40.14405*T;
    double x15 = n2*(x14 - 200.72024999999999);
    double x16 = 1.0/x2;
    double x17 = n2*x16;
    double x18 = log(x17);
    double x19 = n3*x16;
    double x20 = log(x19);
    double x21 = log(n4*x16);
    double x22 = 1.0*n4;
    double x23 = n5*x16;
    double x24 = log(x23);
    double x25 = 1.0*log(x0*x16);
    double x26 = x1*x16;
    double x27 = log(x26);
    double x28 = 3.0*n1 + 3.0*n4 + 0.99999999900000003*n5;
    double x29 = 1.0*n1;
    double x30 = 0.33333333300000001*n5 + x22 + x29;
    double x31 = log(x16*x30);
    double x32 = 3.0*n2*x18 + 3.0*n3*x20 + 1.0*n5*x24 + 1.9999999980000001*n5*(x24 - 0.40546510910816402) + x0*x25 + 2.0*x1*x27 + x21*x22 + x28*x31;
    double x33 = 8.3144626181532395*T;
    double x34 = x32*x33;
    double x35 = 1.0*x2;
    double x36 = 0.10299999999999999*P + 21100.0;
    double x37 = n3*x36;
    double x38 = 181600.0*n4 + 183200.0*n5;
    double x39 = 0.0625*n1;
    double x40 = n1*x36;
    double x41 = 0.0625*n3;
    double x42 = 0.0625*n2*(168800.0*n3 + x38) + 0.0625*n4*(181600.0*n1 + 181600.0*n2 + 488000.0*n3 + 568000.0*n5) + 0.0625*n5*(183200.0*n1 + 183200.0*n2 + 485600.0*n3 + 568000.0*n4) + x39*(8.0*x37 + x38) + x41*(168800.0*n2 + 488000.0*n4 + 485600.0*n5 + 8.0*x40);
    double x43 = -x3*(x35*(x11 + x13 - x15 + x34 + x5 + x7 + x9) + x42);
    double x44 = 3.0*x17;
    double x45 = 1.0/x30;
    double x46 = x3*x30;
    double x47 = 1.0*x16 - x46;
    double x48 = -2.0*x27;
    double x49 = x16*x22;
    double x50 = 1.0*x0*x16;
    double x51 = 3.0*x19;
    double x52 = 2.9999999979999998*x23;
    double x53 = -x16;
    double x54 = -2.0*x2*(-x1*x3 - x53);
    double x55 = x48 + x49 + x50 + x51 + x52 + x54;
    double x56 = x2*x28*x45*x47 + 3.0*x31 - x44 - x55;
    double x57 = x10*x22 + 1.0*x13 + x29*x4 + x34 + 1.0*x7 + 1.0*x9;
    double x58 = -1.0*x15 + x57;
    double x59 = 0.82399999999999995*P + 168800.0;
    double x60 = 22700.0*n4 + 22900.0*n5;
    double x61 = 0.5*x37 + x41*x59 + x60;
    double x62 = T >= 7.5;
    double x63 = fmin(4, 1.0*sqrt(1 - 0.13333333333333333*T));
    double x64 = 301.080375*((x63)*(x63)*(x63)) + (120.43215000000001*T - 903.24112500000001)*(x63 - 1) - 301.080375;
    double x65 = n2*x64;
    double x66 = 24.943387854459719*T;
    double x67 = 0.33333333333333331*x2;
    double x68 = -x3*(x42 + x67*(3*x11 + 3*x13 + x32*x66 + 3*x5 + x65 + 3*x7 + 3*x9));
    double x69 = x57 + 0.33333333333333331*x65;
    double x70 = x16*x28;
    double x71 = 3.0*x18 + 3.0*x2*(-n2*x3 - x53) - x55 - x70;
    double x72 = 21100.0*n3 + x60;
    double x73 = 3.0*x2*(-n3*x3 - x53) + 3.0*x20 - x44 - x48 - x49 - x50 - x52 - x54 - x70;
    double x74 = 21100.0*n2 + 61000.0*n4 + 60700.0*n5 + x39*x59 + 0.5*x40;
    double x75 = x2*x28*x45;
    double x76 = x25 - 2.0*x26 + x35*(-x0*x3 - x53) - x44 - x51;
    double x77 = 1.0*x21 + 3.0*x31 + x35*(-n4*x3 - x53) + x47*x75 - x52 + x76;
    double x78 = 22700.0*n1 + 22700.0*n2 + 61000.0*n3 + 71000.0*n5;
    double x79 = 2.9999999979999998*x2*(-n5*x3 - x53) + 2.9999999979999998*x24 + 0.99999999900000003*x31 - x49 + x75*(0.33333333300000001*x16 - x46) + x76 - 0.81093021740539784;
    double x80 = 22900.0*n1 + 22900.0*n2 + 60700.0*n3 + 71000.0*n4;

if (x62) {
   result[0] = x16*(x35*(x33*x56 + x4) + x58 + x61) + x43;
}
else {
   result[0] = x16*(x61 + x67*(3*x4 + x56*x66) + x69) + x68;
}
if (x62) {
   result[1] = x16*(x35*(-x14 + x33*x71 + x6 + 200.72024999999999) + x58 + x72) + x43;
}
else {
   result[1] = x16*(x67*(3*x6 + x64 + x66*x71) + x69 + x72) + x68;
}
if (x62) {
   result[2] = x16*(x35*(x33*x73 + x8) + x58 + x74) + x43;
}
else {
   result[2] = x16*(x67*(x66*x73 + 3*x8) + x69 + x74) + x68;
}
if (x62) {
   result[3] = x16*(x35*(x10 + x33*x77) + x58 + x78) + x43;
}
else {
   result[3] = x16*(x67*(3*x10 + x66*x77) + x69 + x78) + x68;
}
if (x62) {
   result[4] = x16*(x35*(x12 + x33*x79) + x58 + x80) + x43;
}
else {
   result[4] = x16*(x67*(3*x12 + x66*x79) + x69 + x80) + x68;
}
}
        
static void coder_d2gdn2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n3*x4;
    double x6 = (*endmember[3].mu0)(T, P);
    double x7 = n4*x6;
    double x8 = (*endmember[4].mu0)(T, P);
    double x9 = n5*x8;
    double x10 = 40.14405*T;
    double x11 = n2*(x10 - 200.72024999999999);
    double x12 = n4 + n5;
    double x13 = n1 + n2 + n3;
    double x14 = x12 + x13;
    double x15 = 1.0/x14;
    double x16 = n2*x15;
    double x17 = log(x16);
    double x18 = n3*x15;
    double x19 = log(x18);
    double x20 = log(n4*x15);
    double x21 = 1.0*n4;
    double x22 = n5*x15;
    double x23 = log(x22);
    double x24 = 1.0*log(x12*x15);
    double x25 = x13*x15;
    double x26 = log(x25);
    double x27 = 3.0*n1 + 3.0*n4 + 0.99999999900000003*n5;
    double x28 = 1.0*n1;
    double x29 = 0.33333333300000001*n5 + x21 + x28;
    double x30 = log(x15*x29);
    double x31 = T*(3.0*n2*x17 + 3.0*n3*x19 + 1.0*n5*x23 + 1.9999999980000001*n5*(x23 - 0.40546510910816402) + x12*x24 + 2.0*x13*x26 + x20*x21 + x27*x30);
    double x32 = 8.3144626181532395*x31;
    double x33 = 1.0*x14;
    double x34 = 0.10299999999999999*P + 21100.0;
    double x35 = n3*x34;
    double x36 = 181600.0*n4 + 183200.0*n5;
    double x37 = 0.0625*n1;
    double x38 = n1*x34;
    double x39 = 0.0625*n3;
    double x40 = 0.0625*n2*(168800.0*n3 + x36) + 0.0625*n4*(181600.0*n1 + 181600.0*n2 + 488000.0*n3 + 568000.0*n5) + 0.0625*n5*(183200.0*n1 + 183200.0*n2 + 485600.0*n3 + 568000.0*n4) + x37*(8.0*x35 + x36) + x39*(168800.0*n2 + 488000.0*n4 + 485600.0*n5 + 8.0*x38);
    double x41 = 2/((x14)*(x14)*(x14));
    double x42 = x41*(x33*(x1 - x11 + x3 + x32 + x5 + x7 + x9) + x40);
    double x43 = 3.0*x16;
    double x44 = 1.0/x29;
    double x45 = 1.0*x15;
    double x46 = -x45;
    double x47 = pow(x14, -2);
    double x48 = x29*x47;
    double x49 = -x46 - x48;
    double x50 = -2.0*x26;
    double x51 = x15*x21;
    double x52 = x12*x45;
    double x53 = 3.0*x18;
    double x54 = 2.9999999979999998*x22;
    double x55 = -x15;
    double x56 = x13*x47;
    double x57 = -x55 - x56;
    double x58 = -2.0*x14*x57;
    double x59 = x50 + x51 + x52 + x53 + x54 + x58;
    double x60 = T*(x14*x27*x44*x49 + 3.0*x30 - x43 - x59);
    double x61 = 8.3144626181532395*x60;
    double x62 = x0*x28 + x21*x6 + 1.0*x3 + x32 + 1.0*x5 + 1.0*x9;
    double x63 = -1.0*x11 + x62;
    double x64 = 0.82399999999999995*P + 168800.0;
    double x65 = 22700.0*n4 + 22900.0*n5;
    double x66 = 0.5*x35 + x39*x64 + x65;
    double x67 = x33*(x0 + x61) + x63 + x66;
    double x68 = 2*x47;
    double x69 = -x68;
    double x70 = x13*x41;
    double x71 = 2.0*x14;
    double x72 = x71*(x69 + x70) + x57*x71/x13;
    double x73 = x21*x47;
    double x74 = 1.0*x47;
    double x75 = x12*x74;
    double x76 = 2.0*x56;
    double x77 = -x76;
    double x78 = n3*x47;
    double x79 = 3.0*x78;
    double x80 = n5*x47;
    double x81 = 2.9999999979999998*x80;
    double x82 = x79 + x81;
    double x83 = x73 + x75 + x77 + x82;
    double x84 = n2*x47;
    double x85 = 3.0*x84;
    double x86 = x27*x44;
    double x87 = x49*x86;
    double x88 = x85 + x87;
    double x89 = x83 + x88;
    double x90 = x72 + x89;
    double x91 = 2.0*x15;
    double x92 = x14*x44;
    double x93 = x49*x92;
    double x94 = x29*x41;
    double x95 = x14*x86;
    double x96 = x27/((x29)*(x29));
    double x97 = x49*x96;
    double x98 = -x33*x97 + 6.0*x93 + x95*(-2.0*x47 + x94);
    double x99 = x91 + x98;
    double x100 = 8.3144626181532395*T*x14;
    double x101 = x15*(2.0*x0 + x100*(x90 + x99) + 16.628925236306479*x60);
    double x102 = T >= 7.5;
    double x103 = fmin(4, 1.0*sqrt(1 - 0.13333333333333333*T));
    double x104 = ((x103)*(x103)*(x103));
    double x105 = (120.43215000000001*T - 903.24112500000001)*(x103 - 1);
    double x106 = 301.080375*x104 + x105 - 301.080375;
    double x107 = n2*x106;
    double x108 = 0.33333333333333331*x14;
    double x109 = x41*(x108*(3*x1 + x107 + 3*x3 + 24.943387854459719*x31 + 3*x5 + 3*x7 + 3*x9) + x40);
    double x110 = 0.33333333333333331*x107 + x62;
    double x111 = x108*(3*x0 + 24.943387854459719*x60) + x110 + x66;
    double x112 = x15*x27;
    double x113 = -x55 - x84;
    double x114 = T*(-x112 + 3.0*x113*x14 + 3.0*x17 - x59);
    double x115 = 8.3144626181532395*x114;
    double x116 = -x10 + x115;
    double x117 = x116 + 200.72024999999999;
    double x118 = 1.0*x2;
    double x119 = 1.0*x0 + x61;
    double x120 = x100*(-4.0*x15 + x90 + x95*(-x74 + x94)) + x119;
    double x121 = x118 + x120;
    double x122 = 21100.0*n3 + x65;
    double x123 = x122 + x33*(x117 + x2) + x63;
    double x124 = -x123*x47;
    double x125 = x42 - x47*x67;
    double x126 = 100.360125*x104 + 0.33333333333333331*x105 + x115;
    double x127 = x108*(x106 + 24.943387854459719*x114 + 3*x2) + x110 + x122;
    double x128 = -x127*x47;
    double x129 = x109 - x111*x47;
    double x130 = -x55 - x78;
    double x131 = T*(-x112 + 3.0*x130*x14 + 3.0*x19 - x43 - x50 - x51 - x52 - x54 - x58);
    double x132 = 8.3144626181532395*x131;
    double x133 = x132 + 1.0*x4;
    double x134 = x15*(x120 + x133 + x34);
    double x135 = 21100.0*n2 + 61000.0*n4 + 60700.0*n5 + x37*x64 + 0.5*x38;
    double x136 = x135 + x33*(x132 + x4) + x63;
    double x137 = -x136*x47;
    double x138 = x108*(24.943387854459719*x131 + 3*x4) + x110 + x135;
    double x139 = -x138*x47;
    double x140 = -x47;
    double x141 = x71*(x140 + x70);
    double x142 = x141 + x89;
    double x143 = x33*(-n4*x47 - x55);
    double x144 = x33*(-x12*x47 - x55);
    double x145 = x144 + x24 - 2.0*x25 - x43 - x53;
    double x146 = T*(x14*x87 + x143 + x145 + 1.0*x20 + 3.0*x30 - x54);
    double x147 = 8.3144626181532395*x146;
    double x148 = x147 + 1.0*x6;
    double x149 = x15*(x100*(x142 - x91 + x98) + x119 + x148 + 22700.0);
    double x150 = 22700.0*n1 + 22700.0*n2 + 61000.0*n3 + 71000.0*n5;
    double x151 = x150 + x33*(x147 + x6) + x63;
    double x152 = -x151*x47;
    double x153 = x108*(24.943387854459719*x146 + 3*x6) + x110 + x150;
    double x154 = -x153*x47;
    double x155 = 3.9999999979999998*x15;
    double x156 = 0.33333333300000001*x15 - x48;
    double x157 = 3.0*x14;
    double x158 = 0.33333333300000001*x14;
    double x159 = x156*x157*x44 - x158*x97 + 0.99999999900000003*x93 + x95*(-1.3333333330000001*x47 + x94);
    double x160 = 2.9999999979999998*x14;
    double x161 = x160*(-x55 - x80);
    double x162 = x156*x86;
    double x163 = T*(x14*x162 + x145 + x161 + 2.9999999979999998*x23 + 0.99999999900000003*x30 - x51 - 0.81093021740539784);
    double x164 = 8.3144626181532395*x163;
    double x165 = x164 + 1.0*x8;
    double x166 = x15*(x100*(x142 - x155 + x159) + x119 + x165 + 22900.0);
    double x167 = 22900.0*n1 + 22900.0*n2 + 60700.0*n3 + 71000.0*n4;
    double x168 = x167 + x33*(x164 + x8) + x63;
    double x169 = -x168*x47;
    double x170 = x108*(24.943387854459719*x163 + 3*x8) + x110 + x167;
    double x171 = -x170*x47;
    double x172 = n2*x41;
    double x173 = x83 - x85;
    double x174 = 5.0*x15;
    double x175 = x27*x47;
    double x176 = x175 + x72;
    double x177 = x174 + x176;
    double x178 = x100*(x157*(x172 + x69) + x173 + x177 + x113*x157/n2) + 16.628925236306479*x114 + 2.0*x2;
    double x179 = x116 + x118;
    double x180 = x157*(x140 + x172) + x173;
    double x181 = x100*(x176 + x180 + x46) + x133;
    double x182 = x124 + x42;
    double x183 = x118 + x126;
    double x184 = x109 + x128;
    double x185 = x141 + x175;
    double x186 = -x174 + x185;
    double x187 = x100*(x180 + x186) + x148;
    double x188 = -4.9999999969999998*x15 + x185;
    double x189 = x100*(x180 + x188) + x165;
    double x190 = n3*x41;
    double x191 = x73 + x85;
    double x192 = x191 + x75 + x77 - x79 + x81;
    double x193 = x15*(x100*(x157*(x190 + x69) + x177 + x192 + x130*x157/n3) + 16.628925236306479*x131 + 2.0*x4);
    double x194 = x157*(x140 + x190) + x192;
    double x195 = x15*(x100*(x186 + x194) + x133 + x148 + 61000.0);
    double x196 = x137 + x42;
    double x197 = x109 + x139;
    double x198 = x15*(x100*(x188 + x194) + x133 + x165 + 60700.0);
    double x199 = n4*x41;
    double x200 = x33*(x12*x41 + x69) - x75 + x76 + x144/x12;
    double x201 = x200 - x73 + x82 + x88;
    double x202 = x15*(x100*(x201 + x33*(x199 + x69) + x99 + x143/n4) + 16.628925236306479*x146 + 2.0*x6);
    double x203 = x15*(x100*(-1.9999999979999998*x15 + x159 + x201 + x33*(x140 + x199)) + x148 + x165 + 71000.0);
    double x204 = x15*(x100*(x155 - x156*x158*x96 + 1.9999999980000001*x156*x92 + x160*(n5*x41 + x69) + x162 + x191 + x200 + x79 - x81 + x95*(-0.66666666600000002*x47 + x94) + x161/n5) + 16.628925236306479*x163 + 2.0*x8);

if (x102) {
   result[0] = x101 + x42 - x67*x68;
}
else {
   result[0] = x101 + x109 - x111*x68;
}
if (x102) {
   result[1] = x124 + x125 + x15*(x117 + x121);
}
else {
   result[1] = x128 + x129 + x15*(x121 + x126 - 100.360125);
}
if (x102) {
   result[2] = x125 + x134 + x137;
}
else {
   result[2] = x129 + x134 + x139;
}
if (x102) {
   result[3] = x125 + x149 + x152;
}
else {
   result[3] = x129 + x149 + x154;
}
if (x102) {
   result[4] = x125 + x166 + x169;
}
else {
   result[4] = x129 + x166 + x171;
}
if (x102) {
   result[5] = -x123*x68 + x15*(-80.2881*T + x178 + 401.44049999999999) + x42;
}
else {
   result[5] = x109 - x127*x68 + x15*(200.72024999999999*x104 + 0.66666666666666663*x105 + x178 - 200.72024999999999);
}
if (x102) {
   result[6] = x137 + x15*(x179 + x181 + 21300.720249999998) + x182;
}
else {
   result[6] = x139 + x15*(x181 + x183 + 20999.639875000001) + x184;
}
if (x102) {
   result[7] = x15*(x179 + x187 + 22900.720249999998) + x152 + x182;
}
else {
   result[7] = x15*(x183 + x187 + 22599.639875000001) + x154 + x184;
}
if (x102) {
   result[8] = x15*(x179 + x189 + 23100.720249999998) + x169 + x182;
}
else {
   result[8] = x15*(x183 + x189 + 22799.639875000001) + x171 + x184;
}
if (x102) {
   result[9] = -x136*x68 + x193 + x42;
}
else {
   result[9] = x109 - x138*x68 + x193;
}
if (x102) {
   result[10] = x152 + x195 + x196;
}
else {
   result[10] = x154 + x195 + x197;
}
if (x102) {
   result[11] = x169 + x196 + x198;
}
else {
   result[11] = x171 + x197 + x198;
}
if (x102) {
   result[12] = -x151*x68 + x202 + x42;
}
else {
   result[12] = x109 - x153*x68 + x202;
}
if (x102) {
   result[13] = x152 + x169 + x203 + x42;
}
else {
   result[13] = x109 + x154 + x171 + x203;
}
if (x102) {
   result[14] = -x168*x68 + x204 + x42;
}
else {
   result[14] = x109 - x170*x68 + x204;
}
}
        
static void coder_d3gdn3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n3*x4;
    double x6 = (*endmember[3].mu0)(T, P);
    double x7 = n4*x6;
    double x8 = (*endmember[4].mu0)(T, P);
    double x9 = n5*x8;
    double x10 = 40.14405*T;
    double x11 = n2*(x10 - 200.72024999999999);
    double x12 = n4 + n5;
    double x13 = n1 + n2 + n3;
    double x14 = x12 + x13;
    double x15 = 1.0/x14;
    double x16 = n2*x15;
    double x17 = log(x16);
    double x18 = n3*x15;
    double x19 = log(x18);
    double x20 = log(n4*x15);
    double x21 = 1.0*n4;
    double x22 = n5*x15;
    double x23 = log(x22);
    double x24 = 1.0*log(x12*x15);
    double x25 = log(x13*x15);
    double x26 = 3.0*n1 + 3.0*n4 + 0.99999999900000003*n5;
    double x27 = 1.0*n1;
    double x28 = 0.33333333300000001*n5 + x21 + x27;
    double x29 = log(x15*x28);
    double x30 = 3.0*n2*x17 + 3.0*n3*x19 + 1.0*n5*x23 + 1.9999999980000001*n5*(x23 - 0.40546510910816402) + x12*x24 + 2.0*x13*x25 + x20*x21 + x26*x29;
    double x31 = 8.3144626181532395*T;
    double x32 = x30*x31;
    double x33 = 1.0*x14;
    double x34 = 0.10299999999999999*P + 21100.0;
    double x35 = 8.0*x34;
    double x36 = 181600.0*n4 + 183200.0*n5;
    double x37 = 0.0625*n1;
    double x38 = 0.0625*n3;
    double x39 = 0.0625*n2*(168800.0*n3 + x36) + 0.0625*n4*(181600.0*n1 + 181600.0*n2 + 488000.0*n3 + 568000.0*n5) + 0.0625*n5*(183200.0*n1 + 183200.0*n2 + 485600.0*n3 + 568000.0*n4) + x37*(n3*x35 + x36) + x38*(n1*x35 + 168800.0*n2 + 488000.0*n4 + 485600.0*n5);
    double x40 = 6/((x14)*(x14)*(x14)*(x14));
    double x41 = x40*(x33*(x1 - x11 + x3 + x32 + x5 + x7 + x9) + x39);
    double x42 = -x41;
    double x43 = 3.0*x16;
    double x44 = 1.0/x28;
    double x45 = 1.0*x15;
    double x46 = -x45;
    double x47 = pow(x14, -2);
    double x48 = x28*x47;
    double x49 = -x46 - x48;
    double x50 = -2.0*x25;
    double x51 = x15*x21;
    double x52 = x12*x45;
    double x53 = 3.0*x18;
    double x54 = 2.9999999979999998*x22;
    double x55 = -x15;
    double x56 = x13*x47;
    double x57 = -x55 - x56;
    double x58 = -2.0*x14*x57;
    double x59 = x50 + x51 + x52 + x53 + x54 + x58;
    double x60 = x14*x26*x44*x49 + 3.0*x29 - x43 - x59;
    double x61 = x31*x60;
    double x62 = x0*x27 + x21*x6 + 1.0*x3 + x32 + 1.0*x5 + 1.0*x9;
    double x63 = -1.0*x11 + x62;
    double x64 = 0.82399999999999995*P + 168800.0;
    double x65 = 0.5*x34;
    double x66 = 22700.0*n4 + 22900.0*n5;
    double x67 = n3*x65 + x38*x64 + x66;
    double x68 = x33*(x0 + x61) + x63 + x67;
    double x69 = pow(x14, -3);
    double x70 = 6*x69;
    double x71 = 2*x47;
    double x72 = -x71;
    double x73 = 2*x69;
    double x74 = x13*x73;
    double x75 = x72 + x74;
    double x76 = 2.0*x14;
    double x77 = x75*x76;
    double x78 = 1.0/x13;
    double x79 = x57*x78;
    double x80 = x76*x79 + x77;
    double x81 = x21*x47;
    double x82 = 1.0*x47;
    double x83 = x12*x82;
    double x84 = 2.0*x56;
    double x85 = -x84;
    double x86 = n3*x47;
    double x87 = 3.0*x86;
    double x88 = n5*x47;
    double x89 = 2.9999999979999998*x88;
    double x90 = x87 + x89;
    double x91 = x81 + x83 + x85 + x90;
    double x92 = n2*x47;
    double x93 = 3.0*x92;
    double x94 = x44*x49;
    double x95 = x26*x94;
    double x96 = x93 + x95;
    double x97 = x91 + x96;
    double x98 = x80 + x97;
    double x99 = 2.0*x15;
    double x100 = 2.0*x47;
    double x101 = -x100;
    double x102 = x28*x73;
    double x103 = x101 + x102;
    double x104 = x26*x44;
    double x105 = x103*x104;
    double x106 = pow(x28, -2);
    double x107 = x106*x49;
    double x108 = x107*x26;
    double x109 = x105*x14 - x108*x33 + 6.0*x14*x94;
    double x110 = x109 + x99;
    double x111 = x110 + x98;
    double x112 = 24.943387854459719*T;
    double x113 = 8.0*x47;
    double x114 = 6.0*x69;
    double x115 = n3*x114;
    double x116 = -2.0*x57*x78;
    double x117 = x115 + x116;
    double x118 = -6*x69;
    double x119 = x13*x40;
    double x120 = -x118 - x119;
    double x121 = x57*x76/((x13)*(x13));
    double x122 = -2.0*x120*x14 + x121 - 2.0*x14*x75*x78;
    double x123 = x117 + x122;
    double x124 = n2*x114;
    double x125 = 2.0*x108;
    double x126 = 9.0*x14;
    double x127 = x107*x126;
    double x128 = x28*x40;
    double x129 = -x128 + 6.0*x69;
    double x130 = x26*x76;
    double x131 = x103*x106;
    double x132 = x130*x131;
    double x133 = pow(x28, -3);
    double x134 = 2.0*x69;
    double x135 = n4*x134;
    double x136 = x12*x134;
    double x137 = n5*x69;
    double x138 = 5.9999999959999997*x137;
    double x139 = -8.0*x13*x69;
    double x140 = x135 + x136 + x138 + x139;
    double x141 = -9.0*x103*x14*x44 - 2*x103*x26*x44 + x125 + x127 - x129*x14*x26*x44 + x132 - 2.0*x133*x14*x26*x49 + x140 - 9.0*x44*x49;
    double x142 = x124 + x141;
    double x143 = x14*x31;
    double x144 = 16.628925236306479*T;
    double x145 = x111*x31;
    double x146 = x47*(2.0*x0 + x14*x145 + x144*x60);
    double x147 = -3*x146 + x15*(x111*x112 + x143*(-x113 - x123 - x142));
    double x148 = T >= 7.5;
    double x149 = fmin(4, 1.0*sqrt(1 - 0.13333333333333333*T));
    double x150 = ((x149)*(x149)*(x149));
    double x151 = (120.43215000000001*T - 903.24112500000001)*(x149 - 1);
    double x152 = 301.080375*x150 + x151 - 301.080375;
    double x153 = n2*x152;
    double x154 = 0.33333333333333331*x14;
    double x155 = x40*(x154*(3*x1 + x112*x30 + x153 + 3*x3 + 3*x5 + 3*x7 + 3*x9) + x39);
    double x156 = -x155;
    double x157 = 0.33333333333333331*x153 + x62;
    double x158 = x154*(3*x0 + x112*x60) + x157 + x67;
    double x159 = x15*x26;
    double x160 = -x55 - x92;
    double x161 = 3.0*x14*x160 - x159 + 3.0*x17 - x59;
    double x162 = x161*x31;
    double x163 = -x10 + x162;
    double x164 = x163 + 200.72024999999999;
    double x165 = 1.0*x2;
    double x166 = -x82;
    double x167 = x102 + x166;
    double x168 = x104*x167;
    double x169 = x14*x168 - 4.0*x15 + x98;
    double x170 = x169*x31;
    double x171 = 1.0*x0 + x61;
    double x172 = x14*x170 + x171;
    double x173 = x165 + x172;
    double x174 = x164 + x173;
    double x175 = x174*x71;
    double x176 = 21100.0*n3 + x66;
    double x177 = x176 + x33*(x164 + x2) + x63;
    double x178 = -2*x177*x69 + x41;
    double x179 = -4*x68*x69;
    double x180 = x144*x169;
    double x181 = 1.0*x108;
    double x182 = -x128 + 4.0*x69;
    double x183 = x106*x26*x33;
    double x184 = x167*x183;
    double x185 = 5.0*x47;
    double x186 = x123 + x185;
    double x187 = x146 - x15*(x143*(x103*x26*x44 - x124 + 6.0*x14*x167*x44 + x14*x182*x26*x44 - x140 + x167*x26*x44 - x181 - x184 - x186 + 6.0*x44*x49) + x145 + x180);
    double x188 = x179 + x187;
    double x189 = x154*(x112*x161 + x152 + 3*x2) + x157 + x176;
    double x190 = -2*x189*x69;
    double x191 = 100.360125*x150 + 0.33333333333333331*x151 + x162;
    double x192 = x173 + x191 - 100.360125;
    double x193 = x192*x71;
    double x194 = x155 - 4*x158*x69;
    double x195 = x187 + x194;
    double x196 = -x55 - x86;
    double x197 = 3.0*x14*x196 - x159 + 3.0*x19 - x43 - x50 - x51 - x52 - x54 - x58;
    double x198 = x197*x31;
    double x199 = n1*x65 + 21100.0*n2 + 61000.0*n4 + 60700.0*n5 + x37*x64;
    double x200 = x199 + x33*(x198 + x4) + x63;
    double x201 = x198 + 1.0*x4;
    double x202 = x172 + x201 + x34;
    double x203 = x202*x71;
    double x204 = x203 + x41;
    double x205 = x154*(x112*x197 + 3*x4) + x157 + x199;
    double x206 = -n4*x47 - x55;
    double x207 = x206*x33;
    double x208 = -x12*x47 - x55;
    double x209 = x208*x33;
    double x210 = -x13*x99 + x209 + x24 - x43 - x53;
    double x211 = x14*x95 + 1.0*x20 + x207 + x210 + 3.0*x29 - x54;
    double x212 = x211*x31;
    double x213 = 22700.0*n1 + 22700.0*n2 + 61000.0*n3 + 71000.0*n5;
    double x214 = x213 + x33*(x212 + x6) + x63;
    double x215 = -2*x214*x69;
    double x216 = -x47;
    double x217 = x216 + x74;
    double x218 = x217*x76;
    double x219 = x218 + x97;
    double x220 = x109 + x219 - x99;
    double x221 = x220*x31;
    double x222 = x212 + 1.0*x6;
    double x223 = x14*x221 + x171 + x222 + 22700.0;
    double x224 = x223*x71;
    double x225 = x224 + x41;
    double x226 = x144*x220;
    double x227 = -4*x69;
    double x228 = -x119 - x227;
    double x229 = x146 - x15*(x143*(-x117 + 2.0*x14*x217*x78 + 2.0*x14*x228 - x142 - 4.0*x47) + x145 + x226);
    double x230 = x154*(x112*x211 + 3*x6) + x157 + x213;
    double x231 = -2*x230*x69;
    double x232 = -x55 - x88;
    double x233 = 2.9999999979999998*x14;
    double x234 = x232*x233;
    double x235 = 0.33333333300000001*x15 - x48;
    double x236 = x104*x235;
    double x237 = x14*x236 + x210 + 2.9999999979999998*x23 + x234 + 0.99999999900000003*x29 - x51 - 0.81093021740539784;
    double x238 = x237*x31;
    double x239 = 22900.0*n1 + 22900.0*n2 + 60700.0*n3 + 71000.0*n4;
    double x240 = x239 + x33*(x238 + x8) + x63;
    double x241 = -2*x240*x69;
    double x242 = 3.9999999979999998*x15;
    double x243 = 3.0*x14;
    double x244 = x235*x44;
    double x245 = 0.99999999900000003*x94;
    double x246 = x102 - 1.3333333330000001*x47;
    double x247 = x104*x246;
    double x248 = 0.33333333300000001*x108;
    double x249 = x14*x245 + x14*x247 - x14*x248 + x243*x244;
    double x250 = x219 - x242 + x249;
    double x251 = x250*x31;
    double x252 = x238 + 1.0*x8;
    double x253 = x14*x251 + x171 + x252 + 22900.0;
    double x254 = x253*x71;
    double x255 = x254 + x41;
    double x256 = x144*x250;
    double x257 = 2.0*x79;
    double x258 = 8.0*x13*x69;
    double x259 = -x135;
    double x260 = -x136;
    double x261 = -x115;
    double x262 = -x138;
    double x263 = x261 + x262;
    double x264 = x258 + x259 + x260 + x263;
    double x265 = x257 + x264;
    double x266 = x218*x78 + x228*x76;
    double x267 = x265 + x266;
    double x268 = x246*x44;
    double x269 = x103*x44;
    double x270 = 0.99999999900000003*x14;
    double x271 = x107*x14;
    double x272 = x104*x14;
    double x273 = 0.66666666600000002*x26;
    double x274 = x133*x49;
    double x275 = x14*x274;
    double x276 = 0.33333333300000001*x26;
    double x277 = x14*x276;
    double x278 = -x124;
    double x279 = x105 + x278;
    double x280 = -1.3333333330000001*x108 - x131*x277 + 6.0*x14*x268 - x183*x246 + x269*x270 - 2.9999999970000002*x271 + x272*(-x128 + 4.6666666660000002*x69) + x273*x275 + x279 + 6.9999999989999999*x94;
    double x281 = x247 + x280;
    double x282 = x146 - x15*(x143*(x267 + x281 - 2.0000000020000002*x47) + x145 + x256);
    double x283 = x154*(x112*x237 + 3*x8) + x157 + x239;
    double x284 = -2*x283*x69;
    double x285 = n2*x73;
    double x286 = x243*(x285 + x72);
    double x287 = 1.0/n2;
    double x288 = x160*x243;
    double x289 = x91 - x93;
    double x290 = 5.0*x15;
    double x291 = x26*x47;
    double x292 = x291 + x80;
    double x293 = x290 + x292;
    double x294 = x286 + x287*x288 + x289 + x293;
    double x295 = x294*x31;
    double x296 = x120*x76 - x121 + x265 + x77*x78;
    double x297 = x143*(2*x168 + x272*(-x128 + 2.0*x69) + x278 + x296 + x82) + x180;
    double x298 = x15*(x295 + x297);
    double x299 = x42 + x68*x73;
    double x300 = x14*x295 + x144*x161 + 2.0*x2;
    double x301 = x47*(-80.2881*T + x300 + 401.44049999999999);
    double x302 = 4*x69;
    double x303 = x177*x302 - x301;
    double x304 = x156 + x158*x73;
    double x305 = x47*(200.72024999999999*x150 + 0.66666666666666663*x151 + x300 - 200.72024999999999);
    double x306 = x189*x302 - x305;
    double x307 = x243*(x216 + x285);
    double x308 = x289 + x307;
    double x309 = x292 + x308 + x46;
    double x310 = x309*x31;
    double x311 = -x202*x47;
    double x312 = x15*(x297 + x310) + x311;
    double x313 = x200*x73;
    double x314 = x163 + x165;
    double x315 = x14*x310 + x201;
    double x316 = x314 + x315 + 21300.720249999998;
    double x317 = x313 - x316*x47;
    double x318 = x177*x73;
    double x319 = -x174*x47 + x299 + x318;
    double x320 = x165 + x191;
    double x321 = x315 + x320 + 20999.639875000001;
    double x322 = -x321*x47;
    double x323 = x205*x73;
    double x324 = x304 + x323;
    double x325 = x189*x73;
    double x326 = -x192*x47 + x325;
    double x327 = x218 + x291;
    double x328 = -x290 + x327;
    double x329 = x308 + x328;
    double x330 = x31*x329;
    double x331 = x167*x44;
    double x332 = x168 + x267;
    double x333 = x143*(x100 - x181 + x182*x272 - x184 + x243*x331 + x279 + x332 + 3.0*x94) + x170 + x221;
    double x334 = -x223*x47;
    double x335 = x15*(x330 + x333) + x334;
    double x336 = x214*x73;
    double x337 = x14*x330 + x222;
    double x338 = x314 + x337 + 22900.720249999998;
    double x339 = x336 - x338*x47;
    double x340 = x304 + x326;
    double x341 = x230*x73;
    double x342 = x320 + x337 + 22599.639875000001;
    double x343 = x341 - x342*x47;
    double x344 = -4.9999999969999998*x15 + x327;
    double x345 = x308 + x344;
    double x346 = x31*x345;
    double x347 = x247 + 3.9999999979999998*x47;
    double x348 = x143*(-x106*x167*x277 + x245 - x248 + x270*x331 + x272*(-x128 + 2.6666666660000002*x69) + x278 + x332 + x347) + x170 + x251;
    double x349 = -x253*x47;
    double x350 = x15*(x346 + x348) + x349;
    double x351 = x240*x73;
    double x352 = x14*x346 + x252;
    double x353 = x314 + x352 + 23100.720249999998;
    double x354 = x351 - x353*x47;
    double x355 = x283*x73;
    double x356 = x320 + x352 + 22799.639875000001;
    double x357 = x355 - x356*x47;
    double x358 = -4*x200*x69;
    double x359 = -2*x68*x69;
    double x360 = n3*x73;
    double x361 = x360 + x72;
    double x362 = 1.0/n3;
    double x363 = x196*x243;
    double x364 = x81 + x93;
    double x365 = x364 + x83 + x85 - x87 + x89;
    double x366 = x243*x361 + x293 + x362*x363 + x365;
    double x367 = x31*x366;
    double x368 = x47*(x14*x367 + x144*x197 + 2.0*x4);
    double x369 = -x15*(x297 + x367) + x368;
    double x370 = -4*x205*x69;
    double x371 = x155 - 2*x158*x69;
    double x372 = x243*(x216 + x360);
    double x373 = x365 + x372;
    double x374 = x328 + x373;
    double x375 = x31*x374;
    double x376 = x14*x375 + x201 + x222 + 61000.0;
    double x377 = -x376*x47;
    double x378 = x336 + x377;
    double x379 = x299 + x311 + x313;
    double x380 = x15*(x333 + x375) + x334;
    double x381 = x311 + x324;
    double x382 = x341 + x377;
    double x383 = x349 + x351;
    double x384 = x344 + x373;
    double x385 = x31*x384;
    double x386 = x14*x385 + x201 + x252 + 60700.0;
    double x387 = -x386*x47;
    double x388 = x15*(x348 + x385) + x387;
    double x389 = x349 + x355;
    double x390 = -4*x214*x69;
    double x391 = n4*x73;
    double x392 = x33*(x391 + x72);
    double x393 = 1.0/n4;
    double x394 = x33*(x12*x73 + x72);
    double x395 = 1.0/x12;
    double x396 = x209*x395 + x394 - x83 + x84;
    double x397 = x396 - x81 + x90 + x96;
    double x398 = x110 + x207*x393 + x392 + x397;
    double x399 = x31*x398;
    double x400 = x47*(x14*x399 + x144*x211 + 2.0*x6);
    double x401 = -2*x69;
    double x402 = -x119 - x401;
    double x403 = x124 - 2.0*x14*x402;
    double x404 = -x15*(x143*(-x101 - x115 - x141 - x403) + x226 + x399) + x400;
    double x405 = -4*x230*x69;
    double x406 = x33*(x216 + x391);
    double x407 = -1.9999999979999998*x15 + x249 + x397 + x406;
    double x408 = x31*x407;
    double x409 = x264 + x402*x76;
    double x410 = x14*x408 + x222 + x252 + 71000.0;
    double x411 = -x410*x47;
    double x412 = x15*(x143*(x280 + x347 + x409) + x221 + x251 + x408) + x334 + x411;
    double x413 = -4*x240*x69;
    double x414 = x233*(n5*x73 + x72);
    double x415 = 1.0/n5;
    double x416 = 1.9999999980000001*x14;
    double x417 = x102 - 0.66666666600000002*x47;
    double x418 = x106*x235;
    double x419 = x14*x418;
    double x420 = x234*x415 + x236 + x242 + x244*x416 + x272*x417 - x276*x419 + x364 + x396 + x414 + x87 - x89;
    double x421 = x31*x420;
    double x422 = x47*(x14*x421 + x144*x237 + 2.0*x8);
    double x423 = x417*x44;
    double x424 = 0.22222222177777778*x26;
    double x425 = x106*x14*x273;
    double x426 = -0.66666666600000002*x108 + x243*x423 + 3.0*x244 - x246*x425 + 2*x247 + x268*x416 - x270*x418 - 0.66666666533333341*x271 + x272*(-x128 + 3.3333333320000005*x69) + x275*x424 + x278 + 1.9999999980000001*x94;
    double x427 = -x15*(x143*(x409 + x426 + 5.9999999959999997*x47) + x256 + x421) + x422;
    double x428 = -4*x283*x69;
    double x429 = 20.0*x47;
    double x430 = n2*x40;
    double x431 = x26*x73;
    double x432 = -x431;
    double x433 = 12.0*x69;
    double x434 = n2*x433 + x432;
    double x435 = 3.0*x160*x287 + x434;
    double x436 = x15*(x112*x294 + x143*(x243*(-x118 - x430) + x286*x287 + x296 - x429 + x435 - x288/((n2)*(n2))));
    double x437 = x144*x309;
    double x438 = x243*(-x227 - x430) + x287*x307 + x435;
    double x439 = x15*(x143*(x296 + x438 - 14.0*x47) + x295 + x437);
    double x440 = x316*x71;
    double x441 = x303 + x42;
    double x442 = x321*x71;
    double x443 = x156 + x306;
    double x444 = x144*x329;
    double x445 = -10.0*x47;
    double x446 = x267 + x438;
    double x447 = x15*(x143*(x445 + x446) + x295 + x444);
    double x448 = -x338*x71;
    double x449 = -x342*x71;
    double x450 = x144*x345;
    double x451 = -10.000000003*x47;
    double x452 = x15*(x143*(x446 + x451) + x295 + x450);
    double x453 = -x353*x71;
    double x454 = -x356*x71;
    double x455 = -x401 - x430;
    double x456 = x135 + x136 + x138 + x139 + x431;
    double x457 = -x15*(x143*(12.0*n2*x69 + 3.0*x14*x455 - x186 - x456) + x367 + x437) + x368;
    double x458 = x155 + x370;
    double x459 = x243*x455 + x434;
    double x460 = x267 + x459;
    double x461 = x15*(x143*(x166 + x460) + x310 + x330 + x375) + x377;
    double x462 = x318 + x42;
    double x463 = x317 + x462;
    double x464 = x156 + x325;
    double x465 = x343 + x464;
    double x466 = x322 + x323;
    double x467 = x15*(x143*(x460 - 1.0000000030000002*x47) + x310 + x346 + x385) + x387;
    double x468 = x214*x302;
    double x469 = x409 + x459;
    double x470 = -x400;
    double x471 = x15*(x143*(x185 + x469) + x399 + x444) + x470;
    double x472 = x230*x302;
    double x473 = x15*(x143*(x469 + 4.9999999969999998*x47) + x330 + x346 + x408) + x411;
    double x474 = x240*x302;
    double x475 = -x422;
    double x476 = x15*(x143*(x469 + 4.9999999939999995*x47) + x421 + x450) + x475;
    double x477 = x283*x302;
    double x478 = n3*x40;
    double x479 = -12.0*n3*x69 + x456;
    double x480 = x15*(x112*x366 + x143*(-x116 - x122 - x124 + 3.0*x14*x361*x362 + 3.0*x14*(-x118 - x478) + 3.0*x196*x362 - x429 - x479 - x363/((n3)*(n3)))) - 3*x368;
    double x481 = x215 + x41;
    double x482 = x144*x374;
    double x483 = x259 + x278;
    double x484 = n3*x433 + 3.0*x196*x362 + x243*(-x227 - x478) + x257 + x258 + x260 + x262 + x266 + x362*x372 + x432 + x483;
    double x485 = x376*x71;
    double x486 = -x15*(x143*(x445 + x484) + x367 + x482) + x368 + x485;
    double x487 = x241 + x41;
    double x488 = x144*x384;
    double x489 = x386*x71;
    double x490 = -x15*(x143*(x451 + x484) + x367 + x488) + x368 + x489;
    double x491 = x313 + x42;
    double x492 = -3.0*x14*(-x401 - x478) + x403 + x479;
    double x493 = x15*(x143*(x185 - x492) + x399 + x482) + x470 - x485;
    double x494 = x156 + x323;
    double x495 = x15*(x143*(4.9999999969999998*x47 - x492) + x375 + x385 + x408) + x387 + x411;
    double x496 = x15*(x143*(4.9999999939999995*x47 - x492) + x421 + x488) + x475 - x489;
    double x497 = n4*x40;
    double x498 = 4.0*x69;
    double x499 = x12*x498 - x13*x498 + 1.0*x208*x395 + x33*(-x118 - x12*x40) + x394*x395 - x209/((x12)*(x12));
    double x500 = n4*x498 + x263 + x499;
    double x501 = 1.0*x206*x393 + x500;
    double x502 = x15*(x112*x398 + x143*(2*x105 - x113 - x125 + x126*x269 - x127 + x129*x272 + x130*x274 - x132 + x278 + x33*(-x118 - x497) + x392*x393 + x501 + 9.0*x94 - x207/((n4)*(n4)))) - 3*x400;
    double x503 = x144*x407;
    double x504 = x410*x71;
    double x505 = -x15*(x143*(x281 + x33*(-x227 - x497) + x393*x406 - 4.0000000020000002*x47 + x501) + x399 + x503) + x400 + x504;
    double x506 = -x15*(x143*(x33*(-x401 - x497) + x426 + 0.99999999599999967*x47 + x500) + x421 + x503) + x422 + x504;
    double x507 = x15*(x112*x420 + x143*(2*x104*x417 + x133*x14*x235*x424 + 11.999999991999999*x137 + 2.9999999970000002*x14*x423 + 2.9999999979999998*x232*x415 + x233*(-n5*x40 - x118) + 2.9999999970000002*x244 + x261 + x272*(-x128 + 1.9999999980000001*x69) - x273*x418 + x414*x415 - x417*x425 - 0.99999999800000006*x419 - 15.999999991999999*x47 + x483 + x499 - x234/((n5)*(n5)))) - 3*x422;

if (x148) {
   result[0] = x147 + x42 + x68*x70;
}
else {
   result[0] = x147 + x156 + x158*x70;
}
if (x148) {
   result[1] = -x175 - x178 - x188;
}
else {
   result[1] = -x190 - x193 - x195;
}
if (x148) {
   result[2] = -x188 + 2*x200*x69 - x204;
}
else {
   result[2] = -x195 - x203 + 2*x205*x69;
}
if (x148) {
   result[3] = -x179 - x215 - x225 - x229;
}
else {
   result[3] = -x194 - x224 - x229 - x231;
}
if (x148) {
   result[4] = -x179 - x241 - x255 - x282;
}
else {
   result[4] = -x194 - x254 - x282 - x284;
}
if (x148) {
   result[5] = -x175 + x298 + x299 + x303;
}
else {
   result[5] = -x193 + x298 + x304 + x306;
}
if (x148) {
   result[6] = x312 + x317 + x319;
}
else {
   result[6] = x312 + x322 + x324 + x326;
}
if (x148) {
   result[7] = x319 + x335 + x339;
}
else {
   result[7] = x335 + x340 + x343;
}
if (x148) {
   result[8] = x319 + x350 + x354;
}
else {
   result[8] = x340 + x350 + x357;
}
if (x148) {
   result[9] = -x204 - x358 - x359 - x369;
}
else {
   result[9] = -x203 - x369 - x370 - x371;
}
if (x148) {
   result[10] = x378 + x379 + x380;
}
else {
   result[10] = x380 + x381 + x382;
}
if (x148) {
   result[11] = x379 + x383 + x388;
}
else {
   result[11] = x381 + x388 + x389;
}
if (x148) {
   result[12] = -x225 - x359 - x390 - x404;
}
else {
   result[12] = -x224 - x371 - x404 - x405;
}
if (x148) {
   result[13] = x299 + x336 + x383 + x412;
}
else {
   result[13] = x304 + x341 + x389 + x412;
}
if (x148) {
   result[14] = -x255 - x359 - x413 - x427;
}
else {
   result[14] = -x254 - x371 - x427 - x428;
}
if (x148) {
   result[15] = x177*x70 - 3*x301 + x42 + x436;
}
else {
   result[15] = x156 + x189*x70 - 3*x305 + x436;
}
if (x148) {
   result[16] = x313 + x439 - x440 + x441;
}
else {
   result[16] = x323 + x439 - x442 + x443;
}
if (x148) {
   result[17] = x336 + x441 + x447 + x448;
}
else {
   result[17] = x341 + x443 + x447 + x449;
}
if (x148) {
   result[18] = x351 + x441 + x452 + x453;
}
else {
   result[18] = x355 + x443 + x452 + x454;
}
if (x148) {
   result[19] = -x178 - x358 - x440 - x457;
}
else {
   result[19] = -x190 - x442 - x457 - x458;
}
if (x148) {
   result[20] = x339 + x461 + x463;
}
else {
   result[20] = x461 + x465 + x466;
}
if (x148) {
   result[21] = x354 + x463 + x467;
}
else {
   result[21] = x357 + x464 + x466 + x467;
}
if (x148) {
   result[22] = x448 + x462 + x468 + x471;
}
else {
   result[22] = x449 + x464 + x471 + x472;
}
if (x148) {
   result[23] = x339 + x354 + x462 + x473;
}
else {
   result[23] = x357 + x465 + x473;
}
if (x148) {
   result[24] = x453 + x462 + x474 + x476;
}
else {
   result[24] = x454 + x464 + x476 + x477;
}
if (x148) {
   result[25] = x200*x70 + x42 + x480;
}
else {
   result[25] = x156 + x205*x70 + x480;
}
if (x148) {
   result[26] = -x358 - x481 - x486;
}
else {
   result[26] = -x231 - x458 - x486;
}
if (x148) {
   result[27] = -x358 - x487 - x490;
}
else {
   result[27] = -x284 - x458 - x490;
}
if (x148) {
   result[28] = x468 + x491 + x493;
}
else {
   result[28] = x472 + x493 + x494;
}
if (x148) {
   result[29] = x351 + x378 + x491 + x495;
}
else {
   result[29] = x355 + x382 + x494 + x495;
}
if (x148) {
   result[30] = x474 + x491 + x496;
}
else {
   result[30] = x477 + x494 + x496;
}
if (x148) {
   result[31] = x214*x70 + x42 + x502;
}
else {
   result[31] = x156 + x230*x70 + x502;
}
if (x148) {
   result[32] = -x390 - x487 - x505;
}
else {
   result[32] = -x155 - x284 - x405 - x505;
}
if (x148) {
   result[33] = -x413 - x481 - x506;
}
else {
   result[33] = -x155 - x231 - x428 - x506;
}
if (x148) {
   result[34] = x240*x70 + x42 + x507;
}
else {
   result[34] = x156 + x283*x70 + x507;
}
}
        
static double coder_dgdt(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = 1.0*n1;
    double x1 = 1.0*n4;
    double x2 = n4 + n5;
    double x3 = n1 + n2 + n3;
    double x4 = 1.0/(x2 + x3);
    double x5 = log(n5*x4);
    double x6 = 24.943387854459719*n2*log(n2*x4) + 1.0*n2*(*endmember[1].dmu0dT)(T, P) + 24.943387854459719*n3*log(n3*x4) + 1.0*n3*(*endmember[2].dmu0dT)(T, P) + 8.3144626181532395*n4*log(n4*x4) + 8.3144626181532395*n5*x5 + 16.628925219677555*n5*(x5 - 0.40546510910816402) + 1.0*n5*(*endmember[4].dmu0dT)(T, P) + x0*(*endmember[0].dmu0dT)(T, P) + x1*(*endmember[3].dmu0dT)(T, P) + 8.3144626181532395*x2*log(x2*x4) + 16.628925236306479*x3*log(x3*x4) + 8.3144626181532395*(3.0*n1 + 3.0*n4 + 0.99999999900000003*n5)*log(x4*(0.33333333300000001*n5 + x0 + x1));
    double x7 = sqrt(1 - 0.13333333333333333*T);
    double x8 = 1.0*x7;
    double x9 = fmin(4, x8);
    double x10 = (4 - x8 >= 0. ? 1. : 0.)/x7;

if (T >= 7.5) {
   result = -40.14405*n2 + x6;
}
else {
   result = 0.33333333333333331*n2*(-60.216075000000004*x10*((x9)*(x9)) - 0.066666666666666666*x10*(120.43215000000001*T - 903.24112500000001) + 120.43215000000001*x9 - 120.43215000000001) + x6;
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n4 + n5;
    double x1 = n1 + n2 + n3;
    double x2 = x0 + x1;
    double x3 = 1.0/x2;
    double x4 = 1.0*n1 + 1.0*n4 + 0.33333333300000001*n5;
    double x5 = log(x3*x4);
    double x6 = n3*x3;
    double x7 = 24.943387854459719*x6;
    double x8 = 3.0*n1 + 3.0*n4 + 0.99999999900000003*n5;
    double x9 = 1.0/x4;
    double x10 = pow(x2, -2);
    double x11 = x10*x4;
    double x12 = -x11 + 1.0*x3;
    double x13 = x1*x3;
    double x14 = -16.628925236306479*log(x13);
    double x15 = n4*x3;
    double x16 = 8.3144626181532395*x15;
    double x17 = x0*x3;
    double x18 = 8.3144626181532395*x17;
    double x19 = n5*x3;
    double x20 = 24.943387837830794*x19;
    double x21 = n2*x3;
    double x22 = 24.943387854459719*x21;
    double x23 = -x3;
    double x24 = -16.628925236306479*x2*(-x1*x10 - x23);
    double x25 = x14 + x16 + x18 + x20 + x22 + x24;
    double x26 = 8.3144626181532395*x8;
    double x27 = x26*x3;
    double x28 = x14 + x16 + x18 - 24.943387854459719*x2*(-n2*x10 - x23) + x20 + x24 + x27 + x7 - 24.943387854459719*log(x21) - 1.0*(*endmember[1].dmu0dT)(T, P) + 40.14405;
    double x29 = sqrt(1 - 0.13333333333333333*T);
    double x30 = 1.0*x29;
    double x31 = fmin(4, x30);
    double x32 = (4 - x30 >= 0. ? 1. : 0.)/x29;
    double x33 = 8.3144626181532395*x2;
    double x34 = x2*x26*x9;
    double x35 = -16.628925236306479*x13 - x22 + x33*(-x0*x10 - x23) - x7 + 8.3144626181532395*log(x17);

result[0] = 8.3144626181532395*x12*x2*x8*x9 - x25 + 24.943387854459719*x5 - x7 + 1.0*(*endmember[0].dmu0dT)(T, P);
if (T >= 7.5) {
   result[1] = -x28;
}
else {
   result[1] = -x28 - 20.072025*((x31)*(x31))*x32 + 40.14405*x31 - 0.02222222222222222*x32*(120.43215000000001*T - 903.24112500000001);
}
result[2] = 24.943387854459719*x2*(-n3*x10 - x23) - x25 - x27 + 24.943387854459719*log(x6) + 1.0*(*endmember[2].dmu0dT)(T, P);
result[3] = x12*x34 - x20 + x33*(-n4*x10 - x23) + x35 + 24.943387854459719*x5 + 8.3144626181532395*log(x15) + 1.0*(*endmember[3].dmu0dT)(T, P);
result[4] = -x16 + 24.943387837830794*x2*(-n5*x10 - x23) + x34*(-x11 + 0.33333333300000001*x3) + x35 + 8.3144626098387775*x5 + 24.943387837830794*log(x19) + 1.0*(*endmember[4].dmu0dT)(T, P) - 6.7424489785480599;
}
        
static void coder_d3gdn2dt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n4 + n5;
    double x1 = n1 + n2 + n3;
    double x2 = x0 + x1;
    double x3 = pow(x2, -2);
    double x4 = -2*x3;
    double x5 = 2/((x2)*(x2)*(x2));
    double x6 = x1*x5;
    double x7 = 16.628925236306479*x2;
    double x8 = 1.0/x2;
    double x9 = -x8;
    double x10 = x1*x3;
    double x11 = x7*(x4 + x6) + x7*(-x10 - x9)/x1;
    double x12 = n4*x3;
    double x13 = 8.3144626181532395*x12;
    double x14 = x0*x3;
    double x15 = 8.3144626181532395*x14;
    double x16 = 16.628925236306479*x10;
    double x17 = -x16;
    double x18 = n5*x3;
    double x19 = 24.943387837830794*x18;
    double x20 = n3*x3;
    double x21 = 24.943387854459719*x20;
    double x22 = x19 + x21;
    double x23 = x13 + x15 + x17 + x22;
    double x24 = n2*x3;
    double x25 = 24.943387854459719*x24;
    double x26 = 3.0*n1 + 3.0*n4 + 0.99999999900000003*n5;
    double x27 = 8.3144626181532395*x26;
    double x28 = 1.0*n1 + 1.0*n4 + 0.33333333300000001*n5;
    double x29 = 1.0/x28;
    double x30 = x28*x3;
    double x31 = -x30 + 1.0*x8;
    double x32 = x29*x31;
    double x33 = x25 + x27*x32;
    double x34 = x23 + x33;
    double x35 = x11 + x34;
    double x36 = 16.628925236306479*x8;
    double x37 = x2*x32;
    double x38 = x28*x5;
    double x39 = x2*x27;
    double x40 = x29*x39;
    double x41 = pow(x28, -2);
    double x42 = x31*x41;
    double x43 = 49.886775708919437*x37 - x39*x42 + x40*(-2.0*x3 + x38);
    double x44 = x36 + x43;
    double x45 = x35 + x40*(-1.0*x3 + x38) - 33.257850472612958*x8;
    double x46 = -x3;
    double x47 = x7*(x46 + x6);
    double x48 = x34 + x47;
    double x49 = 33.257850455984034*x8;
    double x50 = 24.943387854459719*x2;
    double x51 = -x30 + 0.33333333300000001*x8;
    double x52 = x29*x51;
    double x53 = 2.7714875366129257*x2*x26;
    double x54 = 8.3144626098387775*x37 + x40*(-1.3333333330000001*x3 + x38) - x42*x53 + x50*x52;
    double x55 = n2*x5;
    double x56 = x23 - x25;
    double x57 = 41.572313090766201*x8;
    double x58 = x27*x3;
    double x59 = x11 + x58;
    double x60 = x57 + x59;
    double x61 = x50*(x46 + x55) + x56;
    double x62 = x47 + x58;
    double x63 = -x57 + x62;
    double x64 = x62 - 41.572313065822811*x8;
    double x65 = n3*x5;
    double x66 = x13 + x25;
    double x67 = x15 + x17 + x19 - x21 + x66;
    double x68 = x50*(x46 + x65) + x67;
    double x69 = n4*x5;
    double x70 = 8.3144626181532395*x2;
    double x71 = -x15 + x16 + x70*(x0*x5 + x4) + x70*(-x14 - x9)/x0;
    double x72 = -x13 + x22 + x33 + x71;
    double x73 = 24.943387837830794*x2;

result[0] = x35 + x44;
result[1] = x45;
result[2] = x45;
result[3] = -x36 + x43 + x48;
result[4] = x48 - x49 + x54;
result[5] = x50*(x4 + x55) + x56 + x60 + x50*(-x24 - x9)/n2;
result[6] = x59 + x61 - 8.3144626181532395*x8;
result[7] = x61 + x63;
result[8] = x61 + x64;
result[9] = x50*(x4 + x65) + x60 + x67 + x50*(-x20 - x9)/n3;
result[10] = x63 + x68;
result[11] = x64 + x68;
result[12] = x44 + x70*(x4 + x69) + x72 + x70*(-x12 - x9)/n4;
result[13] = x54 + x70*(x46 + x69) + x72 - 16.628925219677555*x8;
result[14] = -x19 + 16.628925219677555*x2*x52 + x21 + x27*x52 + x40*(-0.66666666600000002*x3 + x38) - x41*x51*x53 + x49 + x66 + x71 + x73*(n5*x5 + x4) + x73*(-x18 - x9)/n5;
}
        
static void coder_d4gdn3dt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n4 + n5;
    double x1 = n1 + n2 + n3;
    double x2 = x0 + x1;
    double x3 = pow(x2, -2);
    double x4 = 66.515700945225916*x3;
    double x5 = pow(x2, -3);
    double x6 = 49.886775708919437*x5;
    double x7 = n3*x6;
    double x8 = 1.0/x1;
    double x9 = 1.0/x2;
    double x10 = -x9;
    double x11 = -x1*x3 - x10;
    double x12 = -16.628925236306479*x11*x8;
    double x13 = x12 + x7;
    double x14 = -6*x5;
    double x15 = 6/((x2)*(x2)*(x2)*(x2));
    double x16 = x1*x15;
    double x17 = -x14 - x16;
    double x18 = 16.628925236306479*x2;
    double x19 = x11*x18/((x1)*(x1));
    double x20 = -2*x3;
    double x21 = 2*x5;
    double x22 = x1*x21;
    double x23 = x20 + x22;
    double x24 = -16.628925236306479*x17*x2 + x19 - 16.628925236306479*x2*x23*x8;
    double x25 = x13 + x24;
    double x26 = n2*x6;
    double x27 = 1.0*n1 + 1.0*n4 + 0.33333333300000001*n5;
    double x28 = 1.0/x27;
    double x29 = x27*x3;
    double x30 = -x29 + 1.0*x9;
    double x31 = 3.0*n1 + 3.0*n4 + 0.99999999900000003*n5;
    double x32 = 16.628925236306479*x31;
    double x33 = pow(x27, -2);
    double x34 = x30*x33;
    double x35 = x32*x34;
    double x36 = 74.830163563379159*x2;
    double x37 = x34*x36;
    double x38 = x21*x27;
    double x39 = -2.0*x3 + x38;
    double x40 = x18*x31;
    double x41 = x33*x39;
    double x42 = x40*x41;
    double x43 = x15*x27;
    double x44 = -x43 + 6.0*x5;
    double x45 = pow(x27, -3);
    double x46 = 16.628925236306479*x5;
    double x47 = n4*x46;
    double x48 = x0*x46;
    double x49 = n5*x5;
    double x50 = 49.886775675661589*x49;
    double x51 = -66.515700945225916*x1*x5;
    double x52 = x47 + x48 + x50 + x51;
    double x53 = -8.3144626181532395*x2*x28*x31*x44 - 74.830163563379159*x2*x28*x39 - 16.628925236306479*x2*x30*x31*x45 - 74.830163563379159*x28*x30 - 16.628925236306479*x28*x31*x39 + x35 + x37 + x42 + x52;
    double x54 = x26 + x53;
    double x55 = 8.3144626181532395*x31;
    double x56 = x34*x55;
    double x57 = -1.0*x3 + x38;
    double x58 = 8.3144626181532395*x2;
    double x59 = x31*x58;
    double x60 = x33*x59;
    double x61 = x57*x60;
    double x62 = -x43 + 4.0*x5;
    double x63 = 41.572313090766201*x3;
    double x64 = x25 + x63;
    double x65 = 8.3144626181532395*x2*x28*x31*x62 + 49.886775708919437*x2*x28*x57 - x26 + 49.886775708919437*x28*x30 + 8.3144626181532395*x28*x31*x39 + 8.3144626181532395*x28*x31*x57 - x52 - x56 - x61 - x64;
    double x66 = -4*x5;
    double x67 = -x16 - x66;
    double x68 = -x3;
    double x69 = x22 + x68;
    double x70 = 16.628925236306479*x8;
    double x71 = x11*x70;
    double x72 = x1*x5;
    double x73 = 66.515700945225916*x72;
    double x74 = -x47;
    double x75 = -x48;
    double x76 = -x50;
    double x77 = -x7;
    double x78 = x76 + x77;
    double x79 = x73 + x74 + x75 + x78;
    double x80 = x71 + x79;
    double x81 = x2*x70;
    double x82 = x18*x67 + x69*x81;
    double x83 = x80 + x82;
    double x84 = -1.3333333330000001*x3 + x38;
    double x85 = x28*x84;
    double x86 = x55*x85;
    double x87 = x28*x30;
    double x88 = x28*x39;
    double x89 = 8.3144626098387775*x2;
    double x90 = x2*x34;
    double x91 = x31*x34;
    double x92 = x28*x59;
    double x93 = 5.5429750732258514*x31;
    double x94 = x30*x45;
    double x95 = x2*x94;
    double x96 = x2*x31;
    double x97 = 2.7714875366129257*x96;
    double x98 = -x26;
    double x99 = x55*x88 + x98;
    double x100 = 49.886775708919437*x2*x85 - x41*x97 - x60*x84 + x86 + 58.201238318758215*x87 + x88*x89 - 24.943387829516332*x90 - 11.085950154766165*x91 + x92*(-x43 + 4.6666666660000002*x5) + x93*x95 + x99;
    double x101 = 8.3144626181532395*x3;
    double x102 = x28*x57;
    double x103 = x17*x18 - x19 + x23*x81 + x80;
    double x104 = x101 + x102*x32 + x103 + x92*(-x43 + 2.0*x5) + x98;
    double x105 = 24.943387854459719*x2;
    double x106 = x102*x55 + x83;
    double x107 = x102*x105 + x106 + 16.628925236306486*x3 - x56 - x61 + x62*x92 + 24.943387854459719*x87 + x99;
    double x108 = x102*x89 + x106 + 33.257850455984041*x3 - x33*x57*x97 + x86 + 8.3144626098387775*x87 - 2.7714875366129257*x91 + x92*(-x43 + 2.6666666660000002*x5) + x98;
    double x109 = -2*x5;
    double x110 = -x109 - x16;
    double x111 = -16.628925236306479*x110*x2 + x26;
    double x112 = x110*x18 + x79;
    double x113 = -x29 + 0.33333333300000001*x9;
    double x114 = x113*x28;
    double x115 = -0.66666666600000002*x3 + x38;
    double x116 = x115*x28;
    double x117 = x113*x33;
    double x118 = x2*x33*x93;
    double x119 = x105*x116 + 24.943387854459719*x114 - x117*x89 - x118*x84 + 16.628925219677555*x2*x85 + 1.8476583558942921*x31*x95 + x32*x85 + 16.628925219677555*x87 - 5.5429750676828764*x90 - 5.5429750732258514*x91 + x92*(-x43 + 3.3333333320000005*x5) + x98;
    double x120 = 166.2892523630648*x3;
    double x121 = n2*x15;
    double x122 = n2*x21;
    double x123 = 24.943387854459719/n2;
    double x124 = x123*x2;
    double x125 = -n2*x3 - x10;
    double x126 = 99.773551417838874*x5;
    double x127 = x31*x46;
    double x128 = -x127;
    double x129 = n2*x126 + x128;
    double x130 = x123*x125 + x129;
    double x131 = x105*(-x121 - x66) + x124*(x122 + x68) + x130;
    double x132 = -83.144626181532402*x3;
    double x133 = x131 + x83;
    double x134 = -83.144626206475778*x3;
    double x135 = -x109 - x121;
    double x136 = x127 + x47 + x48 + x50 + x51;
    double x137 = x105*x135 + x129;
    double x138 = x137 + x83;
    double x139 = x112 + x137;
    double x140 = 1.0/n3;
    double x141 = -n3*x3 - x10;
    double x142 = n3*x15;
    double x143 = n3*x21;
    double x144 = -99.773551417838874*n3*x5 + x136;
    double x145 = x74 + x98;
    double x146 = n3*x126 + x105*x140*(x143 + x68) + x105*(-x142 - x66) + x128 + 24.943387854459719*x140*x141 + x145 + x71 + x73 + x75 + x76 + x82;
    double x147 = x111 + x144 - 24.943387854459719*x2*(-x109 - x142);
    double x148 = n4*x15;
    double x149 = n4*x21;
    double x150 = 8.3144626181532395/n4;
    double x151 = x150*x2;
    double x152 = -n4*x3 - x10;
    double x153 = 33.257850472612958*x5;
    double x154 = -x0*x3 - x10;
    double x155 = 8.3144626181532395/x0;
    double x156 = x0*x153 + x154*x155 + x155*x2*(x0*x21 + x20) + x58*(-x0*x15 - x14) - 33.257850472612958*x72 - x154*x58/((x0)*(x0));
    double x157 = n4*x153 + x156 + x78;
    double x158 = x150*x152 + x157;
    double x159 = -n5*x3 - x10;
    double x160 = 24.943387837830794/n5;
    double x161 = 24.943387837830794*x2;

result[0] = -x25 - x4 - x54;
result[1] = x65;
result[2] = x65;
result[3] = -x13 + 16.628925236306479*x2*x67 + 16.628925236306479*x2*x69*x8 - 33.257850472612958*x3 - x54;
result[4] = x100 - 16.628925252935407*x3 + x83;
result[5] = x104;
result[6] = x104;
result[7] = x107;
result[8] = x108;
result[9] = x104;
result[10] = x107;
result[11] = x108;
result[12] = -x111 + 16.628925236306479*x3 - x53 - x7;
result[13] = x100 + x112 + 33.257850455984034*x3;
result[14] = x112 + x119 + 49.886775675661582*x3;
result[15] = x103 + x105*(-x121 - x14) - x120 + x124*(x122 + x20) + x130 - x105*x125/((n2)*(n2));
result[16] = x103 + x131 - 116.40247665414537*x3;
result[17] = x132 + x133;
result[18] = x133 + x134;
result[19] = 99.773551417838874*n2*x5 + 24.943387854459719*x135*x2 - x136 - x64;
result[20] = -x101 + x138;
result[21] = x138 - 8.3144626430966255*x3;
result[22] = x139 + x63;
result[23] = x139 + 41.572313065822826*x3;
result[24] = x139 + 41.572313040879436*x3;
result[25] = -x12 - x120 + 24.943387854459719*x140*x141 + 24.943387854459719*x140*x2*(x143 + x20) - x144 + 24.943387854459719*x2*(-x14 - x142) - x24 - x26 - x105*x141/((n3)*(n3));
result[26] = x132 + x146;
result[27] = x134 + x146;
result[28] = -x147 + x63;
result[29] = -x147 + 41.572313065822826*x3;
result[30] = -x147 + 41.572313040879436*x3;
result[31] = x151*(x149 + x20) + x158 + x32*x88 - x35 + x36*x88 - x37 - x4 + x40*x94 - x42 + x44*x92 + x58*(-x14 - x148) + 74.830163563379159*x87 + x98 - x152*x58/((n4)*(n4));
result[32] = x100 + x151*(x149 + x68) + x158 - 33.257850489241882*x3 + x58*(-x148 - x66);
result[33] = x119 + x157 + 8.3144625848953915*x3 + x58*(-x109 - x148);
result[34] = 1.8476583558942921*x113*x45*x96 + 24.943387829516332*x114 - x115*x118 + 24.943387829516332*x116*x2 + x116*x32 - 8.3144626015243155*x117*x2 - x117*x93 + x145 + x156 + x159*x160 + x160*x2*(n5*x21 + x20) + x161*(-n5*x15 - x14) - 133.03140182393614*x3 + 99.773551351323178*x49 + x77 + x92*(-x43 + 1.9999999980000001*x5) - x159*x161/((n5)*(n5));
}
        
static double coder_dgdp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1 + n2 + n3 + n4 + n5;
    double x1 = 1.0/x0;
    double x2 = 0.10299999999999999*n1*n3;
    double x3 = n1*(*endmember[0].dmu0dP)(T, P);
    double x4 = n2*(*endmember[1].dmu0dP)(T, P);
    double x5 = n3*(*endmember[2].dmu0dP)(T, P);
    double x6 = n4*(*endmember[3].dmu0dP)(T, P);
    double x7 = n5*(*endmember[4].dmu0dP)(T, P);

if (T >= 7.5) {
   result = x1*(1.0*x0*(x3 + x4 + x5 + x6 + x7) + x2);
}
else {
   result = x1*(0.33333333333333331*x0*(3*x3 + 3*x4 + 3*x5 + 3*x6 + 3*x7) + x2);
}
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n1 + n2 + n3 + n4 + n5;
    double x1 = pow(x0, -2);
    double x2 = 0.10299999999999999*n3;
    double x3 = n1*x2;
    double x4 = (*endmember[0].dmu0dP)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[1].dmu0dP)(T, P);
    double x7 = n2*x6;
    double x8 = (*endmember[2].dmu0dP)(T, P);
    double x9 = n3*x8;
    double x10 = (*endmember[3].dmu0dP)(T, P);
    double x11 = n4*x10;
    double x12 = (*endmember[4].dmu0dP)(T, P);
    double x13 = n5*x12;
    double x14 = 1.0*x0;
    double x15 = x1*(x14*(x11 + x13 + x5 + x7 + x9) + x3);
    double x16 = 1.0/x0;
    double x17 = 1.0*x11 + 1.0*x13 + 1.0*x5 + 1.0*x7 + 1.0*x9;
    double x18 = -x16*(x14*x4 + x17 + x2);
    double x19 = T >= 7.5;
    double x20 = x1*(0.33333333333333331*x0*(3*x11 + 3*x13 + 3*x5 + 3*x7 + 3*x9) + x3);
    double x21 = -x16*(x14*x6 + x17);
    double x22 = -x16*(0.10299999999999999*n1 + x14*x8 + x17);
    double x23 = -x16*(x10*x14 + x17);
    double x24 = -x16*(x12*x14 + x17);

if (x19) {
   result[0] = -x15 - x18;
}
else {
   result[0] = -x18 - x20;
}
if (x19) {
   result[1] = -x15 - x21;
}
else {
   result[1] = -x20 - x21;
}
if (x19) {
   result[2] = -x15 - x22;
}
else {
   result[2] = -x20 - x22;
}
if (x19) {
   result[3] = -x15 - x23;
}
else {
   result[3] = -x20 - x23;
}
if (x19) {
   result[4] = -x15 - x24;
}
else {
   result[4] = -x20 - x24;
}
}
        
static void coder_d3gdn2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = 0.10299999999999999*n3;
    double x1 = n1*x0;
    double x2 = n1 + n2 + n3 + n4 + n5;
    double x3 = (*endmember[0].dmu0dP)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].dmu0dP)(T, P);
    double x6 = n2*x5;
    double x7 = (*endmember[2].dmu0dP)(T, P);
    double x8 = n3*x7;
    double x9 = (*endmember[3].dmu0dP)(T, P);
    double x10 = n4*x9;
    double x11 = (*endmember[4].dmu0dP)(T, P);
    double x12 = n5*x11;
    double x13 = 2/((x2)*(x2)*(x2));
    double x14 = x13*(x1 + 1.0*x2*(x10 + x12 + x4 + x6 + x8));
    double x15 = pow(x2, -2);
    double x16 = 1.0*x3;
    double x17 = 1.0*x10 + 1.0*x12 + 1.0*x4 + 1.0*x6 + 1.0*x8;
    double x18 = x15*(x0 + x16*x2 + x17);
    double x19 = 1.0/x2;
    double x20 = 2.0*x19;
    double x21 = -2*x18 + x20*x3;
    double x22 = T >= 7.5;
    double x23 = x13*(x1 + 0.33333333333333331*x2*(3*x10 + 3*x12 + 3*x4 + 3*x6 + 3*x8));
    double x24 = -x18;
    double x25 = x14 + x24;
    double x26 = 1.0*x5;
    double x27 = x15*(x17 + x2*x26);
    double x28 = -x27;
    double x29 = x19*(x16 + x26) + x28;
    double x30 = x23 + x24;
    double x31 = 1.0*x7;
    double x32 = x15*(0.10299999999999999*n1 + x17 + x2*x31);
    double x33 = -x32;
    double x34 = x19*(x16 + x31 + 0.10299999999999999) + x33;
    double x35 = 1.0*x9;
    double x36 = x15*(x17 + x2*x35);
    double x37 = -x36;
    double x38 = x19*(x16 + x35) + x37;
    double x39 = 1.0*x11;
    double x40 = x15*(x17 + x2*x39);
    double x41 = -x40;
    double x42 = x19*(x16 + x39) + x41;
    double x43 = x20*x5 - 2*x27;
    double x44 = x14 + x28;
    double x45 = x19*(x26 + x31) + x33;
    double x46 = x23 + x28;
    double x47 = x19*(x26 + x35) + x37;
    double x48 = x19*(x26 + x39) + x41;
    double x49 = x20*x7 - 2*x32;
    double x50 = x14 + x33;
    double x51 = x19*(x31 + x35) + x37;
    double x52 = x23 + x33;
    double x53 = x19*(x31 + x39) + x41;
    double x54 = x20*x9 - 2*x36;
    double x55 = x19*(x35 + x39) + x37 + x41;
    double x56 = x11*x20 - 2*x40;

if (x22) {
   result[0] = x14 + x21;
}
else {
   result[0] = x21 + x23;
}
if (x22) {
   result[1] = x25 + x29;
}
else {
   result[1] = x29 + x30;
}
if (x22) {
   result[2] = x25 + x34;
}
else {
   result[2] = x30 + x34;
}
if (x22) {
   result[3] = x25 + x38;
}
else {
   result[3] = x30 + x38;
}
if (x22) {
   result[4] = x25 + x42;
}
else {
   result[4] = x30 + x42;
}
if (x22) {
   result[5] = x14 + x43;
}
else {
   result[5] = x23 + x43;
}
if (x22) {
   result[6] = x44 + x45;
}
else {
   result[6] = x45 + x46;
}
if (x22) {
   result[7] = x44 + x47;
}
else {
   result[7] = x46 + x47;
}
if (x22) {
   result[8] = x44 + x48;
}
else {
   result[8] = x46 + x48;
}
if (x22) {
   result[9] = x14 + x49;
}
else {
   result[9] = x23 + x49;
}
if (x22) {
   result[10] = x50 + x51;
}
else {
   result[10] = x51 + x52;
}
if (x22) {
   result[11] = x50 + x53;
}
else {
   result[11] = x52 + x53;
}
if (x22) {
   result[12] = x14 + x54;
}
else {
   result[12] = x23 + x54;
}
if (x22) {
   result[13] = x14 + x55;
}
else {
   result[13] = x23 + x55;
}
if (x22) {
   result[14] = x14 + x56;
}
else {
   result[14] = x23 + x56;
}
}
        
static void coder_d4gdn3dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = 0.10299999999999999*n3;
    double x1 = n1*x0;
    double x2 = n1 + n2 + n3 + n4 + n5;
    double x3 = (*endmember[0].dmu0dP)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].dmu0dP)(T, P);
    double x6 = n2*x5;
    double x7 = (*endmember[2].dmu0dP)(T, P);
    double x8 = n3*x7;
    double x9 = (*endmember[3].dmu0dP)(T, P);
    double x10 = n4*x9;
    double x11 = (*endmember[4].dmu0dP)(T, P);
    double x12 = n5*x11;
    double x13 = 6/((x2)*(x2)*(x2)*(x2));
    double x14 = x13*(x1 + 1.0*x2*(x10 + x12 + x4 + x6 + x8));
    double x15 = pow(x2, -3);
    double x16 = 1.0*x3;
    double x17 = 1.0*x10 + 1.0*x12 + 1.0*x4 + 1.0*x6 + 1.0*x8;
    double x18 = x0 + x16*x2 + x17;
    double x19 = pow(x2, -2);
    double x20 = x19*x3;
    double x21 = -6*x15*x18 + 6.0*x20;
    double x22 = T >= 7.5;
    double x23 = x13*(x1 + 0.33333333333333331*x2*(3*x10 + 3*x12 + 3*x4 + 3*x6 + 3*x8));
    double x24 = 1.0*x5;
    double x25 = x19*(x16 + x24);
    double x26 = 2*x25;
    double x27 = x14 + x26;
    double x28 = x17 + x2*x24;
    double x29 = -2*x15*x28;
    double x30 = -4*x15*x18 + 2.0*x20;
    double x31 = x29 + x30;
    double x32 = x23 + x26;
    double x33 = x14 + x30;
    double x34 = 1.0*x7;
    double x35 = 0.10299999999999999*n1 + x17 + x2*x34;
    double x36 = -2*x15*x35;
    double x37 = x19*(x16 + x34 + 0.10299999999999999);
    double x38 = 2*x37;
    double x39 = x36 + x38;
    double x40 = x23 + x30;
    double x41 = 1.0*x9;
    double x42 = x17 + x2*x41;
    double x43 = -2*x15*x42;
    double x44 = x19*(x16 + x41);
    double x45 = 2*x44;
    double x46 = x43 + x45;
    double x47 = 1.0*x11;
    double x48 = x17 + x2*x47;
    double x49 = -2*x15*x48;
    double x50 = x19*(x16 + x47);
    double x51 = 2*x50;
    double x52 = x49 + x51;
    double x53 = -2*x15*x18;
    double x54 = 2.0*x19;
    double x55 = -4*x15*x28 + x5*x54;
    double x56 = x53 + x55;
    double x57 = x14 + x53;
    double x58 = x25 + x29;
    double x59 = x57 + x58;
    double x60 = x19*(x24 + x34);
    double x61 = x36 + x37;
    double x62 = x60 + x61;
    double x63 = x23 + x53;
    double x64 = x58 + x63;
    double x65 = x19*(x24 + x41);
    double x66 = x43 + x44;
    double x67 = x65 + x66;
    double x68 = x19*(x24 + x47);
    double x69 = x49 + x50;
    double x70 = x68 + x69;
    double x71 = -4*x15*x35 + x54*x7;
    double x72 = x38 + x71;
    double x73 = x57 + x61;
    double x74 = x19*(x34 + x41);
    double x75 = x66 + x74;
    double x76 = x61 + x63;
    double x77 = x19*(x34 + x47);
    double x78 = x69 + x77;
    double x79 = -4*x15*x42 + x54*x9;
    double x80 = x45 + x79;
    double x81 = x19*(x41 + x47);
    double x82 = x66 + x69 + x81;
    double x83 = x11*x54 - 4*x15*x48;
    double x84 = x51 + x83;
    double x85 = 6.0*x19;
    double x86 = -6*x15*x28 + x5*x85;
    double x87 = x14 + x55;
    double x88 = 2*x60;
    double x89 = x36 + x88;
    double x90 = x23 + x55;
    double x91 = 2*x65;
    double x92 = x43 + x91;
    double x93 = 2*x68;
    double x94 = x49 + x93;
    double x95 = x14 + x29;
    double x96 = x71 + x88;
    double x97 = x23 + x29;
    double x98 = x36 + x60;
    double x99 = x95 + x98;
    double x100 = x43 + x65;
    double x101 = x100 + x74;
    double x102 = x97 + x98;
    double x103 = x49 + x68;
    double x104 = x103 + x77;
    double x105 = x79 + x91;
    double x106 = x100 + x103 + x81;
    double x107 = x83 + x93;
    double x108 = -6*x15*x35 + x7*x85;
    double x109 = x14 + x71;
    double x110 = 2*x74;
    double x111 = x110 + x43;
    double x112 = x23 + x71;
    double x113 = 2*x77;
    double x114 = x113 + x49;
    double x115 = x14 + x36;
    double x116 = x110 + x79;
    double x117 = x23 + x36;
    double x118 = x43 + x49 + x74 + x77 + x81;
    double x119 = x113 + x83;
    double x120 = -6*x15*x42 + x85*x9;
    double x121 = 2*x81;
    double x122 = x121 + x14;
    double x123 = x49 + x79;
    double x124 = x121 + x23;
    double x125 = x43 + x83;
    double x126 = x11*x85 - 6*x15*x48;

if (x22) {
   result[0] = -x14 - x21;
}
else {
   result[0] = -x21 - x23;
}
if (x22) {
   result[1] = -x27 - x31;
}
else {
   result[1] = -x31 - x32;
}
if (x22) {
   result[2] = -x33 - x39;
}
else {
   result[2] = -x39 - x40;
}
if (x22) {
   result[3] = -x33 - x46;
}
else {
   result[3] = -x40 - x46;
}
if (x22) {
   result[4] = -x33 - x52;
}
else {
   result[4] = -x40 - x52;
}
if (x22) {
   result[5] = -x27 - x56;
}
else {
   result[5] = -x32 - x56;
}
if (x22) {
   result[6] = -x59 - x62;
}
else {
   result[6] = -x62 - x64;
}
if (x22) {
   result[7] = -x59 - x67;
}
else {
   result[7] = -x64 - x67;
}
if (x22) {
   result[8] = -x59 - x70;
}
else {
   result[8] = -x64 - x70;
}
if (x22) {
   result[9] = -x57 - x72;
}
else {
   result[9] = -x63 - x72;
}
if (x22) {
   result[10] = -x73 - x75;
}
else {
   result[10] = -x75 - x76;
}
if (x22) {
   result[11] = -x73 - x78;
}
else {
   result[11] = -x76 - x78;
}
if (x22) {
   result[12] = -x57 - x80;
}
else {
   result[12] = -x63 - x80;
}
if (x22) {
   result[13] = -x57 - x82;
}
else {
   result[13] = -x63 - x82;
}
if (x22) {
   result[14] = -x57 - x84;
}
else {
   result[14] = -x63 - x84;
}
if (x22) {
   result[15] = -x14 - x86;
}
else {
   result[15] = -x23 - x86;
}
if (x22) {
   result[16] = -x87 - x89;
}
else {
   result[16] = -x89 - x90;
}
if (x22) {
   result[17] = -x87 - x92;
}
else {
   result[17] = -x90 - x92;
}
if (x22) {
   result[18] = -x87 - x94;
}
else {
   result[18] = -x90 - x94;
}
if (x22) {
   result[19] = -x95 - x96;
}
else {
   result[19] = -x96 - x97;
}
if (x22) {
   result[20] = -x101 - x99;
}
else {
   result[20] = -x101 - x102;
}
if (x22) {
   result[21] = -x104 - x99;
}
else {
   result[21] = -x102 - x104;
}
if (x22) {
   result[22] = -x105 - x95;
}
else {
   result[22] = -x105 - x97;
}
if (x22) {
   result[23] = -x106 - x95;
}
else {
   result[23] = -x106 - x97;
}
if (x22) {
   result[24] = -x107 - x95;
}
else {
   result[24] = -x107 - x97;
}
if (x22) {
   result[25] = -x108 - x14;
}
else {
   result[25] = -x108 - x23;
}
if (x22) {
   result[26] = -x109 - x111;
}
else {
   result[26] = -x111 - x112;
}
if (x22) {
   result[27] = -x109 - x114;
}
else {
   result[27] = -x112 - x114;
}
if (x22) {
   result[28] = -x115 - x116;
}
else {
   result[28] = -x116 - x117;
}
if (x22) {
   result[29] = -x115 - x118;
}
else {
   result[29] = -x117 - x118;
}
if (x22) {
   result[30] = -x115 - x119;
}
else {
   result[30] = -x117 - x119;
}
if (x22) {
   result[31] = -x120 - x14;
}
else {
   result[31] = -x120 - x23;
}
if (x22) {
   result[32] = -x122 - x123;
}
else {
   result[32] = -x123 - x124;
}
if (x22) {
   result[33] = -x122 - x125;
}
else {
   result[33] = -x124 - x125;
}
if (x22) {
   result[34] = -x126 - x14;
}
else {
   result[34] = -x126 - x23;
}
}
        
static double coder_d2gdt2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dT2)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dT2)(T, P);
    double x3 = n4*(*endmember[3].d2mu0dT2)(T, P);
    double x4 = n5*(*endmember[4].d2mu0dT2)(T, P);
    double x5 = 0.13333333333333333*T - 1;
    double x6 = -x5;
    double x7 = sqrt(x6);
    double x8 = 1.0*x7;
    double x9 = x8 - 4;
    double x10 = (-x9 >= 0. ? 1. : 0.);
    double x11 = 0.53525400000000001*T - 4.014405;
    double x12 = 1.0/x5;
    double x13 = x12*0;
    double x14 = x10/pow(x6, 3.0/2.0);
    double x15 = fmin(4, x8);
    double x16 = 4.014405*((x15)*(x15));

if (T >= 7.5) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3 + 1.0*x4;
}
else {
   result = -0.33333333333333331*n2*(8.02881*((x10)*(x10))*x12*x15 + 16.05762*x10/x7 - x11*x13 + x11*x14 - x13*x16 + x14*x16) + 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3 + 1.0*x4;
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[1].d2mu0dT2)(T, P);
    double x1 = 0.13333333333333333*T - 1;
    double x2 = -x1;
    double x3 = sqrt(x2);
    double x4 = 1.0*x3;
    double x5 = x4 - 4;
    double x6 = (-x5 >= 0. ? 1. : 0.);
    double x7 = 120.43215000000001*T - 903.24112500000001;
    double x8 = 1.0/x1;
    double x9 = 0;
    double x10 = x6/pow(x2, 3.0/2.0);
    double x11 = fmin(4, x4);
    double x12 = ((x11)*(x11));

result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
if (T >= 7.5) {
   result[1] = 1.0*x0;
}
else {
   result[1] = 1.0*x0 - 1.3381349999999999*x10*x12 - 0.0014814814814814814*x10*x7 - 2.6762699999999997*x11*((x6)*(x6))*x8 + 1.3381349999999999*x12*x8*x9 + 0.0014814814814814814*x7*x8*x9 - 5.3525399999999994*x6/x3;
}
result[2] = 1.0*(*endmember[2].d2mu0dT2)(T, P);
result[3] = 1.0*(*endmember[3].d2mu0dT2)(T, P);
result[4] = 1.0*(*endmember[4].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P) + n3*(*endmember[2].d2mu0dTdP)(T, P) + n4*(*endmember[3].d2mu0dTdP)(T, P) + n5*(*endmember[4].d2mu0dTdP)(T, P));
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dTdP)(T, P);
result[3] = 1.0*(*endmember[3].d2mu0dTdP)(T, P);
result[4] = 1.0*(*endmember[4].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P) + n3*(*endmember[2].d2mu0dP2)(T, P) + n4*(*endmember[3].d2mu0dP2)(T, P) + n5*(*endmember[4].d2mu0dP2)(T, P));
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dP2)(T, P);
result[3] = 1.0*(*endmember[3].d2mu0dP2)(T, P);
result[4] = 1.0*(*endmember[4].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT3)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dT3)(T, P);
    double x3 = n4*(*endmember[3].d3mu0dT3)(T, P);
    double x4 = n5*(*endmember[4].d3mu0dT3)(T, P);
    double x5 = 0.13333333333333333*T - 1;
    double x6 = -x5;
    double x7 = 1.0*sqrt(x6);
    double x8 = x7 - 4;
    double x9 = 0;
    double x10 = pow(x6, -3.0/2.0);
    double x11 = (-x8 >= 0. ? 1. : 0.);
    double x12 = 1.6057619999999999*x10*x11;
    double x13 = pow(x5, -2);
    double x14 = x13*x9;
    double x15 = 120.43215000000001*T - 903.24112500000001;
    double x16 = 0.00088888888888888893*x15;
    double x17 = x11/pow(x6, 5.0/2.0);
    double x18 = x10*0;
    double x19 = fmin(4, x7);
    double x20 = ((x19)*(x19));

if (T >= 7.5) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3 + 1.0*x4;
}
else {
   result = -0.33333333333333331*n2*(0.53525400000000001*x10*((x11)*(x11)*(x11)) - 1.6057619999999999*((x11)*(x11))*x13*x19 - x12*x19*x9 + x12 + x14*x16 + 0.80288099999999996*x14*x20 - 0.00029629629629629629*x15*x18 + x16*x17 + 0.80288100000000007*x17*x20 - 0.267627*x18*x20 - 1.6057619999999999*x9/x5) + 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3 + 1.0*x4;
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = 1.0*(*endmember[1].d3mu0dT3)(T, P);
    double x1 = 0.13333333333333333*T - 1;
    double x2 = -x1;
    double x3 = 1.0*sqrt(x2);
    double x4 = x3 - 4;
    double x5 = 0;
    double x6 = 0.5352539999999999*x5;
    double x7 = pow(x2, -3.0/2.0);
    double x8 = (-x4 >= 0. ? 1. : 0.);
    double x9 = x7*x8;
    double x10 = pow(x1, -2);
    double x11 = x10*x5;
    double x12 = 120.43215000000001*T - 903.24112500000001;
    double x13 = 0.00029629629629629629*x12;
    double x14 = x8/pow(x2, 5.0/2.0);
    double x15 = x7*0;
    double x16 = fmin(4, x3);
    double x17 = ((x16)*(x16));

result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
if (T >= 7.5) {
   result[1] = x0;
}
else {
   result[1] = x0 + 0.5352539999999999*x10*x16*((x8)*(x8)) - x11*x13 - 0.26762699999999995*x11*x17 + 9.8765432098765426e-5*x12*x15 - x13*x14 - 0.267627*x14*x17 + 0.089208999999999997*x15*x17 + x16*x6*x9 - 0.17841799999999999*x7*((x8)*(x8)*(x8)) - 0.5352539999999999*x9 + x6/x1;
}
result[2] = 1.0*(*endmember[2].d3mu0dT3)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dT3)(T, P);
result[4] = 1.0*(*endmember[4].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P) + n3*(*endmember[2].d3mu0dT2dP)(T, P) + n4*(*endmember[3].d3mu0dT2dP)(T, P) + n5*(*endmember[4].d3mu0dT2dP)(T, P));
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dT2dP)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dT2dP)(T, P);
result[4] = 1.0*(*endmember[4].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P) + n3*(*endmember[2].d3mu0dTdP2)(T, P) + n4*(*endmember[3].d3mu0dTdP2)(T, P) + n5*(*endmember[4].d3mu0dTdP2)(T, P));
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dTdP2)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dTdP2)(T, P);
result[4] = 1.0*(*endmember[4].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P) + n3*(*endmember[2].d3mu0dP3)(T, P) + n4*(*endmember[3].d3mu0dP3)(T, P) + n5*(*endmember[4].d3mu0dP3)(T, P));
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dP3)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dP3)(T, P);
result[4] = 1.0*(*endmember[4].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_s(double T, double P, double n[5]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[5]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[5]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[5]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[5]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[5]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[5]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[5]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[5]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[5]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[5]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[5]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[5]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[5]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

