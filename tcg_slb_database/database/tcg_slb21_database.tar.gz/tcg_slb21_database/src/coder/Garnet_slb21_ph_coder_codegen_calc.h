#include <math.h>


static double coder_g(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n4 + n5;
    double x1 = n1 + n2 + n3;
    double x2 = x0 + x1;
    double x3 = 1.0/x2;
    double x4 = n1*(*endmember[0].mu0)(T, P);
    double x5 = n2*(*endmember[1].mu0)(T, P);
    double x6 = n3*(*endmember[2].mu0)(T, P);
    double x7 = n4*(*endmember[3].mu0)(T, P);
    double x8 = n5*(*endmember[4].mu0)(T, P);
    double x9 = 1.0*n4;
    double x10 = log(n5*x3);
    double x11 = T*(3.0*n2*log(n2*x3) + 3.0*n3*log(n3*x3) + 1.0*n5*x10 + 1.9999999980000001*n5*(x10 - 0.40546510910816402) + 1.0*x0*log(x0*x3) + 2.0*x1*log(x1*x3) + x9*log(n4*x3) + (3.0*n1 + 3.0*n4 + 0.99999999900000003*n5)*log(x3*(1.0*n1 + 0.33333333300000001*n5 + x9)));
    double x12 = 0.82399999999999995*P + 168800.0;
    double x13 = 181600.0*n4 + 183200.0*n5;
    double x14 = 0.0625*n1*(n3*x12 + x13) + 0.0625*n2*(168800.0*n3 + x13) + 0.0625*n3*(n1*x12 + 168800.0*n2 + 488000.0*n4 + 485600.0*n5) + 0.0625*n4*(181600.0*n1 + 181600.0*n2 + 488000.0*n3 + 568000.0*n5) + 0.0625*n5*(183200.0*n1 + 183200.0*n2 + 485600.0*n3 + 568000.0*n4);
    double x15 = fmin(4, 1.0*sqrt(1 - 0.13333333333333333*T));

if (T >= 7.5) {
   result = x3*(x14 + 1.0*x2*(-n2*(40.14405*T - 200.72024999999999) + 8.3144626181532395*x11 + x4 + x5 + x6 + x7 + x8));
}
else {
   result = x3*(x14 + 0.33333333333333331*x2*(n2*(301.080375*((x15)*(x15)*(x15)) + (120.43215000000001*T - 903.24112500000001)*(x15 - 1) - 301.080375) + 24.943387854459719*x11 + 3*x4 + 3*x5 + 3*x6 + 3*x7 + 3*x8));
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n4 + n5;
    double x1 = n1 + n2 + n3;
    double x2 = x0 + x1;
    double x3 = pow(x2, -2);
    double x4 = (*endmember[0].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[1].mu0)(T, P);
    double x7 = n2*x6;
    double x8 = (*endmember[2].mu0)(T, P);
    double x9 = n3*x8;
    double x10 = (*endmember[3].mu0)(T, P);
    double x11 = n4*x10;
    double x12 = (*endmember[4].mu0)(T, P);
    double x13 = n5*x12;
    double x14 = 40.14405*T;
    double x15 = x14 - 200.72024999999999;
    double x16 = 1.0/x2;
    double x17 = n2*x16;
    double x18 = 3.0*log(x17);
    double x19 = n3*x16;
    double x20 = 3.0*log(x19);
    double x21 = log(n4*x16);
    double x22 = 1.0*n4;
    double x23 = n5*x16;
    double x24 = log(x23);
    double x25 = 1.0*n5;
    double x26 = 1.0*log(x0*x16);
    double x27 = 2.0*log(x1*x16);
    double x28 = 3.0*n1 + 3.0*n4 + 0.99999999900000003*n5;
    double x29 = 1.0*n1;
    double x30 = 0.33333333300000001*n5 + x22 + x29;
    double x31 = log(x16*x30);
    double x32 = n2*x18 + n3*x20 + 1.9999999980000001*n5*(x24 - 0.40546510910816402) + x0*x26 + x1*x27 + x21*x22 + x24*x25 + x28*x31;
    double x33 = 8.3144626181532395*T;
    double x34 = x32*x33;
    double x35 = 1.0*x2;
    double x36 = 0.10299999999999999*P + 21100.0;
    double x37 = n3*x36;
    double x38 = 181600.0*n4 + 183200.0*n5;
    double x39 = 0.0625*n1;
    double x40 = n1*x36;
    double x41 = 0.0625*n3;
    double x42 = 0.0625*n2*(168800.0*n3 + x38) + 0.0625*n4*(181600.0*n1 + 181600.0*n2 + 488000.0*n3 + 568000.0*n5) + 0.0625*n5*(183200.0*n1 + 183200.0*n2 + 485600.0*n3 + 568000.0*n4) + x39*(8.0*x37 + x38) + x41*(168800.0*n2 + 488000.0*n4 + 485600.0*n5 + 8.0*x40);
    double x43 = -x3*(x35*(-n2*x15 + x11 + x13 + x34 + x5 + x7 + x9) + x42);
    double x44 = 1.0*n2;
    double x45 = 1.0*n3;
    double x46 = x22 + x25;
    double x47 = x29 + x44 + x45 + x46;
    double x48 = -x16*x22;
    double x49 = -3.0*x17;
    double x50 = -3.0*x19;
    double x51 = x48 + x49 + x50;
    double x52 = -2.9999999979999998*x23;
    double x53 = -x3*x30;
    double x54 = x2*x28/x30;
    double x55 = 3.0*x31 + x52 + x54*(1.0*x16 + x53);
    double x56 = 2.0*n1 + 2.0*n2 + 2.0*n3;
    double x57 = -x16*x46 + x27 + x2*x56*(-x1*x3 + x16)/x1;
    double x58 = x51 + x55 + x57;
    double x59 = x10*x22 + x12*x25 + x29*x4 + x34 + x44*x6 + x45*x8;
    double x60 = -x15*x44 + x59;
    double x61 = 0.82399999999999995*P + 168800.0;
    double x62 = 22700.0*n4 + 22900.0*n5;
    double x63 = 0.5*x37 + x41*x61 + x62;
    double x64 = T >= 7.5;
    double x65 = fmin(4, 1.0*sqrt(1 - 0.13333333333333333*T));
    double x66 = 301.080375*((x65)*(x65)*(x65)) + (120.43215000000001*T - 903.24112500000001)*(x65 - 1) - 301.080375;
    double x67 = 24.943387854459719*T;
    double x68 = -x3*(0.33333333333333331*x2*(n2*x66 + 3*x11 + 3*x13 + x32*x67 + 3*x5 + 3*x7 + 3*x9) + x42);
    double x69 = 0.33333333333333331*n2;
    double x70 = 0.33333333333333331*n1 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5 + x69;
    double x71 = x59 + x66*x69;
    double x72 = 3.0*x2;
    double x73 = -x16*x28 + x48 + x52 + x57;
    double x74 = x18 + x50 + x72*(-n2*x3 + x16) + x73;
    double x75 = 21100.0*n3 + x62;
    double x76 = x20 + x49 + x72*(-n3*x3 + x16) + x73;
    double x77 = 21100.0*n2 + 61000.0*n4 + 60700.0*n5 + x39*x61 + 0.5*x40;
    double x78 = -x16*x56 + x26 + x2*x46*(-x0*x3 + x16)/x0;
    double x79 = 1.0*x21 + x35*(-n4*x3 + x16) + x49 + x50 + x55 + x78;
    double x80 = 22700.0*n1 + 22700.0*n2 + 61000.0*n3 + 71000.0*n5;
    double x81 = 2.9999999979999998*x2*(-n5*x3 + x16) + 2.9999999979999998*x24 + 0.99999999900000003*x31 + x51 + x54*(0.33333333300000001*x16 + x53) + x78 - 0.81093021740539784;
    double x82 = 22900.0*n1 + 22900.0*n2 + 60700.0*n3 + 71000.0*n4;

if (x64) {
   result[0] = x16*(x47*(x33*x58 + x4) + x60 + x63) + x43;
}
else {
   result[0] = x16*(x63 + x70*(3*x4 + x58*x67) + x71) + x68;
}
if (x64) {
   result[1] = x16*(x47*(-x14 + x33*x74 + x6 + 200.72024999999999) + x60 + x75) + x43;
}
else {
   result[1] = x16*(x70*(3*x6 + x66 + x67*x74) + x71 + x75) + x68;
}
if (x64) {
   result[2] = x16*(x47*(x33*x76 + x8) + x60 + x77) + x43;
}
else {
   result[2] = x16*(x70*(x67*x76 + 3*x8) + x71 + x77) + x68;
}
if (x64) {
   result[3] = x16*(x47*(x10 + x33*x79) + x60 + x80) + x43;
}
else {
   result[3] = x16*(x70*(3*x10 + x67*x79) + x71 + x80) + x68;
}
if (x64) {
   result[4] = x16*(x47*(x12 + x33*x81) + x60 + x82) + x43;
}
else {
   result[4] = x16*(x70*(3*x12 + x67*x81) + x71 + x82) + x68;
}
}
        
static void coder_d2gdn2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n3*x4;
    double x6 = (*endmember[3].mu0)(T, P);
    double x7 = n4*x6;
    double x8 = (*endmember[4].mu0)(T, P);
    double x9 = n5*x8;
    double x10 = 40.14405*T;
    double x11 = x10 - 200.72024999999999;
    double x12 = n4 + n5;
    double x13 = n1 + n2 + n3;
    double x14 = x12 + x13;
    double x15 = 1.0/x14;
    double x16 = n2*x15;
    double x17 = 3.0*log(x16);
    double x18 = n3*x15;
    double x19 = 3.0*log(x18);
    double x20 = log(n4*x15);
    double x21 = 1.0*n4;
    double x22 = n5*x15;
    double x23 = log(x22);
    double x24 = 1.0*n5;
    double x25 = 1.0*log(x12*x15);
    double x26 = 2.0*log(x13*x15);
    double x27 = 3.0*n1 + 3.0*n4 + 0.99999999900000003*n5;
    double x28 = 1.0*n1;
    double x29 = 0.33333333300000001*n5 + x21 + x28;
    double x30 = log(x15*x29);
    double x31 = T*(n2*x17 + n3*x19 + 1.9999999980000001*n5*(x23 - 0.40546510910816402) + x12*x25 + x13*x26 + x20*x21 + x23*x24 + x27*x30);
    double x32 = 8.3144626181532395*x31;
    double x33 = 1.0*x14;
    double x34 = 0.10299999999999999*P + 21100.0;
    double x35 = n3*x34;
    double x36 = 181600.0*n4 + 183200.0*n5;
    double x37 = 0.0625*n1;
    double x38 = n1*x34;
    double x39 = 0.0625*n3;
    double x40 = 0.0625*n2*(168800.0*n3 + x36) + 0.0625*n4*(181600.0*n1 + 181600.0*n2 + 488000.0*n3 + 568000.0*n5) + 0.0625*n5*(183200.0*n1 + 183200.0*n2 + 485600.0*n3 + 568000.0*n4) + x37*(8.0*x35 + x36) + x39*(168800.0*n2 + 488000.0*n4 + 485600.0*n5 + 8.0*x38);
    double x41 = pow(x14, -3);
    double x42 = 2*x41;
    double x43 = x42*(x33*(-n2*x11 + x1 + x3 + x32 + x5 + x7 + x9) + x40);
    double x44 = 1.0*n2;
    double x45 = 1.0*n3;
    double x46 = x21 + x24;
    double x47 = x28 + x44 + x45 + x46;
    double x48 = -x15*x21;
    double x49 = -3.0*x16;
    double x50 = -3.0*x18;
    double x51 = x48 + x49 + x50;
    double x52 = -2.9999999979999998*x22;
    double x53 = 1.0*x15;
    double x54 = pow(x14, -2);
    double x55 = -x29*x54;
    double x56 = x53 + x55;
    double x57 = 1.0/x29;
    double x58 = x27*x57;
    double x59 = x56*x58;
    double x60 = x14*x59 + 3.0*x30 + x52;
    double x61 = 2.0*n1 + 2.0*n2 + 2.0*n3;
    double x62 = 1.0/x13;
    double x63 = -x13*x54 + x15;
    double x64 = x62*x63;
    double x65 = x61*x64;
    double x66 = x14*x65 - x15*x46 + x26;
    double x67 = T*(x51 + x60 + x66);
    double x68 = 8.3144626181532395*x67;
    double x69 = x0*x28 + x2*x44 + x21*x6 + x24*x8 + x32 + x4*x45;
    double x70 = -x11*x44 + x69;
    double x71 = 0.82399999999999995*P + 168800.0;
    double x72 = 22700.0*n4 + 22900.0*n5;
    double x73 = 0.5*x35 + x39*x71 + x72;
    double x74 = x47*(x0 + x68) + x70 + x73;
    double x75 = 2*x54;
    double x76 = x46*x54;
    double x77 = x21*x54;
    double x78 = n3*x54;
    double x79 = 3.0*x78;
    double x80 = n5*x54;
    double x81 = 2.9999999979999998*x80;
    double x82 = x79 + x81;
    double x83 = x65 + x76 + x77 + x82;
    double x84 = n2*x54;
    double x85 = 3.0*x84;
    double x86 = x59 + x85;
    double x87 = x83 + x86;
    double x88 = -x75;
    double x89 = x13*x42;
    double x90 = x14*x61;
    double x91 = x62*x90;
    double x92 = 4.0*x14*x64 + x91*(x88 + x89) - x63*x90/((x13)*(x13));
    double x93 = x87 + x92;
    double x94 = x14*x57;
    double x95 = x56*x94;
    double x96 = -2.0*x54;
    double x97 = x29*x42;
    double x98 = x14*x58;
    double x99 = x27/((x29)*(x29));
    double x100 = x56*x99;
    double x101 = -x100*x33 + 6.0*x95 + x98*(x96 + x97);
    double x102 = T*(x101 + x93);
    double x103 = 8.3144626181532395*x47;
    double x104 = 2.0*x0 + 16.628925236306479*x67;
    double x105 = T >= 7.5;
    double x106 = fmin(4, 1.0*sqrt(1 - 0.13333333333333333*T));
    double x107 = ((x106)*(x106)*(x106));
    double x108 = (120.43215000000001*T - 903.24112500000001)*(x106 - 1);
    double x109 = 301.080375*x107 + x108 - 301.080375;
    double x110 = x42*(0.33333333333333331*x14*(n2*x109 + 3*x1 + 3*x3 + 24.943387854459719*x31 + 3*x5 + 3*x7 + 3*x9) + x40);
    double x111 = 0.33333333333333331*n2;
    double x112 = 0.33333333333333331*n1 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5 + x111;
    double x113 = x109*x111 + x69;
    double x114 = x112*(3*x0 + 24.943387854459719*x67) + x113 + x73;
    double x115 = 24.943387854459719*x112;
    double x116 = 1.0*x2;
    double x117 = 3.0*x14;
    double x118 = x117*(x15 - x84);
    double x119 = -x15*x27 + x48 + x52 + x66;
    double x120 = T*(x118 + x119 + x17 + x50);
    double x121 = 8.3144626181532395*x120;
    double x122 = -x10 + x121;
    double x123 = x122 + 200.72024999999999;
    double x124 = -1.0*x54;
    double x125 = T*(-6.0*x15 + x93 + x98*(x124 + x97));
    double x126 = 1.0*x0 + x68;
    double x127 = x103*x125 + x126;
    double x128 = 21100.0*n3 + x72;
    double x129 = x128 + x47*(x123 + x2) + x70;
    double x130 = -x129*x54;
    double x131 = x43 - x54*x74;
    double x132 = x115*x125 + x126;
    double x133 = 100.360125*x107 + 0.33333333333333331*x108 + x116 + x121;
    double x134 = x112*(x109 + 24.943387854459719*x120 + 3*x2) + x113 + x128;
    double x135 = -x134*x54;
    double x136 = x110 - x114*x54;
    double x137 = x117*(x15 - x78);
    double x138 = T*(x119 + x137 + x19 + x49);
    double x139 = 8.3144626181532395*x138;
    double x140 = x139 + 1.0*x4;
    double x141 = x140 + x34;
    double x142 = 21100.0*n2 + 61000.0*n4 + 60700.0*n5 + x37*x71 + 0.5*x38;
    double x143 = x142 + x47*(x139 + x4) + x70;
    double x144 = -x143*x54;
    double x145 = x112*(24.943387854459719*x138 + 3*x4) + x113 + x142;
    double x146 = -x145*x54;
    double x147 = x91*(-x54 + x89);
    double x148 = x147 + x87;
    double x149 = T*(x101 + x148 - 4.0*x15);
    double x150 = x33*(-n4*x54 + x15);
    double x151 = 1.0/x12;
    double x152 = -x12*x54 + x15;
    double x153 = x151*x152;
    double x154 = x153*x46;
    double x155 = x14*x154 - x15*x61 + x25;
    double x156 = T*(x150 + x155 + 1.0*x20 + x49 + x50 + x60);
    double x157 = 8.3144626181532395*x156;
    double x158 = x157 + 1.0*x6;
    double x159 = x126 + x158 + 22700.0;
    double x160 = 22700.0*n1 + 22700.0*n2 + 61000.0*n3 + 71000.0*n5;
    double x161 = x160 + x47*(x157 + x6) + x70;
    double x162 = -x161*x54;
    double x163 = x112*(24.943387854459719*x156 + 3*x6) + x113 + x160;
    double x164 = -x163*x54;
    double x165 = 0.33333333300000001*x15 + x55;
    double x166 = 0.33333333300000001*x14;
    double x167 = -x100*x166 + x117*x165*x57 + 0.99999999900000003*x95 + x98*(-1.3333333330000001*x54 + x97);
    double x168 = T*(x148 - 5.9999999979999998*x15 + x167);
    double x169 = 2.9999999979999998*x14*(x15 - x80);
    double x170 = x165*x58;
    double x171 = T*(x14*x170 + x155 + x169 + 2.9999999979999998*x23 + 0.99999999900000003*x30 + x51 - 0.81093021740539784);
    double x172 = 8.3144626181532395*x171;
    double x173 = x172 + 1.0*x8;
    double x174 = x126 + x173 + 22900.0;
    double x175 = 22900.0*n1 + 22900.0*n2 + 60700.0*n3 + 71000.0*n4;
    double x176 = x175 + x47*(x172 + x8) + x70;
    double x177 = -x176*x54;
    double x178 = x112*(24.943387854459719*x171 + 3*x8) + x113 + x175;
    double x179 = -x178*x54;
    double x180 = -6.0*x54;
    double x181 = 6.0*x41;
    double x182 = n2*x181;
    double x183 = x83 - x85;
    double x184 = 3.0*x15;
    double x185 = x27*x54;
    double x186 = x185 + x92;
    double x187 = x184 + x186;
    double x188 = T*(x14*(x180 + x182) + x183 + x187 + x118/n2);
    double x189 = 16.628925236306479*x120 + 2.0*x2;
    double x190 = -3.0*x54;
    double x191 = x14*(x182 + x190) + x183;
    double x192 = T*(-x184 + x186 + x191);
    double x193 = x116 + x122;
    double x194 = x130 + x43;
    double x195 = x110 + x135;
    double x196 = x147 + x185;
    double x197 = -7.0*x15 + x196;
    double x198 = T*(x191 + x197);
    double x199 = -6.9999999969999998*x15 + x196;
    double x200 = T*(x191 + x199);
    double x201 = n3*x181;
    double x202 = x77 + x85;
    double x203 = x202 + x65 + x76 - x79 + x81;
    double x204 = T*(x14*(x180 + x201) + x187 + x203 + x137/n3);
    double x205 = 16.628925236306479*x138 + 2.0*x4;
    double x206 = x14*(x190 + x201) + x203;
    double x207 = T*(x197 + x206);
    double x208 = x140 + x158 + 61000.0;
    double x209 = x144 + x43;
    double x210 = x110 + x146;
    double x211 = T*(x199 + x206);
    double x212 = x140 + x173 + 60700.0;
    double x213 = 2.0*n4*x41;
    double x214 = x14*x46;
    double x215 = 2.0*x14*x153 + x151*x214*(x12*x42 + x88) + x154 + x54*x61 - x152*x214/((x12)*(x12));
    double x216 = x215 - x77 + x82 + x86;
    double x217 = T*(x101 + x14*(x213 + x96) + x216 + x53 + x150/n4);
    double x218 = 16.628925236306479*x156 + 2.0*x6;
    double x219 = 2.9999999979999998*x15;
    double x220 = T*(x14*(x124 + x213) + x167 + x216 - x219);
    double x221 = x158 + x173 + 71000.0;
    double x222 = T*(x14*(5.9999999959999997*n5*x41 - 5.9999999959999997*x54) - x165*x166*x99 + 1.9999999980000001*x165*x94 + x170 + x202 + x215 + x219 + x79 - x81 + x98*(-0.66666666600000002*x54 + x97) + x169/n5);
    double x223 = 16.628925236306479*x171 + 2.0*x8;

if (x105) {
   result[0] = x15*(x102*x103 + x104) + x43 - x74*x75;
}
else {
   result[0] = x110 - x114*x75 + x15*(x102*x115 + x104);
}
if (x105) {
   result[1] = x130 + x131 + x15*(x116 + x123 + x127);
}
else {
   result[1] = x135 + x136 + x15*(x132 + x133 - 100.360125);
}
if (x105) {
   result[2] = x131 + x144 + x15*(x127 + x141);
}
else {
   result[2] = x136 + x146 + x15*(x132 + x141);
}
if (x105) {
   result[3] = x131 + x15*(x103*x149 + x159) + x162;
}
else {
   result[3] = x136 + x15*(x115*x149 + x159) + x164;
}
if (x105) {
   result[4] = x131 + x15*(x103*x168 + x174) + x177;
}
else {
   result[4] = x136 + x15*(x115*x168 + x174) + x179;
}
if (x105) {
   result[5] = -x129*x75 + x15*(-80.2881*T + x103*x188 + x189 + 401.44049999999999) + x43;
}
else {
   result[5] = x110 - x134*x75 + x15*(200.72024999999999*x107 + 0.66666666666666663*x108 + x115*x188 + x189 - 200.72024999999999);
}
if (x105) {
   result[6] = x144 + x15*(x103*x192 + x140 + x193 + 21300.720249999998) + x194;
}
else {
   result[6] = x146 + x15*(x115*x192 + x133 + x140 + 20999.639875000001) + x195;
}
if (x105) {
   result[7] = x15*(x103*x198 + x158 + x193 + 22900.720249999998) + x162 + x194;
}
else {
   result[7] = x15*(x115*x198 + x133 + x158 + 22599.639875000001) + x164 + x195;
}
if (x105) {
   result[8] = x15*(x103*x200 + x173 + x193 + 23100.720249999998) + x177 + x194;
}
else {
   result[8] = x15*(x115*x200 + x133 + x173 + 22799.639875000001) + x179 + x195;
}
if (x105) {
   result[9] = -x143*x75 + x15*(x103*x204 + x205) + x43;
}
else {
   result[9] = x110 - x145*x75 + x15*(x115*x204 + x205);
}
if (x105) {
   result[10] = x15*(x103*x207 + x208) + x162 + x209;
}
else {
   result[10] = x15*(x115*x207 + x208) + x164 + x210;
}
if (x105) {
   result[11] = x15*(x103*x211 + x212) + x177 + x209;
}
else {
   result[11] = x15*(x115*x211 + x212) + x179 + x210;
}
if (x105) {
   result[12] = x15*(x103*x217 + x218) - x161*x75 + x43;
}
else {
   result[12] = x110 + x15*(x115*x217 + x218) - x163*x75;
}
if (x105) {
   result[13] = x15*(x103*x220 + x221) + x162 + x177 + x43;
}
else {
   result[13] = x110 + x15*(x115*x220 + x221) + x164 + x179;
}
if (x105) {
   result[14] = x15*(x103*x222 + x223) - x176*x75 + x43;
}
else {
   result[14] = x110 + x15*(x115*x222 + x223) - x178*x75;
}
}
        
static void coder_d3gdn3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n3*x4;
    double x6 = (*endmember[3].mu0)(T, P);
    double x7 = n4*x6;
    double x8 = (*endmember[4].mu0)(T, P);
    double x9 = n5*x8;
    double x10 = 40.14405*T;
    double x11 = x10 - 200.72024999999999;
    double x12 = n4 + n5;
    double x13 = n1 + n2 + n3;
    double x14 = x12 + x13;
    double x15 = 1.0/x14;
    double x16 = n2*x15;
    double x17 = 3.0*log(x16);
    double x18 = n3*x15;
    double x19 = 3.0*log(x18);
    double x20 = log(n4*x15);
    double x21 = 1.0*n4;
    double x22 = n5*x15;
    double x23 = log(x22);
    double x24 = 1.0*n5;
    double x25 = 1.0*log(x12*x15);
    double x26 = 2.0*log(x13*x15);
    double x27 = 3.0*n1 + 3.0*n4 + 0.99999999900000003*n5;
    double x28 = 1.0*n1;
    double x29 = 0.33333333300000001*n5 + x21 + x28;
    double x30 = log(x15*x29);
    double x31 = n2*x17 + n3*x19 + 1.9999999980000001*n5*(x23 - 0.40546510910816402) + x12*x25 + x13*x26 + x20*x21 + x23*x24 + x27*x30;
    double x32 = 8.3144626181532395*T;
    double x33 = x31*x32;
    double x34 = 1.0*x14;
    double x35 = 0.10299999999999999*P + 21100.0;
    double x36 = 8.0*x35;
    double x37 = 181600.0*n4 + 183200.0*n5;
    double x38 = 0.0625*n1;
    double x39 = 0.0625*n3;
    double x40 = 0.0625*n2*(168800.0*n3 + x37) + 0.0625*n4*(181600.0*n1 + 181600.0*n2 + 488000.0*n3 + 568000.0*n5) + 0.0625*n5*(183200.0*n1 + 183200.0*n2 + 485600.0*n3 + 568000.0*n4) + x38*(n3*x36 + x37) + x39*(n1*x36 + 168800.0*n2 + 488000.0*n4 + 485600.0*n5);
    double x41 = pow(x14, -4);
    double x42 = 6*x41;
    double x43 = -x42*(x34*(-n2*x11 + x1 + x3 + x33 + x5 + x7 + x9) + x40);
    double x44 = 1.0*n2;
    double x45 = 1.0*n3;
    double x46 = x21 + x24;
    double x47 = x28 + x44 + x45 + x46;
    double x48 = -x15*x21;
    double x49 = -3.0*x16;
    double x50 = -3.0*x18;
    double x51 = x48 + x49 + x50;
    double x52 = -2.9999999979999998*x22;
    double x53 = 1.0/x29;
    double x54 = 1.0*x15;
    double x55 = pow(x14, -2);
    double x56 = -x29*x55;
    double x57 = x54 + x56;
    double x58 = x53*x57;
    double x59 = x27*x58;
    double x60 = x14*x59 + 3.0*x30 + x52;
    double x61 = 2.0*n1 + 2.0*n2 + 2.0*n3;
    double x62 = 1.0/x13;
    double x63 = -x13*x55 + x15;
    double x64 = x62*x63;
    double x65 = x61*x64;
    double x66 = x14*x65 - x15*x46 + x26;
    double x67 = x51 + x60 + x66;
    double x68 = x32*x67;
    double x69 = x0*x28 + x2*x44 + x21*x6 + x24*x8 + x33 + x4*x45;
    double x70 = -x11*x44 + x69;
    double x71 = 0.82399999999999995*P + 168800.0;
    double x72 = 0.5*x35;
    double x73 = 22700.0*n4 + 22900.0*n5;
    double x74 = n3*x72 + x39*x71 + x73;
    double x75 = x47*(x0 + x68) + x70 + x74;
    double x76 = pow(x14, -3);
    double x77 = 6*x76;
    double x78 = x46*x55;
    double x79 = x21*x55;
    double x80 = 3.0*x55;
    double x81 = n3*x80;
    double x82 = n5*x55;
    double x83 = 2.9999999979999998*x82;
    double x84 = x81 + x83;
    double x85 = x65 + x78 + x79 + x84;
    double x86 = n2*x80;
    double x87 = x59 + x86;
    double x88 = x85 + x87;
    double x89 = 4.0*x64;
    double x90 = 2*x55;
    double x91 = -x90;
    double x92 = 2*x76;
    double x93 = x13*x92;
    double x94 = x91 + x93;
    double x95 = x61*x62;
    double x96 = x94*x95;
    double x97 = pow(x13, -2);
    double x98 = x63*x97;
    double x99 = x61*x98;
    double x100 = x14*x89 + x14*x96 - x14*x99;
    double x101 = x100 + x88;
    double x102 = 6.0*x58;
    double x103 = 2.0*x55;
    double x104 = -x103;
    double x105 = x29*x92;
    double x106 = x104 + x105;
    double x107 = x27*x53;
    double x108 = x106*x107;
    double x109 = pow(x29, -2);
    double x110 = x109*x57;
    double x111 = x110*x27;
    double x112 = x102*x14 + x108*x14 - x111*x34;
    double x113 = x101 + x112;
    double x114 = x113*x32;
    double x115 = 16.628925236306479*T;
    double x116 = 2.0*x0 + x115*x67;
    double x117 = x55*(x114*x47 + x116);
    double x118 = 24.943387854459719*T;
    double x119 = x113*x118;
    double x120 = 9.0*x14;
    double x121 = x106*x53;
    double x122 = 6.0*x76;
    double x123 = -x29*x42;
    double x124 = x107*x14;
    double x125 = 2.0*x14;
    double x126 = x125*x27;
    double x127 = pow(x29, -3);
    double x128 = x127*x57;
    double x129 = x106*x109;
    double x130 = 2*x108 - x110*x120 - 2.0*x111 + x120*x121 + x124*(x122 + x123) + x126*x128 - x126*x129 + 9.0*x58;
    double x131 = n3*x122;
    double x132 = -x131;
    double x133 = n5*x76;
    double x134 = 5.9999999959999997*x133;
    double x135 = -x134;
    double x136 = x132 + x135;
    double x137 = -x46*x92;
    double x138 = 2.0*x76;
    double x139 = n4*x138;
    double x140 = -x139;
    double x141 = n2*x122;
    double x142 = -x141;
    double x143 = x140 + x142;
    double x144 = x137 + x143;
    double x145 = 6.0*x14;
    double x146 = -x13*x42;
    double x147 = x14*x95;
    double x148 = x61*x97;
    double x149 = 2*x14;
    double x150 = x145*x62*x94 - x145*x98 + x147*(x146 + x77) - x148*x149*x94 + 6.0*x64 + 2*x96 - 2*x99 + x149*x61*x63/((x13)*(x13)*(x13));
    double x151 = x144 + x150;
    double x152 = x136 + x151;
    double x153 = x130 + x152;
    double x154 = x32*x47;
    double x155 = T >= 7.5;
    double x156 = fmin(4, 1.0*sqrt(1 - 0.13333333333333333*T));
    double x157 = ((x156)*(x156)*(x156));
    double x158 = (120.43215000000001*T - 903.24112500000001)*(x156 - 1);
    double x159 = 301.080375*x157 + x158 - 301.080375;
    double x160 = -x42*(0.33333333333333331*x14*(n2*x159 + 3*x1 + x118*x31 + 3*x3 + 3*x5 + 3*x7 + 3*x9) + x40);
    double x161 = 0.33333333333333331*n2;
    double x162 = 0.33333333333333331*n1 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5 + x161;
    double x163 = x159*x161 + x69;
    double x164 = x162*(3*x0 + x118*x67) + x163 + x74;
    double x165 = x55*(x116 + x119*x162);
    double x166 = x118*x162;
    double x167 = -n2*x55 + x15;
    double x168 = 3.0*x14;
    double x169 = x167*x168;
    double x170 = -x15*x27 + x48 + x52 + x66;
    double x171 = x169 + x17 + x170 + x50;
    double x172 = x171*x32;
    double x173 = -x10 + x172;
    double x174 = x173 + 200.72024999999999;
    double x175 = 21100.0*n3 + x73;
    double x176 = x175 + x47*(x174 + x2) + x70;
    double x177 = x176*x92;
    double x178 = 1.0*x2;
    double x179 = -1.0*x55;
    double x180 = x105 + x179;
    double x181 = x107*x180;
    double x182 = x101 + x14*x181 - 6.0*x15;
    double x183 = x182*x32;
    double x184 = 1.0*x0 + x68;
    double x185 = x183*x47 + x184;
    double x186 = x174 + x178 + x185;
    double x187 = -x186*x90 + x43;
    double x188 = x145*x53;
    double x189 = 4.0*x76;
    double x190 = x109*x27*x34;
    double x191 = x108 - 1.0*x111 + x124*(x123 + x189) - x180*x190;
    double x192 = x102 + x152 + x180*x188 + x181 + x191 + x80;
    double x193 = x115*x182;
    double x194 = x114 + x193;
    double x195 = 4*x76;
    double x196 = -x117 + x195*x75;
    double x197 = x15*(x154*x192 + x194) + x196;
    double x198 = x162*(x118*x171 + x159 + 3*x2) + x163 + x175;
    double x199 = x198*x92;
    double x200 = x166*x182 + x184;
    double x201 = 100.360125*x157 + 0.33333333333333331*x158 + x172 + x178;
    double x202 = x200 + x201 - 100.360125;
    double x203 = x160 - x202*x90;
    double x204 = x164*x195 - x165;
    double x205 = x15*(x166*x192 + x194) + x204;
    double x206 = -n3*x55 + x15;
    double x207 = x168*x206;
    double x208 = x170 + x19 + x207 + x49;
    double x209 = x208*x32;
    double x210 = n1*x72 + 21100.0*n2 + 61000.0*n4 + 60700.0*n5 + x38*x71;
    double x211 = x210 + x47*(x209 + x4) + x70;
    double x212 = x211*x92;
    double x213 = x209 + 1.0*x4;
    double x214 = x213 + x35;
    double x215 = x185 + x214;
    double x216 = -x215*x90 + x43;
    double x217 = x162*(x118*x208 + 3*x4) + x163 + x210;
    double x218 = x217*x92;
    double x219 = x200 + x214;
    double x220 = x160 - x219*x90;
    double x221 = -x55;
    double x222 = x221 + x93;
    double x223 = x222*x95;
    double x224 = x14*x222;
    double x225 = x147*(x146 + x195) - x148*x224 + x223 + 4.0*x224*x62 + x89 + x96 - x99;
    double x226 = x136 + x144;
    double x227 = x225 + x226;
    double x228 = x103 + x130 + x227;
    double x229 = x14*x223;
    double x230 = x229 + x88;
    double x231 = x112 - 4.0*x15 + x230;
    double x232 = x115*x231;
    double x233 = x114 + x232;
    double x234 = x231*x32;
    double x235 = -n4*x55 + x15;
    double x236 = x235*x34;
    double x237 = 1.0/x12;
    double x238 = -x12*x55 + x15;
    double x239 = x237*x238;
    double x240 = x239*x46;
    double x241 = x14*x240 - x15*x61 + x25;
    double x242 = 1.0*x20 + x236 + x241 + x49 + x50 + x60;
    double x243 = x242*x32;
    double x244 = x243 + 1.0*x6;
    double x245 = x184 + x244 + 22700.0;
    double x246 = x234*x47 + x245;
    double x247 = -x246*x90;
    double x248 = 22700.0*n1 + 22700.0*n2 + 61000.0*n3 + 71000.0*n5;
    double x249 = x248 + x47*(x243 + x6) + x70;
    double x250 = x249*x92;
    double x251 = x196 + x43;
    double x252 = x166*x231 + x245;
    double x253 = -x252*x90;
    double x254 = x162*(x118*x242 + 3*x6) + x163 + x248;
    double x255 = x254*x92;
    double x256 = x160 + x204;
    double x257 = x105 - 1.3333333330000001*x55;
    double x258 = x107*x257;
    double x259 = 0.99999999900000003*x14;
    double x260 = x110*x14;
    double x261 = 0.66666666600000002*x27;
    double x262 = x128*x14;
    double x263 = 0.33333333300000001*x27;
    double x264 = x14*x263;
    double x265 = x108 - 1.3333333330000001*x111 + x121*x259 + x124*(x123 + 4.6666666660000002*x76) - x129*x264 + x188*x257 - x190*x257 + x258 - 2.9999999970000002*x260 + x261*x262 + 6.9999999989999999*x58;
    double x266 = x227 + x265 + 3.9999999979999998*x55;
    double x267 = 0.33333333300000001*x15 + x56;
    double x268 = x267*x53;
    double x269 = 0.99999999900000003*x58;
    double x270 = 0.33333333300000001*x111;
    double x271 = x14*x258 + x14*x269 - x14*x270 + x168*x268;
    double x272 = -5.9999999979999998*x15 + x230 + x271;
    double x273 = x115*x272;
    double x274 = x114 + x273;
    double x275 = x272*x32;
    double x276 = 2.9999999979999998*x15 - 2.9999999979999998*x82;
    double x277 = x14*x276;
    double x278 = x107*x267;
    double x279 = x14*x278 + 2.9999999979999998*x23 + x241 + x277 + 0.99999999900000003*x30 + x51 - 0.81093021740539784;
    double x280 = x279*x32;
    double x281 = x280 + 1.0*x8;
    double x282 = x184 + x281 + 22900.0;
    double x283 = x275*x47 + x282;
    double x284 = -x283*x90;
    double x285 = 22900.0*n1 + 22900.0*n2 + 60700.0*n3 + 71000.0*n4;
    double x286 = x285 + x47*(x280 + x8) + x70;
    double x287 = x286*x92;
    double x288 = x166*x272 + x282;
    double x289 = -x288*x90;
    double x290 = x162*(x118*x279 + 3*x8) + x163 + x285;
    double x291 = x290*x92;
    double x292 = 9.0*x55;
    double x293 = x136 + x292;
    double x294 = x124*(x123 + x138) + x151 + 2*x181 + x293;
    double x295 = x154*x294;
    double x296 = 6.0*x55;
    double x297 = -x296;
    double x298 = 1.0/n2;
    double x299 = x85 - x86;
    double x300 = 3.0*x15;
    double x301 = x27*x55;
    double x302 = x100 + x301;
    double x303 = x300 + x302;
    double x304 = x14*(x141 + x297) + x169*x298 + x299 + x303;
    double x305 = x304*x32;
    double x306 = x193 + x305;
    double x307 = x75*x92;
    double x308 = x115*x171 + 2.0*x2;
    double x309 = x55*(-80.2881*T + x305*x47 + x308 + 401.44049999999999);
    double x310 = x176*x195 - x309;
    double x311 = x166*x294;
    double x312 = x164*x92;
    double x313 = x118*x304;
    double x314 = x55*(200.72024999999999*x157 + 0.66666666666666663*x158 + x162*x313 + x308 - 200.72024999999999);
    double x315 = x195*x198 - x314;
    double x316 = -x80;
    double x317 = x14*(x141 + x316) + x299;
    double x318 = -x300 + x302 + x317;
    double x319 = x318*x32;
    double x320 = x193 + x319;
    double x321 = -x215*x55;
    double x322 = x173 + x178;
    double x323 = x213 + x319*x47 + x322 + 21300.720249999998;
    double x324 = x212 - x323*x55;
    double x325 = x307 + x43;
    double x326 = x177 - x186*x55 + x325;
    double x327 = -x219*x55;
    double x328 = x166*x318 + x201 + x213 + 20999.639875000001;
    double x329 = x218 - x328*x55;
    double x330 = x160 + x312;
    double x331 = x199 - x202*x55 + x330;
    double x332 = x180*x53;
    double x333 = x181 + x227;
    double x334 = x168*x332 + x191 + x333 + 8.0*x55 + 3.0*x58;
    double x335 = x154*x334;
    double x336 = x229 + x301;
    double x337 = -7.0*x15 + x336;
    double x338 = x317 + x337;
    double x339 = x32*x338;
    double x340 = x183 + x234;
    double x341 = x339 + x340;
    double x342 = x244 + x322 + x339*x47 + 22900.720249999998;
    double x343 = -x342*x55;
    double x344 = -x246*x55 + x250;
    double x345 = x166*x334;
    double x346 = x166*x338 + x201 + x244 + 22599.639875000001;
    double x347 = -x346*x55;
    double x348 = -x252*x55 + x255;
    double x349 = -x109*x180*x264 + x124*(x123 + 2.6666666660000002*x76) + x258 + x259*x332 + x269 - x270 + x333 + 9.9999999979999998*x55;
    double x350 = x154*x349;
    double x351 = -6.9999999969999998*x15 + x336;
    double x352 = x317 + x351;
    double x353 = x32*x352;
    double x354 = x183 + x275;
    double x355 = x353 + x354;
    double x356 = x281 + x322 + x353*x47 + 23100.720249999998;
    double x357 = -x356*x55;
    double x358 = -x283*x55 + x287;
    double x359 = x166*x349;
    double x360 = x166*x352 + x201 + x281 + 22799.639875000001;
    double x361 = -x360*x55;
    double x362 = -x288*x55 + x291;
    double x363 = 1.0/n3;
    double x364 = x79 + x86;
    double x365 = x364 + x65 + x78 - x81 + x83;
    double x366 = x14*(x131 + x297) + x207*x363 + x303 + x365;
    double x367 = x32*x366;
    double x368 = x193 + x367;
    double x369 = x115*x208 + 2.0*x4;
    double x370 = x55*(x367*x47 + x369);
    double x371 = x195*x211 - x370;
    double x372 = x118*x366;
    double x373 = x55*(x162*x372 + x369);
    double x374 = x195*x217 - x373;
    double x375 = x14*(x131 + x316) + x365;
    double x376 = x337 + x375;
    double x377 = x32*x376;
    double x378 = x340 + x377;
    double x379 = x213 + x244 + 61000.0;
    double x380 = x377*x47 + x379;
    double x381 = -x380*x55;
    double x382 = x325 + x344;
    double x383 = x212 + x321;
    double x384 = x166*x376 + x379;
    double x385 = -x384*x55;
    double x386 = x330 + x348;
    double x387 = x218 + x327;
    double x388 = x351 + x375;
    double x389 = x32*x388;
    double x390 = x354 + x389;
    double x391 = x213 + x281 + 60700.0;
    double x392 = x389*x47 + x391;
    double x393 = -x392*x55;
    double x394 = x166*x388 + x391;
    double x395 = -x394*x55;
    double x396 = 2*x223;
    double x397 = x147*(x146 + x92);
    double x398 = x226 + x396 + x397;
    double x399 = x130 + x296 + x398;
    double x400 = 1.0/n4;
    double x401 = x14*x46;
    double x402 = x12*x92 + x91;
    double x403 = x237*x402;
    double x404 = pow(x12, -2);
    double x405 = x238*x404;
    double x406 = x125*x239 + x240 + x401*x403 - x401*x405 + x55*x61;
    double x407 = x406 - x79 + x84 + x87;
    double x408 = x112 + x14*(x104 + x139) + x236*x400 + x407 + x54;
    double x409 = x32*x408;
    double x410 = x232 + x409;
    double x411 = x115*x242 + 2.0*x6;
    double x412 = x55*(x409*x47 + x411);
    double x413 = x195*x249 - x412;
    double x414 = x118*x408;
    double x415 = x55*(x162*x414 + x411);
    double x416 = x195*x254 - x415;
    double x417 = x265 + x398 + 7.9999999979999998*x55;
    double x418 = 2.9999999979999998*x15;
    double x419 = x14*(x139 + x179) + x271 + x407 - x418;
    double x420 = x32*x419;
    double x421 = x234 + x275 + x420;
    double x422 = x244 + x281 + 71000.0;
    double x423 = x420*x47 + x422;
    double x424 = -x423*x55;
    double x425 = x166*x419 + x422;
    double x426 = -x425*x55;
    double x427 = x105 - 0.66666666600000002*x55;
    double x428 = x427*x53;
    double x429 = 1.9999999980000001*x14;
    double x430 = x109*x267;
    double x431 = 0.22222222177777778*x27;
    double x432 = x109*x14*x261;
    double x433 = -0.66666666600000002*x111 + x124*(x123 + 3.3333333320000005*x76) + x168*x428 + x257*x429*x53 - x257*x432 + 2*x258 - x259*x430 - 0.66666666533333341*x260 + x262*x431 + 3.0*x268 + 1.9999999980000001*x58;
    double x434 = x398 + x433 + 9.9999999959999997*x55;
    double x435 = 1.0/n5;
    double x436 = x14*x430;
    double x437 = x124*x427 + x14*(x134 - 5.9999999959999997*x55) - x263*x436 + x268*x429 + x277*x435 + x278 + x364 + x406 + x418 + x81 - x83;
    double x438 = x32*x437;
    double x439 = x273 + x438;
    double x440 = x115*x279 + 2.0*x8;
    double x441 = x55*(x438*x47 + x440);
    double x442 = x195*x286 - x441;
    double x443 = x118*x437;
    double x444 = x55*(x162*x443 + x440);
    double x445 = x195*x290 - x444;
    double x446 = 18.0*x76;
    double x447 = 18.0*x41;
    double x448 = -n2*x447;
    double x449 = n2*x92;
    double x450 = x168*x298;
    double x451 = 12.0*x76;
    double x452 = n2*x451;
    double x453 = x137 + x140 - x27*x92;
    double x454 = x136 + x453;
    double x455 = 3.0*x167*x298 + x452 + x454;
    double x456 = x150 - 12.0*x55;
    double x457 = x14*(x446 + x448) + x450*(x449 + x91) + x455 + x456 - x169/((n2)*(n2));
    double x458 = x14*(x448 + x451) + x450*(x221 + x449) + x455;
    double x459 = x150 + x297 + x458;
    double x460 = x115*x318;
    double x461 = x305 + x460;
    double x462 = -x323*x90;
    double x463 = x310 + x43;
    double x464 = -x328*x90;
    double x465 = x160 + x315;
    double x466 = -4.0*x55;
    double x467 = x225 + x466;
    double x468 = x458 + x467;
    double x469 = x115*x338;
    double x470 = x305 + x469;
    double x471 = -x342*x90;
    double x472 = -x346*x90;
    double x473 = x225 - 4.0000000030000002*x55;
    double x474 = x458 + x473;
    double x475 = x115*x352;
    double x476 = x305 + x475;
    double x477 = -x356*x90;
    double x478 = -x360*x90;
    double x479 = x14*(x122 + x448) + x452;
    double x480 = x454 + x479;
    double x481 = x150 + x480 + x80;
    double x482 = x367 + x460;
    double x483 = x177 + x43;
    double x484 = x160 + x199;
    double x485 = x225 + x480;
    double x486 = x485 + 5.0*x55;
    double x487 = x319 + x339 + x377;
    double x488 = x324 + x483;
    double x489 = x250 + x381;
    double x490 = x329 + x484;
    double x491 = x255 + x385;
    double x492 = x485 + 4.9999999969999998*x55;
    double x493 = x319 + x353 + x389;
    double x494 = x287 + x357;
    double x495 = x291 + x361;
    double x496 = x396 + x397 + x453;
    double x497 = x479 + x496;
    double x498 = x293 + x497;
    double x499 = x409 + x469;
    double x500 = 8.9999999969999998*x55;
    double x501 = x136 + x497;
    double x502 = x500 + x501;
    double x503 = x339 + x353 + x420;
    double x504 = 8.9999999939999995*x55;
    double x505 = x501 + x504;
    double x506 = x438 + x475;
    double x507 = -n3*x447;
    double x508 = n3*x92;
    double x509 = x168*x363;
    double x510 = n3*x451 + x135 + x142;
    double x511 = 3.0*x206*x363 + x453 + x510;
    double x512 = x14*(x446 + x507) + x456 + x509*(x508 + x91) + x511 - x207/((n3)*(n3));
    double x513 = x14*(x451 + x507) + x509*(x221 + x508) + x511;
    double x514 = x467 + x513;
    double x515 = x115*x376;
    double x516 = x367 + x515;
    double x517 = -x380*x90;
    double x518 = x371 + x43;
    double x519 = -x384*x90;
    double x520 = x160 + x374;
    double x521 = x473 + x513;
    double x522 = x115*x388;
    double x523 = x367 + x522;
    double x524 = -x392*x90;
    double x525 = -x394*x90;
    double x526 = x14*(x122 + x507) + x496 + x510;
    double x527 = x292 + x526;
    double x528 = x409 + x515;
    double x529 = x212 + x43;
    double x530 = x160 + x218;
    double x531 = x500 + x526;
    double x532 = x377 + x389 + x420;
    double x533 = x504 + x526;
    double x534 = x438 + x522;
    double x535 = -6.0*n4*x41;
    double x536 = n4*x92;
    double x537 = x34*x400;
    double x538 = 2*x46;
    double x539 = 2*x401;
    double x540 = x168*x403 - x168*x405 + x237*x401*(-x12*x42 + x77) + 3.0*x239 - x402*x404*x539 + x403*x538 - x405*x538 - x61*x92 + x238*x539/((x12)*(x12)*(x12));
    double x541 = n4*x189 + x136 + x142 + x540;
    double x542 = 1.0*x235*x400 + x541;
    double x543 = x130 + x14*(x122 + x535) + x466 + x537*(x536 + x91) + x542 - x236/((n4)*(n4));
    double x544 = x14*(x189 + x535) + x265 + x537*(x221 + x536) + x542 - 2.000000165480742e-9*x55;
    double x545 = x115*x419;
    double x546 = x409 + x545;
    double x547 = -x423*x90 + x43;
    double x548 = x160 - x425*x90;
    double x549 = x14*(x138 + x535) + x433 + x541 + 4.9999999959999997*x55;
    double x550 = x438 + x545;
    double x551 = 2*x107*x427 + x124*(x123 + 1.9999999980000001*x76) + x127*x14*x267*x431 + x132 + 11.999999991999999*x133 + 2.9999999970000002*x14*x428 + 2.9999999979999998*x14*x435*(n5*x92 + x91) + x14*(-17.999999987999999*n5*x41 + 17.999999987999999*x76) + x143 - x261*x430 + 2.9999999970000002*x268 + x276*x435 - x427*x432 - 0.99999999800000006*x436 + x540 - 11.999999991999999*x55 - x277/((n5)*(n5));

if (x155) {
   result[0] = -3*x117 + x15*(x119 + x153*x154) + x43 + x75*x77;
}
else {
   result[0] = x15*(x119 + x153*x166) + x160 + x164*x77 - 3*x165;
}
if (x155) {
   result[1] = x177 + x187 + x197;
}
else {
   result[1] = x199 + x203 + x205;
}
if (x155) {
   result[2] = x197 + x212 + x216;
}
else {
   result[2] = x205 + x218 + x220;
}
if (x155) {
   result[3] = x15*(x154*x228 + x233) + x247 + x250 + x251;
}
else {
   result[3] = x15*(x166*x228 + x233) + x253 + x255 + x256;
}
if (x155) {
   result[4] = x15*(x154*x266 + x274) + x251 + x284 + x287;
}
else {
   result[4] = x15*(x166*x266 + x274) + x256 + x289 + x291;
}
if (x155) {
   result[5] = x15*(x295 + x306) + x187 + x307 + x310;
}
else {
   result[5] = x15*(x306 + x311) + x203 + x312 + x315;
}
if (x155) {
   result[6] = x15*(x295 + x320) + x321 + x324 + x326;
}
else {
   result[6] = x15*(x311 + x320) + x327 + x329 + x331;
}
if (x155) {
   result[7] = x15*(x335 + x341) + x326 + x343 + x344;
}
else {
   result[7] = x15*(x341 + x345) + x331 + x347 + x348;
}
if (x155) {
   result[8] = x15*(x350 + x355) + x326 + x357 + x358;
}
else {
   result[8] = x15*(x355 + x359) + x331 + x361 + x362;
}
if (x155) {
   result[9] = x15*(x295 + x368) + x216 + x307 + x371;
}
else {
   result[9] = x15*(x311 + x368) + x220 + x312 + x374;
}
if (x155) {
   result[10] = x15*(x335 + x378) + x381 + x382 + x383;
}
else {
   result[10] = x15*(x345 + x378) + x385 + x386 + x387;
}
if (x155) {
   result[11] = x15*(x350 + x390) + x325 + x358 + x383 + x393;
}
else {
   result[11] = x15*(x359 + x390) + x330 + x362 + x387 + x395;
}
if (x155) {
   result[12] = x15*(x154*x399 + x410) + x247 + x325 + x413;
}
else {
   result[12] = x15*(x166*x399 + x410) + x253 + x330 + x416;
}
if (x155) {
   result[13] = x15*(x154*x417 + x421) + x358 + x382 + x424;
}
else {
   result[13] = x15*(x166*x417 + x421) + x362 + x386 + x426;
}
if (x155) {
   result[14] = x15*(x154*x434 + x439) + x284 + x325 + x442;
}
else {
   result[14] = x15*(x166*x434 + x439) + x289 + x330 + x445;
}
if (x155) {
   result[15] = x15*(x154*x457 + x313) + x176*x77 - 3*x309 + x43;
}
else {
   result[15] = x15*(x166*x457 + x313) + x160 + x198*x77 - 3*x314;
}
if (x155) {
   result[16] = x15*(x154*x459 + x461) + x212 + x462 + x463;
}
else {
   result[16] = x15*(x166*x459 + x461) + x218 + x464 + x465;
}
if (x155) {
   result[17] = x15*(x154*x468 + x470) + x250 + x463 + x471;
}
else {
   result[17] = x15*(x166*x468 + x470) + x255 + x465 + x472;
}
if (x155) {
   result[18] = x15*(x154*x474 + x476) + x287 + x463 + x477;
}
else {
   result[18] = x15*(x166*x474 + x476) + x291 + x465 + x478;
}
if (x155) {
   result[19] = x15*(x154*x481 + x482) + x371 + x462 + x483;
}
else {
   result[19] = x15*(x166*x481 + x482) + x374 + x464 + x484;
}
if (x155) {
   result[20] = x15*(x154*x486 + x487) + x343 + x488 + x489;
}
else {
   result[20] = x15*(x166*x486 + x487) + x347 + x490 + x491;
}
if (x155) {
   result[21] = x15*(x154*x492 + x493) + x393 + x488 + x494;
}
else {
   result[21] = x15*(x166*x492 + x493) + x395 + x490 + x495;
}
if (x155) {
   result[22] = x15*(x154*x498 + x499) + x413 + x471 + x483;
}
else {
   result[22] = x15*(x166*x498 + x499) + x416 + x472 + x484;
}
if (x155) {
   result[23] = x15*(x154*x502 + x503) + x250 + x343 + x424 + x483 + x494;
}
else {
   result[23] = x15*(x166*x502 + x503) + x255 + x347 + x426 + x484 + x495;
}
if (x155) {
   result[24] = x15*(x154*x505 + x506) + x442 + x477 + x483;
}
else {
   result[24] = x15*(x166*x505 + x506) + x445 + x478 + x484;
}
if (x155) {
   result[25] = x15*(x154*x512 + x372) + x211*x77 - 3*x370 + x43;
}
else {
   result[25] = x15*(x166*x512 + x372) + x160 + x217*x77 - 3*x373;
}
if (x155) {
   result[26] = x15*(x154*x514 + x516) + x250 + x517 + x518;
}
else {
   result[26] = x15*(x166*x514 + x516) + x255 + x519 + x520;
}
if (x155) {
   result[27] = x15*(x154*x521 + x523) + x287 + x518 + x524;
}
else {
   result[27] = x15*(x166*x521 + x523) + x291 + x520 + x525;
}
if (x155) {
   result[28] = x15*(x154*x527 + x528) + x413 + x517 + x529;
}
else {
   result[28] = x15*(x166*x527 + x528) + x416 + x519 + x530;
}
if (x155) {
   result[29] = x15*(x154*x531 + x532) + x287 + x393 + x424 + x489 + x529;
}
else {
   result[29] = x15*(x166*x531 + x532) + x291 + x395 + x426 + x491 + x530;
}
if (x155) {
   result[30] = x15*(x154*x533 + x534) + x442 + x524 + x529;
}
else {
   result[30] = x15*(x166*x533 + x534) + x445 + x525 + x530;
}
if (x155) {
   result[31] = x15*(x154*x543 + x414) + x249*x77 - 3*x412 + x43;
}
else {
   result[31] = x15*(x166*x543 + x414) + x160 + x254*x77 - 3*x415;
}
if (x155) {
   result[32] = x15*(x154*x544 + x546) + x287 + x413 + x547;
}
else {
   result[32] = x15*(x166*x544 + x546) + x291 + x416 + x548;
}
if (x155) {
   result[33] = x15*(x154*x549 + x550) + x250 + x442 + x547;
}
else {
   result[33] = x15*(x166*x549 + x550) + x255 + x445 + x548;
}
if (x155) {
   result[34] = x15*(x154*x551 + x443) + x286*x77 + x43 - 3*x441;
}
else {
   result[34] = x15*(x166*x551 + x443) + x160 + x290*x77 - 3*x444;
}
}
        
static double coder_dgdt(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n4 + n5;
    double x1 = n1 + n2 + n3;
    double x2 = 1.0/(x0 + x1);
    double x3 = 1.0*n1 + 1.0*n4;
    double x4 = n1*(*endmember[0].dmu0dT)(T, P);
    double x5 = n2*(*endmember[1].dmu0dT)(T, P);
    double x6 = n3*(*endmember[2].dmu0dT)(T, P);
    double x7 = n4*(*endmember[3].dmu0dT)(T, P);
    double x8 = n5*(*endmember[4].dmu0dT)(T, P);
    double x9 = n2*log(n2*x2);
    double x10 = n3*log(n3*x2);
    double x11 = n4*log(n4*x2);
    double x12 = log(n5*x2);
    double x13 = n5*x12;
    double x14 = n5*(x12 - 0.40546510910816402);
    double x15 = x0*log(x0*x2);
    double x16 = x1*log(x1*x2);
    double x17 = (3.0*n1 + 3.0*n4 + 0.99999999900000003*n5)*log(x2*(0.33333333300000001*n5 + x3));
    double x18 = sqrt(1 - 0.13333333333333333*T);
    double x19 = 1.0*x18;
    double x20 = fmin(4, x19);
    double x21 = (4 - x19 >= 0. ? 1. : 0.)/x18;

if (T >= 7.5) {
   result = x2*(1.0*n2 + 1.0*n3 + 1.0*n5 + x3)*(-40.14405*n2 + 24.943387854459719*x10 + 8.3144626181532395*x11 + 8.3144626181532395*x13 + 16.628925219677555*x14 + 8.3144626181532395*x15 + 16.628925236306479*x16 + 8.3144626181532395*x17 + x4 + x5 + x6 + x7 + x8 + 24.943387854459719*x9);
}
else {
   result = x2*(0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5)*(n2*(-60.216075000000004*((x20)*(x20))*x21 + 120.43215000000001*x20 - 0.066666666666666666*x21*(120.43215000000001*T - 903.24112500000001) - 120.43215000000001) + 74.830163563379159*x10 + 24.943387854459719*x11 + 24.943387854459719*x13 + 49.886775659032665*x14 + 24.943387854459719*x15 + 49.886775708919437*x16 + 24.943387854459719*x17 + 3*x4 + 3*x5 + 3*x6 + 3*x7 + 3*x8 + 74.830163563379159*x9);
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = n4 + n5;
    double x2 = n1 + n2 + n3;
    double x3 = x1 + x2;
    double x4 = 1.0/x3;
    double x5 = n4*x4;
    double x6 = -8.3144626181532395*x5;
    double x7 = n2*x4;
    double x8 = -24.943387854459719*x7;
    double x9 = n3*x4;
    double x10 = -24.943387854459719*x9;
    double x11 = x10 + x6 + x8;
    double x12 = 1.0*n1 + 1.0*n4;
    double x13 = 0.33333333300000001*n5 + x12;
    double x14 = log(x13*x4);
    double x15 = 24.943387854459719*x14;
    double x16 = n5*x4;
    double x17 = -24.943387837830794*x16;
    double x18 = 24.943387854459719*n4;
    double x19 = 24.943387854459719*n1 + 8.3144626098387775*n5 + x18;
    double x20 = 1.0*x4;
    double x21 = pow(x3, -2);
    double x22 = -x13*x21;
    double x23 = x3/x13;
    double x24 = x23*(x20 + x22);
    double x25 = x15 + x17 + x19*x24;
    double x26 = log(x2*x4);
    double x27 = 16.628925236306479*x26;
    double x28 = 8.3144626181532395*n4;
    double x29 = 8.3144626181532395*n5;
    double x30 = x28 + x29;
    double x31 = 16.628925236306479*n1 + 16.628925236306479*n2 + 16.628925236306479*n3;
    double x32 = x3*(-x2*x21 + x4)/x2;
    double x33 = x27 - x30*x4 + x31*x32;
    double x34 = 1.0*n2 + 1.0*n3 + 1.0*n5 + x12;
    double x35 = x34*x4;
    double x36 = n1*x0;
    double x37 = (*endmember[1].dmu0dT)(T, P);
    double x38 = n2*x37;
    double x39 = (*endmember[2].dmu0dT)(T, P);
    double x40 = n3*x39;
    double x41 = (*endmember[3].dmu0dT)(T, P);
    double x42 = n4*x41;
    double x43 = (*endmember[4].dmu0dT)(T, P);
    double x44 = n5*x43;
    double x45 = log(x7);
    double x46 = 24.943387854459719*x45;
    double x47 = log(x9);
    double x48 = 24.943387854459719*x47;
    double x49 = log(x5);
    double x50 = log(x16);
    double x51 = n5*(x50 - 0.40546510910816402);
    double x52 = log(x1*x4);
    double x53 = 8.3144626181532395*x52;
    double x54 = 3.0*n1 + 3.0*n4 + 0.99999999900000003*n5;
    double x55 = n2*x46 - 40.14405*n2 + n3*x48 + x1*x53 + 8.3144626181532395*x14*x54 + x2*x27 + x28*x49 + x29*x50 + x36 + x38 + x40 + x42 + x44 + 16.628925219677555*x51;
    double x56 = x20*x55 - x21*x34*x55;
    double x57 = T >= 7.5;
    double x58 = -74.830163563379159*x7;
    double x59 = -74.830163563379159*x9;
    double x60 = -24.943387854459719*x5;
    double x61 = x58 + x59 + x60;
    double x62 = -74.83016351349238*x16;
    double x63 = 74.830163563379159*n1 + 74.830163563379159*n4 + 24.943387829516332*n5;
    double x64 = 74.830163563379159*x14 + x24*x63 + x62;
    double x65 = 49.886775708919437*x26;
    double x66 = 24.943387854459719*n5;
    double x67 = x18 + x66;
    double x68 = 49.886775708919437*n1 + 49.886775708919437*n2 + 49.886775708919437*n3;
    double x69 = x32*x68 - x4*x67 + x65;
    double x70 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5;
    double x71 = x4*x70;
    double x72 = 74.830163563379159*x45;
    double x73 = 74.830163563379159*x47;
    double x74 = 24.943387854459719*x52;
    double x75 = sqrt(1 - 0.13333333333333333*T);
    double x76 = 1.0*x75;
    double x77 = fmin(4, x76);
    double x78 = (4 - x76 >= 0. ? 1. : 0.)/x75;
    double x79 = -60.216075000000004*((x77)*(x77))*x78 + 120.43215000000001*x77 - 0.066666666666666666*x78*(120.43215000000001*T - 903.24112500000001) - 120.43215000000001;
    double x80 = n2*x72 + n2*x79 + n3*x73 + x1*x74 + x15*x54 + x18*x49 + x2*x65 + 3*x36 + 3*x38 + 3*x40 + 3*x42 + 3*x44 + x50*x66 + 49.886775659032665*x51;
    double x81 = -x21*x70*x80 + 0.33333333333333331*x4*x80;
    double x82 = x3*(-n2*x21 + x4);
    double x83 = x17 - x19*x4 + x33 + x6;
    double x84 = -x4*x63 + x60 + x62 + x69;
    double x85 = x3*(-n3*x21 + x4);
    double x86 = x3*(-n4*x21 + x4);
    double x87 = x3*(-x1*x21 + x4)/x1;
    double x88 = x30*x87 - x31*x4 + x53;
    double x89 = -x4*x68 + x67*x87 + x74;
    double x90 = x3*(-n5*x21 + x4);
    double x91 = x23*(x22 + 0.33333333300000001*x4);

if (x57) {
   result[0] = x35*(x0 + x11 + x25 + x33) + x56;
}
else {
   result[0] = x71*(3*x0 + x61 + x64 + x69) + x81;
}
if (x57) {
   result[1] = x35*(x10 + x37 + x46 + 24.943387854459719*x82 + x83 - 40.14405) + x56;
}
else {
   result[1] = x71*(3*x37 + x59 + x72 + x79 + 74.830163563379159*x82 + x84) + x81;
}
if (x57) {
   result[2] = x35*(x39 + x48 + x8 + x83 + 24.943387854459719*x85) + x56;
}
else {
   result[2] = x71*(3*x39 + x58 + x73 + x84 + 74.830163563379159*x85) + x81;
}
if (x57) {
   result[3] = x35*(x10 + x25 + x41 + 8.3144626181532395*x49 + x8 + 8.3144626181532395*x86 + x88) + x56;
}
else {
   result[3] = x71*(3*x41 + 24.943387854459719*x49 + x58 + x59 + x64 + 24.943387854459719*x86 + x89) + x81;
}
if (x57) {
   result[4] = x35*(x11 + 8.3144626098387775*x14 + x19*x91 + x43 + 24.943387837830794*x50 + x88 + 24.943387837830794*x90 - 6.7424489785480599) + x56;
}
else {
   result[4] = x71*(24.943387829516332*x14 + 3*x43 + 74.83016351349238*x50 + x61 + x63*x91 + x89 + 74.83016351349238*x90 - 20.227346935644182) + x81;
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = n4 + n5;
    double x2 = n1 + n2 + n3;
    double x3 = x1 + x2;
    double x4 = 1.0/x3;
    double x5 = 8.3144626181532395*n4;
    double x6 = -x4*x5;
    double x7 = n2*x4;
    double x8 = -24.943387854459719*x7;
    double x9 = n3*x4;
    double x10 = -24.943387854459719*x9;
    double x11 = x10 + x6 + x8;
    double x12 = 1.0*n1 + 1.0*n4;
    double x13 = 0.33333333300000001*n5 + x12;
    double x14 = log(x13*x4);
    double x15 = 24.943387854459719*x14;
    double x16 = n5*x4;
    double x17 = -24.943387837830794*x16;
    double x18 = 24.943387854459719*n4;
    double x19 = 24.943387854459719*n1 + 8.3144626098387775*n5 + x18;
    double x20 = 1.0/x13;
    double x21 = 1.0*x4;
    double x22 = pow(x3, -2);
    double x23 = -x13*x22;
    double x24 = x21 + x23;
    double x25 = x20*x24;
    double x26 = x19*x25;
    double x27 = x15 + x17 + x26*x3;
    double x28 = log(x2*x4);
    double x29 = 16.628925236306479*x28;
    double x30 = 8.3144626181532395*n5;
    double x31 = x30 + x5;
    double x32 = 16.628925236306479*n1 + 16.628925236306479*n2 + 16.628925236306479*n3;
    double x33 = 1.0/x2;
    double x34 = -x2*x22 + x4;
    double x35 = x33*x34;
    double x36 = x32*x35;
    double x37 = x29 + x3*x36 - x31*x4;
    double x38 = x0 + x11 + x27 + x37;
    double x39 = 2.0*x4;
    double x40 = x22*x31;
    double x41 = x22*x5;
    double x42 = n5*x22;
    double x43 = 24.943387837830794*x42;
    double x44 = n3*x22;
    double x45 = 24.943387854459719*x44;
    double x46 = x43 + x45;
    double x47 = x36 + x40 + x41 + x46;
    double x48 = n2*x22;
    double x49 = 24.943387854459719*x48;
    double x50 = x26 + x49;
    double x51 = x47 + x50;
    double x52 = x3*x35;
    double x53 = x3*x32;
    double x54 = 2*x22;
    double x55 = -x54;
    double x56 = pow(x3, -3);
    double x57 = 2*x56;
    double x58 = x2*x57;
    double x59 = x33*(x55 + x58);
    double x60 = x34/((x2)*(x2));
    double x61 = 33.257850472612958*x52 + x53*x59 - x53*x60;
    double x62 = x51 + x61;
    double x63 = x25*x3;
    double x64 = 2.0*x22;
    double x65 = x13*x57;
    double x66 = x20*x3;
    double x67 = x66*(-x64 + x65);
    double x68 = x3/((x13)*(x13));
    double x69 = x24*x68;
    double x70 = 1.0*x69;
    double x71 = x19*x67 - x19*x70 + 49.886775708919437*x63;
    double x72 = 1.0*n2 + 1.0*n3 + 1.0*n5 + x12;
    double x73 = x4*x72;
    double x74 = x54*x72;
    double x75 = n1*x0;
    double x76 = (*endmember[1].dmu0dT)(T, P);
    double x77 = n2*x76;
    double x78 = (*endmember[2].dmu0dT)(T, P);
    double x79 = n3*x78;
    double x80 = (*endmember[3].dmu0dT)(T, P);
    double x81 = n4*x80;
    double x82 = (*endmember[4].dmu0dT)(T, P);
    double x83 = n5*x82;
    double x84 = log(x7);
    double x85 = 24.943387854459719*x84;
    double x86 = log(x9);
    double x87 = 24.943387854459719*x86;
    double x88 = log(n4*x4);
    double x89 = log(x16);
    double x90 = n5*(x89 - 0.40546510910816402);
    double x91 = log(x1*x4);
    double x92 = 8.3144626181532395*x91;
    double x93 = 3.0*n1 + 3.0*n4 + 0.99999999900000003*n5;
    double x94 = n2*x85 - 40.14405*n2 + n3*x87 + x1*x92 + 8.3144626181532395*x14*x93 + x2*x29 + x30*x89 + x5*x88 + x75 + x77 + x79 + x81 + x83 + 16.628925219677555*x90;
    double x95 = x57*x72*x94 - x64*x94;
    double x96 = T >= 7.5;
    double x97 = -74.830163563379159*x7;
    double x98 = -74.830163563379159*x9;
    double x99 = -x18*x4;
    double x100 = x97 + x98 + x99;
    double x101 = -74.83016351349238*x16;
    double x102 = 74.830163563379159*n1 + 74.830163563379159*n4 + 24.943387829516332*n5;
    double x103 = x102*x25;
    double x104 = x101 + x103*x3 + 74.830163563379159*x14;
    double x105 = 49.886775708919437*x28;
    double x106 = 24.943387854459719*n5;
    double x107 = x106 + x18;
    double x108 = 49.886775708919437*n2;
    double x109 = 49.886775708919437*n3;
    double x110 = 49.886775708919437*n1 + x108 + x109;
    double x111 = x110*x35;
    double x112 = x105 - x107*x4 + x111*x3;
    double x113 = 3*x0 + x100 + x104 + x112;
    double x114 = x113*x4;
    double x115 = x107*x22;
    double x116 = x18*x22;
    double x117 = 74.83016351349238*x42;
    double x118 = 74.830163563379159*x44;
    double x119 = x117 + x118;
    double x120 = x111 + x115 + x116 + x119;
    double x121 = 74.830163563379159*x48;
    double x122 = x103 + x121;
    double x123 = x120 + x122;
    double x124 = x110*x3;
    double x125 = x124*x59 - x124*x60 + 99.773551417838874*x52;
    double x126 = x123 + x125;
    double x127 = x102*x67 - x102*x70 + 149.66032712675832*x63;
    double x128 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5;
    double x129 = x128*x4;
    double x130 = x128*x54;
    double x131 = 74.830163563379159*x84;
    double x132 = 74.830163563379159*x86;
    double x133 = 24.943387854459719*x91;
    double x134 = sqrt(1 - 0.13333333333333333*T);
    double x135 = 1.0*x134;
    double x136 = fmin(4, x135);
    double x137 = (4 - x135 >= 0. ? 1. : 0.)/x134;
    double x138 = -60.216075000000004*((x136)*(x136))*x137 + 120.43215000000001*x136 - 0.066666666666666666*x137*(120.43215000000001*T - 903.24112500000001) - 120.43215000000001;
    double x139 = n2*x131 + n2*x138 + n3*x132 + x1*x133 + x105*x2 + x106*x89 + x15*x93 + x18*x88 + 3*x75 + 3*x77 + 3*x79 + 3*x81 + 3*x83 + 49.886775659032665*x90;
    double x140 = x128*x139*x57 - 0.66666666666666663*x139*x22;
    double x141 = x3*(x4 - x48);
    double x142 = 24.943387854459719*x141;
    double x143 = x17 - x19*x4 + x37 + x6;
    double x144 = x10 + x142 + x143 + x76 + x85 - 40.14405;
    double x145 = x22*x72;
    double x146 = -x144*x145 + x144*x21;
    double x147 = x66*(-1.0*x22 + x65);
    double x148 = -x145*x38 + x21*x38 + x95;
    double x149 = x148 + x73*(x147*x19 - 49.886775708919437*x4 + x62);
    double x150 = 74.830163563379159*x141;
    double x151 = x101 - x102*x4 + x112 + x99;
    double x152 = x131 + x138 + x150 + x151 + 3*x76 + x98;
    double x153 = 0.33333333333333331*x4;
    double x154 = x128*x22;
    double x155 = x152*x153 - x152*x154;
    double x156 = -x113*x154 + 0.33333333333333331*x114 + x140;
    double x157 = x129*(x102*x147 + x126 - 149.66032712675832*x4) + x156;
    double x158 = x3*(x4 - x44);
    double x159 = 24.943387854459719*x158;
    double x160 = x143 + x159 + x78 + x8 + x87;
    double x161 = -x145*x160 + x160*x21;
    double x162 = 74.830163563379159*x158;
    double x163 = x132 + x151 + x162 + 3*x78 + x97;
    double x164 = x153*x163 - x154*x163;
    double x165 = x33*(-x22 + x58);
    double x166 = x165*x53;
    double x167 = x166 + x51;
    double x168 = x3*(-n4*x22 + x4);
    double x169 = 8.3144626181532395*x168;
    double x170 = 1.0/x1;
    double x171 = -x1*x22 + x4;
    double x172 = x170*x171;
    double x173 = x172*x31;
    double x174 = x173*x3 - x32*x4 + x92;
    double x175 = x10 + x169 + x174 + x27 + x8 + x80 + 8.3144626181532395*x88;
    double x176 = -x145*x175 + x175*x21;
    double x177 = x124*x165;
    double x178 = x123 + x177;
    double x179 = 24.943387854459719*x168;
    double x180 = x107*x172;
    double x181 = -x110*x4 + x133 + x180*x3;
    double x182 = x104 + x179 + x181 + 3*x80 + 24.943387854459719*x88 + x97 + x98;
    double x183 = x153*x182 - x154*x182;
    double x184 = x23 + 0.33333333300000001*x4;
    double x185 = x184*x20;
    double x186 = x185*x3;
    double x187 = x66*(-1.3333333330000001*x22 + x65);
    double x188 = 0.33333333300000001*x69;
    double x189 = 24.943387854459719*x186 + x187*x19 - x188*x19 + 8.3144626098387775*x63;
    double x190 = x3*(x4 - x42);
    double x191 = 24.943387837830794*x190;
    double x192 = x185*x19;
    double x193 = x11 + 8.3144626098387775*x14 + x174 + x191 + x192*x3 + x82 + 24.943387837830794*x89 - 6.7424489785480599;
    double x194 = -x145*x193 + x193*x21;
    double x195 = x102*x187 - x102*x188 + 74.830163563379159*x186 + 24.943387829516332*x63;
    double x196 = 74.83016351349238*x190;
    double x197 = x102*x185;
    double x198 = x100 + 24.943387829516332*x14 + x181 + x196 + x197*x3 + 3*x82 + 74.83016351349238*x89 - 20.227346935644182;
    double x199 = x153*x198 - x154*x198;
    double x200 = -49.886775708919437*x22;
    double x201 = x108*x56;
    double x202 = 1.0/n2;
    double x203 = x47 - x49;
    double x204 = 24.943387854459719*x4;
    double x205 = x19*x22;
    double x206 = x205 + x61;
    double x207 = x204 + x206;
    double x208 = 0.66666666666666663*x4;
    double x209 = -149.66032712675832*x22;
    double x210 = 149.66032712675832*x56;
    double x211 = n2*x210;
    double x212 = x120 - x121;
    double x213 = 74.830163563379159*x4;
    double x214 = x102*x22;
    double x215 = x125 + x214;
    double x216 = x213 + x215;
    double x217 = -24.943387854459719*x22;
    double x218 = x203 + x3*(x201 + x217);
    double x219 = x146 + x95;
    double x220 = -74.830163563379159*x22;
    double x221 = x212 + x3*(x211 + x220);
    double x222 = x140 + x155;
    double x223 = x166 + x205;
    double x224 = x223 - 58.201238327072687*x4;
    double x225 = x177 + x214;
    double x226 = x225 - 174.60371498121805*x4;
    double x227 = x223 - 58.201238302129298*x4;
    double x228 = x225 - 174.60371490638786*x4;
    double x229 = x109*x56;
    double x230 = 1.0/n3;
    double x231 = x41 + x49;
    double x232 = x231 + x36 + x40 + x43 - x45;
    double x233 = n3*x210;
    double x234 = x116 + x121;
    double x235 = x111 + x115 + x117 - x118 + x234;
    double x236 = x232 + x3*(x217 + x229);
    double x237 = x161 + x95;
    double x238 = x235 + x3*(x220 + x233);
    double x239 = x140 + x164;
    double x240 = n4*x56;
    double x241 = 16.628925236306479*x240;
    double x242 = 1.0/n4;
    double x243 = x172*x3;
    double x244 = x3*x31;
    double x245 = x170*(x1*x57 + x55);
    double x246 = x171/((x1)*(x1));
    double x247 = x173 + x22*x32 + 16.628925236306479*x243 + x244*x245 - x244*x246;
    double x248 = x247 - x41 + x46 + x50;
    double x249 = 49.886775708919437*x240;
    double x250 = x107*x3;
    double x251 = x110*x22 + x180 + 49.886775708919437*x243 + x245*x250 - x246*x250;
    double x252 = -x116 + x119 + x122 + x251;
    double x253 = 24.943387837830794*x4;
    double x254 = 74.83016351349238*x4;
    double x255 = n5*x56;
    double x256 = 1.0/n5;
    double x257 = x66*(-0.66666666600000002*x22 + x65);
    double x258 = 0.33333333300000001*x184*x68;

if (x96) {
   result[0] = x38*x39 - x38*x74 + x73*(x62 + x71) + x95;
}
else {
   result[0] = -x113*x130 + 0.66666666666666663*x114 + x129*(x126 + x127) + x140;
}
if (x96) {
   result[1] = x146 + x149;
}
else {
   result[1] = x155 + x157;
}
if (x96) {
   result[2] = x149 + x161;
}
else {
   result[2] = x157 + x164;
}
if (x96) {
   result[3] = x148 + x176 + x73*(x167 - 33.257850472612958*x4 + x71);
}
else {
   result[3] = x129*(x127 + x178 - 99.773551417838874*x4) + x156 + x183;
}
if (x96) {
   result[4] = x148 + x194 + x73*(x167 + x189 - 49.886775692290513*x4);
}
else {
   result[4] = x129*(x178 + x195 - 149.66032707687154*x4) + x156 + x199;
}
if (x96) {
   result[5] = x144*x39 - x144*x74 + x73*(x142*x202 + x203 + x207 + x3*(x200 + x201)) + x95;
}
else {
   result[5] = x129*(x150*x202 + x212 + x216 + x3*(x209 + x211)) - x130*x152 + x140 + x152*x208;
}
if (x96) {
   result[6] = x161 + x219 + x73*(-x204 + x206 + x218);
}
else {
   result[6] = x129*(-x213 + x215 + x221) + x164 + x222;
}
if (x96) {
   result[7] = x176 + x219 + x73*(x218 + x224);
}
else {
   result[7] = x129*(x221 + x226) + x183 + x222;
}
if (x96) {
   result[8] = x194 + x219 + x73*(x218 + x227);
}
else {
   result[8] = x129*(x221 + x228) + x199 + x222;
}
if (x96) {
   result[9] = x160*x39 - x160*x74 + x73*(x159*x230 + x207 + x232 + x3*(x200 + x229)) + x95;
}
else {
   result[9] = x129*(x162*x230 + x216 + x235 + x3*(x209 + x233)) - x130*x163 + x140 + x163*x208;
}
if (x96) {
   result[10] = x176 + x237 + x73*(x224 + x236);
}
else {
   result[10] = x129*(x226 + x238) + x183 + x239;
}
if (x96) {
   result[11] = x194 + x237 + x73*(x227 + x236);
}
else {
   result[11] = x129*(x228 + x238) + x199 + x239;
}
if (x96) {
   result[12] = x175*x39 - x175*x74 + x73*(x169*x242 + x248 + x3*(-16.628925236306479*x22 + x241) + 8.3144626181532395*x4 + x71) + x95;
}
else {
   result[12] = x129*(x127 + x179*x242 + x204 + x252 + x3*(x200 + x249)) - x130*x182 + x140 + x182*x208;
}
if (x96) {
   result[13] = x176 + x194 + x73*(x189 + x248 - x253 + x3*(-8.3144626181532395*x22 + x241)) + x95;
}
else {
   result[13] = x129*(x195 + x252 - x254 + x3*(x217 + x249)) + x140 + x183 + x199;
}
if (x96) {
   result[14] = x193*x39 - x193*x74 + x73*(16.628925219677555*x186 + x19*x257 - x19*x258 + x191*x256 + x192 + x231 + x247 + x253 + x3*(-49.886775675661589*x22 + 49.886775675661589*x255) - x43 + x45) + x95;
}
else {
   result[14] = x129*(x102*x257 - x102*x258 - x117 + x118 + 49.886775659032665*x186 + x196*x256 + x197 + x234 + x251 + x254 + x3*(-149.66032702698476*x22 + 149.66032702698476*x255)) - x130*x198 + x140 + x198*x208;
}
}
        
static void coder_d4gdn3dt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = 8.3144626181532395*n4;
    double x1 = 8.3144626181532395*n5;
    double x2 = x0 + x1;
    double x3 = n4 + n5;
    double x4 = n1 + n2 + n3;
    double x5 = x3 + x4;
    double x6 = pow(x5, -2);
    double x7 = x2*x6;
    double x8 = x0*x6;
    double x9 = 16.628925236306479*n1 + 16.628925236306479*n2 + 16.628925236306479*n3;
    double x10 = 1.0/x4;
    double x11 = 1.0/x5;
    double x12 = x11 - x4*x6;
    double x13 = x10*x12;
    double x14 = x13*x9;
    double x15 = n5*x6;
    double x16 = 24.943387837830794*x15;
    double x17 = 24.943387854459719*x6;
    double x18 = n3*x17;
    double x19 = x16 + x18;
    double x20 = x14 + x19 + x7 + x8;
    double x21 = n2*x6;
    double x22 = 24.943387854459719*x21;
    double x23 = 24.943387854459719*n4;
    double x24 = 24.943387854459719*n1 + 8.3144626098387775*n5 + x23;
    double x25 = 1.0*n1 + 1.0*n4;
    double x26 = 0.33333333300000001*n5 + x25;
    double x27 = 1.0/x26;
    double x28 = 1.0*x11;
    double x29 = -x26*x6;
    double x30 = x28 + x29;
    double x31 = x27*x30;
    double x32 = x24*x31;
    double x33 = x22 + x32;
    double x34 = x20 + x33;
    double x35 = 33.257850472612958*x13;
    double x36 = 2*x6;
    double x37 = -x36;
    double x38 = pow(x5, -3);
    double x39 = 2*x38;
    double x40 = x39*x4;
    double x41 = x37 + x40;
    double x42 = x10*x9;
    double x43 = x41*x42;
    double x44 = pow(x4, -2);
    double x45 = x12*x44;
    double x46 = x45*x9;
    double x47 = x35*x5 + x43*x5 - x46*x5;
    double x48 = x34 + x47;
    double x49 = 49.886775708919437*x31;
    double x50 = 2.0*x6;
    double x51 = x26*x39;
    double x52 = -x50 + x51;
    double x53 = x24*x27;
    double x54 = x52*x53;
    double x55 = pow(x26, -2);
    double x56 = x30*x55;
    double x57 = 1.0*x56;
    double x58 = x24*x57;
    double x59 = x49*x5 + x5*x54 - x5*x58;
    double x60 = x48 + x59;
    double x61 = 3.0*x11;
    double x62 = (*endmember[0].dmu0dT)(T, P);
    double x63 = -x0*x11;
    double x64 = n2*x11;
    double x65 = -24.943387854459719*x64;
    double x66 = n3*x11;
    double x67 = -24.943387854459719*x66;
    double x68 = x63 + x65 + x67;
    double x69 = log(x11*x26);
    double x70 = 24.943387854459719*x69;
    double x71 = n5*x11;
    double x72 = -24.943387837830794*x71;
    double x73 = x32*x5 + x70 + x72;
    double x74 = log(x11*x4);
    double x75 = 16.628925236306479*x74;
    double x76 = -x11*x2 + x14*x5 + x75;
    double x77 = x62 + x68 + x73 + x76;
    double x78 = x6*x77;
    double x79 = 49.886775708919437*n2;
    double x80 = x38*x79;
    double x81 = -x80;
    double x82 = -x2*x39;
    double x83 = 16.628925236306479*x38;
    double x84 = n4*x83;
    double x85 = -x84;
    double x86 = n5*x38;
    double x87 = 49.886775675661589*x86;
    double x88 = -x87;
    double x89 = 49.886775708919437*n3;
    double x90 = x38*x89;
    double x91 = -x90;
    double x92 = x88 + x91;
    double x93 = x82 + x85 + x92;
    double x94 = x81 + x93;
    double x95 = 49.886775708919437*x5;
    double x96 = x10*x41;
    double x97 = 6*x38;
    double x98 = pow(x5, -4);
    double x99 = 6*x98;
    double x100 = -x4*x99;
    double x101 = x5*(x100 + x97);
    double x102 = 2*x5;
    double x103 = x102*x9;
    double x104 = x41*x44;
    double x105 = x12/((x4)*(x4)*(x4));
    double x106 = x101*x42 - x103*x104 + x103*x105 + 49.886775708919437*x13 + 2*x43 - x45*x95 - 2*x46 + x95*x96;
    double x107 = x106 + x94;
    double x108 = 74.830163563379159*x31;
    double x109 = 74.830163563379159*x5;
    double x110 = x27*x52;
    double x111 = 2.0*x56;
    double x112 = 6.0*x38;
    double x113 = -x26*x99;
    double x114 = x5*(x112 + x113);
    double x115 = 2.0*x5;
    double x116 = x115*x24;
    double x117 = pow(x26, -3);
    double x118 = x117*x30;
    double x119 = x52*x55;
    double x120 = x108 + x109*x110 - x109*x56 - x111*x24 + x114*x53 + x116*x118 - x116*x119 + 2*x54;
    double x121 = 1.0*n2 + 1.0*n3 + 1.0*n5 + x25;
    double x122 = x11*x121;
    double x123 = x121*x6;
    double x124 = x123*x60;
    double x125 = x121*x77;
    double x126 = n1*x62;
    double x127 = (*endmember[1].dmu0dT)(T, P);
    double x128 = n2*x127;
    double x129 = (*endmember[2].dmu0dT)(T, P);
    double x130 = n3*x129;
    double x131 = (*endmember[3].dmu0dT)(T, P);
    double x132 = n4*x131;
    double x133 = (*endmember[4].dmu0dT)(T, P);
    double x134 = n5*x133;
    double x135 = log(x64);
    double x136 = 24.943387854459719*x135;
    double x137 = log(x66);
    double x138 = 24.943387854459719*x137;
    double x139 = log(n4*x11);
    double x140 = log(x71);
    double x141 = n5*(x140 - 0.40546510910816402);
    double x142 = log(x11*x3);
    double x143 = 8.3144626181532395*x142;
    double x144 = 3.0*n1 + 3.0*n4 + 0.99999999900000003*n5;
    double x145 = n2*x136 - 40.14405*n2 + n3*x138 + x0*x139 + x1*x140 + x126 + x128 + x130 + x132 + x134 + 16.628925219677555*x141 + x143*x3 + 8.3144626181532395*x144*x69 + x4*x75;
    double x146 = x112*x145 - x121*x145*x99;
    double x147 = T >= 7.5;
    double x148 = 24.943387854459719*n5;
    double x149 = x148 + x23;
    double x150 = x149*x6;
    double x151 = x23*x6;
    double x152 = 49.886775708919437*n1 + x79 + x89;
    double x153 = x13*x152;
    double x154 = 74.83016351349238*x15;
    double x155 = 74.830163563379159*x6;
    double x156 = n3*x155;
    double x157 = x154 + x156;
    double x158 = x150 + x151 + x153 + x157;
    double x159 = 74.830163563379159*x21;
    double x160 = 74.830163563379159*n1 + 74.830163563379159*n4 + 24.943387829516332*n5;
    double x161 = x160*x31;
    double x162 = x159 + x161;
    double x163 = x158 + x162;
    double x164 = 99.773551417838874*x13;
    double x165 = x10*x152;
    double x166 = x165*x41;
    double x167 = x152*x45;
    double x168 = x164*x5 + x166*x5 - x167*x5;
    double x169 = x163 + x168;
    double x170 = 149.66032712675832*x31;
    double x171 = x160*x27;
    double x172 = x171*x52;
    double x173 = x160*x57;
    double x174 = x170*x5 + x172*x5 - x173*x5;
    double x175 = x169 + x174;
    double x176 = -74.830163563379159*x64;
    double x177 = -74.830163563379159*x66;
    double x178 = -x11*x23;
    double x179 = x176 + x177 + x178;
    double x180 = -74.83016351349238*x71;
    double x181 = x161*x5 + x180 + 74.830163563379159*x69;
    double x182 = 49.886775708919437*x74;
    double x183 = -x11*x149 + x153*x5 + x182;
    double x184 = x179 + x181 + x183 + 3*x62;
    double x185 = 224.49049069013748*x5;
    double x186 = x115*x160;
    double x187 = x110*x185 - x111*x160 + x114*x171 + x118*x186 - x119*x186 + 2*x172 - x185*x56 + 224.49049069013748*x31;
    double x188 = 149.66032702698476*x38;
    double x189 = n5*x188;
    double x190 = -x189;
    double x191 = 149.66032712675832*x38;
    double x192 = n3*x191;
    double x193 = -x192;
    double x194 = x190 + x193;
    double x195 = -x149*x39;
    double x196 = 49.886775708919437*x38;
    double x197 = n4*x196;
    double x198 = -x197;
    double x199 = n2*x191;
    double x200 = -x199;
    double x201 = x198 + x200;
    double x202 = x195 + x201;
    double x203 = 149.66032712675832*x5;
    double x204 = x102*x152;
    double x205 = x101*x165 - x104*x204 + x105*x204 + 149.66032712675832*x13 + 2*x166 - 2*x167 - x203*x45 + x203*x96;
    double x206 = x202 + x205;
    double x207 = x194 + x206;
    double x208 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5;
    double x209 = x11*x208;
    double x210 = x208*x6;
    double x211 = x175*x210;
    double x212 = x184*x208;
    double x213 = 74.830163563379159*x135;
    double x214 = 74.830163563379159*x137;
    double x215 = 24.943387854459719*x142;
    double x216 = sqrt(1 - 0.13333333333333333*T);
    double x217 = 1.0*x216;
    double x218 = fmin(4, x217);
    double x219 = (4 - x217 >= 0. ? 1. : 0.)/x216;
    double x220 = -60.216075000000004*((x218)*(x218))*x219 + 120.43215000000001*x218 - 0.066666666666666666*x219*(120.43215000000001*T - 903.24112500000001) - 120.43215000000001;
    double x221 = n2*x213 + n2*x220 + n3*x214 + 3*x126 + 3*x128 + 3*x130 + 3*x132 + 3*x134 + x139*x23 + x140*x148 + 49.886775659032665*x141 + x144*x70 + x182*x4 + x215*x3;
    double x222 = 2.0*x38;
    double x223 = -x208*x221*x99 + x221*x222;
    double x224 = x51 - 1.0*x6;
    double x225 = x224*x53;
    double x226 = -49.886775708919437*x11 + x225*x5 + x48;
    double x227 = 2.0*x11;
    double x228 = x121*x36;
    double x229 = x146 + x226*x227 - x226*x228;
    double x230 = x11 - x21;
    double x231 = x230*x5;
    double x232 = 24.943387854459719*x231;
    double x233 = -x11*x24 + x63 + x72 + x76;
    double x234 = x127 + x136 + x232 + x233 + x67 - 40.14405;
    double x235 = x121*x39;
    double x236 = x234*x235 - x234*x50;
    double x237 = x229 + x236;
    double x238 = x224*x27;
    double x239 = x5*(x113 + 4.0*x38);
    double x240 = x24*x5;
    double x241 = 1.0*x55;
    double x242 = x224*x241;
    double x243 = x239*x53 - x240*x242 + x54 - x58;
    double x244 = 4*x38;
    double x245 = -x124 + x125*x244 + x28*x60 - 4.0*x78;
    double x246 = x122*(x107 + x17 + x225 + x238*x95 + x243 + x49) + x245;
    double x247 = x171*x224;
    double x248 = -149.66032712675832*x11 + x169 + x247*x5;
    double x249 = 0.66666666666666663*x11;
    double x250 = x208*x36;
    double x251 = x223 + x248*x249 - x248*x250;
    double x252 = 74.830163563379159*x231;
    double x253 = -x11*x160 + x178 + x180 + x183;
    double x254 = 3*x127 + x177 + x213 + x220 + x252 + x253;
    double x255 = 0.66666666666666663*x6;
    double x256 = x208*x39;
    double x257 = -x254*x255 + x254*x256;
    double x258 = x251 + x257;
    double x259 = x160*x5;
    double x260 = x171*x239 + x172 - x173 - x242*x259;
    double x261 = 0.33333333333333331*x11;
    double x262 = 1.3333333333333333*x6;
    double x263 = x175*x261 - x184*x262 - x211 + x212*x244;
    double x264 = x209*(x155 + x170 + x203*x238 + x207 + x247 + x260) + x263;
    double x265 = -n3*x6 + x11;
    double x266 = x265*x5;
    double x267 = 24.943387854459719*x266;
    double x268 = x129 + x138 + x233 + x267 + x65;
    double x269 = x235*x268 - x268*x50;
    double x270 = 74.830163563379159*x266;
    double x271 = 3*x129 + x176 + x214 + x253 + x270;
    double x272 = -x255*x271 + x256*x271;
    double x273 = 16.628925236306479*x6;
    double x274 = -x6;
    double x275 = x274 + x40;
    double x276 = x275*x42;
    double x277 = x275*x5;
    double x278 = x10*x277;
    double x279 = x5*(x100 + x244);
    double x280 = x277*x44;
    double x281 = x276 + 33.257850472612958*x278 + x279*x42 - x280*x9 + x35 + x43 - x46;
    double x282 = x281 + x94;
    double x283 = x146 + x245;
    double x284 = x276*x5;
    double x285 = x284 + x34;
    double x286 = -33.257850472612958*x11 + x285 + x59;
    double x287 = x227*x286 - x228*x286;
    double x288 = -n4*x6 + x11;
    double x289 = x288*x5;
    double x290 = 8.3144626181532395*x289;
    double x291 = 1.0/x3;
    double x292 = x11 - x3*x6;
    double x293 = x291*x292;
    double x294 = x2*x293;
    double x295 = -x11*x9 + x143 + x294*x5;
    double x296 = x131 + 8.3144626181532395*x139 + x290 + x295 + x65 + x67 + x73;
    double x297 = x235*x296 - x296*x50;
    double x298 = 49.886775708919437*x6;
    double x299 = x165*x275;
    double x300 = -x152*x280 + x164 + x165*x279 + x166 - x167 + 99.773551417838874*x278 + x299;
    double x301 = x194 + x202;
    double x302 = x300 + x301;
    double x303 = x223 + x263;
    double x304 = x299*x5;
    double x305 = x163 + x304;
    double x306 = -99.773551417838874*x11 + x174 + x305;
    double x307 = x249*x306 - x250*x306;
    double x308 = 24.943387854459719*x289;
    double x309 = x149*x293;
    double x310 = -x11*x152 + x215 + x309*x5;
    double x311 = 3*x131 + 24.943387854459719*x139 + x176 + x177 + x181 + x308 + x310;
    double x312 = -x255*x311 + x256*x311;
    double x313 = x51 - 1.3333333330000001*x6;
    double x314 = x313*x53;
    double x315 = x110*x5;
    double x316 = x27*x313;
    double x317 = 1.3333333330000001*x56;
    double x318 = x5*x56;
    double x319 = x5*(x113 + 4.6666666660000002*x38);
    double x320 = 0.66666666600000002*x118;
    double x321 = x241*x313;
    double x322 = 0.33333333300000001*x119;
    double x323 = -x24*x317 + x240*x320 - x240*x321 - x240*x322 + 58.201238318758215*x31 + x314 + 8.3144626098387775*x315 + x316*x95 - 24.943387829516332*x318 + x319*x53 + x54;
    double x324 = 8.3144626098387775*x31;
    double x325 = 0.33333333300000001*x11 + x29;
    double x326 = x27*x325;
    double x327 = 24.943387854459719*x326;
    double x328 = 0.33333333300000001*x318;
    double x329 = -x24*x328 + x314*x5 + x324*x5 + x327*x5;
    double x330 = -49.886775692290513*x11 + x285 + x329;
    double x331 = x227*x330 - x228*x330;
    double x332 = x11 - x15;
    double x333 = x332*x5;
    double x334 = 24.943387837830794*x333;
    double x335 = x325*x53;
    double x336 = x133 + 24.943387837830794*x140 + x295 + x334 + x335*x5 + x68 + 8.3144626098387775*x69 - 6.7424489785480599;
    double x337 = x235*x336 - x336*x50;
    double x338 = x171*x313;
    double x339 = -x160*x317 + x171*x319 + x172 + x203*x316 + x259*x320 - x259*x321 - x259*x322 + 174.60371495627464*x31 + 24.943387829516332*x315 - 74.830163488549005*x318 + x338;
    double x340 = 74.830163563379159*x326;
    double x341 = 24.943387829516332*x31;
    double x342 = -x160*x328 + x338*x5 + x340*x5 + x341*x5;
    double x343 = -149.66032707687154*x11 + x305 + x342;
    double x344 = x249*x343 - x250*x343;
    double x345 = 74.83016351349238*x333;
    double x346 = x171*x325;
    double x347 = 3*x133 + 74.83016351349238*x140 + x179 + x310 + x345 + x346*x5 + 24.943387829516332*x69 - 20.227346935644182;
    double x348 = -x255*x347 + x256*x347;
    double x349 = x5*(x113 + x222);
    double x350 = x125*x39 - x50*x77;
    double x351 = x122*(x107 + x155 + 2*x225 + x349*x53) + x350;
    double x352 = x229 + x351;
    double x353 = -x298;
    double x354 = 1.0/n2;
    double x355 = x20 - x22;
    double x356 = 24.943387854459719*x11;
    double x357 = x24*x6;
    double x358 = x357 + x47;
    double x359 = x356 + x358;
    double x360 = x232*x354 + x355 + x359 + x5*(x353 + x80);
    double x361 = 4.0*x6;
    double x362 = x123*x360;
    double x363 = x121*x244;
    double x364 = -x234*x361 + x234*x363 + x28*x360 - x362;
    double x365 = 224.49049069013748*x6;
    double x366 = x194 + x365;
    double x367 = -x184*x255 + x212*x39;
    double x368 = x209*(x171*x349 + x206 + 2*x247 + x366) + x367;
    double x369 = x251 + x368;
    double x370 = 149.66032712675832*x6;
    double x371 = -x370;
    double x372 = x158 - x159;
    double x373 = 74.830163563379159*x11;
    double x374 = x160*x6;
    double x375 = x168 + x374;
    double x376 = x373 + x375;
    double x377 = x252*x354 + x372 + x376 + x5*(x199 + x371);
    double x378 = x210*x377;
    double x379 = x208*x244;
    double x380 = -x254*x262 + x254*x379 + x261*x377 - x378;
    double x381 = -x17;
    double x382 = x355 + x5*(x381 + x80);
    double x383 = -x356 + x358 + x382;
    double x384 = -x123*x383 + x269 + x28*x383;
    double x385 = -x155;
    double x386 = x372 + x5*(x199 + x385);
    double x387 = -x373 + x375 + x386;
    double x388 = -x210*x387 + x261*x387 + x272;
    double x389 = x284 + x357;
    double x390 = -58.201238327072687*x11 + x389;
    double x391 = x382 + x390;
    double x392 = -x123*x391 + x28*x391 + x297;
    double x393 = x146 + x350;
    double x394 = -x123*x226 + x226*x28 + x393;
    double x395 = x236 + x394;
    double x396 = x238*x5;
    double x397 = x225 + x282;
    double x398 = -x123*x286 + x28*x286;
    double x399 = x122*(x243 + 24.943387854459719*x31 + 24.943387854459719*x396 + x397 + 66.515700945225916*x6) + x398;
    double x400 = x304 + x374;
    double x401 = -174.60371498121805*x11 + x400;
    double x402 = x386 + x401;
    double x403 = -x210*x402 + x261*x402 + x312;
    double x404 = x223 + x367;
    double x405 = -x210*x248 + x248*x261 + x404;
    double x406 = x257 + x405;
    double x407 = x247 + x302;
    double x408 = -x210*x306 + x261*x306;
    double x409 = x209*(x108 + x109*x238 + x260 + x407 + 199.54710283567778*x6) + x408;
    double x410 = -58.201238302129298*x11 + x389;
    double x411 = x382 + x410;
    double x412 = -x123*x411 + x28*x411;
    double x413 = 0.33333333300000001*x56;
    double x414 = x5*(x113 + 2.6666666660000002*x38);
    double x415 = x240*x55;
    double x416 = 0.33333333300000001*x224;
    double x417 = -x123*x330 + x28*x330 + x337;
    double x418 = x122*(-x24*x413 + x314 + x324 + 8.3144626098387775*x396 + x397 + x414*x53 - x415*x416 + 83.144626164903471*x6) + x417;
    double x419 = -174.60371490638786*x11 + x400;
    double x420 = x386 + x419;
    double x421 = -x210*x420 + x261*x420;
    double x422 = x259*x55;
    double x423 = -x210*x343 + x261*x343 + x348;
    double x424 = x209*(-x160*x413 + x171*x414 + x338 + x341 + 24.943387829516332*x396 + x407 - x416*x422 + 249.43387849471043*x6) + x423;
    double x425 = 1.0/n3;
    double x426 = x22 + x8;
    double x427 = x14 + x16 - x18 + x426 + x7;
    double x428 = x267*x425 + x359 + x427 + x5*(x353 + x90);
    double x429 = x123*x428;
    double x430 = -x268*x361 + x268*x363 + x28*x428 - x429;
    double x431 = x151 + x159;
    double x432 = x150 + x153 + x154 - x156 + x431;
    double x433 = x270*x425 + x376 + x432 + x5*(x192 + x371);
    double x434 = x210*x433;
    double x435 = x261*x433 - x262*x271 + x271*x379 - x434;
    double x436 = x269 + x394;
    double x437 = x427 + x5*(x381 + x90);
    double x438 = x390 + x437;
    double x439 = -x123*x438 + x28*x438;
    double x440 = x297 + x439;
    double x441 = x272 + x405;
    double x442 = x432 + x5*(x192 + x385);
    double x443 = x401 + x442;
    double x444 = -x210*x443 + x261*x443;
    double x445 = x312 + x444;
    double x446 = x410 + x437;
    double x447 = -x123*x446 + x28*x446;
    double x448 = x419 + x442;
    double x449 = -x210*x448 + x261*x448;
    double x450 = 49.886775708919444*x6;
    double x451 = 2*x276;
    double x452 = x5*(x100 + x39);
    double x453 = x42*x452;
    double x454 = x451 + x453 + x94;
    double x455 = 1.0/n4;
    double x456 = x2*x5;
    double x457 = x3*x39 + x37;
    double x458 = x291*x457;
    double x459 = pow(x3, -2);
    double x460 = x292*x459;
    double x461 = 16.628925236306479*x293*x5 + x294 + x456*x458 - x456*x460 + x6*x9;
    double x462 = x19 + x33 + x461 - x8;
    double x463 = 8.3144626181532395*x11 + x290*x455 + x462 + x5*(-x273 + x84) + x59;
    double x464 = x123*x463;
    double x465 = x28*x463 - x296*x361 + x296*x363 - x464;
    double x466 = 2*x299;
    double x467 = x165*x452;
    double x468 = x301 + x466 + x467;
    double x469 = x149*x5;
    double x470 = x152*x6 + x293*x95 + x309 + x458*x469 - x460*x469;
    double x471 = -x151 + x157 + x162 + x470;
    double x472 = x174 + x308*x455 + x356 + x471 + x5*(x197 + x353);
    double x473 = x210*x472;
    double x474 = x261*x472 - x262*x311 + x311*x379 - x473;
    double x475 = 24.943387837830794*x11;
    double x476 = x329 + x462 - x475 + x5*(-8.3144626181532395*x6 + x84);
    double x477 = -x123*x476 + x28*x476;
    double x478 = 74.83016351349238*x11;
    double x479 = x342 + x471 - x478 + x5*(x197 + x381);
    double x480 = -x210*x479 + x261*x479;
    double x481 = 16.628925219677555*x5;
    double x482 = x51 - 0.66666666600000002*x6;
    double x483 = x482*x5;
    double x484 = x27*x483;
    double x485 = x325*x55;
    double x486 = x485*x5;
    double x487 = 0.66666666600000002*x56;
    double x488 = x5*(x113 + 3.3333333320000005*x38);
    double x489 = 0.22222222177777778*x118;
    double x490 = 0.66666666600000002*x313;
    double x491 = -x24*x487 + x240*x489 + 16.628925219677555*x31 + 2*x314 + x316*x481 - 5.5429750676828764*x318 + x327 - x415*x490 + 24.943387854459719*x484 - 8.3144626098387775*x486 + x488*x53;
    double x492 = 1.0/n5;
    double x493 = 0.33333333300000001*x486;
    double x494 = -x16 + x18 - x24*x493 + x326*x481 + x334*x492 + x335 + x426 + x461 + x475 + x483*x53 + x5*(-49.886775675661589*x6 + x87);
    double x495 = x123*x494;
    double x496 = x28*x494 - x336*x361 + x336*x363 - x495;
    double x497 = 49.886775659032665*x5;
    double x498 = x109*x27*x482 - x160*x487 + x171*x488 + x259*x489 + 49.886775659032665*x31 + x316*x497 - 16.628925203048631*x318 + 2*x338 + x340 - x422*x490 - 24.943387829516332*x486;
    double x499 = -x154 + x156 - x160*x493 + x171*x483 + x326*x497 + x345*x492 + x346 + x431 + x470 + x478 + x5*(x189 - 149.66032702698476*x6);
    double x500 = x210*x499;
    double x501 = x261*x499 - x262*x347 + x347*x379 - x500;
    double x502 = 6.0*x6;
    double x503 = n2*x98;
    double x504 = -149.66032712675832*x503;
    double x505 = n2*x39;
    double x506 = x354*(x37 + x505);
    double x507 = 24.943387854459719*x5;
    double x508 = pow(n2, -2);
    double x509 = x230*x354;
    double x510 = 99.773551417838874*x38;
    double x511 = n2*x510 + x93;
    double x512 = 24.943387854459719*x509 + x511;
    double x513 = -99.773551417838874*x6;
    double x514 = -x24*x39;
    double x515 = x106 + x514;
    double x516 = x513 + x515;
    double x517 = x121*x97;
    double x518 = 448.98098138027495*x38;
    double x519 = -448.98098138027495*x503;
    double x520 = 299.32065425351664*x38;
    double x521 = n2*x520;
    double x522 = -x160*x39 + x195 + x198;
    double x523 = x194 + x522;
    double x524 = 74.830163563379159*x509 + x521 + x523;
    double x525 = x205 - 299.32065425351664*x6;
    double x526 = x208*x97;
    double x527 = x354*(x274 + x505);
    double x528 = x5*(x504 + x510) + x507*x527 + x512;
    double x529 = x146 + x364;
    double x530 = x227*x383 - x228*x383;
    double x531 = x109*x527 + x5*(x519 + x520) + x524;
    double x532 = x223 + x380;
    double x533 = x249*x387 - x250*x387;
    double x534 = -33.257850472612958*x6;
    double x535 = x281 + x514;
    double x536 = x534 + x535;
    double x537 = x227*x391 - x228*x391;
    double x538 = x300 - 99.773551417838888*x6;
    double x539 = x249*x402 - x250*x402;
    double x540 = x535 - 33.257850497556348*x6;
    double x541 = x227*x411 - x228*x411;
    double x542 = x300 - 99.773551492669043*x6;
    double x543 = x249*x420 - x250*x420;
    double x544 = x5*(x196 + x504) + x511;
    double x545 = x514 + x544;
    double x546 = x146 + x236;
    double x547 = x5*(x191 + x519) + x521;
    double x548 = x523 + x547;
    double x549 = x223 + x257;
    double x550 = x281 + x545;
    double x551 = x384 + x546;
    double x552 = x300 + x548;
    double x553 = x388 + x549;
    double x554 = x337 + x412;
    double x555 = x348 + x421;
    double x556 = x451 + x453 + x514;
    double x557 = x556 + 74.830163563379173*x6;
    double x558 = x466 + x467 + x522;
    double x559 = x547 + x558;
    double x560 = 74.830163538435784*x6;
    double x561 = x544 + x556;
    double x562 = 224.49049061530732*x6;
    double x563 = x194 + x559;
    double x564 = 74.830163513492408*x6;
    double x565 = 224.49049054047714*x6;
    double x566 = n3*x98;
    double x567 = -149.66032712675832*x566;
    double x568 = n3*x39;
    double x569 = x425*(x37 + x568);
    double x570 = pow(n3, -2);
    double x571 = x265*x425;
    double x572 = x81 + x85;
    double x573 = n3*x510 + x572 + x82 + x88;
    double x574 = 24.943387854459719*x571 + x573;
    double x575 = -448.98098138027495*x566;
    double x576 = n3*x520 + x190 + x200;
    double x577 = x522 + 74.830163563379159*x571 + x576;
    double x578 = x425*(x274 + x568);
    double x579 = x5*(x510 + x567) + x507*x578 + x574;
    double x580 = x146 + x430;
    double x581 = x227*x438 - x228*x438;
    double x582 = x109*x578 + x5*(x520 + x575) + x577;
    double x583 = x223 + x435;
    double x584 = x249*x443 - x250*x443;
    double x585 = x227*x446 - x228*x446;
    double x586 = x249*x448 - x250*x448;
    double x587 = x5*(x196 + x567) + x573;
    double x588 = x146 + x269;
    double x589 = x5*(x191 + x575) + x558 + x576;
    double x590 = x223 + x272;
    double x591 = x556 + x587;
    double x592 = n4*x98;
    double x593 = -49.886775708919437*x592;
    double x594 = n4*x39;
    double x595 = x455*(x37 + x594);
    double x596 = 8.3144626181532395*x5;
    double x597 = pow(n4, -2);
    double x598 = x288*x455;
    double x599 = 33.257850472612958*x38;
    double x600 = 2*x2;
    double x601 = x291*(-x3*x99 + x97);
    double x602 = 2*x456;
    double x603 = x457*x459;
    double x604 = x292/((x3)*(x3)*(x3));
    double x605 = 24.943387854459719*x293 - x39*x9 + x456*x601 + x458*x507 + x458*x600 - x460*x507 - x460*x600 - x602*x603 + x602*x604;
    double x606 = n4*x599 + x605 + x81 + x92;
    double x607 = 8.3144626181532395*x598 + x606;
    double x608 = -149.66032712675832*x592;
    double x609 = 2*x149;
    double x610 = 2*x469;
    double x611 = x109*x458 - x109*x460 - x152*x39 + 74.830163563379159*x293 + x458*x609 - x460*x609 + x469*x601 - x603*x610 + x604*x610;
    double x612 = n4*x510 + x194 + x200 + x611;
    double x613 = 24.943387854459719*x598 + x612;
    double x614 = x455*(x274 + x594);
    double x615 = x146 + x227*x476 - x228*x476;
    double x616 = x223 + x249*x479 - x250*x479;
    double x617 = n5*x98;
    double x618 = x332*x492;
    double x619 = 2*x482;
    double x620 = x492*x5*(n5*x39 + x37);
    double x621 = 0.66666666600000002*x485;
    double x622 = pow(n5, -2);
    double x623 = x5*(x113 + 1.9999999980000001*x38);
    double x624 = 0.22222222177777778*x117*x325;
    double x625 = 0.66666666600000002*x483*x55;

if (x147) {
   result[0] = x122*(x107 + x120) - 3*x124 + x125*x97 + x146 + x60*x61 - 6.0*x78;
}
else {
   result[0] = x175*x28 - x184*x50 + x209*(x187 + x207) - 3*x211 + x212*x97 + x223;
}
if (x147) {
   result[1] = x237 + x246;
}
else {
   result[1] = x258 + x264;
}
if (x147) {
   result[2] = x229 + x246 + x269;
}
else {
   result[2] = x251 + x264 + x272;
}
if (x147) {
   result[3] = x122*(x120 + x273 + x282) + x283 + x287 + x297;
}
else {
   result[3] = x209*(x187 + x298 + x302) + x303 + x307 + x312;
}
if (x147) {
   result[4] = x122*(x282 + x323 + 33.257850455984034*x6) + x283 + x331 + x337;
}
else {
   result[4] = x209*(x302 + x339 + 99.773551367952095*x6) + x303 + x344 + x348;
}
if (x147) {
   result[5] = x352 + x364;
}
else {
   result[5] = x369 + x380;
}
if (x147) {
   result[6] = x237 + x351 + x384;
}
else {
   result[6] = x258 + x368 + x388;
}
if (x147) {
   result[7] = x392 + x395 + x399;
}
else {
   result[7] = x403 + x406 + x409;
}
if (x147) {
   result[8] = x395 + x412 + x418;
}
else {
   result[8] = x406 + x421 + x424;
}
if (x147) {
   result[9] = x352 + x430;
}
else {
   result[9] = x369 + x435;
}
if (x147) {
   result[10] = x399 + x436 + x440;
}
else {
   result[10] = x409 + x441 + x445;
}
if (x147) {
   result[11] = x418 + x436 + x447;
}
else {
   result[11] = x424 + x441 + x449;
}
if (x147) {
   result[12] = x122*(x120 + x450 + x454) + x287 + x393 + x465;
}
else {
   result[12] = x209*(x187 + x370 + x468) + x307 + x404 + x474;
}
if (x147) {
   result[13] = x122*(x323 + x454 + 66.515700928596999*x6) + x297 + x393 + x398 + x417 + x477;
}
else {
   result[13] = x209*(x339 + x468 + 199.54710278579097*x6) + x312 + x404 + x408 + x423 + x480;
}
if (x147) {
   result[14] = x122*(x454 + x491 + 83.144626148274554*x6) + x331 + x393 + x496;
}
else {
   result[14] = x209*(x468 + x498 + 249.43387844482365*x6) + x344 + x404 + x501;
}
if (x147) {
   result[15] = x122*(-x232*x508 + x5*(x191 + x504) + x506*x507 + x512 + x516) + x146 - x234*x502 + x234*x517 + x360*x61 - 3*x362;
}
else {
   result[15] = x209*(x109*x506 - x252*x508 + x5*(x518 + x519) + x524 + x525) + x223 - x254*x50 + x254*x526 + x28*x377 - 3*x378;
}
if (x147) {
   result[16] = x122*(-x450 + x515 + x528) + x269 + x529 + x530;
}
else {
   result[16] = x209*(x205 + x371 + x531) + x272 + x532 + x533;
}
if (x147) {
   result[17] = x122*(x528 + x536) + x297 + x529 + x537;
}
else {
   result[17] = x209*(x531 + x538) + x312 + x532 + x539;
}
if (x147) {
   result[18] = x122*(x528 + x540) + x337 + x529 + x541;
}
else {
   result[18] = x209*(x531 + x542) + x348 + x532 + x543;
}
if (x147) {
   result[19] = x122*(x106 + x17 + x545) + x430 + x530 + x546;
}
else {
   result[19] = x209*(x155 + x205 + x548) + x435 + x533 + x549;
}
if (x147) {
   result[20] = x122*(x550 + 41.572313090766201*x6) + x392 + x439 + x551;
}
else {
   result[20] = x209*(x552 + 124.7169392722986*x6) + x403 + x444 + x553;
}
if (x147) {
   result[21] = x122*(x550 + 41.572313065822811*x6) + x447 + x551 + x554;
}
else {
   result[21] = x209*(x552 + 124.71693919746843*x6) + x449 + x553 + x555;
}
if (x147) {
   result[22] = x122*(x544 + x557) + x465 + x537 + x546;
}
else {
   result[22] = x209*(x366 + x559) + x474 + x539 + x549;
}
if (x147) {
   result[23] = x122*(x560 + x561) + x392 + x477 + x546 + x554;
}
else {
   result[23] = x209*(x562 + x563) + x403 + x480 + x549 + x555;
}
if (x147) {
   result[24] = x122*(x561 + x564) + x496 + x541 + x546;
}
else {
   result[24] = x209*(x563 + x565) + x501 + x543 + x549;
}
if (x147) {
   result[25] = x122*(-x267*x570 + x5*(x191 + x567) + x507*x569 + x516 + x574) + x146 - x268*x502 + x268*x517 + x428*x61 - 3*x429;
}
else {
   result[25] = x209*(x109*x569 - x270*x570 + x5*(x518 + x575) + x525 + x577) + x223 - x271*x50 + x271*x526 + x28*x433 - 3*x434;
}
if (x147) {
   result[26] = x122*(x536 + x579) + x297 + x580 + x581;
}
else {
   result[26] = x209*(x538 + x582) + x312 + x583 + x584;
}
if (x147) {
   result[27] = x122*(x540 + x579) + x337 + x580 + x585;
}
else {
   result[27] = x209*(x542 + x582) + x348 + x583 + x586;
}
if (x147) {
   result[28] = x122*(x557 + x587) + x465 + x581 + x588;
}
else {
   result[28] = x209*(x365 + x589) + x474 + x584 + x590;
}
if (x147) {
   result[29] = x122*(x560 + x591) + x337 + x440 + x447 + x477 + x588;
}
else {
   result[29] = x209*(x562 + x589) + x348 + x445 + x449 + x480 + x590;
}
if (x147) {
   result[30] = x122*(x564 + x591) + x496 + x585 + x588;
}
else {
   result[30] = x209*(x565 + x589) + x501 + x586 + x590;
}
if (x147) {
   result[31] = x122*(x120 - x290*x597 + x5*(x196 + x593) + x534 + x595*x596 + x607) + x146 - x296*x502 + x296*x517 + x463*x61 - 3*x464;
}
else {
   result[31] = x209*(x187 - x308*x597 + x5*(x191 + x608) + x507*x595 + x513 + x613) + x223 + x28*x472 - x311*x50 + x311*x526 - 3*x473;
}
if (x147) {
   result[32] = x122*(x323 + x5*(x593 + x599) + x596*x614 - 1.6628924015549273e-8*x6 + x607) + x337 + x465 + x615;
}
else {
   result[32] = x209*(x339 + x5*(x510 + x608) + x507*x614 - 4.9886779152075178e-8*x6 + x613) + x348 + x474 + x616;
}
if (x147) {
   result[33] = x122*(x491 + x5*(x593 + x83) + 41.572313057508353*x6 + x606) + x297 + x496 + x615;
}
else {
   result[33] = x209*(x498 + x5*(x196 + x608) + 124.71693917252504*x6 + x612) + x312 + x501 + x616;
}
if (x147) {
   result[34] = x122*(-x24*x621 - x24*x625 + x240*x624 + 24.943387829516332*x326 - x334*x622 + 24.943387829516332*x484 - 8.3144626015243155*x486 + x5*(x188 - 149.66032702698476*x617) + x53*x619 + x53*x623 + x572 - 99.773551351323178*x6 + x605 + 24.943387837830794*x618 + 24.943387837830794*x620 + 99.773551351323178*x86 + x91) + x146 - x336*x502 + x336*x517 + x494*x61 - 3*x495;
}
else {
   result[34] = x209*(-x160*x621 - x160*x625 + x171*x619 + x171*x623 + x193 + x201 + x259*x624 + 74.830163488549005*x326 - x345*x622 + 74.830163488549005*x484 - 24.943387804572946*x486 + x5*(448.98098108095428*x38 - 448.98098108095428*x617) - 299.32065405396952*x6 + x611 + 74.83016351349238*x618 + 74.83016351349238*x620 + 299.32065405396952*x86) + x223 + x28*x499 - x347*x50 + x347*x526 - 3*x500;
}
}
        
static double coder_dgdp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = 1.0/(n1 + n2 + n3 + n4 + n5);
    double x1 = 0.10299999999999999*n1*n3;
    double x2 = n1*(*endmember[0].dmu0dP)(T, P);
    double x3 = n2*(*endmember[1].dmu0dP)(T, P);
    double x4 = n3*(*endmember[2].dmu0dP)(T, P);
    double x5 = n4*(*endmember[3].dmu0dP)(T, P);
    double x6 = n5*(*endmember[4].dmu0dP)(T, P);

if (T >= 7.5) {
   result = x0*(x1 + (1.0*n1 + 1.0*n2 + 1.0*n3 + 1.0*n4 + 1.0*n5)*(x2 + x3 + x4 + x5 + x6));
}
else {
   result = x0*(x1 + (0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5)*(3*x2 + 3*x3 + 3*x4 + 3*x5 + 3*x6));
}
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n1 + n2 + n3 + n4 + n5;
    double x1 = pow(x0, -2);
    double x2 = 0.10299999999999999*n3;
    double x3 = n1*x2;
    double x4 = 1.0*n1;
    double x5 = 1.0*n2;
    double x6 = 1.0*n3;
    double x7 = 1.0*n4;
    double x8 = 1.0*n5;
    double x9 = x4 + x5 + x6 + x7 + x8;
    double x10 = (*endmember[0].dmu0dP)(T, P);
    double x11 = n1*x10;
    double x12 = (*endmember[1].dmu0dP)(T, P);
    double x13 = n2*x12;
    double x14 = (*endmember[2].dmu0dP)(T, P);
    double x15 = n3*x14;
    double x16 = (*endmember[3].dmu0dP)(T, P);
    double x17 = n4*x16;
    double x18 = (*endmember[4].dmu0dP)(T, P);
    double x19 = n5*x18;
    double x20 = -x1*(x3 + x9*(x11 + x13 + x15 + x17 + x19));
    double x21 = 1.0/x0;
    double x22 = x10*x4 + x12*x5 + x14*x6 + x16*x7 + x18*x8;
    double x23 = x2 + x22;
    double x24 = T >= 7.5;
    double x25 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5;
    double x26 = -x1*(x25*(3*x11 + 3*x13 + 3*x15 + 3*x17 + 3*x19) + x3);
    double x27 = 3*x25;
    double x28 = 0.10299999999999999*n1 + x22;

if (x24) {
   result[0] = x20 + x21*(x10*x9 + x23);
}
else {
   result[0] = x21*(x10*x27 + x23) + x26;
}
if (x24) {
   result[1] = x20 + x21*(x12*x9 + x22);
}
else {
   result[1] = x21*(x12*x27 + x22) + x26;
}
if (x24) {
   result[2] = x20 + x21*(x14*x9 + x28);
}
else {
   result[2] = x21*(x14*x27 + x28) + x26;
}
if (x24) {
   result[3] = x20 + x21*(x16*x9 + x22);
}
else {
   result[3] = x21*(x16*x27 + x22) + x26;
}
if (x24) {
   result[4] = x20 + x21*(x18*x9 + x22);
}
else {
   result[4] = x21*(x18*x27 + x22) + x26;
}
}
        
static void coder_d3gdn2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2 + n3 + n4 + n5;
    double x2 = 1.0/x1;
    double x3 = 2.0*x2;
    double x4 = x0*x3;
    double x5 = 0.10299999999999999*n3;
    double x6 = n1*x5;
    double x7 = 1.0*n1;
    double x8 = 1.0*n2;
    double x9 = 1.0*n3;
    double x10 = 1.0*n4;
    double x11 = 1.0*n5;
    double x12 = x10 + x11 + x7 + x8 + x9;
    double x13 = n1*x0;
    double x14 = (*endmember[1].dmu0dP)(T, P);
    double x15 = n2*x14;
    double x16 = (*endmember[2].dmu0dP)(T, P);
    double x17 = n3*x16;
    double x18 = (*endmember[3].dmu0dP)(T, P);
    double x19 = n4*x18;
    double x20 = (*endmember[4].dmu0dP)(T, P);
    double x21 = n5*x20;
    double x22 = 2/((x1)*(x1)*(x1));
    double x23 = x22*(x12*(x13 + x15 + x17 + x19 + x21) + x6);
    double x24 = pow(x1, -2);
    double x25 = x0*x7 + x10*x18 + x11*x20 + x14*x8 + x16*x9;
    double x26 = x25 + x5;
    double x27 = x24*(x0*x12 + x26);
    double x28 = T >= 7.5;
    double x29 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5;
    double x30 = x22*(x29*(3*x13 + 3*x15 + 3*x17 + 3*x19 + 3*x21) + x6);
    double x31 = 3*x29;
    double x32 = x24*(x0*x31 + x26);
    double x33 = 1.0*x0;
    double x34 = 1.0*x14;
    double x35 = x2*(x33 + x34);
    double x36 = x24*(x12*x14 + x25);
    double x37 = -x36;
    double x38 = x23 - x27;
    double x39 = x24*(x14*x31 + x25);
    double x40 = -x39;
    double x41 = x30 - x32;
    double x42 = 1.0*x16;
    double x43 = x2*(x33 + x42 + 0.10299999999999999);
    double x44 = 0.10299999999999999*n1 + x25;
    double x45 = x24*(x12*x16 + x44);
    double x46 = -x45;
    double x47 = x24*(x16*x31 + x44);
    double x48 = -x47;
    double x49 = 1.0*x18;
    double x50 = x2*(x33 + x49);
    double x51 = x24*(x12*x18 + x25);
    double x52 = -x51;
    double x53 = x24*(x18*x31 + x25);
    double x54 = -x53;
    double x55 = 1.0*x20;
    double x56 = x2*(x33 + x55);
    double x57 = x24*(x12*x20 + x25);
    double x58 = -x57;
    double x59 = x24*(x20*x31 + x25);
    double x60 = -x59;
    double x61 = x14*x3;
    double x62 = x2*(x34 + x42);
    double x63 = x23 + x37;
    double x64 = x30 + x40;
    double x65 = x2*(x34 + x49);
    double x66 = x2*(x34 + x55);
    double x67 = x16*x3;
    double x68 = x2*(x42 + x49);
    double x69 = x23 + x46;
    double x70 = x30 + x48;
    double x71 = x2*(x42 + x55);
    double x72 = x18*x3;
    double x73 = x2*(x49 + x55);
    double x74 = x20*x3;

if (x28) {
   result[0] = x23 - 2*x27 + x4;
}
else {
   result[0] = x30 - 2*x32 + x4;
}
if (x28) {
   result[1] = x35 + x37 + x38;
}
else {
   result[1] = x35 + x40 + x41;
}
if (x28) {
   result[2] = x38 + x43 + x46;
}
else {
   result[2] = x41 + x43 + x48;
}
if (x28) {
   result[3] = x38 + x50 + x52;
}
else {
   result[3] = x41 + x50 + x54;
}
if (x28) {
   result[4] = x38 + x56 + x58;
}
else {
   result[4] = x41 + x56 + x60;
}
if (x28) {
   result[5] = x23 - 2*x36 + x61;
}
else {
   result[5] = x30 - 2*x39 + x61;
}
if (x28) {
   result[6] = x46 + x62 + x63;
}
else {
   result[6] = x48 + x62 + x64;
}
if (x28) {
   result[7] = x52 + x63 + x65;
}
else {
   result[7] = x54 + x64 + x65;
}
if (x28) {
   result[8] = x58 + x63 + x66;
}
else {
   result[8] = x60 + x64 + x66;
}
if (x28) {
   result[9] = x23 - 2*x45 + x67;
}
else {
   result[9] = x30 - 2*x47 + x67;
}
if (x28) {
   result[10] = x52 + x68 + x69;
}
else {
   result[10] = x54 + x68 + x70;
}
if (x28) {
   result[11] = x58 + x69 + x71;
}
else {
   result[11] = x60 + x70 + x71;
}
if (x28) {
   result[12] = x23 - 2*x51 + x72;
}
else {
   result[12] = x30 - 2*x53 + x72;
}
if (x28) {
   result[13] = x23 + x52 + x58 + x73;
}
else {
   result[13] = x30 + x54 + x60 + x73;
}
if (x28) {
   result[14] = x23 - 2*x57 + x74;
}
else {
   result[14] = x30 - 2*x59 + x74;
}
}
        
static void coder_d4gdn3dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2 + n3 + n4 + n5;
    double x2 = pow(x1, -2);
    double x3 = x0*x2;
    double x4 = -6.0*x3;
    double x5 = 0.10299999999999999*n3;
    double x6 = n1*x5;
    double x7 = 1.0*n1;
    double x8 = 1.0*n2;
    double x9 = 1.0*n3;
    double x10 = 1.0*n4;
    double x11 = 1.0*n5;
    double x12 = x10 + x11 + x7 + x8 + x9;
    double x13 = n1*x0;
    double x14 = (*endmember[1].dmu0dP)(T, P);
    double x15 = n2*x14;
    double x16 = (*endmember[2].dmu0dP)(T, P);
    double x17 = n3*x16;
    double x18 = (*endmember[3].dmu0dP)(T, P);
    double x19 = n4*x18;
    double x20 = (*endmember[4].dmu0dP)(T, P);
    double x21 = n5*x20;
    double x22 = 6/((x1)*(x1)*(x1)*(x1));
    double x23 = -x22*(x12*(x13 + x15 + x17 + x19 + x21) + x6);
    double x24 = x0*x7 + x10*x18 + x11*x20 + x14*x8 + x16*x9;
    double x25 = x24 + x5;
    double x26 = x0*x12 + x25;
    double x27 = pow(x1, -3);
    double x28 = 6*x27;
    double x29 = T >= 7.5;
    double x30 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + 0.33333333333333331*n5;
    double x31 = -x22*(x30*(3*x13 + 3*x15 + 3*x17 + 3*x19 + 3*x21) + x6);
    double x32 = 3*x30;
    double x33 = x0*x32 + x25;
    double x34 = 4*x27;
    double x35 = x26*x34;
    double x36 = 1.0*x0;
    double x37 = 1.0*x14;
    double x38 = x2*(x36 + x37);
    double x39 = -2*x38;
    double x40 = -2.0*x3;
    double x41 = x39 + x40;
    double x42 = x12*x14 + x24;
    double x43 = 2*x27;
    double x44 = x23 + x42*x43;
    double x45 = x14*x32 + x24;
    double x46 = x43*x45;
    double x47 = x31 + x33*x34;
    double x48 = 1.0*x16;
    double x49 = x2*(x36 + x48 + 0.10299999999999999);
    double x50 = -2*x49;
    double x51 = x40 + x50;
    double x52 = 0.10299999999999999*n1 + x24;
    double x53 = x12*x16 + x52;
    double x54 = x43*x53;
    double x55 = x23 + x54;
    double x56 = x16*x32 + x52;
    double x57 = x43*x56;
    double x58 = 1.0*x18;
    double x59 = x2*(x36 + x58);
    double x60 = -2*x59;
    double x61 = x40 + x60;
    double x62 = x12*x18 + x24;
    double x63 = x43*x62;
    double x64 = x23 + x63;
    double x65 = x18*x32 + x24;
    double x66 = x43*x65;
    double x67 = 1.0*x20;
    double x68 = x2*(x36 + x67);
    double x69 = -2*x68;
    double x70 = x40 + x69;
    double x71 = x12*x20 + x24;
    double x72 = x43*x71;
    double x73 = x23 + x72;
    double x74 = x20*x32 + x24;
    double x75 = x43*x74;
    double x76 = x34*x42;
    double x77 = 2.0*x2;
    double x78 = -x14*x77;
    double x79 = x39 + x78;
    double x80 = x26*x43;
    double x81 = x23 + x80;
    double x82 = x34*x45;
    double x83 = x31 + x33*x43;
    double x84 = -x49;
    double x85 = x80 + x84;
    double x86 = -x38;
    double x87 = x2*(x37 + x48);
    double x88 = -x87;
    double x89 = x86 + x88;
    double x90 = x44 + x54;
    double x91 = x46 + x83;
    double x92 = x57 + x84;
    double x93 = -x59;
    double x94 = x63 + x93;
    double x95 = x2*(x37 + x58);
    double x96 = -x95;
    double x97 = x86 + x96;
    double x98 = x44 + x80;
    double x99 = x66 + x93;
    double x100 = -x68;
    double x101 = x100 + x72;
    double x102 = x2*(x37 + x67);
    double x103 = -x102;
    double x104 = x103 + x86;
    double x105 = x100 + x75;
    double x106 = x34*x53;
    double x107 = -x16*x77;
    double x108 = x107 + x50;
    double x109 = x34*x56;
    double x110 = x2*(x48 + x58);
    double x111 = -x110;
    double x112 = x55 + x85;
    double x113 = x83 + x92;
    double x114 = x2*(x48 + x67);
    double x115 = -x114;
    double x116 = x34*x62;
    double x117 = -x18*x77;
    double x118 = x117 + x60;
    double x119 = x34*x65;
    double x120 = x2*(x58 + x67);
    double x121 = -x120;
    double x122 = x34*x71;
    double x123 = -x20*x77;
    double x124 = x123 + x69;
    double x125 = x34*x74;
    double x126 = 6.0*x2;
    double x127 = -x126*x14;
    double x128 = -2*x87;
    double x129 = x128 + x78;
    double x130 = x31 + x82;
    double x131 = -2*x95;
    double x132 = x131 + x78;
    double x133 = -2*x102;
    double x134 = x133 + x78;
    double x135 = x107 + x128;
    double x136 = x31 + x46;
    double x137 = x88 + x90;
    double x138 = x63 + x96;
    double x139 = x111 + x66;
    double x140 = x136 + x57 + x88;
    double x141 = x103 + x115;
    double x142 = x117 + x131;
    double x143 = x103 + x121;
    double x144 = x123 + x133;
    double x145 = -x126*x16;
    double x146 = -2*x110;
    double x147 = x107 + x146;
    double x148 = x109 + x31;
    double x149 = -2*x114;
    double x150 = x107 + x149;
    double x151 = x117 + x146;
    double x152 = x31 + x57;
    double x153 = x115 + x121;
    double x154 = x123 + x149;
    double x155 = -x126*x18;
    double x156 = -2*x120;
    double x157 = x117 + x156;
    double x158 = x123 + x156;
    double x159 = -x126*x20;

if (x29) {
   result[0] = x23 + x26*x28 + x4;
}
else {
   result[0] = x28*x33 + x31 + x4;
}
if (x29) {
   result[1] = x35 + x41 + x44;
}
else {
   result[1] = x41 + x46 + x47;
}
if (x29) {
   result[2] = x35 + x51 + x55;
}
else {
   result[2] = x47 + x51 + x57;
}
if (x29) {
   result[3] = x35 + x61 + x64;
}
else {
   result[3] = x47 + x61 + x66;
}
if (x29) {
   result[4] = x35 + x70 + x73;
}
else {
   result[4] = x47 + x70 + x75;
}
if (x29) {
   result[5] = x76 + x79 + x81;
}
else {
   result[5] = x79 + x82 + x83;
}
if (x29) {
   result[6] = x85 + x89 + x90;
}
else {
   result[6] = x89 + x91 + x92;
}
if (x29) {
   result[7] = x94 + x97 + x98;
}
else {
   result[7] = x91 + x97 + x99;
}
if (x29) {
   result[8] = x101 + x104 + x98;
}
else {
   result[8] = x104 + x105 + x91;
}
if (x29) {
   result[9] = x106 + x108 + x81;
}
else {
   result[9] = x108 + x109 + x83;
}
if (x29) {
   result[10] = x111 + x112 + x94;
}
else {
   result[10] = x111 + x113 + x99;
}
if (x29) {
   result[11] = x101 + x112 + x115;
}
else {
   result[11] = x105 + x113 + x115;
}
if (x29) {
   result[12] = x116 + x118 + x81;
}
else {
   result[12] = x118 + x119 + x83;
}
if (x29) {
   result[13] = x101 + x121 + x64 + x80 + x93;
}
else {
   result[13] = x105 + x121 + x83 + x99;
}
if (x29) {
   result[14] = x122 + x124 + x81;
}
else {
   result[14] = x124 + x125 + x83;
}
if (x29) {
   result[15] = x127 + x23 + x28*x42;
}
else {
   result[15] = x127 + x28*x45 + x31;
}
if (x29) {
   result[16] = x129 + x55 + x76;
}
else {
   result[16] = x129 + x130 + x57;
}
if (x29) {
   result[17] = x132 + x64 + x76;
}
else {
   result[17] = x130 + x132 + x66;
}
if (x29) {
   result[18] = x134 + x73 + x76;
}
else {
   result[18] = x130 + x134 + x75;
}
if (x29) {
   result[19] = x106 + x135 + x44;
}
else {
   result[19] = x109 + x135 + x136;
}
if (x29) {
   result[20] = x111 + x137 + x138;
}
else {
   result[20] = x139 + x140 + x96;
}
if (x29) {
   result[21] = x137 + x141 + x72;
}
else {
   result[21] = x140 + x141 + x75;
}
if (x29) {
   result[22] = x116 + x142 + x44;
}
else {
   result[22] = x119 + x136 + x142;
}
if (x29) {
   result[23] = x138 + x143 + x44 + x72;
}
else {
   result[23] = x136 + x143 + x66 + x75 + x96;
}
if (x29) {
   result[24] = x122 + x144 + x44;
}
else {
   result[24] = x125 + x136 + x144;
}
if (x29) {
   result[25] = x145 + x23 + x28*x53;
}
else {
   result[25] = x145 + x28*x56 + x31;
}
if (x29) {
   result[26] = x106 + x147 + x64;
}
else {
   result[26] = x147 + x148 + x66;
}
if (x29) {
   result[27] = x106 + x150 + x73;
}
else {
   result[27] = x148 + x150 + x75;
}
if (x29) {
   result[28] = x116 + x151 + x55;
}
else {
   result[28] = x119 + x151 + x152;
}
if (x29) {
   result[29] = x111 + x153 + x55 + x63 + x72;
}
else {
   result[29] = x139 + x152 + x153 + x75;
}
if (x29) {
   result[30] = x122 + x154 + x55;
}
else {
   result[30] = x125 + x152 + x154;
}
if (x29) {
   result[31] = x155 + x23 + x28*x62;
}
else {
   result[31] = x155 + x28*x65 + x31;
}
if (x29) {
   result[32] = x116 + x157 + x73;
}
else {
   result[32] = x119 + x157 + x31 + x75;
}
if (x29) {
   result[33] = x122 + x158 + x64;
}
else {
   result[33] = x125 + x158 + x31 + x66;
}
if (x29) {
   result[34] = x159 + x23 + x28*x71;
}
else {
   result[34] = x159 + x28*x74 + x31;
}
}
        
static double coder_d2gdt2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = 1.0*n1*(*endmember[0].d2mu0dT2)(T, P) + 1.0*n2*(*endmember[1].d2mu0dT2)(T, P) + 1.0*n3*(*endmember[2].d2mu0dT2)(T, P) + 1.0*n4*(*endmember[3].d2mu0dT2)(T, P) + 1.0*n5*(*endmember[4].d2mu0dT2)(T, P);
    double x1 = 0.13333333333333333*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 0.53525400000000001*T - 4.014405;
    double x7 = 1.0/(x1 - 1);
    double x8 = x7*0;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = 4.014405*((x10)*(x10));

if (T >= 7.5) {
   result = x0;
}
else {
   result = -0.33333333333333331*n2*(8.02881*x10*((x5)*(x5))*x7 - x11*x8 + x11*x9 - x6*x8 + x6*x9 + 16.05762*x5/x3) + x0;
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = 1.0*(*endmember[1].d2mu0dT2)(T, P);
    double x1 = 0.13333333333333333*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 1.0/(x1 - 1);
    double x7 = x6*0;
    double x8 = 0.17841799999999999*T - 1.3381349999999999;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = 1.3381349999999999*((x10)*(x10));

result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
if (T >= 7.5) {
   result[1] = x0;
}
else {
   result[1] = x0 - 2.6762699999999997*x10*((x5)*(x5))*x6 + x11*x7 - x11*x9 + x7*x8 - x8*x9 - 5.3525399999999994*x5/x3;
}
result[2] = 1.0*(*endmember[2].d2mu0dT2)(T, P);
result[3] = 1.0*(*endmember[3].d2mu0dT2)(T, P);
result[4] = 1.0*(*endmember[4].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dTdP)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dTdP)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dTdP)(T, P);
    double x3 = n4*(*endmember[3].d2mu0dTdP)(T, P);
    double x4 = n5*(*endmember[4].d2mu0dTdP)(T, P);

if (T >= 7.5) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3 + 1.0*x4;
}
else {
   result = x0 + x1 + x2 + x3 + x4;
}
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dTdP)(T, P);
result[3] = 1.0*(*endmember[3].d2mu0dTdP)(T, P);
result[4] = 1.0*(*endmember[4].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dP2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dP2)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dP2)(T, P);
    double x3 = n4*(*endmember[3].d2mu0dP2)(T, P);
    double x4 = n5*(*endmember[4].d2mu0dP2)(T, P);

if (T >= 7.5) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3 + 1.0*x4;
}
else {
   result = x0 + x1 + x2 + x3 + x4;
}
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dP2)(T, P);
result[3] = 1.0*(*endmember[3].d2mu0dP2)(T, P);
result[4] = 1.0*(*endmember[4].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = 1.0*n1*(*endmember[0].d3mu0dT3)(T, P) + 1.0*n2*(*endmember[1].d3mu0dT3)(T, P) + 1.0*n3*(*endmember[2].d3mu0dT3)(T, P) + 1.0*n4*(*endmember[3].d3mu0dT3)(T, P) + 1.0*n5*(*endmember[4].d3mu0dT3)(T, P);
    double x1 = 0.13333333333333333*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = pow(x3, -3.0/2.0);
    double x8 = (4 - x4 >= 0. ? 1. : 0.);
    double x9 = 1.6057619999999999*x7*x8;
    double x10 = pow(x2, -2);
    double x11 = x10*x6;
    double x12 = 120.43215000000001*T - 903.24112500000001;
    double x13 = 0.00088888888888888893*x12;
    double x14 = x8/pow(x3, 5.0/2.0);
    double x15 = x7*0;
    double x16 = fmin(4, x4);
    double x17 = ((x16)*(x16));

if (T >= 7.5) {
   result = x0;
}
else {
   result = -0.33333333333333331*n2*(-1.6057619999999999*x10*x16*((x8)*(x8)) + x11*x13 + 0.80288099999999996*x11*x17 - 0.00029629629629629629*x12*x15 + x13*x14 + 0.80288100000000007*x14*x17 - 0.267627*x15*x17 - x16*x6*x9 + 0.53525400000000001*x7*((x8)*(x8)*(x8)) + x9 - 1.6057619999999999*x6/x2) + x0;
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = 1.0*(*endmember[1].d3mu0dT3)(T, P);
    double x1 = 0.13333333333333333*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = 0.5352539999999999*x6;
    double x8 = pow(x3, -3.0/2.0);
    double x9 = (4 - x4 >= 0. ? 1. : 0.);
    double x10 = x8*x9;
    double x11 = pow(x2, -2);
    double x12 = x11*x6;
    double x13 = 120.43215000000001*T - 903.24112500000001;
    double x14 = 0.00029629629629629629*x13;
    double x15 = x9/pow(x3, 5.0/2.0);
    double x16 = x8*0;
    double x17 = fmin(4, x4);
    double x18 = ((x17)*(x17));

result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
if (T >= 7.5) {
   result[1] = x0;
}
else {
   result[1] = x0 + x10*x17*x7 - 0.5352539999999999*x10 + 0.5352539999999999*x11*x17*((x9)*(x9)) - x12*x14 - 0.26762699999999995*x12*x18 + 9.8765432098765426e-5*x13*x16 - x14*x15 - 0.267627*x15*x18 + 0.089208999999999997*x16*x18 - 0.17841799999999999*x8*((x9)*(x9)*(x9)) + x7/x2;
}
result[2] = 1.0*(*endmember[2].d3mu0dT3)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dT3)(T, P);
result[4] = 1.0*(*endmember[4].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT2dP)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT2dP)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dT2dP)(T, P);
    double x3 = n4*(*endmember[3].d3mu0dT2dP)(T, P);
    double x4 = n5*(*endmember[4].d3mu0dT2dP)(T, P);

if (T >= 7.5) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3 + 1.0*x4;
}
else {
   result = x0 + x1 + x2 + x3 + x4;
}
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dT2dP)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dT2dP)(T, P);
result[4] = 1.0*(*endmember[4].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dTdP2)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dTdP2)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dTdP2)(T, P);
    double x3 = n4*(*endmember[3].d3mu0dTdP2)(T, P);
    double x4 = n5*(*endmember[4].d3mu0dTdP2)(T, P);

if (T >= 7.5) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3 + 1.0*x4;
}
else {
   result = x0 + x1 + x2 + x3 + x4;
}
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dTdP2)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dTdP2)(T, P);
result[4] = 1.0*(*endmember[4].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dP3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dP3)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dP3)(T, P);
    double x3 = n4*(*endmember[3].d3mu0dP3)(T, P);
    double x4 = n5*(*endmember[4].d3mu0dP3)(T, P);

if (T >= 7.5) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3 + 1.0*x4;
}
else {
   result = x0 + x1 + x2 + x3 + x4;
}
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dP3)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dP3)(T, P);
result[4] = 1.0*(*endmember[4].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_s(double T, double P, double n[5]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[5]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[5]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[5]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[5]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[5]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[5]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[5]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[5]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[5]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[5]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[5]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[5]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[5]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

