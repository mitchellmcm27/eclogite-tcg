#include <math.h>


static double coder_g(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = 0.00029999999999999997*P - 153.0;

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result = n1*x0;
}
else {
   result = n1*(x0*x1 - sqrt((1.9607843137254902e-6*P - 0.00023529411764705883*T - 1)/(0.0001*P - 51.0))*(2.1424285285628555e-7*((P)*(P)) - 2.5709142342754266e-5*P*T - 0.18210642492784271*P + 8.7411083965364504*T + 37149.710685279919))/x1;
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = 0.00029999999999999997*P - 153.0;

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result[0] = x0;
}
else {
   result[0] = (x0*x1 - sqrt((1.9607843137254902e-6*P - 0.00023529411764705883*T - 1)/(0.0001*P - 51.0))*(2.1424285285628555e-7*((P)*(P)) - 2.5709142342754266e-5*P*T - 0.18210642492784271*P + 8.7411083965364504*T + 37149.710685279919))/x1;
}
}
        
static void coder_d2gdn2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d3gdn3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_dgdt(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = 0.00029999999999999997*P - 153.0;
    double x2 = 2.5709142342754266e-5*P;
    double x3 = 1.9607843137254902e-6*P - 0.00023529411764705883*T - 1;
    double x4 = sqrt(x3/(0.0001*P - 51.0));

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result = n1*x0;
}
else {
   result = n1*(x0*x1 - x4*(8.7411083965364504 - x2) + 0.00011764705882352942*x4*(2.1424285285628555e-7*((P)*(P)) - 0.18210642492784271*P - T*x2 + 8.7411083965364504*T + 37149.710685279919)/x3)/x1;
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = 0.00029999999999999997*P - 153.0;
    double x2 = 2.5709142342754266e-5*P;
    double x3 = 1.9607843137254902e-6*P - 0.00023529411764705883*T - 1;
    double x4 = sqrt(x3/(0.0001*P - 51.0));

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result[0] = x0;
}
else {
   result[0] = (x0*x1 - x4*(8.7411083965364504 - x2) + 0.00011764705882352942*x4*(2.1424285285628555e-7*((P)*(P)) - 0.18210642492784271*P - T*x2 + 8.7411083965364504*T + 37149.710685279919)/x3)/x1;
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d4gdn3dt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_dgdp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].dmu0dP)(T, P);
    double x2 = pow(1.9607843137254902e-6*P - 1, -2);
    double x3 = 0.00029999999999999997*P - 153.0;
    double x4 = 2.5709142342754266e-5*T;
    double x5 = 0.0001*P - 51.0;
    double x6 = 1.0/x5;
    double x7 = 1.9607843137254902e-6*P - 0.00023529411764705883*T - 1;
    double x8 = sqrt(x6*x7);
    double x9 = x8*(2.1424285285628555e-7*((P)*(P)) - P*x4 - 0.18210642492784271*P + 8.7411083965364504*T + 37149.710685279919);

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result = n1*x1;
}
else {
   result = -1.2815583749839804e-8*n1*x2*(x0*x3 - x9) + n1*(0.00029999999999999997*x0 + x1*x3 - x5*x9*(-1.922337562475971e-8*x2*x7 + 9.8039215686274508e-7*x6)/x7 - x8*(4.284857057125711e-7*P - x4 - 0.18210642492784271))/x3;
}
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].dmu0dP)(T, P);
    double x2 = pow(1.9607843137254902e-6*P - 1, -2);
    double x3 = 0.00029999999999999997*P - 153.0;
    double x4 = 2.5709142342754266e-5*T;
    double x5 = 0.0001*P - 51.0;
    double x6 = 1.0/x5;
    double x7 = 1.9607843137254902e-6*P - 0.00023529411764705883*T - 1;
    double x8 = sqrt(x6*x7);
    double x9 = x8*(2.1424285285628555e-7*((P)*(P)) - P*x4 - 0.18210642492784271*P + 8.7411083965364504*T + 37149.710685279919);

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result[0] = x1;
}
else {
   result[0] = -1.2815583749839804e-8*x2*(x0*x3 - x9) + (0.00029999999999999997*x0 + x1*x3 - x5*x9*(-1.922337562475971e-8*x2*x7 + 9.8039215686274508e-7*x6)/x7 - x8*(4.284857057125711e-7*P - x4 - 0.18210642492784271))/x3;
}
}
        
static void coder_d3gdn2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = 0.00029999999999999997*P - 153.0;
    double x2 = 2.5709142342754266e-5*P;
    double x3 = -1.9607843137254902e-6*P + 0.00023529411764705883*T + 1;
    double x4 = sqrt(-x3/(0.0001*P - 51.0));

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result = n1*x0;
}
else {
   result = n1*(x0*x1 + 0.00023529411764705883*x4*(x2 - 8.7411083965364504)/x3 + 1.384083044982699e-8*x4*(2.1424285285628555e-7*((P)*(P)) - 0.18210642492784271*P - T*x2 + 8.7411083965364504*T + 37149.710685279919)/((x3)*(x3)))/x1;
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = 0.00029999999999999997*P - 153.0;
    double x2 = 2.5709142342754266e-5*P;
    double x3 = -1.9607843137254902e-6*P + 0.00023529411764705883*T + 1;
    double x4 = sqrt(-x3/(0.0001*P - 51.0));

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result[0] = x0;
}
else {
   result[0] = (x0*x1 + 0.00023529411764705883*x4*(x2 - 8.7411083965364504)/x3 + 1.384083044982699e-8*x4*(2.1424285285628555e-7*((P)*(P)) - 0.18210642492784271*P - T*x2 + 8.7411083965364504*T + 37149.710685279919)/((x3)*(x3)))/x1;
}
}
        
static void coder_d4gdn2dt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d2mu0dTdP)(T, P);
    double x2 = 1.9607843137254902e-6*P;
    double x3 = pow(x2 - 1, -2);
    double x4 = 0.00029999999999999997*P - 153.0;
    double x5 = (*endmember[0].dmu0dT)(T, P);
    double x6 = 0.0001*P - 51.0;
    double x7 = 1.0/x6;
    double x8 = 0.00023529411764705883*T - x2 + 1;
    double x9 = sqrt(-x7*x8);
    double x10 = x9*(2.5709142342754266e-5*P - 8.7411083965364504);
    double x11 = 2.5709142342754266e-5*T;
    double x12 = 2.1424285285628555e-7*((P)*(P)) - P*x11 - 0.18210642492784271*P + 8.7411083965364504*T + 37149.710685279919;
    double x13 = 1.0/x8;
    double x14 = x13*x9;
    double x15 = x12*x14;
    double x16 = x6*(x3*(-3.7692893381881782e-14*P + 4.5231472058258138e-12*T + 1.922337562475971e-8) + 9.8039215686274508e-7*x7);

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result = n1*x1;
}
else {
   result = n1*(-x3*(1.2815583749839804e-8*x10 - 1.5077157352752712e-12*x15 + 1.2815583749839804e-8*x4*x5) + (x1*x4 - x10*x13*x16 - 0.00011764705882352942*x12*x16*x9/((x8)*(x8)) + 0.00011764705882352942*x14*(-4.284857057125711e-7*P + x11 + 0.18210642492784271) + 4.5231472058258138e-12*x15*x3*x6 + 0.00029999999999999997*x5 + 2.5709142342754266e-5*x9)/x4);
}
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d2mu0dTdP)(T, P);
    double x2 = 1.9607843137254902e-6*P;
    double x3 = pow(x2 - 1, -2);
    double x4 = 0.00029999999999999997*P - 153.0;
    double x5 = (*endmember[0].dmu0dT)(T, P);
    double x6 = 0.0001*P - 51.0;
    double x7 = 1.0/x6;
    double x8 = 0.00023529411764705883*T - x2 + 1;
    double x9 = sqrt(-x7*x8);
    double x10 = x9*(2.5709142342754266e-5*P - 8.7411083965364504);
    double x11 = 2.5709142342754266e-5*T;
    double x12 = 2.1424285285628555e-7*((P)*(P)) - P*x11 - 0.18210642492784271*P + 8.7411083965364504*T + 37149.710685279919;
    double x13 = 1.0/x8;
    double x14 = x13*x9;
    double x15 = x12*x14;
    double x16 = x6*(x3*(-3.7692893381881782e-14*P + 4.5231472058258138e-12*T + 1.922337562475971e-8) + 9.8039215686274508e-7*x7);

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result[0] = x1;
}
else {
   result[0] = -x3*(1.2815583749839804e-8*x10 - 1.5077157352752712e-12*x15 + 1.2815583749839804e-8*x4*x5) + (x1*x4 - x10*x13*x16 - 0.00011764705882352942*x12*x16*x9/((x8)*(x8)) + 0.00011764705882352942*x14*(-4.284857057125711e-7*P + x11 + 0.18210642492784271) + 4.5231472058258138e-12*x15*x3*x6 + 0.00029999999999999997*x5 + 2.5709142342754266e-5*x9)/x4;
}
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d2mu0dP2)(T, P);
    double x2 = 1.9607843137254902e-6*P - 1;
    double x3 = 0.00029999999999999997*P - 153.0;
    double x4 = 0.0001*P - 51.0;
    double x5 = 1.0/x4;
    double x6 = 1.9607843137254902e-6*P - 0.00023529411764705883*T - 1;
    double x7 = sqrt(x5*x6);
    double x8 = 2.5709142342754266e-5*T;
    double x9 = 2.1424285285628555e-7*((P)*(P)) - P*x8 - 0.18210642492784271*P + 8.7411083965364504*T + 37149.710685279919;
    double x10 = x7*x9;
    double x11 = ((x2)*(x2));
    double x12 = 1.0/x11;
    double x13 = (*endmember[0].dmu0dP)(T, P);
    double x14 = 4.284857057125711e-7*P - x8 - 0.18210642492784271;
    double x15 = 2.5631167499679608e-8*x7;
    double x16 = 1.0/x6;
    double x17 = -x12*(3.7692893381881782e-14*P - 4.5231472058258138e-12*T - 1.922337562475971e-8) + 9.8039215686274508e-7*x5;
    double x18 = x16*x17;
    double x19 = x18*x4;
    double x20 = x10/((x6)*(x6));

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result = n1*x1;
}
else {
   result = n1*(x12*(-7.6893502499038817e-12*x0 - 2.5631167499679608e-8*x13*x3 + x14*x15 + x15*x19*x9) - (-x1*x3 + 7.5385786763763563e-14*x10*x12*x16*x4*(-1 + x6/x2) + 0.0001*x10*x18 + 2.5000000000000001e-9*x11*x20*((-x12*(3.8446751249519419e-8*P - 4.6136101499423305e-6*T - 0.019607843137254905) + x5)*(-x12*(3.8446751249519419e-8*P - 4.6136101499423305e-6*T - 0.019607843137254905) + x5)) - 0.00059999999999999995*x13 + 2*x14*x19*x7 - 1.9607843137254902e-6*x17*x20*x4 + 4.284857057125711e-7*x7)/x3 - (-5.0257191175842371e-14*x0*x3 + 5.0257191175842371e-14*x10)/((x2)*(x2)*(x2)));
}
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d2mu0dP2)(T, P);
    double x2 = 1.9607843137254902e-6*P - 1;
    double x3 = 0.00029999999999999997*P - 153.0;
    double x4 = 0.0001*P - 51.0;
    double x5 = 1.0/x4;
    double x6 = 1.9607843137254902e-6*P - 0.00023529411764705883*T - 1;
    double x7 = sqrt(x5*x6);
    double x8 = 2.5709142342754266e-5*T;
    double x9 = 2.1424285285628555e-7*((P)*(P)) - P*x8 - 0.18210642492784271*P + 8.7411083965364504*T + 37149.710685279919;
    double x10 = x7*x9;
    double x11 = ((x2)*(x2));
    double x12 = 1.0/x11;
    double x13 = (*endmember[0].dmu0dP)(T, P);
    double x14 = 4.284857057125711e-7*P - x8 - 0.18210642492784271;
    double x15 = 2.5631167499679608e-8*x7;
    double x16 = 1.0/x6;
    double x17 = -x12*(3.7692893381881782e-14*P - 4.5231472058258138e-12*T - 1.922337562475971e-8) + 9.8039215686274508e-7*x5;
    double x18 = x16*x17;
    double x19 = x18*x4;
    double x20 = x10/((x6)*(x6));

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result[0] = x1;
}
else {
   result[0] = x12*(-7.6893502499038817e-12*x0 - 2.5631167499679608e-8*x13*x3 + x14*x15 + x15*x19*x9) - (-x1*x3 + 7.5385786763763563e-14*x10*x12*x16*x4*(-1 + x6/x2) + 0.0001*x10*x18 + 2.5000000000000001e-9*x11*x20*((-x12*(3.8446751249519419e-8*P - 4.6136101499423305e-6*T - 0.019607843137254905) + x5)*(-x12*(3.8446751249519419e-8*P - 4.6136101499423305e-6*T - 0.019607843137254905) + x5)) - 0.00059999999999999995*x13 + 2*x14*x19*x7 - 1.9607843137254902e-6*x17*x20*x4 + 4.284857057125711e-7*x7)/x3 - (-5.0257191175842371e-14*x0*x3 + 5.0257191175842371e-14*x10)/((x2)*(x2)*(x2));
}
}
        
static void coder_d4gdn2dp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = 0.00029999999999999997*P - 153.0;
    double x2 = 2.5709142342754266e-5*P;
    double x3 = -1.9607843137254902e-6*P + 0.00023529411764705883*T + 1;
    double x4 = sqrt(-x3/(0.0001*P - 51.0));

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result = n1*x0;
}
else {
   result = -n1*(-x0*x1 + 4.152249134948097e-8*x4*(x2 - 8.7411083965364504)/((x3)*(x3)) + 4.8849989822918787e-12*x4*(2.1424285285628555e-7*((P)*(P)) - 0.18210642492784271*P - T*x2 + 8.7411083965364504*T + 37149.710685279919)/((x3)*(x3)*(x3)))/x1;
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = 0.00029999999999999997*P - 153.0;
    double x2 = 2.5709142342754266e-5*P;
    double x3 = -1.9607843137254902e-6*P + 0.00023529411764705883*T + 1;
    double x4 = sqrt(-x3/(0.0001*P - 51.0));

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result[0] = x0;
}
else {
   result[0] = -(-x0*x1 + 4.152249134948097e-8*x4*(x2 - 8.7411083965364504)/((x3)*(x3)) + 4.8849989822918787e-12*x4*(2.1424285285628555e-7*((P)*(P)) - 0.18210642492784271*P - T*x2 + 8.7411083965364504*T + 37149.710685279919)/((x3)*(x3)*(x3)))/x1;
}
}
        
static void coder_d5gdn2dt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x2 = 1.9607843137254902e-6*P;
    double x3 = pow(x2 - 1, -2);
    double x4 = 0.00029999999999999997*P - 153.0;
    double x5 = (*endmember[0].d2mu0dT2)(T, P);
    double x6 = 2.5709142342754266e-5*P;
    double x7 = x6 - 8.7411083965364504;
    double x8 = 0.00023529411764705883*T - x2 + 1;
    double x9 = 0.0001*P - 51.0;
    double x10 = 1.0/x9;
    double x11 = sqrt(-x10*x8);
    double x12 = 2.1424285285628555e-7*((P)*(P)) - 0.18210642492784271*P - T*x6 + 8.7411083965364504*T + 37149.710685279919;
    double x13 = -x8;
    double x14 = sqrt(x10*x13);
    double x15 = x14/x13;
    double x16 = x14/((x13)*(x13));
    double x17 = -x7;
    double x18 = x3*x9;
    double x19 = x9*(9.8039215686274508e-7*x10 - x3*(3.7692893381881782e-14*P - 4.5231472058258138e-12*T - 1.922337562475971e-8));

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result = n1*x1;
}
else {
   result = -n1*(x3*(1.7737832179709071e-16*x11*x12/((x8)*(x8)) + 3.0154314705505424e-12*x11*x7/x8 + 1.2815583749839804e-8*x4*x5) + (-x1*x4 + 1.0642699307825445e-15*x12*x16*x18 + 4.152249134948097e-8*x12*x14*x19/((x13)*(x13)*(x13)) + 9.0462944116516277e-12*x15*x17*x18 + 6.0492099630010037e-9*x15 + 0.00023529411764705883*x16*x17*x19 - 1.384083044982699e-8*x16*(4.284857057125711e-7*P - 2.5709142342754266e-5*T - 0.18210642492784271) - 0.00029999999999999997*x5)/x4);
}
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x2 = 1.9607843137254902e-6*P;
    double x3 = pow(x2 - 1, -2);
    double x4 = 0.00029999999999999997*P - 153.0;
    double x5 = (*endmember[0].d2mu0dT2)(T, P);
    double x6 = 2.5709142342754266e-5*P;
    double x7 = x6 - 8.7411083965364504;
    double x8 = 0.00023529411764705883*T - x2 + 1;
    double x9 = 0.0001*P - 51.0;
    double x10 = 1.0/x9;
    double x11 = sqrt(-x10*x8);
    double x12 = 2.1424285285628555e-7*((P)*(P)) - 0.18210642492784271*P - T*x6 + 8.7411083965364504*T + 37149.710685279919;
    double x13 = -x8;
    double x14 = sqrt(x10*x13);
    double x15 = x14/x13;
    double x16 = x14/((x13)*(x13));
    double x17 = -x7;
    double x18 = x3*x9;
    double x19 = x9*(9.8039215686274508e-7*x10 - x3*(3.7692893381881782e-14*P - 4.5231472058258138e-12*T - 1.922337562475971e-8));

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result[0] = x1;
}
else {
   result[0] = -x3*(1.7737832179709071e-16*x11*x12/((x8)*(x8)) + 3.0154314705505424e-12*x11*x7/x8 + 1.2815583749839804e-8*x4*x5) - (-x1*x4 + 1.0642699307825445e-15*x12*x16*x18 + 4.152249134948097e-8*x12*x14*x19/((x13)*(x13)*(x13)) + 9.0462944116516277e-12*x15*x17*x18 + 6.0492099630010037e-9*x15 + 0.00023529411764705883*x16*x17*x19 - 1.384083044982699e-8*x16*(4.284857057125711e-7*P - 2.5709142342754266e-5*T - 0.18210642492784271) - 0.00029999999999999997*x5)/x4;
}
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x2 = 1.9607843137254902e-6*P;
    double x3 = x2 - 1;
    double x4 = pow(x3, -3);
    double x5 = 0.00029999999999999997*P - 153.0;
    double x6 = (*endmember[0].dmu0dT)(T, P);
    double x7 = 0.0001*P - 51.0;
    double x8 = 1.0/x7;
    double x9 = 0.00023529411764705883*T - x2 + 1;
    double x10 = sqrt(-x8*x9);
    double x11 = 2.5709142342754266e-5*P;
    double x12 = x11 - 8.7411083965364504;
    double x13 = x10*x12;
    double x14 = 2.1424285285628555e-7*((P)*(P)) - 0.18210642492784271*P - T*x11 + 8.7411083965364504*T + 37149.710685279919;
    double x15 = 1.0/x9;
    double x16 = x10*x15;
    double x17 = x14*x16;
    double x18 = ((x3)*(x3));
    double x19 = 1.0/x18;
    double x20 = (*endmember[0].d2mu0dTdP)(T, P);
    double x21 = -4.284857057125711e-7*P + 2.5709142342754266e-5*T + 0.18210642492784271;
    double x22 = x19*x7;
    double x23 = 9.8039215686274508e-7*x8;
    double x24 = -3.7692893381881782e-14*P + 4.5231472058258138e-12*T + 1.922337562475971e-8;
    double x25 = x7*(x19*x24 + x23);
    double x26 = -x9;
    double x27 = sqrt(x26*x8);
    double x28 = x27/x26;
    double x29 = x19*x28;
    double x30 = -x21*x7;
    double x31 = x27/((x26)*(x26));
    double x32 = x14*x31;
    double x33 = 8.8689160898545363e-18*x22*x32;
    double x34 = -x12;
    double x35 = x19*x24 + x23;
    double x36 = x28*x35;
    double x37 = x26/x3 - 1;
    double x38 = x31*x34;
    double x39 = x35*x7;
    double x40 = -x19*(3.8446751249519419e-8*P - 4.6136101499423305e-6*T - 0.019607843137254905) + x8;
    double x41 = x18*((x40)*(x40));
    double x42 = x14*x27/((x26)*(x26)*(x26));

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result = n1*x1;
}
else {
   result = n1*(-x19*(-3.0154314705505424e-12*x10*x14*x25/((x9)*(x9)) + 6.5895533366024e-13*x10 - 2.5631167499679608e-8*x13*x15*x25 + 3.0154314705505424e-12*x16*x21 + 1.1593354365822922e-19*x17*x22 + 2.5631167499679608e-8*x20*x5 + 7.6893502499038817e-12*x6) + x4*(5.0257191175842371e-14*x13 - 5.9126107265696911e-18*x17 + 5.0257191175842371e-14*x5*x6) - (-x1*x5 - 1.7737832179709073e-17*x14*x28*x4*x7 + 4.5231472058258136e-16*x14*x29 - 0.00059999999999999995*x20 - 5.0410083025008364e-11*x28 + 9.0462944116516277e-12*x29*x30 + 7.5385786763763563e-14*x29*x34*x37*x7 + 0.00023529411764705883*x30*x31*x35 + 1.1764705882352942e-8*x32*x35 + 2.3068050749711654e-14*x32*x40 + x33*x37 - x33 + 0.0001*x34*x36 - 5.1418284685508533e-5*x36*x7 - 1.9607843137254902e-6*x38*x39 + 2.5000000000000001e-9*x38*x41 - 6.9204152249134948e-10*x39*x42 + 8.8235294117647062e-13*x41*x42)/x5);
}
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x2 = 1.9607843137254902e-6*P;
    double x3 = x2 - 1;
    double x4 = pow(x3, -3);
    double x5 = 0.00029999999999999997*P - 153.0;
    double x6 = (*endmember[0].dmu0dT)(T, P);
    double x7 = 0.0001*P - 51.0;
    double x8 = 1.0/x7;
    double x9 = 0.00023529411764705883*T - x2 + 1;
    double x10 = sqrt(-x8*x9);
    double x11 = 2.5709142342754266e-5*P;
    double x12 = x11 - 8.7411083965364504;
    double x13 = x10*x12;
    double x14 = 2.1424285285628555e-7*((P)*(P)) - 0.18210642492784271*P - T*x11 + 8.7411083965364504*T + 37149.710685279919;
    double x15 = 1.0/x9;
    double x16 = x10*x15;
    double x17 = x14*x16;
    double x18 = ((x3)*(x3));
    double x19 = 1.0/x18;
    double x20 = (*endmember[0].d2mu0dTdP)(T, P);
    double x21 = -4.284857057125711e-7*P + 2.5709142342754266e-5*T + 0.18210642492784271;
    double x22 = x19*x7;
    double x23 = 9.8039215686274508e-7*x8;
    double x24 = -3.7692893381881782e-14*P + 4.5231472058258138e-12*T + 1.922337562475971e-8;
    double x25 = x7*(x19*x24 + x23);
    double x26 = -x9;
    double x27 = sqrt(x26*x8);
    double x28 = x27/x26;
    double x29 = x19*x28;
    double x30 = -x21*x7;
    double x31 = x27/((x26)*(x26));
    double x32 = x14*x31;
    double x33 = 8.8689160898545363e-18*x22*x32;
    double x34 = -x12;
    double x35 = x19*x24 + x23;
    double x36 = x28*x35;
    double x37 = x26/x3 - 1;
    double x38 = x31*x34;
    double x39 = x35*x7;
    double x40 = -x19*(3.8446751249519419e-8*P - 4.6136101499423305e-6*T - 0.019607843137254905) + x8;
    double x41 = x18*((x40)*(x40));
    double x42 = x14*x27/((x26)*(x26)*(x26));

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result[0] = x1;
}
else {
   result[0] = -x19*(-3.0154314705505424e-12*x10*x14*x25/((x9)*(x9)) + 6.5895533366024e-13*x10 - 2.5631167499679608e-8*x13*x15*x25 + 3.0154314705505424e-12*x16*x21 + 1.1593354365822922e-19*x17*x22 + 2.5631167499679608e-8*x20*x5 + 7.6893502499038817e-12*x6) + x4*(5.0257191175842371e-14*x13 - 5.9126107265696911e-18*x17 + 5.0257191175842371e-14*x5*x6) - (-x1*x5 - 1.7737832179709073e-17*x14*x28*x4*x7 + 4.5231472058258136e-16*x14*x29 - 0.00059999999999999995*x20 - 5.0410083025008364e-11*x28 + 9.0462944116516277e-12*x29*x30 + 7.5385786763763563e-14*x29*x34*x37*x7 + 0.00023529411764705883*x30*x31*x35 + 1.1764705882352942e-8*x32*x35 + 2.3068050749711654e-14*x32*x40 + x33*x37 - x33 + 0.0001*x34*x36 - 5.1418284685508533e-5*x36*x7 - 1.9607843137254902e-6*x38*x39 + 2.5000000000000001e-9*x38*x41 - 6.9204152249134948e-10*x39*x42 + 8.8235294117647062e-13*x41*x42)/x5;
}
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d3mu0dP3)(T, P);
    double x2 = 1.9607843137254902e-6*P - 1;
    double x3 = 0.00029999999999999997*P - 153.0;
    double x4 = 0.0001*P - 51.0;
    double x5 = 1.0/x4;
    double x6 = 1.9607843137254902e-6*P - 0.00023529411764705883*T - 1;
    double x7 = sqrt(x5*x6);
    double x8 = 2.5709142342754266e-5*T;
    double x9 = x7*(2.1424285285628555e-7*((P)*(P)) - P*x8 - 0.18210642492784271*P + 8.7411083965364504*T + 37149.710685279919);
    double x10 = pow(x2, -3);
    double x11 = (*endmember[0].dmu0dP)(T, P);
    double x12 = x7*(4.284857057125711e-7*P - x8 - 0.18210642492784271);
    double x13 = 1.0/x6;
    double x14 = ((x2)*(x2));
    double x15 = 1.0/x14;
    double x16 = -x15*(3.7692893381881782e-14*P - 4.5231472058258138e-12*T - 1.922337562475971e-8) + 9.8039215686274508e-7*x5;
    double x17 = x13*x16;
    double x18 = x17*x9;
    double x19 = (*endmember[0].d2mu0dP2)(T, P);
    double x20 = x12*x17;
    double x21 = x13*x9;
    double x22 = 1.0/x2;
    double x23 = x22*x6 - 1;
    double x24 = x15*x23;
    double x25 = x21*x24;
    double x26 = pow(x6, -2);
    double x27 = x26*x9;
    double x28 = x16*x27;
    double x29 = -x15*(3.8446751249519419e-8*P - 4.6136101499423305e-6*T - 0.019607843137254905) + x5;
    double x30 = ((x29)*(x29));
    double x31 = x14*x30;
    double x32 = x24*x4;
    double x33 = x12*x26;
    double x34 = x16*x4;
    double x35 = x9/((x6)*(x6)*(x6));
    double x36 = x34*x35;
    double x37 = x27*x30;

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result = n1*x1;
}
else {
   result = n1*(-x10*(-4.5231472058258123e-17*x0 - 1.507715735275271e-13*x11*x3 + 1.507715735275271e-13*x12 + 1.507715735275271e-13*x18*x4) + x15*(-2.3068050749711645e-11*x11 + 3.8446751249519417e-12*x18 - 3.8446751249519412e-8*x19*x3 + 7.6893502499038825e-8*x20*x4 + 2.8983385914557307e-21*x25*x4 + 9.6116878123798532e-17*x27*x31 - 7.538578676376355e-14*x28*x4 + 1.6473883341506001e-14*x7) - (-x1*x3 + x10*x21*x4*(-x22*(8.695015774367191e-25*P - 1.043401892924063e-22*T - 4.4344580449272676e-19) + 4.4344580449272685e-19) + 2.261573602912907e-13*x12*x13*x32 + 1.2854571171377134e-6*x17*x4*x7 - 0.00089999999999999998*x19 + 0.00030000000000000003*x20 + 3.8446751249519418e-16*x23*x27*x29 + 1.9607843137254903e-10*x23*x28 + 1.5077157352752712e-17*x25 - 2.9563053632848454e-19*x27*x32 - 3.9215686274509806e-10*x28 + 7.500000000000001e-9*x31*x33 - 1.4705882352941176e-14*x31*x35 + 2.5000000000000001e-9*x31*x36 - 5.8823529411764701e-6*x33*x34 + 7.6893502499038834e-12*x36 + 9.6116878123798545e-17*x37*x4 + 9.6116878123798542e-13*x37*(2.0e-8*P - 0.010199999999999999))/x3 + (-2.9563053632848449e-19*x0*x3 + 2.9563053632848449e-19*x9)/((x2)*(x2)*(x2)*(x2)));
}
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d3mu0dP3)(T, P);
    double x2 = 1.9607843137254902e-6*P - 1;
    double x3 = 0.00029999999999999997*P - 153.0;
    double x4 = 0.0001*P - 51.0;
    double x5 = 1.0/x4;
    double x6 = 1.9607843137254902e-6*P - 0.00023529411764705883*T - 1;
    double x7 = sqrt(x5*x6);
    double x8 = 2.5709142342754266e-5*T;
    double x9 = x7*(2.1424285285628555e-7*((P)*(P)) - P*x8 - 0.18210642492784271*P + 8.7411083965364504*T + 37149.710685279919);
    double x10 = pow(x2, -3);
    double x11 = (*endmember[0].dmu0dP)(T, P);
    double x12 = x7*(4.284857057125711e-7*P - x8 - 0.18210642492784271);
    double x13 = 1.0/x6;
    double x14 = ((x2)*(x2));
    double x15 = 1.0/x14;
    double x16 = -x15*(3.7692893381881782e-14*P - 4.5231472058258138e-12*T - 1.922337562475971e-8) + 9.8039215686274508e-7*x5;
    double x17 = x13*x16;
    double x18 = x17*x9;
    double x19 = (*endmember[0].d2mu0dP2)(T, P);
    double x20 = x12*x17;
    double x21 = x13*x9;
    double x22 = 1.0/x2;
    double x23 = x22*x6 - 1;
    double x24 = x15*x23;
    double x25 = x21*x24;
    double x26 = pow(x6, -2);
    double x27 = x26*x9;
    double x28 = x16*x27;
    double x29 = -x15*(3.8446751249519419e-8*P - 4.6136101499423305e-6*T - 0.019607843137254905) + x5;
    double x30 = ((x29)*(x29));
    double x31 = x14*x30;
    double x32 = x24*x4;
    double x33 = x12*x26;
    double x34 = x16*x4;
    double x35 = x9/((x6)*(x6)*(x6));
    double x36 = x34*x35;
    double x37 = x27*x30;

if (0.0083333333333333332*P - 1.0*T <= 4250.0) {
   result[0] = x1;
}
else {
   result[0] = -x10*(-4.5231472058258123e-17*x0 - 1.507715735275271e-13*x11*x3 + 1.507715735275271e-13*x12 + 1.507715735275271e-13*x18*x4) + x15*(-2.3068050749711645e-11*x11 + 3.8446751249519417e-12*x18 - 3.8446751249519412e-8*x19*x3 + 7.6893502499038825e-8*x20*x4 + 2.8983385914557307e-21*x25*x4 + 9.6116878123798532e-17*x27*x31 - 7.538578676376355e-14*x28*x4 + 1.6473883341506001e-14*x7) - (-x1*x3 + x10*x21*x4*(-x22*(8.695015774367191e-25*P - 1.043401892924063e-22*T - 4.4344580449272676e-19) + 4.4344580449272685e-19) + 2.261573602912907e-13*x12*x13*x32 + 1.2854571171377134e-6*x17*x4*x7 - 0.00089999999999999998*x19 + 0.00030000000000000003*x20 + 3.8446751249519418e-16*x23*x27*x29 + 1.9607843137254903e-10*x23*x28 + 1.5077157352752712e-17*x25 - 2.9563053632848454e-19*x27*x32 - 3.9215686274509806e-10*x28 + 7.500000000000001e-9*x31*x33 - 1.4705882352941176e-14*x31*x35 + 2.5000000000000001e-9*x31*x36 - 5.8823529411764701e-6*x33*x34 + 7.6893502499038834e-12*x36 + 9.6116878123798545e-17*x37*x4 + 9.6116878123798542e-13*x37*(2.0e-8*P - 0.010199999999999999))/x3 + (-2.9563053632848449e-19*x0*x3 + 2.9563053632848449e-19*x9)/((x2)*(x2)*(x2)*(x2));
}
}
        
static void coder_d5gdn2dp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_s(double T, double P, double n[1]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[1]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[1]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[1]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[1]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[1]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[1]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[1]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[1]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[1]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[1]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[1]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[1]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[1]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

