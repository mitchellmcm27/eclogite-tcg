#include <math.h>


static double coder_g(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = fmin(4, 1.0000000000000002*sqrt(1 - 0.015384615384615385*T));

if (T >= 65.0) {
   result = n1*(-26.762699999999999*T + x0 + 1159.7169999999999);
}
else {
   result = (1.0/3.0)*n1*(3*x0 + 1739.5754999999999*((x1)*(x1)*(x1)) + (80.2881*T - 5218.7264999999998)*(x1 - 1) - 1739.5754999999999);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = fmin(4, 1.0000000000000002*sqrt(1 - 0.015384615384615385*T));

if (T >= 65.0) {
   result[0] = -26.762699999999999*T + x0 + 1159.7169999999999;
}
else {
   result[0] = x0 + 579.85849999999994*((x1)*(x1)*(x1)) + (1.0/3.0)*(80.2881*T - 5218.7264999999998)*(x1 - 1) - 579.85849999999994;
}
}
        
static void coder_d2gdn2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d3gdn3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_dgdt(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = sqrt(1 - 0.015384615384615385*T);
    double x2 = 1.0000000000000002*x1;
    double x3 = fmin(4, x2);
    double x4 = (4 - x2 >= 0. ? 1. : 0.)/x1;

if (T >= 65.0) {
   result = n1*(x0 - 26.762699999999999);
}
else {
   result = (1.0/3.0)*n1*(3*x0 - 40.144050000000014*((x3)*(x3))*x4 + 80.2881*x3 - 0.0076923076923076945*x4*(80.2881*T - 5218.7264999999998) - 80.2881);
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = sqrt(1 - 0.015384615384615385*T);
    double x2 = 1.0000000000000002*x1;
    double x3 = fmin(4, x2);
    double x4 = (4 - x2 >= 0. ? 1. : 0.)/x1;

if (T >= 65.0) {
   result[0] = x0 - 26.762699999999999;
}
else {
   result[0] = x0 - 13.381350000000005*((x3)*(x3))*x4 + 26.762699999999999*x3 - 0.0025641025641025645*x4*(80.2881*T - 5218.7264999999998) - 26.762699999999999;
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d4gdn3dt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_dgdp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].dmu0dP)(T, P);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].dmu0dP)(T, P);
}
        
static void coder_d3gdn2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = 0.015384615384615385*T - 1;
    double x2 = -x1;
    double x3 = sqrt(x2);
    double x4 = 1.0000000000000002*x3;
    double x5 = x4 - 4;
    double x6 = (-x5 >= 0. ? 1. : 0.);
    double x7 = 80.2881*T - 5218.7264999999998;
    double x8 = 1.0/x1;
    double x9 = x8*0;
    double x10 = x6/pow(x2, 3.0/2.0);
    double x11 = fmin(4, x4);
    double x12 = ((x11)*(x11));

if (T >= 65.0) {
   result = n1*x0;
}
else {
   result = -1.0/3.0*n1*(-3*x0 + 0.30880038461538473*x10*x12 + 5.9171597633136114e-5*x10*x7 + 0.61760076923076968*x11*((x6)*(x6))*x8 - 0.30880038461538484*x12*x9 - 5.9171597633136128e-5*x7*x9 + 1.2352015384615389*x6/x3);
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = 0.015384615384615385*T - 1;
    double x2 = -x1;
    double x3 = sqrt(x2);
    double x4 = 1.0000000000000002*x3;
    double x5 = x4 - 4;
    double x6 = (-x5 >= 0. ? 1. : 0.);
    double x7 = 80.2881*T - 5218.7264999999998;
    double x8 = 1.0/x1;
    double x9 = 0;
    double x10 = x6/pow(x2, 3.0/2.0);
    double x11 = fmin(4, x4);
    double x12 = ((x11)*(x11));

if (T >= 65.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - 0.10293346153846157*x10*x12 - 1.9723865877712037e-5*x10*x7 - 0.20586692307692323*x11*((x6)*(x6))*x8 + 0.10293346153846161*x12*x8*x9 + 1.972386587771204e-5*x7*x8*x9 - 0.41173384615384628*x6/x3;
}
}
        
static void coder_d4gdn2dt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d2mu0dTdP)(T, P);
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d2mu0dP2)(T, P);
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = 0.015384615384615385*T - 1;
    double x2 = -x1;
    double x3 = 1.0000000000000002*sqrt(x2);
    double x4 = x3 - 4;
    double x5 = 0;
    double x6 = pow(x2, -3.0/2.0);
    double x7 = (-x4 >= 0. ? 1. : 0.);
    double x8 = 80.2881*T - 5218.7264999999998;
    double x9 = pow(x1, -2);
    double x10 = pow(x2, -5.0/2.0);
    double x11 = x6*0;
    double x12 = fmin(4, x3);
    double x13 = ((x12)*(x12));

if (T >= 65.0) {
   result = n1*x0;
}
else {
   result = -1.0/3.0*n1*(-3*x0 + 0.0071261627218934939*x10*x13*x7 + 1.3654984069185257e-6*x10*x7*x8 - 0.0023753875739644993*x11*x13 - 4.5516613563950879e-7*x11*x8 - 0.014252325443786996*x12*x5*x6*x7 - 0.014252325443786993*x12*((x7)*(x7))*x9 + 0.0071261627218934965*x13*x5*x9 + 1.3654984069185262e-6*x5*x8*x9 + 0.0047507751479289985*x6*((x7)*(x7)*(x7)) + 0.014252325443786988*x6*x7 - 0.01425232544378699*x5/x1);
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = 0.015384615384615385*T - 1;
    double x2 = -x1;
    double x3 = 1.0000000000000002*sqrt(x2);
    double x4 = x3 - 4;
    double x5 = 0;
    double x6 = pow(x2, -3.0/2.0);
    double x7 = (-x4 >= 0. ? 1. : 0.);
    double x8 = x6*x7;
    double x9 = 80.2881*T - 5218.7264999999998;
    double x10 = pow(x1, -2);
    double x11 = x10*x5;
    double x12 = x7/pow(x2, 5.0/2.0);
    double x13 = x6*0;
    double x14 = fmin(4, x3);
    double x15 = ((x14)*(x14));

if (T >= 65.0) {
   result[0] = x0;
}
else {
   result[0] = x0 + 0.0047507751479289977*x10*x14*((x7)*(x7)) - 0.0023753875739644988*x11*x15 - 4.5516613563950868e-7*x11*x9 - 0.002375387573964498*x12*x15 - 4.5516613563950858e-7*x12*x9 + 0.00079179585798816639*x13*x15 + 1.517220452131696e-7*x13*x9 + 0.0047507751479289985*x14*x5*x8 - 0.0015835917159763328*x6*((x7)*(x7)*(x7)) - 0.0047507751479289959*x8 + 0.0047507751479289959*x5/x1;
}
}
        
static void coder_d5gdn2dt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d3mu0dT2dP)(T, P);
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d3mu0dTdP2)(T, P);
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d3mu0dP3)(T, P);
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_s(double T, double P, double n[1]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[1]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[1]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[1]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[1]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[1]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[1]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[1]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[1]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[1]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[1]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[1]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[1]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[1]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

