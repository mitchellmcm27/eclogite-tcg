
static char *identifier = "HPClinoferrosilite_slb21_em.emml:90fbf79b58d66232554dc24dbc764c78e6462df2:Fri Oct 25 20:52:30 2024";



#include <math.h>
#include "coder_error.h"

#include <float.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

static double chebvalat(double x) {
    double c[17] = {
        2.707737068327440945 / 2.0, 0.340068135211091751, -0.12945150184440869e-01, 0.7963755380173816e-03,
        -0.546360009590824e-04, 0.39243019598805e-05, -0.2894032823539e-06, 0.217317613962e-07, -0.16542099950e-08,
        0.1272796189e-09, -0.987963460e-11, 0.7725074e-12, -0.607797e-13, 0.48076e-14, -0.3820e-15, 0.305e-16, -0.24e-17
    };
    double x2 = 2 * x;
    double c0 = c[17-2];
    double c1 = c[17-1];
    for (int i=3; i<18; i++) {
        double tmp = c0;
        c0 = c[17-i] - c1;
        c1 = tmp + c1 * x2;
    }
    return c0 + c1 * x;
}

static double Debye(double x) {
    //
    // returns D_3(x) = 3/x^3\int_0^x t^3/(e^t - 1) dt
    //
    
    double val_infinity = 19.4818182068004875;
    double sqrt_eps = sqrt(DBL_EPSILON);
    double log_eps = log(DBL_EPSILON);
    double xcut = -log_eps;

    //Check for negative x (was returning zero)
    assert(x >= 0.);

    if (x < (2.0*sqrt(2.0)*sqrt_eps)) return 1.0 - 3.0*x/8.0 + x*x/20.0;
    else if (x <= 4.0) {
        double t = x*x/8.0 - 1.0;
        double c = chebvalat(t);
        return c - 0.375*x;
    } else if (x < -(log(2.0)+log_eps)) {
        int nexp = (int)(floor(xcut / x));
        double ex = exp(-x);
        double xk = nexp * x;
        double rk = nexp;
        double sum = 0.0;
        for (int i=nexp; i>0; i--) {
            double xk_inv = 1.0/xk;
            sum *= ex;
            sum += (((6.0*xk_inv + 6.0)*xk_inv + 3.0)*xk_inv + 1.0)/rk;
            rk -= 1.0;
            xk -= x;
        }
        return val_infinity / (x * x * x) - 3.0 * sum * ex;
    } else if (x < xcut) {
        double x3 = x*x*x;
        double sum = 6.0 + 6.0*x + 3.0*x*x + x3;
        return (val_infinity - 3.0*sum*exp(-x))/x3;
    } else return ((val_infinity/x)/x)/x;
}

double born_B(double t, double p);
double born_Q(double t, double p);
double born_N(double t, double p);
double born_U(double t, double p);
double born_Y(double t, double p);
double born_X(double t, double p);
double born_dUdT(double t, double p);
double born_dUdP(double t, double p);
double born_dNdT(double t, double p);
double born_dNdP(double t, double p);
double born_dXdT(double t, double p);
double gSolvent(double t, double p);
double DgSolventDt(double t, double p);
double DgSolventDp(double t, double p);
double D2gSolventDt2(double t, double p);
double D2gSolventDtDp(double t, double p);
double D2gSolventDp2(double t, double p);
double D3gSolventDt3(double t, double p);
double D3gSolventDt2Dp(double t, double p);
double D3gSolventDtDp2(double t, double p);
double D3gSolventDp3(double t, double p);
double D4gSolventDt4(double t, double p);

static double coder_a(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/V;
    double x1 = pow(x0, 2.0/3.0);
    double x2 = pow(x0, 4.0/3.0);
    double x3 = sqrt(-0.30007181827068985*x1 + x2 + 0.026972668184777525);
    double x4 = 14.9706912126339*x3;
    double x5 = 4491.2073637901703*x3/T;

    result += 249.43387854459721*T*log(1 - exp(-x5)) - 83.144626181532402*T*Debye(x5) - 26.76322271834383*T + 38877373.052514061*x1 - 232546229.14783397*x2 - 74830.163563379159*log(1 - exp(-x4)) + 24943.387854459721*Debye(x4) - 3211127.055441821 + 380074813.04099667/((V)*(V));
    return result;
}

static double coder_dadt(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = 1.0/V;
    double x2 = sqrt(pow(x1, 4.0/3.0) - 0.30007181827068985*pow(x1, 2.0/3.0) + 0.026972668184777525);
    double x3 = x0*x2;
    double x4 = 4491.2073637901703*x3;
    double x5 = Debye(x4);
    double x6 = exp(-x4);
    double x7 = 1 - x6;

    result += 373419.75736607931*x0*x2*(-0.00066797182962139454*T*x5/x2 + 3/(exp(x4) - 1)) - 1120259.2720982379*x3*x6/x7 - 83.144626181532402*x5 + 249.43387854459721*log(x7) - 26.76322271834383;
    return result;
}

static double coder_dadv(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/V;
    double x1 = pow(x0, 2.0/3.0);
    double x2 = pow(x0, 4.0/3.0);
    double x3 = sqrt(-0.30007181827068985*x1 + x2 + 0.026972668184777525);
    double x4 = 14.9706912126339*x3;
    double x5 = exp(-x4);
    double x6 = 1.0/x3;
    double x7 = 0.10002393942356327*x0*x1 - 2.0/3.0*x0*x2;
    double x8 = x6*x7;
    double x9 = 4491.2073637901703*x3/T;
    double x10 = exp(-x9);

    result += -25918248.701676041*x0*x1 + 310061638.86377859*x0*x2 + 1120259.2720982379*x10*x6*x7/(1 - x10) - 1120259.2720982379*x5*x8/(1 - x5) + 373419.75736607931*x6*x7*(-0.20039154888641836*x6*Debye(x4) + 3/(exp(x4) - 1)) - 373419.75736607931*x8*(-0.00066797182962139454*T*x6*Debye(x9) + 3/(exp(x9) - 1)) - 760149626.08199334/((V)*(V)*(V));
    return result;
}

static double coder_d2adt2(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = 1.0/V;
    double x2 = pow(x1, 4.0/3.0);
    double x3 = pow(x1, 2.0/3.0);
    double x4 = sqrt(x2 - 0.30007181827068985*x3 + 0.026972668184777525);
    double x5 = x0*x4;
    double x6 = 4491.2073637901703*x5;
    double x7 = exp(-x6);
    double x8 = 1 - x7;
    double x9 = pow(T, -2);
    double x10 = x9*(5031316692.2018223*x2 - 1509756348.1246736*x3 + 135708035.67129219);
    double x11 = Debye(x6)/x4;
    double x12 = exp(x6);
    double x13 = x12 - 1;

    result += -x0*(x10*x7/x8 + x10*exp(-8982.4147275803407*x5)/((x8)*(x8)) + 373419.75736607931*x4*(x0*(0.0020039154888641837*T*x11 - 9.0/x13) + 0.00066797182962139454*x11 - 13473.622091370511*x12*x4*x9/((x13)*(x13))));
    return result;
}

static double coder_d2adtdv(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = 1.0/V;
    double x2 = pow(x1, 2.0/3.0);
    double x3 = pow(x1, 4.0/3.0) - 0.30007181827068985*x2 + 0.026972668184777525;
    double x4 = sqrt(x3);
    double x5 = x0*x4;
    double x6 = 4491.2073637901703*x5;
    double x7 = exp(-x6);
    double x8 = 1 - x7;
    double x9 = 1677105564.0672741*x0;
    double x10 = T*Debye(x6);
    double x11 = 1.0/x4;
    double x12 = exp(x6);
    double x13 = x12 - 1;

    result += -x0*x1*x2*(2*x2 - 0.30007181827068985)*(373419.75736607931*x4*(-4491.2073637901703*x0*x11*x12/((x13)*(x13)) + 0.00022265727654046484*x10/pow(x3, 3.0/2.0) + (0.00066797182962139454*x10*x11 - 3/x13)/x3) + x7*x9/x8 + x9*exp(-8982.4147275803407*x5)/((x8)*(x8)));
    return result;
}

static double coder_d2adv2(double T, double V) {
    double result = 0.0;
    double x0 = pow(V, -2);
    double x1 = 1.0/V;
    double x2 = pow(x1, 2.0/3.0);
    double x3 = pow(x1, 4.0/3.0);
    double x4 = -0.30007181827068985*x2 + x3 + 0.026972668184777525;
    double x5 = sqrt(x4);
    double x6 = 14.9706912126339*x5;
    double x7 = exp(-x6);
    double x8 = 1 - x7;
    double x9 = 1.0/x4;
    double x10 = x3*((x2 - 0.15003590913534492)*(x2 - 0.15003590913534492));
    double x11 = x10*x9;
    double x12 = 7453802.5069656614*x11;
    double x13 = x7/x8;
    double x14 = pow(x4, -3.0/2.0);
    double x15 = 497893.00982143905*x10;
    double x16 = x14*x15;
    double x17 = 1.0/x5;
    double x18 = x17*x2*(14*x2 - 1.500359091353449);
    double x19 = 124473.25245535976*x18;
    double x20 = 1.0/T;
    double x21 = x20*x5;
    double x22 = 4491.2073637901703*x21;
    double x23 = exp(-x22);
    double x24 = 1 - x23;
    double x25 = x23/x24;
    double x26 = 2236140752.0896988*x11*x20;
    double x27 = exp(x6);
    double x28 = x27 - 1;
    double x29 = Debye(x6);
    double x30 = 0.20039154888641836*x17*x29 - 3/x28;
    double x31 = 165964.33660714634*x10*x14;
    double x32 = 41491.084151786585*x18;
    double x33 = exp(x22);
    double x34 = x33 - 1;
    double x35 = T*Debye(x22);
    double x36 = 0.00066797182962139454*x17*x35 - 3/x34;
    double x37 = x15*x17;

    result += x0*(2280448878.2459803*x0 + x12*x13 + x12*exp(-29.9413824252678*x5)/((x8)*(x8)) + x13*x16 - x13*x19 - x16*x25 + x19*x25 + 43197081.169460066*x2 - x25*x26 - 723477157.34881663*x3 + x30*x31 - x30*x32 - x31*x36 + x32*x36 + x37*(0.066797182962139448*x14*x29 - 14.970691212633898*x17*x27/((x28)*(x28)) + x30*x9) - x37*(0.00022265727654046484*x14*x35 - 4491.2073637901703*x17*x20*x33/((x34)*(x34)) + x36*x9) - x26*exp(-8982.4147275803407*x21)/((x24)*(x24)));
    return result;
}

static double coder_d3adt3(double T, double V) {
    double result = 0.0;
    double x0 = pow(T, -2);
    double x1 = 1.0/T;
    double x2 = 1.0/V;
    double x3 = pow(x2, 4.0/3.0);
    double x4 = pow(x2, 2.0/3.0);
    double x5 = x3 - 0.30007181827068985*x4 + 0.026972668184777525;
    double x6 = sqrt(x5);
    double x7 = x1*x6;
    double x8 = 4491.2073637901703*x7;
    double x9 = exp(-x8);
    double x10 = 1 - x9;
    double x11 = pow(T, -3);
    double x12 = x11*pow(x5, 3.0/2.0);
    double x13 = pow(x10, -2);
    double x14 = 8982.4147275803407*x7;
    double x15 = exp(-x14);
    double x16 = 1.0/x10;
    double x17 = 15093950076.605467*x3 - 4529269044.3740206*x4 + 407124107.01387656;
    double x18 = Debye(x8)/x6;
    double x19 = exp(x8);
    double x20 = x19 - 1;
    double x21 = x19/((x20)*(x20));
    double x22 = -13473.622091370511*x0*x21*x6;
    double x23 = 0.0020039154888641837*x18;
    double x24 = x1*(T*x23 - 9.0/x20);
    double x25 = x11*x5;

    result += x0*(x0*x13*x15*x17 + x0*x16*x17*x9 - 67790059732731.68*x12*x13*x15 - 22596686577577.227*x12*x16*x9 + 373419.75736607931*x6*(0.00066797182962139454*x18 + x22 + x24) - 373419.75736607931*x6*(60512830.753689155*x21*x25 + x22 + x23 + 3.0*x24 - 121025661.50737831*x25*exp(x14)/((x20)*(x20)*(x20))) - 45193373155154.453*x12*exp(-13473.622091370511*x7)/((x10)*(x10)*(x10)));
    return result;
}

static double coder_d3adt2dv(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = 1.0/V;
    double x2 = pow(x1, 2.0/3.0);
    double x3 = pow(T, -2);
    double x4 = 6708422256.2690964*x2 - 1006504232.0831157;
    double x5 = pow(x1, 4.0/3.0) - 0.30007181827068985*x2 + 0.026972668184777525;
    double x6 = sqrt(x5);
    double x7 = x0*x6;
    double x8 = 8982.4147275803407*x7;
    double x9 = exp(-x8);
    double x10 = 4491.2073637901703*x7;
    double x11 = exp(-x10);
    double x12 = 1 - x11;
    double x13 = pow(x12, -2);
    double x14 = 1.0/x12;
    double x15 = pow(T, -3);
    double x16 = 2*x2 - 0.30007181827068985;
    double x17 = x16*x6;
    double x18 = x15*x17;
    double x19 = 1.0/x6;
    double x20 = Debye(x10);
    double x21 = x19*x20;
    double x22 = 0.00066797182962139454*x21;
    double x23 = exp(x10);
    double x24 = x23 - 1;
    double x25 = x23/((x24)*(x24));
    double x26 = 13473.622091370511*x25;
    double x27 = 1.0/x24;
    double x28 = x20/pow(x5, 3.0/2.0);
    double x29 = (T*x22 - 3*x27)/x5;

    result += x0*x1*x2*(-7532228859192.4082*x11*x14*x18 + x11*x14*x3*x4 - 22596686577577.227*x13*x18*x9 + x13*x3*x4*x9 + 124473.25245535976*x16*x19*(x0*(0.0020039154888641837*T*x21 - 9.0*x27) + x22 - x26*x3*x6) - 373419.75736607931*x17*(x0*x29 + x0*(0.00066797182962139454*T*x28 - x0*x19*x26 + 3.0*x29) + 20170943.58456305*x15*x25 - 40341887.169126101*x15*exp(x8)/((x24)*(x24)*(x24)) + 4491.2073637901703*x19*x25*x3 + 0.00022265727654046484*x28) - 15064457718384.816*x18*exp(-13473.622091370511*x7)/((x12)*(x12)*(x12)));
    return result;
}

static double coder_d3adtdv2(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = 1.0/V;
    double x2 = pow(x1, 2.0/3.0);
    double x3 = 7826492632.3139458*x2 - 838753526.73592961;
    double x4 = pow(x1, 4.0/3.0) - 0.30007181827068985*x2 + 0.026972668184777525;
    double x5 = sqrt(x4);
    double x6 = x0*x5;
    double x7 = 8982.4147275803407*x6;
    double x8 = exp(-x7);
    double x9 = 4491.2073637901703*x6;
    double x10 = exp(-x9);
    double x11 = 1 - x10;
    double x12 = pow(x11, -2);
    double x13 = 1.0/x11;
    double x14 = 1.0/x5;
    double x15 = ((x2 - 0.15003590913534492)*(x2 - 0.15003590913534492));
    double x16 = x15*x2;
    double x17 = x16/((T)*(T));
    double x18 = x14*x17;
    double x19 = pow(x4, -3.0/2.0);
    double x20 = T*Debye(x9);
    double x21 = x19*x20;
    double x22 = exp(x9);
    double x23 = x22 - 1;
    double x24 = x22/((x23)*(x23));
    double x25 = x0*x14*x24;
    double x26 = 1.0/x4;
    double x27 = 0.00066797182962139454*x14*x20 - 3/x23;
    double x28 = x26*x27;
    double x29 = 0.00022265727654046484*x21 - 4491.2073637901703*x25 + x28;
    double x30 = 14*x2 - 1.500359091353449;
    double x31 = x17*x26;
    double x32 = x0*x2;
    double x33 = x27/((x4)*(x4));
    double x34 = 4*x2;

    result += x32*(x0*x10*x13*x3 + x0*x12*x3*x8 - 10042971812256.545*x10*x13*x18 - 30128915436769.633*x12*x18*x8 + 497893.00982143905*x14*x15*x2*x29 - 373419.75736607931*x5*(-5988.2764850535605*x15*x19*x24*x32 + x15*x26*x29*x34 + 0.00089062910616185935*x16*x20/pow(x4, 5.0/2.0) + 1.3333333333333333*x16*x33 + 0.33333333333333331*x2*x33*(2*x2 - 0.30007181827068985)*(x34 - 0.6001436365413797) - 7.421909218015495e-5*x21*x30 + 26894591.446084067*x24*x31 + 1497.0691212633901*x25*x30 - 0.33333333333333331*x28*x30 - 53789182.892168134*x31*exp(x7)/((x23)*(x23)*(x23))) - 20085943624513.09*x18*exp(-13473.622091370511*x6)/((x11)*(x11)*(x11)))/((V)*(V));
    return result;
}

static double coder_d3adv3(double T, double V) {
    double result = 0.0;
    double x0 = pow(V, -2);
    double x1 = 1.0/V;
    double x2 = pow(x1, 2.0/3.0);
    double x3 = pow(x1, 4.0/3.0);
    double x4 = 140*x2 - 12.00287273082759;
    double x5 = -0.30007181827068985*x2 + x3 + 0.026972668184777525;
    double x6 = sqrt(x5);
    double x7 = 1.0/x6;
    double x8 = 14.9706912126339*x6;
    double x9 = exp(-x8);
    double x10 = 1 - x9;
    double x11 = 1.0/x10;
    double x12 = x4*x7;
    double x13 = 1.0/T;
    double x14 = x13*x6;
    double x15 = 4491.2073637901703*x14;
    double x16 = exp(-x15);
    double x17 = 1 - x16;
    double x18 = 1.0/x17;
    double x19 = x16*x18;
    double x20 = x2 - 0.15003590913534492;
    double x21 = ((x20)*(x20));
    double x22 = 2*x2 - 0.30007181827068985;
    double x23 = pow(x5, -3.0/2.0);
    double x24 = pow(x5, -2);
    double x25 = 29.9413824252678*x6;
    double x26 = exp(-x25);
    double x27 = pow(x10, -2);
    double x28 = 4*x2;
    double x29 = x28 - 0.6001436365413797;
    double x30 = pow(x5, -5.0/2.0);
    double x31 = 1.0/x5;
    double x32 = x26*x27*x31;
    double x33 = 14*x2 - 1.500359091353449;
    double x34 = 2484600.8356552203*x20*x3*x33;
    double x35 = x11*x9;
    double x36 = x31*x35;
    double x37 = x22*x3;
    double x38 = x33*x37;
    double x39 = 621150.20891380508*x38;
    double x40 = x23*x38;
    double x41 = x0*x21;
    double x42 = x22*x41;
    double x43 = x30*x42;
    double x44 = pow(T, -2);
    double x45 = x23*x42;
    double x46 = x44*x45;
    double x47 = pow(x17, -2);
    double x48 = 8982.4147275803407*x14;
    double x49 = exp(-x48);
    double x50 = x47*x49;
    double x51 = x22*x24;
    double x52 = 745380250.69656622*x13*x41;
    double x53 = x50*x52;
    double x54 = x24*x29;
    double x55 = x19*x52;
    double x56 = exp(x8);
    double x57 = x56 - 1;
    double x58 = Debye(x8);
    double x59 = 0.20039154888641836*x58*x7 - 3/x57;
    double x60 = exp(x15);
    double x61 = x60 - 1;
    double x62 = T*Debye(x15);
    double x63 = 0.00066797182962139454*x62*x7 - 3/x61;
    double x64 = x2*x63;
    double x65 = x23*x58;
    double x66 = x56/((x57)*(x57));
    double x67 = x66*x7;
    double x68 = x31*x59;
    double x69 = 0.066797182962139448*x65 - 14.970691212633898*x67 + x68;
    double x70 = x37*x7;
    double x71 = x23*x62;
    double x72 = x60/((x61)*(x61));
    double x73 = x13*x72;
    double x74 = x7*x73;
    double x75 = x31*x63;
    double x76 = 0.00022265727654046484*x71 - 4491.2073637901703*x74 + x75;
    double x77 = x2*x21;
    double x78 = x30*x77;
    double x79 = x21*x31;
    double x80 = x2*x79;
    double x81 = x23*x77;
    double x82 = 0.33333333333333331*x33;
    double x83 = x2*x59;
    double x84 = 1.3333333333333333*x24;
    double x85 = 0.33333333333333331*x29*x51;
    double x86 = x28*x79;
    double x87 = x44*x80;

    result += (37196191.89724645*x0*x11*x21*x22*x23*x9 + 2484600.8356552203*x0*x11*x21*x22*x24*x9 + 497893.00982143905*x0*x11*x21*x22*x30*x9 + 2484600.8356552203*x0*x11*x21*x24*x29*x9 + 111588575.69173935*x0*x21*x22*x23*x26*x27 + 331928.67321429268*x0*x21*x22*x23*x69 + 2484600.8356552203*x0*x21*x22*x24*x26*x27 + 165964.33660714634*x0*x21*x22*x30*x59 + 2484600.8356552203*x0*x21*x24*x26*x27*x29 - 9121795512.9839211*x0 + 74392383.7944929*x0*x21*x22*x23*exp(-44.912073637901699*x6)/((x10)*(x10)*(x10)) + 41491.084151786585*x11*x2*x4*x7*x9 - 41491.084151786585*x12*x19*x2 - 13830.361383928863*x12*x64 + 745380250.69656622*x13*x16*x18*x20*x3*x31*x33 + 186345062.67414156*x13*x16*x18*x22*x3*x31*x33 + 745380250.69656622*x13*x20*x3*x31*x33*x47*x49 + 186345062.67414156*x13*x22*x3*x31*x33*x47*x49 + 124473.25245535976*x16*x18*x22*x23*x3*x33 - 497893.00982143905*x19*x43 - 3347657270752.1816*x19*x46 + 13830.361383928863*x2*x4*x59*x7 - 115192216.45189351*x2 + 41491.084151786585*x22*x23*x3*x33*x63 + 82982.168303573169*x22*x3*x33*x7*x76 + 124473.25245535976*x22*x3*x7*(x21*x83*x84 - 0.022265727654046483*x33*x65 + 4.9902304042112995*x33*x67 + 0.26718873184855779*x58*x78 + 298.82879384537847*x66*x80 - 19.960921616845198*x66*x81 - x68*x82 + x69*x86 + x83*x85 - 597.65758769075694*x80*exp(x25)/((x57)*(x57)*(x57))) + 2411590524.4960556*x3 - x32*x34 - x32*x39 - 82982.168303573169*x33*x69*x70 - x34*x36 - 124473.25245535976*x35*x40 - x36*x39 - 41491.084151786585*x40*x59 - 165964.33660714634*x43*x63 - 331928.67321429268*x45*x76 - 10042971812256.543*x46*x50 - x51*x53 - x51*x55 - x53*x54 - x54*x55 - 124473.25245535976*x70*(-7.421909218015495e-5*x33*x71 + 1497.0691212633901*x33*x74 + 0.00089062910616185935*x62*x78 + x63*x77*x84 + x64*x85 + 26894591.446084067*x72*x87 - 5988.2764850535605*x73*x81 - x75*x82 + x76*x86 - 53789182.892168134*x87*exp(x48)/((x61)*(x61)*(x61))) - 6695314541504.3633*x46*exp(-13473.622091370511*x14)/((x17)*(x17)*(x17)))/((V)*(V)*(V));
    return result;
}


static const double tol = 0.001;
static const int MAX_ITS = 200;
static double Told = 0.0;
static double Pold = 0.0;
static const double Vmin = 0.5*6.3854;
static const double Vmax = 1.15*6.3854;
static double V = 0.9*6.3854;

static void coder_solve_V(double T, double P) {
    // Newtsafe routine, newton + bisection with bracket check
    // Update if *either* T or P changes (was only if both changed)
    if ((T != Told) || (P != Pold)) {
        // check bracket
        double fa = -coder_dadv(T, Vmin) - P;
        double fb = -coder_dadv(T, Vmax) - P;
        if ( isnan(fa) ) {
            fprintf(stderr, "Error: lower bracket isnan for Vmin=%g\n",Vmin);
            coder_error_flag = CODER_ERR_NAN;
            return;
        }
        if ( isnan(fb) ) {
            fprintf(stderr, "Error: upper bracket isnan for Vmax=%g\n",Vmax);
            coder_error_flag = CODER_ERR_NAN;
            return;
        }
        if ( fa*fb > 0.) 
        {
            fprintf(stderr, "Error: improper  initial bracket in solve_V\n");
            coder_error_flag = CODER_ERR_BOUNDS;
            return;
        }
        //set up bisection parameters
        double a = Vmin;
        double b = Vmax;
        double c = 0.;
        double fc = 0.;
        Told = T;
        Pold = P;
        //start Newton step
        double f = 0.0;
        int iter = 0;
        do {
            //newton step
            f = -coder_dadv(T, V) - P;
            double df = -coder_d2adv2(T, V);
            V -= f/df;
            if (V < a || V > b || df == 0. || isnan(V) ) {
                //take a bisection step
                c = 0.5*(a + b);
                fc = -coder_dadv(T, c) - P;
                if ( fa*fc < 0 ) { // left bracket
                    b = c;
                    fb = fc;
                }
                else if ( fb*fc < 0 ) { //right bracket
                    a = c;
                    fa = fc;
                }
                //reset V to middle of new bracket and clear f
                V = 0.5*( a + b);
                f = 1.;
            }
            iter++;
        } while ((fabs(f) > tol) && (iter < MAX_ITS));
        if ( iter == MAX_ITS) {
            fprintf(stderr, "Error: max iterations exceeded in solve_V\n");
            coder_error_flag = CODER_ERR_MAXITS;
            return;
        }
    }
}

static double coder_g(double T, double P) {
    coder_solve_V(T, P);
    double A = coder_a(T, V);
    return A + P*V;
}

static double coder_dgdt(double T, double P) {
    coder_solve_V(T, P);
    double dAdT = coder_dadt(T, V);
    return dAdT;
}

static double coder_dgdp(double T, double P) {
    coder_solve_V(T, P);
    return V;
}

static double coder_d2gdt2(double T, double P) {
    coder_solve_V(T, P);
    double d2AdT2 = coder_d2adt2(T, V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    return d2AdT2 - d2AdTdV*d2AdTdV/d2AdV2;
}

static double coder_d2gdtdp(double T, double P) {
    coder_solve_V(T, P);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    return - d2AdTdV/d2AdV2;
}

static double coder_d2gdp2(double T, double P) {
    coder_solve_V(T, P);
    double d2AdV2 = coder_d2adv2(T, V);
    return - 1.0/d2AdV2;
}

static double coder_d3gdt3(double T, double P) {
    coder_solve_V(T, P);
    double d3AdT3 = coder_d3adt3(T, V);
    double d3AdT2dV = coder_d3adt2dv(T, V);
    double d3AdTdV2 = coder_d3adtdv2(T, V);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double dVdT = -d2AdTdV/d2AdV2;
    double d2VdT2 = (-d3AdT2dV - 2.0*d3AdTdV2*dVdT - d3AdV3*dVdT*dVdT)/d2AdV2;
    return d3AdT3 + 2.0*d3AdT2dV*dVdT + d3AdTdV2*dVdT*dVdT + d2AdTdV*d2VdT2;
}

static double coder_d3gdt2dp(double T, double P) {
    coder_solve_V(T, P);
    double d3AdT2dV = coder_d3adt2dv(T, V);
    double d3AdTdV2 = coder_d3adtdv2(T, V);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double dVdT = -d2AdTdV/d2AdV2;
    double dVdP = -1.0/d2AdV2;
    double d2VdTdP = (-d3AdTdV2*dVdP - d3AdV3*dVdT*dVdP)/d2AdV2;
    return d3AdT2dV*dVdP + d3AdTdV2*dVdT*dVdP + d2AdTdV*d2VdTdP;
}

static double coder_d3gdtdp2(double T, double P) {
    coder_solve_V(T, P);
    double d3AdTdV2 = coder_d3adtdv2(T, V);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double dVdT = -d2AdTdV/d2AdV2;
    return (d3AdTdV2 + d3AdV3*dVdT)/d2AdV2/d2AdV2;
}

static double coder_d3gdp3(double T, double P) {
    coder_solve_V(T, P);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdV2 = coder_d2adv2(T, V);
    double dVdP = -1.0/d2AdV2;
    return d3AdV3*dVdP/d2AdV2/d2AdV2;
}

static double coder_s(double T, double P) {
    double result = -coder_dgdt(T, P);
    return result;
}

static double coder_dsdt(double T, double P) {
    double result = -coder_d2gdt2(T, P);
    return result;
}

static double coder_dsdp(double T, double P) {
    double result = -coder_d2gdtdp(T, P);
    return result;
}

static double coder_v(double T, double P) {
    double result = coder_dgdp(T, P);
    return result;
}

static double coder_cv(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    double dvdt = coder_d2gdtdp(T, P);
    double dvdp = coder_d2gdp2(T, P);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    return result;
}

static double coder_dcpdt(double T, double P) {
    double result = -T*coder_d3gdt3(T, P) - coder_d2gdt2(T, P);
    return result;
}

static double coder_dcpdp(double T, double P) {
    double result = -T*coder_d3gdt2dp(T, P);
    return result;
}

static double coder_alpha(double T, double P) {
    double result = coder_d2gdtdp(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_dalphadt(double T, double P) {
    double dgdp = coder_dgdp(T, P);
    double d2gdtdp = coder_d2gdtdp(T, P);
    double result = coder_d3gdt2dp(T, P)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P) {
    double dgdp = coder_dgdp(T, P);
    double result = coder_d3gdtdp2(T, P)/dgdp - coder_d2gdp2(T, P)*coder_d2gdtdp(T, P)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P) {
    double result = -coder_d2gdp2(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_K(double T, double P) {
    double result = -coder_dgdp(T, P)/coder_d2gdp2(T, P);
    return result;
}

static double coder_Kp(double T, double P) {
    double result = coder_dgdp(T, P);
    result *= coder_d3gdp3(T, P);
    result /= pow(coder_d2gdp2(T, P), 2.0);
    return result - 1.0;
}


#include <math.h>

static double coder_dparam_a(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dadt(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dadv(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2adt2(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2adtdv(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2adv2(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3adt3(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3adt2dv(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3adtdv2(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3adv3(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}


static double coder_dparam_g(double T, double P, int index) {
    coder_solve_V(T, P);
    double dAdz = coder_dparam_a(T, V, index);
    return dAdz + P*V;
}

static double coder_dparam_dgdt(double T, double P, int index) {
    coder_solve_V(T, P);
    double dAdTdz = coder_dparam_dadt(T, V, index);
    return dAdTdz;
}

static double coder_dparam_dgdp(double T, double P, int index) {
    coder_solve_V(T, P);
    return 0.0; /* V; */
}

static double coder_dparam_d2gdt2(double T, double P, int index) {
    coder_solve_V(T, P);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double d2AdT2dz = coder_dparam_d2adt2(T, V, index);
    double d2AdTdVdz = coder_dparam_d2adtdv(T, V, index);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    /* return d2AdT2 - d2AdTdV*d2AdTdV/d2AdV2; */
    return d2AdT2dz - 2.0*d2AdTdV*d2AdTdVdz/d2AdV2 + d2AdTdV*d2AdTdV*d2AdV2dz/d2AdV2/d2AdV2;
}

static double coder_dparam_d2gdtdp(double T, double P, int index) {
    coder_solve_V(T, P);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double d2AdTdVdz = coder_dparam_d2adtdv(T, V, index);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    /* return - d2AdTdV/d2AdV2; */
    return - d2AdTdVdz/d2AdV2 + d2AdTdV*d2AdV2dz/d2AdV2/d2AdV2;
}

static double coder_dparam_d2gdp2(double T, double P, int index) {
    coder_solve_V(T, P);
    double d2AdV2 = coder_d2adv2(T, V);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    /* return - 1.0/d2AdV2; */
    return d2AdV2dz/d2AdV2/d2AdV2;
}

static double coder_dparam_d3gdt3(double T, double P, int index) {
    coder_solve_V(T, P);
    double d3AdT2dV = coder_d3adt2dv(T, V);
    double d3AdTdV2 = coder_d3adtdv2(T, V);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double d3AdT3dz = coder_dparam_d3adt3(T, V, index);
    double d3AdT2dVdz = coder_dparam_d3adt2dv(T, V, index);
    double d3AdTdV2dz = coder_dparam_d3adtdv2(T, V, index);
    double d3AdV3dz = coder_dparam_d3adv3(T, V, index);
    double d2AdTdVdz = coder_dparam_d2adtdv(T, V, index);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    double dVdT = - d2AdTdV/d2AdV2;
    double dVdTdz = - d2AdTdVdz/d2AdV2 + d2AdTdV*d2AdV2dz/d2AdV2/d2AdV2;
    double d2VdT2 = (-d3AdT2dV - 2.0*d3AdTdV2*dVdT - d3AdV3*dVdT*dVdT)/d2AdV2;
    double d2VdT2dz = (-d3AdT2dVdz - 2.0*d3AdTdV2dz*dVdT - 2.0*d3AdTdV2*dVdTdz
                        - d3AdV3dz*dVdT*dVdT - 2.0*d3AdV3*dVdT*dVdTdz)/d2AdV2
                    - (-d3AdT2dV - 2.0*d3AdTdV2*dVdT - d3AdV3*dVdT*dVdT)*d2AdV2dz/d2AdV2/d2AdV2;
    /* return d3AdT3 + 2.0*d3AdT2dV*dVdT + d3AdTdV2*dVdT*dVdT + d2AdTdV*d2VdT2; */
    return d3AdT3dz + 2.0*d3AdT2dVdz*dVdT + 2.0*d3AdT2dV*dVdTdz + d3AdTdV2dz*dVdT*dVdT
            + 2.0*d3AdTdV2*dVdT*dVdTdz + d2AdTdVdz*d2VdT2 + d2AdTdV*d2VdT2dz;
}

static double coder_dparam_d3gdt2dp(double T, double P, int index) {
    coder_solve_V(T, P);
    double d3AdT2dV = coder_d3adt2dv(T, V);
    double d3AdTdV2 = coder_d3adtdv2(T, V);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double d3AdT2dVdz = coder_dparam_d3adt2dv(T, V, index);
    double d3AdTdV2dz = coder_dparam_d3adtdv2(T, V, index);
    double d3AdV3dz = coder_dparam_d3adv3(T,V, index);
    double d2AdTdVdz = coder_dparam_d2adtdv(T, V, index);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    double dVdT = -d2AdTdV/d2AdV2;
    double dVdTdz = - d2AdTdVdz/d2AdV2 + d2AdTdV*d2AdV2dz/d2AdV2/d2AdV2;
    double dVdP = -1.0/d2AdV2;
    double dVdPdz = d2AdV2dz/d2AdV2/d2AdV2;
    double d2VdTdP = (-d3AdTdV2*dVdP - d3AdV3*dVdT*dVdP)/d2AdV2;
    double d2VdTdPdz = (-d3AdTdV2dz*dVdP -d3AdTdV2*dVdPdz
            - d3AdV3dz*dVdT*dVdP - d3AdV3*dVdTdz*dVdP - d3AdV3*dVdT*dVdPdz)/d2AdV2
            - (-d3AdTdV2*dVdP - d3AdV3*dVdT*dVdP)*d2AdV2dz/d2AdV2/d2AdV2;
    /* return d3AdT2dV*dVdP + d3AdTdV2*dVdT*dVdP + d2AdTdV*d2VdTdP; */
    return d3AdT2dVdz*dVdP + d3AdT2dV*dVdPdz + d3AdTdV2dz*dVdT*dVdP + d3AdTdV2*dVdTdz*dVdP
        + d3AdTdV2*dVdT*dVdPdz + d2AdTdVdz*d2VdTdP + d2AdTdV*d2VdTdPdz;
}

static double coder_dparam_d3gdtdp2(double T, double P, int index) {
    coder_solve_V(T, P);
    double d3AdTdV2 = coder_d3adtdv2(T, V);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double d3AdTdV2dz = coder_dparam_d3adtdv2(T, V, index);
    double d3AdV3dz = coder_dparam_d3adv3(T, V, index);
    double d2AdTdVdz = coder_dparam_d2adtdv(T, V, index);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    double dVdT = -d2AdTdV/d2AdV2;
    double dVdTdz = - d2AdTdVdz/d2AdV2 + d2AdTdV*d2AdV2dz/d2AdV2/d2AdV2;
    /* return (d3AdTdV2 + d3AdV3*dVdT)/d2AdV2/d2AdV2; */
    return (d3AdTdV2dz + d3AdV3dz*dVdT + d3AdV3*dVdTdz)/d2AdV2/d2AdV2
        - 2.0*(d3AdTdV2 + d3AdV3*dVdT)*d2AdV2dz/d2AdV2/d2AdV2/d2AdV2;
}

static double coder_dparam_d3gdp3(double T, double P, int index) {
    coder_solve_V(T, P);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdV2 = coder_d2adv2(T, V);
    double d3AdV3dz = coder_dparam_d3adv3(T, V, index);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    double dVdP = -1.0/d2AdV2;
    double dVdPdz = d2AdV2dz/d2AdV2/d2AdV2;
    /* return d3AdV3*dVdP/d2AdV2/d2AdV2; */
    return d3AdV3dz*dVdP/d2AdV2/d2AdV2 + d3AdV3*dVdPdz/d2AdV2/d2AdV2
        - 2.0*d3AdV3*dVdP*d2AdV2dz/d2AdV2/d2AdV2/d2AdV2;
}

static int coder_get_param_number(void) {
    return 0;
}

static const char *paramNames[0] = {  };

static const char *paramUnits[0] = {  };

static const char **coder_get_param_names(void) {
    return paramNames;
}

static const char **coder_get_param_units(void) {
    return paramUnits;
}

static void coder_get_param_values(double **values) {
}

static int coder_set_param_values(double *values) {
    return 1;
}

static double coder_get_param_value(int index) {
    double result = 0.0;
    switch (index) {
     default:
         break;
    }
    return result;
}

static int coder_set_param_value(int index, double value) {
    int result = 1;
    switch (index) {
     default:
         break;
    }
    return result;
}



const char *HPClinoferrosilite_slb21_em_coder_calib_identifier(void) {
    return identifier;
}

const char *HPClinoferrosilite_slb21_em_coder_calib_name(void) {
    return "HPClinoferrosilite_slb21_em";
}

const char *HPClinoferrosilite_slb21_em_coder_calib_formula(void) {
    return "Fe2Si2O6";
}

const double HPClinoferrosilite_slb21_em_coder_calib_mw(void) {
    return 263.8614;
}

static const double elmformula[106] = {
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,6.0,0.0,0.0,0.0,
        0.0,0.0,2.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,2.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0
    };

const double *HPClinoferrosilite_slb21_em_coder_calib_elements(void) {
    return elmformula;
}

double HPClinoferrosilite_slb21_em_coder_calib_g(double T, double P) {
    return coder_g(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_dgdt(double T, double P) {
    return coder_dgdt(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_dgdp(double T, double P) {
    return coder_dgdp(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_d2gdt2(double T, double P) {
    return coder_d2gdt2(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_d2gdtdp(double T, double P) {
    return coder_d2gdtdp(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_d2gdp2(double T, double P) {
    return coder_d2gdp2(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_d3gdt3(double T, double P) {
    return coder_d3gdt3(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_d3gdt2dp(double T, double P) {
    return coder_d3gdt2dp(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_d3gdtdp2(double T, double P) {
    return coder_d3gdtdp2(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_d3gdp3(double T, double P) {
    return coder_d3gdp3(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_s(double T, double P) {
    return coder_s(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_dsdt(double T, double P) {
    return coder_dsdt(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_dsdp(double T, double P) {
    return coder_dsdp(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_v(double T, double P) {
    return coder_v(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_cv(double T, double P) {
    return coder_cv(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_cp(double T, double P) {
    return coder_cp(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_dcpdt(double T, double P) {
    return coder_dcpdt(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_dcpdp(double T, double P) {
    return coder_dcpdp(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_alpha(double T, double P) {
    return coder_alpha(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_dalphadt(double T, double P) {
    return coder_dalphadt(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_dalphadp(double T, double P) {
    return coder_dalphadp(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_beta(double T, double P) {
    return coder_beta(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_K(double T, double P) {
    return coder_K(T, P);
}

double HPClinoferrosilite_slb21_em_coder_calib_Kp(double T, double P) {
    return coder_Kp(T, P);
}

int HPClinoferrosilite_slb21_em_coder_get_param_number(void) {
    return coder_get_param_number();
}

const char **HPClinoferrosilite_slb21_em_coder_get_param_names(void) {
    return coder_get_param_names();
}

const char **HPClinoferrosilite_slb21_em_coder_get_param_units(void) {
    return coder_get_param_units();
}

void HPClinoferrosilite_slb21_em_coder_get_param_values(double **values) {
    coder_get_param_values(values);
}

int HPClinoferrosilite_slb21_em_coder_set_param_values(double *values) {
    return coder_set_param_values(values);
}

double HPClinoferrosilite_slb21_em_coder_get_param_value(int index) {
    return coder_get_param_value(index);
}

int HPClinoferrosilite_slb21_em_coder_set_param_value(int index, double value) {
    return coder_set_param_value(index, value);
}

double HPClinoferrosilite_slb21_em_coder_dparam_g(double T, double P, int index) {
    return coder_dparam_g(T, P, index);
}

double HPClinoferrosilite_slb21_em_coder_dparam_dgdt(double T, double P, int index) {
    return coder_dparam_dgdt(T, P, index);
}

double HPClinoferrosilite_slb21_em_coder_dparam_dgdp(double T, double P, int index) {
    return coder_dparam_dgdp(T, P, index);
}

double HPClinoferrosilite_slb21_em_coder_dparam_d2gdt2(double T, double P, int index) {
    return coder_dparam_d2gdt2(T, P, index);
}

double HPClinoferrosilite_slb21_em_coder_dparam_d2gdtdp(double T, double P, int index) {
    return coder_dparam_d2gdtdp(T, P, index);
}

double HPClinoferrosilite_slb21_em_coder_dparam_d2gdp2(double T, double P, int index) {
    return coder_dparam_d2gdp2(T, P, index);
}

double HPClinoferrosilite_slb21_em_coder_dparam_d3gdt3(double T, double P, int index) {
    return coder_dparam_d3gdt3(T, P, index);
}

double HPClinoferrosilite_slb21_em_coder_dparam_d3gdt2dp(double T, double P, int index) {
    return coder_dparam_d3gdt2dp(T, P, index);
}

double HPClinoferrosilite_slb21_em_coder_dparam_d3gdtdp2(double T, double P, int index) {
    return coder_dparam_d3gdtdp2(T, P, index);
}

double HPClinoferrosilite_slb21_em_coder_dparam_d3gdp3(double T, double P, int index) {
    return coder_dparam_d3gdp3(T, P, index);
}

