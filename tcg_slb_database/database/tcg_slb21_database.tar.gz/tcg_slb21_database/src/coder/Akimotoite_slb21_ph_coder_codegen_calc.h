#include <math.h>


static double coder_g(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = 1.0/x1;
    double x3 = n1*(*endmember[0].mu0)(T, P);
    double x4 = n2*(*endmember[1].mu0)(T, P);
    double x5 = n3*(*endmember[2].mu0)(T, P);
    double x6 = T*(1.0*n1*log(n1*x2) + 1.0*n2*log(n2*x2) + 2.0*n3*log(n3*x2) + 1.0*x0*log(x0*x2));
    double x7 = 29650.0*n3;
    double x8 = n1*x7 + n2*x7 + x0*x7;
    double x9 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));

if (T >= 5.0) {
   result = x2*(1.0*x1*(-n2*(13.381349999999999*T - 44.604500000000002) + x3 + x4 + x5 + 8.3144626181532395*x6) + x8);
}
else {
   result = x2*(0.33333333333333331*x1*(n2*(66.906750000000002*((x9)*(x9)*(x9)) + (40.14405*T - 200.72024999999999)*(x9 - 1) - 66.906750000000002) + 3*x3 + 3*x4 + 3*x5 + 24.943387854459719*x6) + x8);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = pow(x1, -2);
    double x3 = (*endmember[0].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = n2*x5;
    double x7 = (*endmember[2].mu0)(T, P);
    double x8 = n3*x7;
    double x9 = 13.381349999999999*T;
    double x10 = n2*(x9 - 44.604500000000002);
    double x11 = 1.0/x1;
    double x12 = n1*x11;
    double x13 = 1.0*log(x12);
    double x14 = n2*x11;
    double x15 = 1.0*log(x14);
    double x16 = n3*x11;
    double x17 = log(x16);
    double x18 = x0*x11;
    double x19 = 1.0*log(x18);
    double x20 = n1*x13 + n2*x15 + 2.0*n3*x17 + x0*x19;
    double x21 = 8.3144626181532395*T;
    double x22 = x20*x21;
    double x23 = 1.0*x1;
    double x24 = 29650.0*n3;
    double x25 = n1*x24 + n2*x24 + x0*x24;
    double x26 = -x2*(x23*(-x10 + x22 + x4 + x6 + x8) + x25);
    double x27 = -x11;
    double x28 = 1.0*x14;
    double x29 = -2.0*x16 + x19 + x23*(-x0*x2 - x27);
    double x30 = x13 + x23*(-n1*x2 - x27) - x28 + x29;
    double x31 = -1.0*x10;
    double x32 = x22 + 1.0*x4 + 1.0*x6 + 1.0*x8;
    double x33 = 59300.0*n3 + x32;
    double x34 = x31 + x33;
    double x35 = T >= 5.0;
    double x36 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x37 = 66.906750000000002*((x36)*(x36)*(x36)) + (40.14405*T - 200.72024999999999)*(x36 - 1) - 66.906750000000002;
    double x38 = n2*x37;
    double x39 = 24.943387854459719*T;
    double x40 = 0.33333333333333331*x1;
    double x41 = -x2*(x25 + x40*(x20*x39 + x38 + 3*x4 + 3*x6 + 3*x8));
    double x42 = 0.33333333333333331*x38;
    double x43 = x33 + x42;
    double x44 = 1.0*x12;
    double x45 = x15 + x23*(-n2*x2 - x27) + x29 - x44;
    double x46 = 2.0*x1*(-n3*x2 - x27) + 2.0*x17 - 1.0*x18 - x28 - x44;
    double x47 = 59300.0*n1 + 59300.0*n2 + x32;

if (x35) {
   result[0] = x11*(x23*(x21*x30 + x3) + x34) + x26;
}
else {
   result[0] = x11*(x40*(3*x3 + x30*x39) + x43) + x41;
}
if (x35) {
   result[1] = x11*(x23*(x21*x45 + x5 - x9 + 44.604500000000002) + x34) + x26;
}
else {
   result[1] = x11*(x40*(x37 + x39*x45 + 3*x5) + x43) + x41;
}
if (x35) {
   result[2] = x11*(x23*(x21*x46 + x7) + x31 + x47) + x26;
}
else {
   result[2] = x11*(x40*(x39*x46 + 3*x7) + x42 + x47) + x41;
}
}
        
static void coder_d2gdn2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n3*x4;
    double x6 = 13.381349999999999*T;
    double x7 = n2*(x6 - 44.604500000000002);
    double x8 = n1 + n2;
    double x9 = n3 + x8;
    double x10 = 1.0/x9;
    double x11 = n1*x10;
    double x12 = 1.0*log(x11);
    double x13 = n2*x10;
    double x14 = 1.0*log(x13);
    double x15 = log(n3*x10);
    double x16 = x10*x8;
    double x17 = 1.0*log(x16);
    double x18 = T*(n1*x12 + n2*x14 + 2.0*n3*x15 + x17*x8);
    double x19 = 8.3144626181532395*x18;
    double x20 = 1.0*x9;
    double x21 = 29650.0*n3;
    double x22 = n1*x21 + n2*x21 + x21*x8;
    double x23 = 2/((x9)*(x9)*(x9));
    double x24 = x23*(x20*(x1 + x19 + x3 + x5 - x7) + x22);
    double x25 = pow(x9, -2);
    double x26 = n1*x25;
    double x27 = -x10;
    double x28 = x20*(-x26 - x27);
    double x29 = 1.0*x13;
    double x30 = x25*x8;
    double x31 = x20*(-x27 - x30);
    double x32 = 2.0*x10;
    double x33 = -n3*x32 + x17 + x31;
    double x34 = T*(x12 + x28 - x29 + x33);
    double x35 = 8.3144626181532395*x34;
    double x36 = -1.0*x7;
    double x37 = 1.0*x1 + x19 + 1.0*x3 + 1.0*x5;
    double x38 = 59300.0*n3 + x37;
    double x39 = x36 + x38;
    double x40 = x20*(x0 + x35) + x39;
    double x41 = 2*x25;
    double x42 = 1.0*x26;
    double x43 = -x42;
    double x44 = -x41;
    double x45 = n1*x23;
    double x46 = x23*x8;
    double x47 = n3*x25;
    double x48 = 2.0*x47;
    double x49 = 1.0*x30;
    double x50 = x48 - x49;
    double x51 = x20*(x44 + x46) + x31/x8 + x50;
    double x52 = n2*x25;
    double x53 = 1.0*x52;
    double x54 = x32 + x53;
    double x55 = 8.3144626181532395*T*x9;
    double x56 = x10*(2.0*x0 + 16.628925236306479*x34 + x55*(x20*(x44 + x45) + x43 + x51 + x54 + x28/n1));
    double x57 = T >= 5.0;
    double x58 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x59 = ((x58)*(x58)*(x58));
    double x60 = (40.14405*T - 200.72024999999999)*(x58 - 1);
    double x61 = 66.906750000000002*x59 + x60 - 66.906750000000002;
    double x62 = n2*x61;
    double x63 = 0.33333333333333331*x9;
    double x64 = x23*(x22 + x63*(3*x1 + 24.943387854459719*x18 + 3*x3 + 3*x5 + x62));
    double x65 = 0.33333333333333331*x62;
    double x66 = x38 + x65;
    double x67 = x63*(3*x0 + 24.943387854459719*x34) + x66;
    double x68 = x20*(-x27 - x52);
    double x69 = 1.0*x11;
    double x70 = T*(x14 + x33 + x68 - x69);
    double x71 = 8.3144626181532395*x70;
    double x72 = -x6 + x71;
    double x73 = x72 + 44.604500000000002;
    double x74 = 1.0*x2;
    double x75 = -x25;
    double x76 = x20*(x45 + x75) + x43 + x53;
    double x77 = 1.0*x0 + x35;
    double x78 = x55*(x51 + x76) + x74 + x77;
    double x79 = x20*(x2 + x73) + x39;
    double x80 = -x25*x79;
    double x81 = x24 - x25*x40;
    double x82 = 22.302250000000001*x59 + 0.33333333333333331*x60 + x71;
    double x83 = x63*(3*x2 + x61 + 24.943387854459719*x70) + x66;
    double x84 = -x25*x83;
    double x85 = -x25*x67 + x64;
    double x86 = x20*(x46 + x75) - x32 + x50;
    double x87 = -x27 - x47;
    double x88 = T*(2.0*x15 - 1.0*x16 - x29 - x69 + 2.0*x87*x9);
    double x89 = 8.3144626181532395*x88;
    double x90 = 1.0*x4 + x89;
    double x91 = x10*(x55*(x76 + x86) + x77 + x90 + 59300.0);
    double x92 = 59300.0*n1 + 59300.0*n2 + x37;
    double x93 = x20*(x4 + x89) + x36 + x92;
    double x94 = -x25*x93;
    double x95 = x63*(3*x4 + 24.943387854459719*x88) + x65 + x92;
    double x96 = -x25*x95;
    double x97 = n2*x23;
    double x98 = x42 - x53;
    double x99 = 2.0*x2 + x55*(x20*(x44 + x97) + x32 + x51 + x98 + x68/n2) + 16.628925236306479*x70;
    double x100 = x55*(x20*(x75 + x97) + x86 + x98) + x74 + x90;
    double x101 = 2.0*x9;
    double x102 = x10*(2.0*x4 + x55*(x101*(n3*x23 + x44) + x42 - x48 + x49 + x54 + x101*x87/n3) + 16.628925236306479*x88);

if (x57) {
   result[0] = x24 - x40*x41 + x56;
}
else {
   result[0] = -x41*x67 + x56 + x64;
}
if (x57) {
   result[1] = x10*(x73 + x78) + x80 + x81;
}
else {
   result[1] = x10*(x78 + x82 - 22.302250000000001) + x84 + x85;
}
if (x57) {
   result[2] = x81 + x91 + x94;
}
else {
   result[2] = x85 + x91 + x96;
}
if (x57) {
   result[3] = x10*(-26.762699999999999*T + x99 + 89.209000000000003) + x24 - x41*x79;
}
else {
   result[3] = x10*(44.604500000000002*x59 + 0.66666666666666663*x60 + x99 - 44.604500000000002) - x41*x83 + x64;
}
if (x57) {
   result[4] = x10*(x100 + x72 + 59344.604500000001) + x24 + x80 + x94;
}
else {
   result[4] = x10*(x100 + x82 + 59277.697749999999) + x64 + x84 + x96;
}
if (x57) {
   result[5] = x102 + x24 - x41*x93;
}
else {
   result[5] = x102 - x41*x95 + x64;
}
}
        
static void coder_d3gdn3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n3*x4;
    double x6 = 13.381349999999999*T;
    double x7 = n2*(x6 - 44.604500000000002);
    double x8 = n1 + n2;
    double x9 = n3 + x8;
    double x10 = 1.0/x9;
    double x11 = n1*x10;
    double x12 = 1.0*log(x11);
    double x13 = n2*x10;
    double x14 = 1.0*log(x13);
    double x15 = log(n3*x10);
    double x16 = x10*x8;
    double x17 = 1.0*log(x16);
    double x18 = n1*x12 + n2*x14 + 2.0*n3*x15 + x17*x8;
    double x19 = 8.3144626181532395*T;
    double x20 = x18*x19;
    double x21 = 1.0*x9;
    double x22 = 29650.0*n3;
    double x23 = n1*x22 + n2*x22 + x22*x8;
    double x24 = 6/((x9)*(x9)*(x9)*(x9));
    double x25 = -x24*(x21*(x1 + x20 + x3 + x5 - x7) + x23);
    double x26 = pow(x9, -2);
    double x27 = n1*x26;
    double x28 = -x10;
    double x29 = -x27 - x28;
    double x30 = x21*x29;
    double x31 = 1.0*x13;
    double x32 = x26*x8;
    double x33 = -x28 - x32;
    double x34 = x21*x33;
    double x35 = 2.0*x10;
    double x36 = -n3*x35 + x17 + x34;
    double x37 = x12 + x30 - x31 + x36;
    double x38 = x19*x37;
    double x39 = -1.0*x7;
    double x40 = 1.0*x1 + x20 + 1.0*x3 + 1.0*x5;
    double x41 = 59300.0*n3 + x40;
    double x42 = x39 + x41;
    double x43 = x21*(x0 + x38) + x42;
    double x44 = pow(x9, -3);
    double x45 = 6*x44;
    double x46 = 1.0*x27;
    double x47 = -x46;
    double x48 = 2*x26;
    double x49 = -x48;
    double x50 = 2*x44;
    double x51 = n1*x50;
    double x52 = x21*(x49 + x51);
    double x53 = 1.0/n1;
    double x54 = x29*x53;
    double x55 = x50*x8;
    double x56 = x21*(x49 + x55);
    double x57 = 1.0/x8;
    double x58 = x33*x57;
    double x59 = n3*x26;
    double x60 = 2.0*x59;
    double x61 = 1.0*x32;
    double x62 = x60 - x61;
    double x63 = x21*x58 + x56 + x62;
    double x64 = n2*x26;
    double x65 = 1.0*x64;
    double x66 = x35 + x65;
    double x67 = x21*x54 + x47 + x52 + x63 + x66;
    double x68 = 24.943387854459719*T;
    double x69 = -6*x44;
    double x70 = n1*x24;
    double x71 = 4.0*x44;
    double x72 = 2.0*x44;
    double x73 = n2*x72;
    double x74 = n1*x71 - x73;
    double x75 = 1.0*x54 + x74;
    double x76 = 8.0*x26;
    double x77 = -n3*x71 + x71*x8;
    double x78 = 1.0*x58 + x77;
    double x79 = x24*x8;
    double x80 = x21*(-x69 - x79) - x34/((x8)*(x8)) + x56*x57;
    double x81 = x78 + x80;
    double x82 = -x76 + x81;
    double x83 = x19*x9;
    double x84 = 16.628925236306479*T;
    double x85 = x19*x67;
    double x86 = x26*(2.0*x0 + x37*x84 + x85*x9);
    double x87 = x10*(x67*x68 + x83*(x21*(-x69 - x70) + x52*x53 + x75 + x82 - x30/((n1)*(n1)))) - 3*x86;
    double x88 = T >= 5.0;
    double x89 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x90 = ((x89)*(x89)*(x89));
    double x91 = (40.14405*T - 200.72024999999999)*(x89 - 1);
    double x92 = 66.906750000000002*x90 + x91 - 66.906750000000002;
    double x93 = n2*x92;
    double x94 = 0.33333333333333331*x9;
    double x95 = -x24*(x23 + x94*(3*x1 + x18*x68 + 3*x3 + 3*x5 + x93));
    double x96 = 0.33333333333333331*x93;
    double x97 = x41 + x96;
    double x98 = x94*(3*x0 + x37*x68) + x97;
    double x99 = -x28 - x64;
    double x100 = x21*x99;
    double x101 = 1.0*x11;
    double x102 = x100 - x101 + x14 + x36;
    double x103 = x102*x19;
    double x104 = x103 - x6;
    double x105 = x104 + 44.604500000000002;
    double x106 = x21*(x105 + x2) + x42;
    double x107 = x106*x50;
    double x108 = 4*x44;
    double x109 = x108*x43;
    double x110 = -x26;
    double x111 = x21*(x110 + x51);
    double x112 = x111 + x47 + x65;
    double x113 = x112 + x63;
    double x114 = x113*x84;
    double x115 = -4*x44;
    double x116 = x111*x53 + x21*(-x115 - x70) + x75;
    double x117 = -x86;
    double x118 = x10*(x114 + x83*(x116 - 6.0*x26 + x81) + x85) + x117;
    double x119 = 1.0*x2;
    double x120 = x113*x19;
    double x121 = 1.0*x0 + x38;
    double x122 = x119 + x120*x9 + x121;
    double x123 = x105 + x122;
    double x124 = -x123*x48 + x25;
    double x125 = x103 + 22.302250000000001*x90 + 0.33333333333333331*x91;
    double x126 = x122 + x125 - 22.302250000000001;
    double x127 = -x126*x48;
    double x128 = x94*(x102*x68 + 3*x2 + x92) + x97;
    double x129 = x128*x50;
    double x130 = x108*x98 + x95;
    double x131 = -x28 - x59;
    double x132 = -x101 + 2.0*x131*x9 + 2.0*x15 - 1.0*x16 - x31;
    double x133 = x132*x19;
    double x134 = 59300.0*n1 + 59300.0*n2 + x40;
    double x135 = x134 + x21*(x133 + x4) + x39;
    double x136 = x135*x50;
    double x137 = x21*(x110 + x55);
    double x138 = x137 - x35 + x62;
    double x139 = x112 + x138;
    double x140 = x139*x19;
    double x141 = x133 + 1.0*x4;
    double x142 = x121 + x140*x9 + x141 + 59300.0;
    double x143 = -x142*x48;
    double x144 = x143 + x25;
    double x145 = x139*x84;
    double x146 = x137*x57 + x21*(-x115 - x79);
    double x147 = x146 - 4.0*x26 + x78;
    double x148 = x10*(x145 + x83*(x116 + x147) + x85) + x117;
    double x149 = x134 + x94*(x132*x68 + 3*x4) + x96;
    double x150 = x149*x50;
    double x151 = n2*x50;
    double x152 = x21*(x151 + x49);
    double x153 = 1.0/n2;
    double x154 = x46 - x65;
    double x155 = x100*x153 + x152 + x154 + x35 + x63;
    double x156 = x155*x19;
    double x157 = -2*x44;
    double x158 = x21*(-x157 - x70) + x74;
    double x159 = x158 + x78;
    double x160 = x10*(x114 + x156 + x83*(x159 - 3.0*x26 + x80));
    double x161 = x43*x50;
    double x162 = x102*x84 + x156*x9 + 2.0*x2;
    double x163 = x26*(-26.762699999999999*T + x162 + 89.209000000000003);
    double x164 = x106*x108 - x163;
    double x165 = x50*x98 + x95;
    double x166 = x26*(x162 + 44.604500000000002*x90 + 0.66666666666666663*x91 - 44.604500000000002);
    double x167 = x108*x128 - x166;
    double x168 = x21*(x110 + x151);
    double x169 = x138 + x154 + x168;
    double x170 = x169*x19;
    double x171 = x119 + x141 + x170*x9;
    double x172 = x104 + x171 + 59344.604500000001;
    double x173 = x10*(x120 + x140 + x170 + x83*(x146 + x159 - 1.0*x26)) - x142*x26;
    double x174 = x125 + x171 + 59277.697749999999;
    double x175 = x108*x135;
    double x176 = n3*x50 + x49;
    double x177 = 2.0*x9;
    double x178 = 1.0/n3;
    double x179 = x131*x177;
    double x180 = x176*x177 + x178*x179 + x46 - x60 + x61 + x66;
    double x181 = x180*x19;
    double x182 = x21*(-x157 - x79) + 2.0*x26 + x77;
    double x183 = x26*(x132*x84 + x181*x9 + 2.0*x4);
    double x184 = -x183;
    double x185 = x10*(x145 + x181 + x83*(x158 + x182)) + x184;
    double x186 = x108*x149;
    double x187 = n2*x24;
    double x188 = n1*x72;
    double x189 = n2*x71 - x188;
    double x190 = 1.0*x153*x99 + x189;
    double x191 = x10*(x155*x68 + x83*(x152*x153 + x190 + x21*(-x187 - x69) + x82 - x100/((n2)*(n2))));
    double x192 = x169*x84;
    double x193 = x10*(x156 + x192 + x83*(x147 + x153*x168 + x190 + x21*(-x115 - x187)));
    double x194 = -x172*x48 + x25;
    double x195 = -x174*x48 + x95;
    double x196 = x10*(x181 + x192 + x83*(x182 + x189 + x21*(-x157 - x187))) + x184;
    double x197 = x10*(x180*x68 + x83*(8.0*n3*x44 + 2.0*x131*x178 + 2.0*x176*x178*x9 - x188 - x72*x8 - x73 - x76 + 2.0*x9*(-n3*x24 - x69) - x179/((n3)*(n3)))) - 3*x183;

if (x88) {
   result[0] = x25 + x43*x45 + x87;
}
else {
   result[0] = x45*x98 + x87 + x95;
}
if (x88) {
   result[1] = x107 + x109 + x118 + x124;
}
else {
   result[1] = x118 + x127 + x129 + x130;
}
if (x88) {
   result[2] = x109 + x136 + x144 + x148;
}
else {
   result[2] = x130 + x143 + x148 + x150;
}
if (x88) {
   result[3] = x124 + x160 + x161 + x164;
}
else {
   result[3] = x127 + x160 + x165 + x167;
}
if (x88) {
   result[4] = x107 - x123*x26 + x136 + x161 - x172*x26 + x173 + x25;
}
else {
   result[4] = -x126*x26 + x129 + x150 + x165 + x173 - x174*x26;
}
if (x88) {
   result[5] = x144 + x161 + x175 + x185;
}
else {
   result[5] = x143 + x165 + x185 + x186;
}
if (x88) {
   result[6] = x106*x45 - 3*x163 + x191 + x25;
}
else {
   result[6] = x128*x45 - 3*x166 + x191 + x95;
}
if (x88) {
   result[7] = x136 + x164 + x193 + x194;
}
else {
   result[7] = x150 + x167 + x193 + x195;
}
if (x88) {
   result[8] = x107 + x175 + x194 + x196;
}
else {
   result[8] = x129 + x186 + x195 + x196;
}
if (x88) {
   result[9] = x135*x45 + x197 + x25;
}
else {
   result[9] = x149*x45 + x197 + x95;
}
}
        
static double coder_dgdt(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1 + n2;
    double x1 = 1.0/(n3 + x0);
    double x2 = 8.3144626181532395*n1*log(n1*x1) + 1.0*n1*(*endmember[0].dmu0dT)(T, P) + 8.3144626181532395*n2*log(n2*x1) + 1.0*n2*(*endmember[1].dmu0dT)(T, P) + 16.628925236306479*n3*log(n3*x1) + 1.0*n3*(*endmember[2].dmu0dT)(T, P) + 8.3144626181532395*x0*log(x0*x1);
    double x3 = sqrt(1 - 0.19999999999999998*T);
    double x4 = 1.0*x3;
    double x5 = fmin(4, x4);
    double x6 = (4 - x4 >= 0. ? 1. : 0.)/x3;

if (T >= 5.0) {
   result = -13.381349999999999*n2 + x2;
}
else {
   result = 0.33333333333333331*n2*(-20.072025*((x5)*(x5))*x6 + 40.14405*x5 - 0.099999999999999992*x6*(40.14405*T - 200.72024999999999) - 40.14405) + x2;
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = 1.0/x1;
    double x3 = n1*x2;
    double x4 = pow(x1, -2);
    double x5 = -x2;
    double x6 = 8.3144626181532395*x1;
    double x7 = n2*x2;
    double x8 = 8.3144626181532395*x7;
    double x9 = x0*x2;
    double x10 = n3*x2;
    double x11 = -16.628925236306479*x10 + x6*(-x0*x4 - x5) + 8.3144626181532395*log(x9);
    double x12 = 8.3144626181532395*x3;
    double x13 = x11 - x12 + x6*(-n2*x4 - x5) + 8.3144626181532395*log(x7) + 1.0*(*endmember[1].dmu0dT)(T, P) - 13.381349999999999;
    double x14 = sqrt(1 - 0.19999999999999998*T);
    double x15 = 1.0*x14;
    double x16 = fmin(4, x15);
    double x17 = (4 - x15 >= 0. ? 1. : 0.)/x14;

result[0] = x11 + x6*(-n1*x4 - x5) - x8 + 8.3144626181532395*log(x3) + 1.0*(*endmember[0].dmu0dT)(T, P);
if (T >= 5.0) {
   result[1] = x13;
}
else {
   result[1] = x13 - 6.6906749999999997*((x16)*(x16))*x17 + 13.381349999999999*x16 - 0.033333333333333326*x17*(40.14405*T - 200.72024999999999);
}
result[2] = 16.628925236306479*x1*(-n3*x4 - x5) - x12 - x8 - 8.3144626181532395*x9 + 16.628925236306479*log(x10) + 1.0*(*endmember[2].dmu0dT)(T, P);
}
        
static void coder_d3gdn2dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = pow(x1, -2);
    double x3 = n1*x2;
    double x4 = 8.3144626181532395*x3;
    double x5 = -x4;
    double x6 = -2*x2;
    double x7 = 2/((x1)*(x1)*(x1));
    double x8 = n1*x7;
    double x9 = 8.3144626181532395*x1;
    double x10 = 1.0/x1;
    double x11 = -x10;
    double x12 = x0*x7;
    double x13 = x0*x2;
    double x14 = n3*x2;
    double x15 = 16.628925236306479*x14;
    double x16 = 8.3144626181532395*x13;
    double x17 = x15 - x16;
    double x18 = x17 + x9*(x12 + x6) + x9*(-x11 - x13)/x0;
    double x19 = n2*x2;
    double x20 = 8.3144626181532395*x19;
    double x21 = 16.628925236306479*x10;
    double x22 = x20 + x21;
    double x23 = -x2;
    double x24 = x20 + x5 + x9*(x23 + x8);
    double x25 = x17 - x21 + x9*(x12 + x23);
    double x26 = n2*x7;
    double x27 = -x20 + x4;
    double x28 = 16.628925236306479*x1;

result[0] = x18 + x22 + x5 + x9*(x6 + x8) + x9*(-x11 - x3)/n1;
result[1] = x18 + x24;
result[2] = x24 + x25;
result[3] = x18 + x21 + x27 + x9*(x26 + x6) + x9*(-x11 - x19)/n2;
result[4] = x25 + x27 + x9*(x23 + x26);
result[5] = -x15 + x16 + x22 + x28*(n3*x7 + x6) + x4 + x28*(-x11 - x14)/n3;
}
        
static void coder_d4gdn3dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = pow(x1, -3);
    double x3 = -6*x2;
    double x4 = 6/((x1)*(x1)*(x1)*(x1));
    double x5 = n1*x4;
    double x6 = 8.3144626181532395*x1;
    double x7 = pow(x1, -2);
    double x8 = -2*x7;
    double x9 = 2*x2;
    double x10 = n1*x9;
    double x11 = 8.3144626181532395/n1;
    double x12 = x1*x11;
    double x13 = -1/x1;
    double x14 = -n1*x7 - x13;
    double x15 = 33.257850472612958*x2;
    double x16 = 16.628925236306479*x2;
    double x17 = n2*x16;
    double x18 = n1*x15 - x17;
    double x19 = x11*x14 + x18;
    double x20 = 66.515700945225916*x7;
    double x21 = -x0*x7 - x13;
    double x22 = 8.3144626181532395/x0;
    double x23 = -n3*x15 + x0*x15;
    double x24 = x21*x22 + x23;
    double x25 = x0*x4;
    double x26 = x0*x9;
    double x27 = x1*x22;
    double x28 = x27*(x26 + x8) + x6*(-x25 - x3) - x21*x6/((x0)*(x0));
    double x29 = x24 + x28;
    double x30 = -x20 + x29;
    double x31 = -4*x2;
    double x32 = -x7;
    double x33 = x12*(x10 + x32) + x19 + x6*(-x31 - x5);
    double x34 = x27*(x26 + x32) + x6*(-x25 - x31);
    double x35 = x24 + x34 - 33.257850472612958*x7;
    double x36 = -2*x2;
    double x37 = x18 + x6*(-x36 - x5);
    double x38 = x24 + x37;
    double x39 = x23 + x6*(-x25 - x36) + 16.628925236306479*x7;
    double x40 = n2*x4;
    double x41 = n2*x9;
    double x42 = 1.0/n2;
    double x43 = x42*x6;
    double x44 = -n2*x7 - x13;
    double x45 = n1*x16;
    double x46 = n2*x15 - x45;
    double x47 = 8.3144626181532395*x42*x44 + x46;
    double x48 = 1.0/n3;
    double x49 = -n3*x7 - x13;

result[0] = x12*(x10 + x8) + x19 + x30 + x6*(-x3 - x5) - x14*x6/((n1)*(n1));
result[1] = x29 + x33 - 49.886775708919444*x7;
result[2] = x33 + x35;
result[3] = x28 + x38 - 24.943387854459719*x7;
result[4] = x34 + x38 - 8.3144626181532395*x7;
result[5] = x37 + x39;
result[6] = x30 + x43*(x41 + x8) + x47 + x6*(-x3 - x40) - x44*x6/((n2)*(n2));
result[7] = x35 + x43*(x32 + x41) + x47 + x6*(-x31 - x40);
result[8] = x39 + x46 + x6*(-x36 - x40);
result[9] = 66.515700945225916*n3*x2 - x0*x16 + 16.628925236306479*x1*x48*(n3*x9 + x8) + 16.628925236306479*x1*(-n3*x4 - x3) - x17 - x20 - x45 + 16.628925236306479*x48*x49 - 16.628925236306479*x1*x49/((n3)*(n3));
}
        
static double coder_dgdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*n1*(*endmember[0].dmu0dP)(T, P) + 1.0*n2*(*endmember[1].dmu0dP)(T, P) + 1.0*n3*(*endmember[2].dmu0dP)(T, P);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].dmu0dP)(T, P);
result[1] = 1.0*(*endmember[1].dmu0dP)(T, P);
result[2] = 1.0*(*endmember[2].dmu0dP)(T, P);
}
        
static void coder_d3gdn2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dT2)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dT2)(T, P);
    double x3 = 0.19999999999999998*T - 1;
    double x4 = -x3;
    double x5 = sqrt(x4);
    double x6 = 1.0*x5;
    double x7 = x6 - 4;
    double x8 = (-x7 >= 0. ? 1. : 0.);
    double x9 = 0.40144049999999992*T - 2.0072024999999996;
    double x10 = 1.0/x3;
    double x11 = x10*0;
    double x12 = x8/pow(x4, 3.0/2.0);
    double x13 = fmin(4, x6);
    double x14 = 2.0072025*((x13)*(x13));

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = -0.33333333333333331*n2*(4.014405*x10*x13*((x8)*(x8)) - x11*x14 - x11*x9 + x12*x14 + x12*x9 + 8.02881*x8/x5) + 1.0*x0 + 1.0*x1 + 1.0*x2;
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[1].d2mu0dT2)(T, P);
    double x1 = 0.19999999999999998*T - 1;
    double x2 = -x1;
    double x3 = sqrt(x2);
    double x4 = 1.0*x3;
    double x5 = x4 - 4;
    double x6 = (-x5 >= 0. ? 1. : 0.);
    double x7 = 40.14405*T - 200.72024999999999;
    double x8 = 1.0/x1;
    double x9 = 0;
    double x10 = x6/pow(x2, 3.0/2.0);
    double x11 = fmin(4, x4);
    double x12 = ((x11)*(x11));

result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
if (T >= 5.0) {
   result[1] = 1.0*x0;
}
else {
   result[1] = 1.0*x0 - 0.66906749999999993*x10*x12 - 0.0033333333333333327*x10*x7 - 1.3381349999999999*x11*((x6)*(x6))*x8 + 0.66906749999999993*x12*x8*x9 + 0.0033333333333333327*x7*x8*x9 - 2.6762699999999997*x6/x3;
}
result[2] = 1.0*(*endmember[2].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P) + n3*(*endmember[2].d2mu0dTdP)(T, P));
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P) + n3*(*endmember[2].d2mu0dP2)(T, P));
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT3)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dT3)(T, P);
    double x3 = 0.19999999999999998*T - 1;
    double x4 = -x3;
    double x5 = 1.0*sqrt(x4);
    double x6 = x5 - 4;
    double x7 = 0;
    double x8 = pow(x4, -3.0/2.0);
    double x9 = (-x6 >= 0. ? 1. : 0.);
    double x10 = 1.2043214999999998*x8*x9;
    double x11 = 40.14405*T - 200.72024999999999;
    double x12 = pow(x3, -2);
    double x13 = x12*x7;
    double x14 = x9/pow(x4, 5.0/2.0);
    double x15 = x8*0;
    double x16 = fmin(4, x5);
    double x17 = ((x16)*(x16));

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = -0.33333333333333331*n2*(-x10*x16*x7 + x10 + 0.0029999999999999992*x11*x13 + 0.0029999999999999996*x11*x14 - 0.0009999999999999998*x11*x15 - 1.2043214999999998*x12*x16*((x9)*(x9)) + 0.60216074999999991*x13*x17 + 0.60216075000000002*x14*x17 - 0.20072024999999999*x15*x17 + 0.40144049999999998*x8*((x9)*(x9)*(x9)) - 1.2043214999999998*x7/x3) + 1.0*x0 + 1.0*x1 + 1.0*x2;
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 1.0*(*endmember[1].d3mu0dT3)(T, P);
    double x1 = 0.19999999999999998*T - 1;
    double x2 = -x1;
    double x3 = 1.0*sqrt(x2);
    double x4 = x3 - 4;
    double x5 = 0;
    double x6 = 0.40144049999999992*x5;
    double x7 = pow(x2, -3.0/2.0);
    double x8 = (-x4 >= 0. ? 1. : 0.);
    double x9 = x7*x8;
    double x10 = 40.14405*T - 200.72024999999999;
    double x11 = pow(x1, -2);
    double x12 = x11*x5;
    double x13 = x8/pow(x2, 5.0/2.0);
    double x14 = x7*0;
    double x15 = fmin(4, x3);
    double x16 = ((x15)*(x15));

result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
if (T >= 5.0) {
   result[1] = x0;
}
else {
   result[1] = x0 - 0.00099999999999999959*x10*x12 - 0.0009999999999999998*x10*x13 + 0.00033333333333333327*x10*x14 + 0.40144049999999992*x11*x15*((x8)*(x8)) - 0.20072024999999996*x12*x16 - 0.20072024999999999*x13*x16 + 0.066906749999999987*x14*x16 + x15*x6*x9 - 0.13381349999999997*x7*((x8)*(x8)*(x8)) - 0.40144049999999992*x9 + x6/x1;
}
result[2] = 1.0*(*endmember[2].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P) + n3*(*endmember[2].d3mu0dT2dP)(T, P));
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P) + n3*(*endmember[2].d3mu0dTdP2)(T, P));
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P) + n3*(*endmember[2].d3mu0dP3)(T, P));
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_s(double T, double P, double n[3]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[3]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[3]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[3]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[3]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[3]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

