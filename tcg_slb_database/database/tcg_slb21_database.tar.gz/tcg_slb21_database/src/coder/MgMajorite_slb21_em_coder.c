
static char *identifier = "MgMajorite_slb21_em.emml:06d5c2957f2fad8c81933d20beb5c1eac7f1ed85:Fri Oct 25 20:52:45 2024";



#include <math.h>
#include "coder_error.h"

#include <float.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

static double chebvalat(double x) {
    double c[17] = {
        2.707737068327440945 / 2.0, 0.340068135211091751, -0.12945150184440869e-01, 0.7963755380173816e-03,
        -0.546360009590824e-04, 0.39243019598805e-05, -0.2894032823539e-06, 0.217317613962e-07, -0.16542099950e-08,
        0.1272796189e-09, -0.987963460e-11, 0.7725074e-12, -0.607797e-13, 0.48076e-14, -0.3820e-15, 0.305e-16, -0.24e-17
    };
    double x2 = 2 * x;
    double c0 = c[17-2];
    double c1 = c[17-1];
    for (int i=3; i<18; i++) {
        double tmp = c0;
        c0 = c[17-i] - c1;
        c1 = tmp + c1 * x2;
    }
    return c0 + c1 * x;
}

static double Debye(double x) {
    //
    // returns D_3(x) = 3/x^3\int_0^x t^3/(e^t - 1) dt
    //
    
    double val_infinity = 19.4818182068004875;
    double sqrt_eps = sqrt(DBL_EPSILON);
    double log_eps = log(DBL_EPSILON);
    double xcut = -log_eps;

    //Check for negative x (was returning zero)
    assert(x >= 0.);

    if (x < (2.0*sqrt(2.0)*sqrt_eps)) return 1.0 - 3.0*x/8.0 + x*x/20.0;
    else if (x <= 4.0) {
        double t = x*x/8.0 - 1.0;
        double c = chebvalat(t);
        return c - 0.375*x;
    } else if (x < -(log(2.0)+log_eps)) {
        int nexp = (int)(floor(xcut / x));
        double ex = exp(-x);
        double xk = nexp * x;
        double rk = nexp;
        double sum = 0.0;
        for (int i=nexp; i>0; i--) {
            double xk_inv = 1.0/xk;
            sum *= ex;
            sum += (((6.0*xk_inv + 6.0)*xk_inv + 3.0)*xk_inv + 1.0)/rk;
            rk -= 1.0;
            xk -= x;
        }
        return val_infinity / (x * x * x) - 3.0 * sum * ex;
    } else if (x < xcut) {
        double x3 = x*x*x;
        double sum = 6.0 + 6.0*x + 3.0*x*x + x3;
        return (val_infinity - 3.0*sum*exp(-x))/x3;
    } else return ((val_infinity/x)/x)/x;
}

double born_B(double t, double p);
double born_Q(double t, double p);
double born_N(double t, double p);
double born_U(double t, double p);
double born_Y(double t, double p);
double born_X(double t, double p);
double born_dUdT(double t, double p);
double born_dUdP(double t, double p);
double born_dNdT(double t, double p);
double born_dNdP(double t, double p);
double born_dXdT(double t, double p);
double gSolvent(double t, double p);
double DgSolventDt(double t, double p);
double DgSolventDp(double t, double p);
double D2gSolventDt2(double t, double p);
double D2gSolventDtDp(double t, double p);
double D2gSolventDp2(double t, double p);
double D3gSolventDt3(double t, double p);
double D3gSolventDt2Dp(double t, double p);
double D3gSolventDtDp2(double t, double p);
double D3gSolventDp3(double t, double p);
double D4gSolventDt4(double t, double p);

static double coder_a(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/V;
    double x1 = pow(x0, 2.0/3.0);
    double x2 = pow(x0, 4.0/3.0);
    double x3 = sqrt(x1 - 0.68972315711456977*x2 - 0.12130379631843027);
    double x4 = 12.389835589913426*x3;
    double x5 = 3716.9506769740274*x3/T;

    result += 498.86775708919441*T*log(1 - exp(-x5)) - 166.2892523630648*T*Debye(x5) - 181301791.31923044*x1 + 373148702.01547533*x2 - 149660.32712675832*log(1 - exp(-x4)) + 49886.775708919442*Debye(x4) + 13294048.561349172 + 293979887.61160558/((V)*(V));
    return result;
}

static double coder_dadt(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/V;
    double x1 = sqrt(-0.68972315711456977*pow(x0, 4.0/3.0) + pow(x0, 2.0/3.0) - 0.12130379631843027);
    double x2 = x1/T;
    double x3 = 3716.9506769740274*x2;
    double x4 = Debye(x3);
    double x5 = exp(-x3);
    double x6 = 1 - x5;

    result += -1854266.8474331959*x2*x5/x6 + 618088.94914439856*x2*(-0.00080711321207046593*T*x4/x1 + 3/(exp(x3) - 1)) - 166.2892523630648*x4 + 498.86775708919441*log(x6);
    return result;
}

static double coder_dadv(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/V;
    double x1 = pow(x0, 2.0/3.0);
    double x2 = pow(x0, 4.0/3.0);
    double x3 = x0*x2;
    double x4 = sqrt(x1 - 0.68972315711456977*x2 - 0.12130379631843027);
    double x5 = 12.389835589913426*x4;
    double x6 = exp(-x5);
    double x7 = 1.0/x4;
    double x8 = -1.0/3.0*x0*x1 + 0.45981543807637981*x3;
    double x9 = x7*x8;
    double x10 = 3716.9506769740274*x4/T;
    double x11 = exp(-x10);

    result += 120867860.87948695*x0*x1 + 1854266.8474331959*x11*x7*x8/(1 - x11) - 497531602.68730044*x3 - 1854266.8474331959*x6*x9/(1 - x6) + 618088.94914439868*x7*x8*(-0.24213396362113973*x7*Debye(x5) + 3/(exp(x5) - 1)) - 618088.94914439856*x9*(-0.00080711321207046593*T*x7*Debye(x10) + 3/(exp(x10) - 1)) - 587959775.22321117/((V)*(V)*(V));
    return result;
}

static double coder_d2adt2(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = 1.0/V;
    double x2 = pow(x1, 4.0/3.0);
    double x3 = pow(x1, 2.0/3.0);
    double x4 = sqrt(-0.68972315711456977*x2 + x3 - 0.12130379631843027);
    double x5 = x0*x4;
    double x6 = 3716.9506769740274*x5;
    double x7 = exp(-x6);
    double x8 = 1 - x7;
    double x9 = pow(T, -2);
    double x10 = x9*(4753722643.9288387*x2 - 6892218413.8573132*x3 + 836052258.65668213);
    double x11 = Debye(x6)/x4;
    double x12 = exp(x6);
    double x13 = x12 - 1;

    result += x0*(x10*x7/x8 + x10*exp(-7433.9013539480547*x5)/((x8)*(x8)) - 618088.94914439856*x4*(x0*(0.0024213396362113976*T*x11 - 9.0/x13) + 0.00080711321207046593*x11 - 11150.852030922082*x12*x4*x9/((x13)*(x13))));
    return result;
}

static double coder_d2adtdv(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = 1.0/V;
    double x2 = pow(x1, 2.0/3.0);
    double x3 = 0.68972315711456977*pow(x1, 4.0/3.0) - x2 + 0.12130379631843027;
    double x4 = -x3;
    double x5 = sqrt(x4);
    double x6 = x0*x5;
    double x7 = 3716.9506769740274*x6;
    double x8 = exp(-x7);
    double x9 = 1 - x8;
    double x10 = 2297406137.9524374*x0;
    double x11 = T*Debye(x7);
    double x12 = 1.0/x5;
    double x13 = exp(x7);
    double x14 = x13 - 1;

    result += x0*x1*x2*(1.3794463142291393*x2 - 1)*(x10*x8/x9 + x10*exp(-7433.9013539480547*x6)/((x9)*(x9)) - 618088.94914439856*x5*(3716.9506769740274*x0*x12*x13/((x14)*(x14)) - 0.00026903773735682194*x11/pow(x4, 3.0/2.0) + (0.00080711321207046593*x11*x12 - 3/x14)/x3));
    return result;
}

static double coder_d2adv2(double T, double V) {
    double result = 0.0;
    double x0 = pow(V, -2);
    double x1 = 1.0/V;
    double x2 = pow(x1, 2.0/3.0);
    double x3 = pow(x1, 4.0/3.0);
    double x4 = -x2 + 0.68972315711456977*x3 + 0.12130379631843027;
    double x5 = -x4;
    double x6 = sqrt(x5);
    double x7 = 12.389835589913426*x6;
    double x8 = exp(-x7);
    double x9 = 1 - x8;
    double x10 = x8/x9;
    double x11 = pow(x5, -3.0/2.0);
    double x12 = x3*((x2 - 0.72492853812786384)*(x2 - 0.72492853812786384));
    double x13 = x11*x12;
    double x14 = 392048.07918718207*x13;
    double x15 = 1.0/x6;
    double x16 = x15*x2*(9.6561241996039744*x2 - 5);
    double x17 = 206029.64971479954*x16;
    double x18 = 1.0/x4;
    double x19 = x12*x18;
    double x20 = 4857411.2444705451*x19;
    double x21 = 1.0/T;
    double x22 = x21*x6;
    double x23 = 3716.9506769740274*x22;
    double x24 = exp(-x23);
    double x25 = 1 - x24;
    double x26 = x24/x25;
    double x27 = 1457223373.3411634*x19*x21;
    double x28 = exp(x7);
    double x29 = x28 - 1;
    double x30 = Debye(x7);
    double x31 = 0.24213396362113973*x15*x30 - 3/x29;
    double x32 = exp(x23);
    double x33 = x32 - 1;
    double x34 = T*Debye(x23);
    double x35 = 0.00080711321207046593*x15*x34 - 3/x33;
    double x36 = x15*x3*((x2 - 0.72492853812786395)*(x2 - 0.72492853812786395));

    result += x0*(1763879325.6696334*x0 + x10*x14 + x10*x17 - x10*x20 + 130682.69306239403*x13*x31 - 130682.693062394*x13*x35 - x14*x26 + 68676.549904933185*x16*x31 - 68676.54990493317*x16*x35 - x17*x26 - 201446434.79914492*x2 - x20*exp(-24.779671179826853*x6)/((x9)*(x9)) + x26*x27 + 1160907072.9370344*x3 - 392048.07918718195*x36*(-0.080711321207046577*x11*x30 + 12.389835589913426*x15*x28/((x29)*(x29)) + x18*x31) + 392048.07918718189*x36*(-0.00026903773735682194*x11*x34 + 3716.9506769740274*x15*x21*x32/((x33)*(x33)) + x18*x35) + x27*exp(-7433.9013539480547*x22)/((x25)*(x25)));
    return result;
}

static double coder_d3adt3(double T, double V) {
    double result = 0.0;
    double x0 = pow(T, -2);
    double x1 = 1.0/V;
    double x2 = pow(x1, 2.0/3.0);
    double x3 = pow(x1, 4.0/3.0);
    double x4 = x0*(-20676655241.571938*x2 + 14261167931.786514*x3 + 2508156775.970046);
    double x5 = 1.0/T;
    double x6 = -x2 + 0.68972315711456977*x3 + 0.12130379631843027;
    double x7 = -x6;
    double x8 = sqrt(x7);
    double x9 = x5*x8;
    double x10 = 3716.9506769740274*x9;
    double x11 = exp(-x10);
    double x12 = 1 - x11;
    double x13 = 7433.9013539480547*x9;
    double x14 = exp(-x13)/((x12)*(x12));
    double x15 = x11/x12;
    double x16 = pow(T, -3);
    double x17 = x16*pow(x7, 3.0/2.0);
    double x18 = Debye(x10)/x8;
    double x19 = exp(x10);
    double x20 = x19 - 1;
    double x21 = x19/((x20)*(x20));
    double x22 = x0*x21*x8;
    double x23 = 0.0024213396362113976*x18;
    double x24 = x5*(T*x23 - 9.0/x20);
    double x25 = x16*x6;

    result += x0*(-76854107697719.391*x14*x17 - x14*x4 - 25618035899239.797*x15*x17 - x15*x4 + 618088.94914439856*x8*(0.00080711321207046593*x18 - 11150.852030922082*x22 + x24) - 618088.94914439856*x8*(-41447167.005173042*x21*x25 - 11150.85203092208*x22 + x23 + 3.0*x24 + 82894334.010346085*x25*exp(x13)/((x20)*(x20)*(x20))) - 51236071798479.594*x17*exp(-11150.852030922082*x9)/((x12)*(x12)*(x12)));
    return result;
}

static double coder_d3adt2dv(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = 1.0/V;
    double x2 = pow(x1, 2.0/3.0);
    double x3 = pow(T, -2);
    double x4 = x3*(6338296858.5717831*x2 - 4594812275.9048748);
    double x5 = 0.68972315711456977*pow(x1, 4.0/3.0) - x2 + 0.12130379631843027;
    double x6 = -x5;
    double x7 = sqrt(x6);
    double x8 = x0*x7;
    double x9 = 3716.9506769740274*x8;
    double x10 = exp(-x9);
    double x11 = 1 - x10;
    double x12 = 7433.9013539480547*x8;
    double x13 = exp(-x12)/((x11)*(x11));
    double x14 = x10/x11;
    double x15 = pow(T, -3);
    double x16 = 1.3794463142291393*x2 - 1;
    double x17 = x16*x7;
    double x18 = x15*x17;
    double x19 = 1.0/x7;
    double x20 = Debye(x9);
    double x21 = x19*x20;
    double x22 = 0.00080711321207046593*x21;
    double x23 = exp(x9);
    double x24 = x23 - 1;
    double x25 = x23/((x24)*(x24));
    double x26 = 1.0/x24;
    double x27 = x20/pow(x6, 3.0/2.0);
    double x28 = x19*x25;
    double x29 = 1.0/x5;
    double x30 = T*x22;

    result += x0*x1*x2*(25618035899239.797*x13*x18 - x13*x4 + 8539345299746.5986*x14*x18 - x14*x4 - 206029.64971479951*x16*x19*(x0*(0.0024213396362113976*T*x21 - 9.0*x26) + x22 - 11150.852030922082*x25*x3*x7) + 618088.94914439856*x17*(-x0*x29*(-3.0*x26 + x30) - x0*(-0.00080711321207046583*T*x27 + 11150.852030922082*x0*x28 + 3.0*x29*(-3*x26 + x30)) + 13815722.33505768*x15*x25 - 27631444.670115359*x15*exp(x12)/((x24)*(x24)*(x24)) + 0.00026903773735682194*x27 + 3716.9506769740274*x28*x3) + 17078690599493.197*x18*exp(-11150.852030922082*x8)/((x11)*(x11)*(x11)));
    return result;
}

static double coder_d3adtdv2(double T, double V) {
    double result = 0.0;
    double x0 = 1.0/T;
    double x1 = 1.0/V;
    double x2 = pow(x1, 2.0/3.0);
    double x3 = x0*(7394679668.3337469*x2 - 3829010229.9207296);
    double x4 = 0.68972315711456977*pow(x1, 4.0/3.0) - x2 + 0.12130379631843027;
    double x5 = -x4;
    double x6 = sqrt(x5);
    double x7 = x0*x6;
    double x8 = 3716.9506769740274*x7;
    double x9 = exp(-x8);
    double x10 = 1 - x9;
    double x11 = 7433.9013539480547*x7;
    double x12 = exp(-x11)/((x10)*(x10));
    double x13 = x9/x10;
    double x14 = 1.0/x6;
    double x15 = ((x2 - 0.72492853812786384)*(x2 - 0.72492853812786384));
    double x16 = x15*x2;
    double x17 = x16/((T)*(T));
    double x18 = x14*x17;
    double x19 = pow(x5, -3.0/2.0);
    double x20 = T*Debye(x8);
    double x21 = x19*x20;
    double x22 = exp(x8);
    double x23 = x22 - 1;
    double x24 = x22/((x23)*(x23));
    double x25 = x0*x14*x24;
    double x26 = 1.0/x4;
    double x27 = 0.00080711321207046593*x14*x20 - 3/x23;
    double x28 = x26*x27;
    double x29 = x2*((x2 - 0.72492853812786395)*(x2 - 0.72492853812786395));
    double x30 = x29*(-0.00026903773735682194*x21 + 3716.9506769740274*x25 + x28);
    double x31 = 9.6561241996039744*x2 - 5;
    double x32 = x0*x2;
    double x33 = x17*x26;
    double x34 = x27/((x4)*(x4));

    result += -x32*(16249282212128.439*x12*x18 + x12*x3 + 5416427404042.8135*x13*x18 + x13*x3 + 392048.07918718189*x14*x30 + 618088.94914439856*x6*(-2357.6272886909765*x15*x19*x24*x32 + 0.63429071128011927*x16*x34 + 0.33333333333333331*x2*x34*(1.3794463142291393*x2 - 1)*(2.7588926284582787*x2 - 2) + 0.00051194441336775741*x20*x29/pow(x5, 5.0/2.0) + 8.9679245785607327e-5*x21*x31 - 8763184.3467523661*x24*x33 - 1238.9835589913423*x25*x31 + 1.9028721338403574*x26*x30 - 0.33333333333333331*x28*x31 + 17526368.693504732*x33*exp(x11)/((x23)*(x23)*(x23))) + 10832854808085.627*x18*exp(-11150.852030922082*x7)/((x10)*(x10)*(x10)))/((V)*(V));
    return result;
}

static double coder_d3adv3(double T, double V) {
    double result = 0.0;
    double x0 = pow(V, -2);
    double x1 = 1.0/V;
    double x2 = pow(x1, 2.0/3.0);
    double x3 = pow(x1, 4.0/3.0);
    double x4 = -x2 + 0.68972315711456977*x3 + 0.12130379631843027;
    double x5 = -x4;
    double x6 = sqrt(x5);
    double x7 = 1.0/x6;
    double x8 = 96.56124199603974*x2 - 40;
    double x9 = x7*x8;
    double x10 = 12.389835589913426*x6;
    double x11 = exp(-x10);
    double x12 = 1 - x11;
    double x13 = 1.0/x12;
    double x14 = x11*x13;
    double x15 = 1.0/T;
    double x16 = x15*x6;
    double x17 = 3716.9506769740274*x16;
    double x18 = exp(-x17);
    double x19 = 1 - x18;
    double x20 = 1.0/x19;
    double x21 = pow(x5, -3.0/2.0);
    double x22 = 1.3794463142291393*x2 - 1;
    double x23 = x2 - 0.72492853812786384;
    double x24 = ((x23)*(x23));
    double x25 = x0*x24;
    double x26 = x22*x25;
    double x27 = x21*x26;
    double x28 = pow(x12, -2);
    double x29 = 24.779671179826853*x6;
    double x30 = exp(-x29);
    double x31 = x28*x30;
    double x32 = pow(x5, -5.0/2.0);
    double x33 = x26*x32;
    double x34 = pow(x4, -2);
    double x35 = 1619137.0814901816*x34;
    double x36 = x31*x35;
    double x37 = 2.7588926284582787*x2 - 2;
    double x38 = x25*x37;
    double x39 = x14*x35;
    double x40 = 14*x2 - 7.2492853812786375;
    double x41 = 1.0/x4;
    double x42 = 9.6561241996039744*x2 - 5;
    double x43 = x22*x3;
    double x44 = x42*x43;
    double x45 = x21*x44;
    double x46 = pow(T, -2);
    double x47 = 7433.9013539480547*x16;
    double x48 = exp(-x47);
    double x49 = pow(x19, -2);
    double x50 = exp(x10);
    double x51 = x50 - 1;
    double x52 = Debye(x10);
    double x53 = 0.24213396362113973*x52*x7 - 3/x51;
    double x54 = x2*x53;
    double x55 = x15*x41*x48*x49;
    double x56 = 485741124.44705445*x23*x3*x40;
    double x57 = x15*x18*x20*x41;
    double x58 = 255267348.66138196*x44;
    double x59 = exp(x17);
    double x60 = x59 - 1;
    double x61 = T*Debye(x17);
    double x62 = 0.00080711321207046593*x61*x7 - 3/x60;
    double x63 = x21*x52;
    double x64 = x50/((x51)*(x51));
    double x65 = x64*x7;
    double x66 = x41*x53;
    double x67 = -0.080711321207046577*x63 + 12.389835589913426*x65 + x66;
    double x68 = x21*x61;
    double x69 = x59/((x60)*(x60));
    double x70 = x15*x69;
    double x71 = x7*x70;
    double x72 = x41*x62;
    double x73 = -0.00026903773735682194*x68 + 3716.9506769740274*x71 + x72;
    double x74 = x43*x7;
    double x75 = x2*((x2 - 0.72492853812786395)*(x2 - 0.72492853812786395));
    double x76 = x32*x75;
    double x77 = x2*x24;
    double x78 = x21*x77;
    double x79 = x41*x77;
    double x80 = 0.33333333333333331*x42;
    double x81 = 0.63429071128011927*x24;
    double x82 = x34*x54;
    double x83 = 0.33333333333333331*x22*x37;
    double x84 = 1.9028721338403574*x41*x75;
    double x85 = x46*x79;
    double x86 = x2*x34*x62;

    result += (485741124.44705445*x0*x15*x18*x20*x22*x24*x34 + 485741124.44705445*x0*x15*x18*x20*x24*x34*x37 + 485741124.44705445*x0*x15*x22*x24*x34*x48*x49 + 485741124.44705445*x0*x15*x24*x34*x37*x48*x49 + 1805475801347.6045*x0*x18*x20*x21*x22*x24*x46 + 392048.07918718207*x0*x18*x20*x22*x24*x32 + 5416427404042.8135*x0*x21*x22*x24*x46*x48*x49 + 261365.38612478806*x0*x21*x22*x24*x67 + 130682.693062394*x0*x22*x24*x32*x62 - 7055517302.6785336*x0 + 3610951602695.209*x0*x21*x22*x24*x46*exp(-11150.852030922082*x16)/((x19)*(x19)*(x19)) + 850891.16220460657*x11*x13*x22*x3*x41*x42 + 1619137.0814901816*x11*x13*x23*x3*x40*x41 - 68676.549904933185*x14*x2*x9 - 20060842.237195607*x14*x27 - 392048.07918718207*x14*x33 - 206029.64971479951*x14*x45 + 68676.549904933185*x18*x2*x20*x7*x8 + 206029.64971479951*x18*x20*x21*x22*x3*x42 + 22892.183301644389*x2*x62*x7*x8 + 537190492.79771972*x2 + 68676.54990493317*x21*x22*x3*x42*x62 + 850891.16220460657*x22*x28*x3*x30*x41*x42 + 137353.09980986637*x22*x3*x42*x67*x7 + 206029.64971479951*x22*x3*x7*(8.9679245785607327e-5*x42*x68 - 1238.9835589913423*x42*x71 + 0.00051194441336775741*x61*x76 - 8763184.3467523661*x69*x85 - 2357.6272886909765*x70*x78 - x72*x80 + x73*x84 + x81*x86 + x83*x86 + 17526368.693504732*x85*exp(x47)/((x60)*(x60)*(x60))) + 1619137.0814901816*x23*x28*x3*x30*x40*x41 - x26*x36 - x26*x39 - 60182526.711586833*x27*x31 - 261365.386124788*x27*x73 - 3869690243.1234479*x3 - 130682.69306239403*x33*x53 - x36*x38 - x38*x39 - 137353.09980986634*x42*x73*x74 - 68676.549904933185*x45*x53 - 22892.183301644392*x54*x9 - x55*x56 - x55*x58 - x56*x57 - x57*x58 - 206029.64971479954*x74*(0.026903773735682191*x42*x63 - 4.1299451966378085*x42*x65 + 0.1535833240103272*x52*x76 - 7.858757628969923*x64*x78 - 97.36871496391521*x64*x79 - x66*x80 + x67*x84 + x81*x82 + x82*x83 + 194.73742992783042*x79*exp(x29)/((x51)*(x51)*(x51))) - 40121684.474391222*x27*exp(-37.169506769740281*x6)/((x12)*(x12)*(x12)))/((V)*(V)*(V));
    return result;
}


static const double tol = 0.001;
static const int MAX_ITS = 200;
static double Told = 0.0;
static double Pold = 0.0;
static const double Vmin = 0.5*11.4324;
static const double Vmax = 1.15*11.4324;
static double V = 0.9*11.4324;

static void coder_solve_V(double T, double P) {
    // Newtsafe routine, newton + bisection with bracket check
    // Update if *either* T or P changes (was only if both changed)
    if ((T != Told) || (P != Pold)) {
        // check bracket
        double fa = -coder_dadv(T, Vmin) - P;
        double fb = -coder_dadv(T, Vmax) - P;
        if ( isnan(fa) ) {
            fprintf(stderr, "Error: lower bracket isnan for Vmin=%g\n",Vmin);
            coder_error_flag = CODER_ERR_NAN;
            return;
        }
        if ( isnan(fb) ) {
            fprintf(stderr, "Error: upper bracket isnan for Vmax=%g\n",Vmax);
            coder_error_flag = CODER_ERR_NAN;
            return;
        }
        if ( fa*fb > 0.) 
        {
            fprintf(stderr, "Error: improper  initial bracket in solve_V\n");
            coder_error_flag = CODER_ERR_BOUNDS;
            return;
        }
        //set up bisection parameters
        double a = Vmin;
        double b = Vmax;
        double c = 0.;
        double fc = 0.;
        Told = T;
        Pold = P;
        //start Newton step
        double f = 0.0;
        int iter = 0;
        do {
            //newton step
            f = -coder_dadv(T, V) - P;
            double df = -coder_d2adv2(T, V);
            V -= f/df;
            if (V < a || V > b || df == 0. || isnan(V) ) {
                //take a bisection step
                c = 0.5*(a + b);
                fc = -coder_dadv(T, c) - P;
                if ( fa*fc < 0 ) { // left bracket
                    b = c;
                    fb = fc;
                }
                else if ( fb*fc < 0 ) { //right bracket
                    a = c;
                    fa = fc;
                }
                //reset V to middle of new bracket and clear f
                V = 0.5*( a + b);
                f = 1.;
            }
            iter++;
        } while ((fabs(f) > tol) && (iter < MAX_ITS));
        if ( iter == MAX_ITS) {
            fprintf(stderr, "Error: max iterations exceeded in solve_V\n");
            coder_error_flag = CODER_ERR_MAXITS;
            return;
        }
    }
}

static double coder_g(double T, double P) {
    coder_solve_V(T, P);
    double A = coder_a(T, V);
    return A + P*V;
}

static double coder_dgdt(double T, double P) {
    coder_solve_V(T, P);
    double dAdT = coder_dadt(T, V);
    return dAdT;
}

static double coder_dgdp(double T, double P) {
    coder_solve_V(T, P);
    return V;
}

static double coder_d2gdt2(double T, double P) {
    coder_solve_V(T, P);
    double d2AdT2 = coder_d2adt2(T, V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    return d2AdT2 - d2AdTdV*d2AdTdV/d2AdV2;
}

static double coder_d2gdtdp(double T, double P) {
    coder_solve_V(T, P);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    return - d2AdTdV/d2AdV2;
}

static double coder_d2gdp2(double T, double P) {
    coder_solve_V(T, P);
    double d2AdV2 = coder_d2adv2(T, V);
    return - 1.0/d2AdV2;
}

static double coder_d3gdt3(double T, double P) {
    coder_solve_V(T, P);
    double d3AdT3 = coder_d3adt3(T, V);
    double d3AdT2dV = coder_d3adt2dv(T, V);
    double d3AdTdV2 = coder_d3adtdv2(T, V);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double dVdT = -d2AdTdV/d2AdV2;
    double d2VdT2 = (-d3AdT2dV - 2.0*d3AdTdV2*dVdT - d3AdV3*dVdT*dVdT)/d2AdV2;
    return d3AdT3 + 2.0*d3AdT2dV*dVdT + d3AdTdV2*dVdT*dVdT + d2AdTdV*d2VdT2;
}

static double coder_d3gdt2dp(double T, double P) {
    coder_solve_V(T, P);
    double d3AdT2dV = coder_d3adt2dv(T, V);
    double d3AdTdV2 = coder_d3adtdv2(T, V);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double dVdT = -d2AdTdV/d2AdV2;
    double dVdP = -1.0/d2AdV2;
    double d2VdTdP = (-d3AdTdV2*dVdP - d3AdV3*dVdT*dVdP)/d2AdV2;
    return d3AdT2dV*dVdP + d3AdTdV2*dVdT*dVdP + d2AdTdV*d2VdTdP;
}

static double coder_d3gdtdp2(double T, double P) {
    coder_solve_V(T, P);
    double d3AdTdV2 = coder_d3adtdv2(T, V);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double dVdT = -d2AdTdV/d2AdV2;
    return (d3AdTdV2 + d3AdV3*dVdT)/d2AdV2/d2AdV2;
}

static double coder_d3gdp3(double T, double P) {
    coder_solve_V(T, P);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdV2 = coder_d2adv2(T, V);
    double dVdP = -1.0/d2AdV2;
    return d3AdV3*dVdP/d2AdV2/d2AdV2;
}

static double coder_s(double T, double P) {
    double result = -coder_dgdt(T, P);
    return result;
}

static double coder_dsdt(double T, double P) {
    double result = -coder_d2gdt2(T, P);
    return result;
}

static double coder_dsdp(double T, double P) {
    double result = -coder_d2gdtdp(T, P);
    return result;
}

static double coder_v(double T, double P) {
    double result = coder_dgdp(T, P);
    return result;
}

static double coder_cv(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    double dvdt = coder_d2gdtdp(T, P);
    double dvdp = coder_d2gdp2(T, P);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P) {
    double result = -T*coder_d2gdt2(T, P);
    return result;
}

static double coder_dcpdt(double T, double P) {
    double result = -T*coder_d3gdt3(T, P) - coder_d2gdt2(T, P);
    return result;
}

static double coder_dcpdp(double T, double P) {
    double result = -T*coder_d3gdt2dp(T, P);
    return result;
}

static double coder_alpha(double T, double P) {
    double result = coder_d2gdtdp(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_dalphadt(double T, double P) {
    double dgdp = coder_dgdp(T, P);
    double d2gdtdp = coder_d2gdtdp(T, P);
    double result = coder_d3gdt2dp(T, P)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P) {
    double dgdp = coder_dgdp(T, P);
    double result = coder_d3gdtdp2(T, P)/dgdp - coder_d2gdp2(T, P)*coder_d2gdtdp(T, P)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P) {
    double result = -coder_d2gdp2(T, P)/coder_dgdp(T, P);
    return result;
}

static double coder_K(double T, double P) {
    double result = -coder_dgdp(T, P)/coder_d2gdp2(T, P);
    return result;
}

static double coder_Kp(double T, double P) {
    double result = coder_dgdp(T, P);
    result *= coder_d3gdp3(T, P);
    result /= pow(coder_d2gdp2(T, P), 2.0);
    return result - 1.0;
}


#include <math.h>

static double coder_dparam_a(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dadt(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_dadv(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2adt2(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2adtdv(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d2adv2(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3adt3(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3adt2dv(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3adtdv2(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}

static double coder_dparam_d3adv3(double T, double V, int index) {
    double result = 0.0;
    switch (index) {
    }
    return result;
}


static double coder_dparam_g(double T, double P, int index) {
    coder_solve_V(T, P);
    double dAdz = coder_dparam_a(T, V, index);
    return dAdz + P*V;
}

static double coder_dparam_dgdt(double T, double P, int index) {
    coder_solve_V(T, P);
    double dAdTdz = coder_dparam_dadt(T, V, index);
    return dAdTdz;
}

static double coder_dparam_dgdp(double T, double P, int index) {
    coder_solve_V(T, P);
    return 0.0; /* V; */
}

static double coder_dparam_d2gdt2(double T, double P, int index) {
    coder_solve_V(T, P);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double d2AdT2dz = coder_dparam_d2adt2(T, V, index);
    double d2AdTdVdz = coder_dparam_d2adtdv(T, V, index);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    /* return d2AdT2 - d2AdTdV*d2AdTdV/d2AdV2; */
    return d2AdT2dz - 2.0*d2AdTdV*d2AdTdVdz/d2AdV2 + d2AdTdV*d2AdTdV*d2AdV2dz/d2AdV2/d2AdV2;
}

static double coder_dparam_d2gdtdp(double T, double P, int index) {
    coder_solve_V(T, P);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double d2AdTdVdz = coder_dparam_d2adtdv(T, V, index);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    /* return - d2AdTdV/d2AdV2; */
    return - d2AdTdVdz/d2AdV2 + d2AdTdV*d2AdV2dz/d2AdV2/d2AdV2;
}

static double coder_dparam_d2gdp2(double T, double P, int index) {
    coder_solve_V(T, P);
    double d2AdV2 = coder_d2adv2(T, V);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    /* return - 1.0/d2AdV2; */
    return d2AdV2dz/d2AdV2/d2AdV2;
}

static double coder_dparam_d3gdt3(double T, double P, int index) {
    coder_solve_V(T, P);
    double d3AdT2dV = coder_d3adt2dv(T, V);
    double d3AdTdV2 = coder_d3adtdv2(T, V);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double d3AdT3dz = coder_dparam_d3adt3(T, V, index);
    double d3AdT2dVdz = coder_dparam_d3adt2dv(T, V, index);
    double d3AdTdV2dz = coder_dparam_d3adtdv2(T, V, index);
    double d3AdV3dz = coder_dparam_d3adv3(T, V, index);
    double d2AdTdVdz = coder_dparam_d2adtdv(T, V, index);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    double dVdT = - d2AdTdV/d2AdV2;
    double dVdTdz = - d2AdTdVdz/d2AdV2 + d2AdTdV*d2AdV2dz/d2AdV2/d2AdV2;
    double d2VdT2 = (-d3AdT2dV - 2.0*d3AdTdV2*dVdT - d3AdV3*dVdT*dVdT)/d2AdV2;
    double d2VdT2dz = (-d3AdT2dVdz - 2.0*d3AdTdV2dz*dVdT - 2.0*d3AdTdV2*dVdTdz
                        - d3AdV3dz*dVdT*dVdT - 2.0*d3AdV3*dVdT*dVdTdz)/d2AdV2
                    - (-d3AdT2dV - 2.0*d3AdTdV2*dVdT - d3AdV3*dVdT*dVdT)*d2AdV2dz/d2AdV2/d2AdV2;
    /* return d3AdT3 + 2.0*d3AdT2dV*dVdT + d3AdTdV2*dVdT*dVdT + d2AdTdV*d2VdT2; */
    return d3AdT3dz + 2.0*d3AdT2dVdz*dVdT + 2.0*d3AdT2dV*dVdTdz + d3AdTdV2dz*dVdT*dVdT
            + 2.0*d3AdTdV2*dVdT*dVdTdz + d2AdTdVdz*d2VdT2 + d2AdTdV*d2VdT2dz;
}

static double coder_dparam_d3gdt2dp(double T, double P, int index) {
    coder_solve_V(T, P);
    double d3AdT2dV = coder_d3adt2dv(T, V);
    double d3AdTdV2 = coder_d3adtdv2(T, V);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double d3AdT2dVdz = coder_dparam_d3adt2dv(T, V, index);
    double d3AdTdV2dz = coder_dparam_d3adtdv2(T, V, index);
    double d3AdV3dz = coder_dparam_d3adv3(T,V, index);
    double d2AdTdVdz = coder_dparam_d2adtdv(T, V, index);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    double dVdT = -d2AdTdV/d2AdV2;
    double dVdTdz = - d2AdTdVdz/d2AdV2 + d2AdTdV*d2AdV2dz/d2AdV2/d2AdV2;
    double dVdP = -1.0/d2AdV2;
    double dVdPdz = d2AdV2dz/d2AdV2/d2AdV2;
    double d2VdTdP = (-d3AdTdV2*dVdP - d3AdV3*dVdT*dVdP)/d2AdV2;
    double d2VdTdPdz = (-d3AdTdV2dz*dVdP -d3AdTdV2*dVdPdz
            - d3AdV3dz*dVdT*dVdP - d3AdV3*dVdTdz*dVdP - d3AdV3*dVdT*dVdPdz)/d2AdV2
            - (-d3AdTdV2*dVdP - d3AdV3*dVdT*dVdP)*d2AdV2dz/d2AdV2/d2AdV2;
    /* return d3AdT2dV*dVdP + d3AdTdV2*dVdT*dVdP + d2AdTdV*d2VdTdP; */
    return d3AdT2dVdz*dVdP + d3AdT2dV*dVdPdz + d3AdTdV2dz*dVdT*dVdP + d3AdTdV2*dVdTdz*dVdP
        + d3AdTdV2*dVdT*dVdPdz + d2AdTdVdz*d2VdTdP + d2AdTdV*d2VdTdPdz;
}

static double coder_dparam_d3gdtdp2(double T, double P, int index) {
    coder_solve_V(T, P);
    double d3AdTdV2 = coder_d3adtdv2(T, V);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdTdV = coder_d2adtdv(T, V);
    double d2AdV2 = coder_d2adv2(T, V);
    double d3AdTdV2dz = coder_dparam_d3adtdv2(T, V, index);
    double d3AdV3dz = coder_dparam_d3adv3(T, V, index);
    double d2AdTdVdz = coder_dparam_d2adtdv(T, V, index);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    double dVdT = -d2AdTdV/d2AdV2;
    double dVdTdz = - d2AdTdVdz/d2AdV2 + d2AdTdV*d2AdV2dz/d2AdV2/d2AdV2;
    /* return (d3AdTdV2 + d3AdV3*dVdT)/d2AdV2/d2AdV2; */
    return (d3AdTdV2dz + d3AdV3dz*dVdT + d3AdV3*dVdTdz)/d2AdV2/d2AdV2
        - 2.0*(d3AdTdV2 + d3AdV3*dVdT)*d2AdV2dz/d2AdV2/d2AdV2/d2AdV2;
}

static double coder_dparam_d3gdp3(double T, double P, int index) {
    coder_solve_V(T, P);
    double d3AdV3 = coder_d3adv3(T,V);
    double d2AdV2 = coder_d2adv2(T, V);
    double d3AdV3dz = coder_dparam_d3adv3(T, V, index);
    double d2AdV2dz = coder_dparam_d2adv2(T, V, index);
    double dVdP = -1.0/d2AdV2;
    double dVdPdz = d2AdV2dz/d2AdV2/d2AdV2;
    /* return d3AdV3*dVdP/d2AdV2/d2AdV2; */
    return d3AdV3dz*dVdP/d2AdV2/d2AdV2 + d3AdV3*dVdPdz/d2AdV2/d2AdV2
        - 2.0*d3AdV3*dVdP*d2AdV2dz/d2AdV2/d2AdV2/d2AdV2;
}

static int coder_get_param_number(void) {
    return 0;
}

static const char *paramNames[0] = {  };

static const char *paramUnits[0] = {  };

static const char **coder_get_param_names(void) {
    return paramNames;
}

static const char **coder_get_param_units(void) {
    return paramUnits;
}

static void coder_get_param_values(double **values) {
}

static int coder_set_param_values(double *values) {
    return 1;
}

static double coder_get_param_value(int index) {
    double result = 0.0;
    switch (index) {
     default:
         break;
    }
    return result;
}

static int coder_set_param_value(int index, double value) {
    int result = 1;
    switch (index) {
     default:
         break;
    }
    return result;
}



const char *MgMajorite_slb21_em_coder_calib_identifier(void) {
    return identifier;
}

const char *MgMajorite_slb21_em_coder_calib_name(void) {
    return "MgMajorite_slb21_em";
}

const char *MgMajorite_slb21_em_coder_calib_formula(void) {
    return "Mg4Si4O12";
}

const double MgMajorite_slb21_em_coder_calib_mw(void) {
    return 401.5548;
}

static const double elmformula[106] = {
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,12.0,0.0,0.0,0.0,
        4.0,0.0,4.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0,0.0,0.0,
        0.0,0.0,0.0,0.0
    };

const double *MgMajorite_slb21_em_coder_calib_elements(void) {
    return elmformula;
}

double MgMajorite_slb21_em_coder_calib_g(double T, double P) {
    return coder_g(T, P);
}

double MgMajorite_slb21_em_coder_calib_dgdt(double T, double P) {
    return coder_dgdt(T, P);
}

double MgMajorite_slb21_em_coder_calib_dgdp(double T, double P) {
    return coder_dgdp(T, P);
}

double MgMajorite_slb21_em_coder_calib_d2gdt2(double T, double P) {
    return coder_d2gdt2(T, P);
}

double MgMajorite_slb21_em_coder_calib_d2gdtdp(double T, double P) {
    return coder_d2gdtdp(T, P);
}

double MgMajorite_slb21_em_coder_calib_d2gdp2(double T, double P) {
    return coder_d2gdp2(T, P);
}

double MgMajorite_slb21_em_coder_calib_d3gdt3(double T, double P) {
    return coder_d3gdt3(T, P);
}

double MgMajorite_slb21_em_coder_calib_d3gdt2dp(double T, double P) {
    return coder_d3gdt2dp(T, P);
}

double MgMajorite_slb21_em_coder_calib_d3gdtdp2(double T, double P) {
    return coder_d3gdtdp2(T, P);
}

double MgMajorite_slb21_em_coder_calib_d3gdp3(double T, double P) {
    return coder_d3gdp3(T, P);
}

double MgMajorite_slb21_em_coder_calib_s(double T, double P) {
    return coder_s(T, P);
}

double MgMajorite_slb21_em_coder_calib_dsdt(double T, double P) {
    return coder_dsdt(T, P);
}

double MgMajorite_slb21_em_coder_calib_dsdp(double T, double P) {
    return coder_dsdp(T, P);
}

double MgMajorite_slb21_em_coder_calib_v(double T, double P) {
    return coder_v(T, P);
}

double MgMajorite_slb21_em_coder_calib_cv(double T, double P) {
    return coder_cv(T, P);
}

double MgMajorite_slb21_em_coder_calib_cp(double T, double P) {
    return coder_cp(T, P);
}

double MgMajorite_slb21_em_coder_calib_dcpdt(double T, double P) {
    return coder_dcpdt(T, P);
}

double MgMajorite_slb21_em_coder_calib_dcpdp(double T, double P) {
    return coder_dcpdp(T, P);
}

double MgMajorite_slb21_em_coder_calib_alpha(double T, double P) {
    return coder_alpha(T, P);
}

double MgMajorite_slb21_em_coder_calib_dalphadt(double T, double P) {
    return coder_dalphadt(T, P);
}

double MgMajorite_slb21_em_coder_calib_dalphadp(double T, double P) {
    return coder_dalphadp(T, P);
}

double MgMajorite_slb21_em_coder_calib_beta(double T, double P) {
    return coder_beta(T, P);
}

double MgMajorite_slb21_em_coder_calib_K(double T, double P) {
    return coder_K(T, P);
}

double MgMajorite_slb21_em_coder_calib_Kp(double T, double P) {
    return coder_Kp(T, P);
}

int MgMajorite_slb21_em_coder_get_param_number(void) {
    return coder_get_param_number();
}

const char **MgMajorite_slb21_em_coder_get_param_names(void) {
    return coder_get_param_names();
}

const char **MgMajorite_slb21_em_coder_get_param_units(void) {
    return coder_get_param_units();
}

void MgMajorite_slb21_em_coder_get_param_values(double **values) {
    coder_get_param_values(values);
}

int MgMajorite_slb21_em_coder_set_param_values(double *values) {
    return coder_set_param_values(values);
}

double MgMajorite_slb21_em_coder_get_param_value(int index) {
    return coder_get_param_value(index);
}

int MgMajorite_slb21_em_coder_set_param_value(int index, double value) {
    return coder_set_param_value(index, value);
}

double MgMajorite_slb21_em_coder_dparam_g(double T, double P, int index) {
    return coder_dparam_g(T, P, index);
}

double MgMajorite_slb21_em_coder_dparam_dgdt(double T, double P, int index) {
    return coder_dparam_dgdt(T, P, index);
}

double MgMajorite_slb21_em_coder_dparam_dgdp(double T, double P, int index) {
    return coder_dparam_dgdp(T, P, index);
}

double MgMajorite_slb21_em_coder_dparam_d2gdt2(double T, double P, int index) {
    return coder_dparam_d2gdt2(T, P, index);
}

double MgMajorite_slb21_em_coder_dparam_d2gdtdp(double T, double P, int index) {
    return coder_dparam_d2gdtdp(T, P, index);
}

double MgMajorite_slb21_em_coder_dparam_d2gdp2(double T, double P, int index) {
    return coder_dparam_d2gdp2(T, P, index);
}

double MgMajorite_slb21_em_coder_dparam_d3gdt3(double T, double P, int index) {
    return coder_dparam_d3gdt3(T, P, index);
}

double MgMajorite_slb21_em_coder_dparam_d3gdt2dp(double T, double P, int index) {
    return coder_dparam_d3gdt2dp(T, P, index);
}

double MgMajorite_slb21_em_coder_dparam_d3gdtdp2(double T, double P, int index) {
    return coder_dparam_d3gdtdp2(T, P, index);
}

double MgMajorite_slb21_em_coder_dparam_d3gdp3(double T, double P, int index) {
    return coder_dparam_d3gdp3(T, P, index);
}

