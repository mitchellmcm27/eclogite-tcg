#include <math.h>


static double coder_g(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = 1.0*n2;
    double x1 = 1.0*n3;
    double x2 = 1.0*n5;
    double x3 = 1.0*n1 + x0 + x1 + x2;
    double x4 = 3.5*n4 + x3;
    double x5 = 444600.0*n3 + 728000.0*n4 + 437400.0*n5;
    double x6 = 0.027777777777777773*x5;
    double x7 = n3*(444600.0*n1 + 444600.0*n2 + 1682800.0*n4 + 828000.0*n5);
    double x8 = n4*(2369250.0*n1 + 2369250.0*n2 + 5476612.5*n3 + 911250.0*n5);
    double x9 = n5*(437400.0*n1 + 437400.0*n2 + 828000.0*n3 + 280000.0*n4);
    double x10 = n1*(*endmember[0].mu0)(T, P);
    double x11 = n2*(*endmember[1].mu0)(T, P);
    double x12 = n3*(*endmember[2].mu0)(T, P);
    double x13 = n4*(*endmember[3].mu0)(T, P);
    double x14 = n5*(*endmember[4].mu0)(T, P);
    double x15 = n1 + n3;
    double x16 = n4 + n5;
    double x17 = 1.0/(n2 + x15 + x16);
    double x18 = 1.0*n4;
    double x19 = n1 + n2 + n4;
    double x20 = T*(x0*log(n2*x17) + x1*log(n3*x17) + 1.0*x15*log(x15*x17) + 1.0*x16*log(x16*x17) + x18*(log(n4*x17) - 0.69314718055994495) + 1.0*x19*log(x17*x19) + x2*log(n5*x17) + (2.0*n1 + 2.0*n2 + 2.0*n3 + 2.0*n5 + x18)*log(x17*(0.5*n4 + x3)));
    double x21 = 0.083333333333333315*x5;
    double x22 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));

if (T >= 5.0) {
   result = (n1*x6 + n2*x6 + x4*(-n2*(13.381349999999999*T - 44.604500000000002) + x10 + x11 + x12 + x13 + x14 + 8.3144626181532395*x20) + 0.027777777777777773*x7 + 0.0085352842554488641*x8 + 0.027777777777777773*x9)/x4;
}
else {
   result = (n1*x21 + n2*x21 + x4*(n2*(66.906750000000002*((x22)*(x22)*(x22)) + (40.14405*T - 200.72024999999999)*(x22 - 1) - 66.906750000000002) + 3*x10 + 3*x11 + 3*x12 + 3*x13 + 3*x14 + 24.943387854459719*x20) + 0.083333333333333315*x7 + 0.025605852766346592*x8 + 0.083333333333333315*x9)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = pow(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5, -2);
    double x1 = 444600.0*n3 + 728000.0*n4 + 437400.0*n5;
    double x2 = 0.027777777777777773*x1;
    double x3 = n3*(444600.0*n1 + 444600.0*n2 + 1682800.0*n4 + 828000.0*n5);
    double x4 = n4*(2369250.0*n1 + 2369250.0*n2 + 5476612.5*n3 + 911250.0*n5);
    double x5 = n5*(437400.0*n1 + 437400.0*n2 + 828000.0*n3 + 280000.0*n4);
    double x6 = 3.5*n4;
    double x7 = 1.0*n1;
    double x8 = 1.0*n2;
    double x9 = 1.0*n3;
    double x10 = 1.0*n5;
    double x11 = x10 + x7 + x8 + x9;
    double x12 = x11 + x6;
    double x13 = (*endmember[0].mu0)(T, P);
    double x14 = n1*x13;
    double x15 = (*endmember[1].mu0)(T, P);
    double x16 = n2*x15;
    double x17 = (*endmember[2].mu0)(T, P);
    double x18 = n3*x17;
    double x19 = (*endmember[3].mu0)(T, P);
    double x20 = n4*x19;
    double x21 = (*endmember[4].mu0)(T, P);
    double x22 = n5*x21;
    double x23 = 13.381349999999999*T;
    double x24 = x23 - 44.604500000000002;
    double x25 = n2*x24;
    double x26 = n1 + n3;
    double x27 = n4 + n5;
    double x28 = n2 + x26 + x27;
    double x29 = 1.0/x28;
    double x30 = log(n2*x29);
    double x31 = log(n3*x29);
    double x32 = log(n5*x29);
    double x33 = log(n4*x29);
    double x34 = 1.0*n4;
    double x35 = x26*x29;
    double x36 = 1.0*log(x35);
    double x37 = 1.0*log(x27*x29);
    double x38 = n1 + n2 + n4;
    double x39 = x29*x38;
    double x40 = 1.0*log(x39);
    double x41 = 2.0*n1 + 2.0*n2 + 2.0*n3 + 2.0*n5 + x34;
    double x42 = 0.5*n4 + x11;
    double x43 = log(x29*x42);
    double x44 = x10*x32 + x26*x36 + x27*x37 + x30*x8 + x31*x9 + x34*(x33 - 0.69314718055994495) + x38*x40 + x41*x43;
    double x45 = 8.3144626181532395*T;
    double x46 = x44*x45;
    double x47 = x0*(n1*x2 + n2*x2 + x12*(x14 + x16 + x18 + x20 + x22 - x25 + x46) + 0.027777777777777773*x3 + 0.0085352842554488641*x4 + 0.027777777777777773*x5);
    double x48 = -0.081632653061224483*x47;
    double x49 = 1.0/x12;
    double x50 = 2.0*x43;
    double x51 = -x29*x8;
    double x52 = -x29*x9;
    double x53 = 1.0*x29;
    double x54 = -n4*x53;
    double x55 = pow(x28, -2);
    double x56 = x42*x55;
    double x57 = x28*x41/x42;
    double x58 = x57*(1.0*x29 - x56);
    double x59 = x50 + x51 + x52 + x54 + x58;
    double x60 = -x27*x53;
    double x61 = -x29;
    double x62 = 1.0*x28;
    double x63 = -x10*x29;
    double x64 = x40 + x62*(-x38*x55 - x61) + x63;
    double x65 = x60 + x64;
    double x66 = x36 + x62*(-x26*x55 - x61);
    double x67 = x59 + x65 + x66;
    double x68 = x10*x21 + x13*x7 + x15*x8 + x17*x9 + x19*x34 - x24*x8 + x46;
    double x69 = 24699.999999999996*n3 + 40444.444444444438*n4 + 24299.999999999996*n5 + x68;
    double x70 = T >= 5.0;
    double x71 = 0.083333333333333315*x1;
    double x72 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x73 = 66.906750000000002*((x72)*(x72)*(x72)) + (40.14405*T - 200.72024999999999)*(x72 - 1) - 66.906750000000002;
    double x74 = n2*x73;
    double x75 = 24.943387854459719*T;
    double x76 = x44*x75;
    double x77 = x0*(n1*x71 + n2*x71 + x12*(3*x14 + 3*x16 + 3*x18 + 3*x20 + 3*x22 + x74 + x76) + 0.083333333333333315*x3 + 0.025605852766346592*x4 + 0.083333333333333315*x5);
    double x78 = -0.027210884353741499*x77;
    double x79 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x80 = 3.0*x14 + 3.0*x16 + 3.0*x18 + 3.0*x20 + 3.0*x22 + x73*x8 + x76;
    double x81 = 74099.999999999985*n3 + 121333.33333333331*n4 + 72899.999999999985*n5 + x80;
    double x82 = -1.0*x35;
    double x83 = x52 + x82;
    double x84 = x50 + x54 + x58;
    double x85 = 1.0*x30 + x62*(-n2*x55 - x61) + x65 + x83 + x84;
    double x86 = -1.0*x39;
    double x87 = 1.0*x31 + x51 + x60 + x62*(-n3*x55 - x61) + x63 + x66 + x84 + x86;
    double x88 = T*x44;
    double x89 = x37 + x62*(-x27*x55 - x61);
    double x90 = 1.0*x33 + 1.0*x43 + x51 + x57*(0.5*x29 - x56) + x62*(-n4*x55 - x61) + x64 + x83 + x89 - 0.69314718055994495;
    double x91 = 1.0*x32 + x59 + x62*(-n5*x55 - x61) + x82 + x86 + x89;

if (x70) {
   result[0] = x48 + x49*(x12*(x13 + x45*x67) + x69);
}
else {
   result[0] = x78 + x79*(x12*(3*x13 + x67*x75) + x81);
}
if (x70) {
   result[1] = x48 + x49*(x12*(x15 - x23 + x45*x85 + 44.604500000000002) + x69);
}
else {
   result[1] = x78 + x79*(x12*(3*x15 + x73 + x75*x85) + x81);
}
if (x70) {
   result[2] = x48 + x49*(24699.999999999996*n1 + 24699.999999999996*n2 + 93488.888888888876*n4 + 45999.999999999993*n5 + x12*(x17 + x45*x87) + x68);
}
else {
   result[2] = x78 + x79*(74099.999999999985*n1 + 74099.999999999985*n2 + 280466.66666666663*n4 + 137999.99999999997*n5 + x12*(3*x17 + x75*x87) + x80);
}
if (x70) {
   result[3] = -0.2857142857142857*x47 + x49*(40444.444444444438*n1 + 40444.444444444438*n2 + 93488.888888888876*n3 + 15555.555555555555*n5 + x12*(x19 + x45*x90) + 3.5*x14 + 3.5*x16 + 3.5*x18 + x19*x6 + 3.5*x22 - 3.5*x25 + 29.100619163536336*x88);
}
else {
   result[3] = -0.095238095238095247*x77 + x79*(121333.33333333331*n1 + 121333.33333333331*n2 + 280466.66666666663*n3 + 46666.666666666657*n5 + x12*(3*x19 + x75*x90) + 10.5*x14 + 10.5*x16 + 10.5*x18 + 10.5*x20 + 10.5*x22 + 3.5*x74 + 87.301857490609009*x88);
}
if (x70) {
   result[4] = x48 + x49*(24299.999999999996*n1 + 24299.999999999996*n2 + 45999.999999999993*n3 + 15555.555555555555*n4 + x12*(x21 + x45*x91) + x68);
}
else {
   result[4] = x78 + x79*(72899.999999999985*n1 + 72899.999999999985*n2 + 137999.99999999997*n3 + 46666.666666666657*n4 + x12*(3*x21 + x75*x91) + x80);
}
}
        
static void coder_d2gdn2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x1 = pow(x0, -3);
    double x2 = 444600.0*n3 + 728000.0*n4 + 437400.0*n5;
    double x3 = 0.027777777777777773*x2;
    double x4 = n3*(444600.0*n1 + 444600.0*n2 + 1682800.0*n4 + 828000.0*n5);
    double x5 = n4*(2369250.0*n1 + 2369250.0*n2 + 5476612.5*n3 + 911250.0*n5);
    double x6 = n5*(437400.0*n1 + 437400.0*n2 + 828000.0*n3 + 280000.0*n4);
    double x7 = 3.5*n4;
    double x8 = 1.0*n1;
    double x9 = 1.0*n2;
    double x10 = 1.0*n3;
    double x11 = 1.0*n5;
    double x12 = x10 + x11 + x8 + x9;
    double x13 = x12 + x7;
    double x14 = (*endmember[0].mu0)(T, P);
    double x15 = n1*x14;
    double x16 = (*endmember[1].mu0)(T, P);
    double x17 = n2*x16;
    double x18 = (*endmember[2].mu0)(T, P);
    double x19 = n3*x18;
    double x20 = (*endmember[3].mu0)(T, P);
    double x21 = n4*x20;
    double x22 = (*endmember[4].mu0)(T, P);
    double x23 = n5*x22;
    double x24 = 13.381349999999999*T;
    double x25 = x24 - 44.604500000000002;
    double x26 = n2*x25;
    double x27 = n1 + n3;
    double x28 = n4 + n5;
    double x29 = n2 + x27 + x28;
    double x30 = 1.0/x29;
    double x31 = log(n2*x30);
    double x32 = log(n3*x30);
    double x33 = log(n5*x30);
    double x34 = log(n4*x30);
    double x35 = 1.0*n4;
    double x36 = x27*x30;
    double x37 = 1.0*log(x36);
    double x38 = 1.0*log(x28*x30);
    double x39 = n1 + n2 + n4;
    double x40 = x30*x39;
    double x41 = 1.0*log(x40);
    double x42 = 2.0*n1 + 2.0*n2 + 2.0*n3 + 2.0*n5 + x35;
    double x43 = 0.5*n4 + x12;
    double x44 = log(x30*x43);
    double x45 = T*(x10*x32 + x11*x33 + x27*x37 + x28*x38 + x31*x9 + x35*(x34 - 0.69314718055994495) + x39*x41 + x42*x44);
    double x46 = 8.3144626181532395*x45;
    double x47 = x1*(n1*x3 + n2*x3 + x13*(x15 + x17 + x19 + x21 + x23 - x26 + x46) + 0.027777777777777773*x4 + 0.0085352842554488641*x5 + 0.027777777777777773*x6);
    double x48 = 0.046647230320699701*x47;
    double x49 = pow(x0, -2);
    double x50 = 2.0*x44;
    double x51 = -x30*x9;
    double x52 = -x10*x30;
    double x53 = 1.0*x30;
    double x54 = -n4*x53;
    double x55 = -x53;
    double x56 = pow(x29, -2);
    double x57 = x43*x56;
    double x58 = -x55 - x57;
    double x59 = 1.0/x43;
    double x60 = x42*x59;
    double x61 = x58*x60;
    double x62 = x29*x61;
    double x63 = x50 + x51 + x52 + x54 + x62;
    double x64 = -x28*x53;
    double x65 = -x30;
    double x66 = x39*x56;
    double x67 = 1.0*x29;
    double x68 = x67*(-x65 - x66);
    double x69 = -x11*x30;
    double x70 = x41 + x68 + x69;
    double x71 = x64 + x70;
    double x72 = x27*x56;
    double x73 = x67*(-x65 - x72);
    double x74 = x37 + x73;
    double x75 = T*(x63 + x71 + x74);
    double x76 = 8.3144626181532395*x75;
    double x77 = x10*x18 + x11*x22 + x14*x8 + x16*x9 + x20*x35 - x25*x9 + x46;
    double x78 = 24699.999999999996*n3 + 40444.444444444438*n4 + 24299.999999999996*n5 + x77;
    double x79 = x49*(x13*(x14 + x76) + x78);
    double x80 = 1.0/x13;
    double x81 = -2*x56;
    double x82 = 2/((x29)*(x29)*(x29));
    double x83 = x39*x82;
    double x84 = x67*(x81 + x83);
    double x85 = x68/x39;
    double x86 = x56*x9;
    double x87 = x10*x56;
    double x88 = x11*x56;
    double x89 = 1.0*x66;
    double x90 = -x89;
    double x91 = x86 + x87 + x88 + x90;
    double x92 = x84 + x85 + x91;
    double x93 = 2.0*x30;
    double x94 = 1.0*x72;
    double x95 = -x94;
    double x96 = x27*x82;
    double x97 = x58*x59;
    double x98 = x43*x82;
    double x99 = x29*x60;
    double x100 = x42/((x43)*(x43));
    double x101 = x100*x58;
    double x102 = -x101*x67 + 4.0*x29*x97 + x99*(-2.0*x56 + x98);
    double x103 = x35*x56;
    double x104 = x28*x56;
    double x105 = 1.0*x104;
    double x106 = x103 + x105 + x61;
    double x107 = x102 + x106;
    double x108 = x107 + x67*(x81 + x96) + x95 + x73/x27;
    double x109 = x108 + x93;
    double x110 = T*x13;
    double x111 = x110*(x109 + x92);
    double x112 = T >= 5.0;
    double x113 = 0.083333333333333315*x2;
    double x114 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x115 = (40.14405*T - 200.72024999999999)*(x114 - 1);
    double x116 = ((x114)*(x114)*(x114));
    double x117 = 66.906750000000002*x116;
    double x118 = x117 - 66.906750000000002;
    double x119 = x115 + x118;
    double x120 = n2*x119;
    double x121 = 24.943387854459719*x45;
    double x122 = x1*(n1*x113 + n2*x113 + x13*(x120 + x121 + 3*x15 + 3*x17 + 3*x19 + 3*x21 + 3*x23) + 0.083333333333333315*x4 + 0.025605852766346592*x5 + 0.083333333333333315*x6);
    double x123 = 0.01554907677356657*x122;
    double x124 = 24.943387854459719*x75;
    double x125 = x119*x9 + x121 + 3.0*x15 + 3.0*x17 + 3.0*x19 + 3.0*x21 + 3.0*x23;
    double x126 = 74099.999999999985*n3 + 121333.33333333331*n4 + 72899.999999999985*n5 + x125;
    double x127 = x49*(x126 + x13*(x124 + 3*x14));
    double x128 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x129 = 1.0*x16;
    double x130 = -x56;
    double x131 = x103 + x105 + x61 + x67*(x130 + x96) + x95;
    double x132 = x102 + x131;
    double x133 = x110*(x132 + x92);
    double x134 = x67*(-n2*x56 - x65);
    double x135 = -1.0*x36;
    double x136 = x135 + x52;
    double x137 = x50 + x54 + x62;
    double x138 = T*(x134 + x136 + x137 + 1.0*x31 + x71);
    double x139 = 8.3144626181532395*x138 - x24;
    double x140 = x139 + 44.604500000000002;
    double x141 = 1.0*x14 + x76;
    double x142 = x13*(x140 + x16) + x78;
    double x143 = 0.081632653061224483*x49;
    double x144 = -x142*x143;
    double x145 = x48 - 0.081632653061224483*x79;
    double x146 = x124 + 3.0*x14;
    double x147 = 24.943387854459719*x138;
    double x148 = 1.0*x115 + x147 + 3.0*x16;
    double x149 = x126 + x13*(x119 + x147 + 3*x16);
    double x150 = 0.027210884353741499*x49;
    double x151 = -x149*x150;
    double x152 = x123 - 0.027210884353741499*x127;
    double x153 = x67*(x130 + x83);
    double x154 = x153 + x91;
    double x155 = x110*(x108 + x154);
    double x156 = x67*(-n3*x56 - x65);
    double x157 = -1.0*x40;
    double x158 = T*(x137 + x156 + x157 + 1.0*x32 + x51 + x64 + x69 + x74);
    double x159 = 8.3144626181532395*x158;
    double x160 = x159 + 1.0*x18;
    double x161 = 24699.999999999996*n1 + 24699.999999999996*n2 + 93488.888888888876*n4 + 45999.999999999993*n5 + x13*(x159 + x18) + x77;
    double x162 = -x143*x161;
    double x163 = 24.943387854459719*x158;
    double x164 = x163 + 3.0*x18;
    double x165 = 74099.999999999985*n1 + 74099.999999999985*n2 + 280466.66666666663*n4 + 137999.99999999997*n5 + x125 + x13*(x163 + 3*x18);
    double x166 = -x150*x165;
    double x167 = 0.5*x30 - x57;
    double x168 = x167*x29;
    double x169 = 2.0*x168*x59;
    double x170 = x169 + x67*x97 + x99*(-1.5*x56 + x98);
    double x171 = -0.5*x101*x29 + x170;
    double x172 = x131 + x171;
    double x173 = x110*(x172 + x55 + x92);
    double x174 = x67*(-n4*x56 - x65);
    double x175 = x167*x60;
    double x176 = x67*(-x104 - x65);
    double x177 = x176 + x38;
    double x178 = T*(x136 + x174 + x175*x29 + x177 + 1.0*x34 + 1.0*x44 + x51 + x70 - 0.69314718055994495);
    double x179 = 8.3144626181532395*x178;
    double x180 = x179 + 1.0*x20;
    double x181 = 40444.444444444438*n1 + 40444.444444444438*n2 + 93488.888888888876*n3 + 15555.555555555555*n5 + x13*(x179 + x20) + 3.5*x15 + 3.5*x17 + 3.5*x19 + x20*x7 + 3.5*x23 - 3.5*x26 + 29.100619163536336*x45;
    double x182 = -x143*x181 + 0.16326530612244897*x47;
    double x183 = 24.943387854459719*x178;
    double x184 = x183 + 3.0*x20;
    double x185 = 121333.33333333331*n1 + 121333.33333333331*n2 + 280466.66666666663*n3 + 46666.666666666657*n5 + 3.5*x120 + x13*(x183 + 3*x20) + 10.5*x15 + 10.5*x17 + 10.5*x19 + 10.5*x21 + 10.5*x23 + 87.301857490609009*x45;
    double x186 = 0.054421768707482998*x122 - x150*x185;
    double x187 = -x93;
    double x188 = x132 + x187;
    double x189 = x110*(x154 + x188);
    double x190 = x67*(-n5*x56 - x65);
    double x191 = T*(x135 + x157 + x177 + x190 + 1.0*x33 + x63);
    double x192 = 8.3144626181532395*x191;
    double x193 = x192 + 1.0*x22;
    double x194 = 24299.999999999996*n1 + 24299.999999999996*n2 + 45999.999999999993*n3 + 15555.555555555555*n4 + x13*(x192 + x22) + x77;
    double x195 = -x143*x194;
    double x196 = 24.943387854459719*x191;
    double x197 = x196 + 3.0*x22;
    double x198 = 72899.999999999985*n1 + 72899.999999999985*n2 + 137999.99999999997*n3 + 46666.666666666657*n4 + x125 + x13*(x196 + 3*x22);
    double x199 = -x150*x198;
    double x200 = x142*x49;
    double x201 = n2*x82;
    double x202 = -x86;
    double x203 = x87 + x94;
    double x204 = x107 + x202 + x203 + x88 + x90;
    double x205 = x84 + x85;
    double x206 = x110*(x204 + x205 + x67*(x201 + x81) + x93 + x134/n2);
    double x207 = x149*x49;
    double x208 = x67*(x130 + x201);
    double x209 = x110*(x153 + x187 + x204 + x208);
    double x210 = x129 + x139 + 8.3144626181532395*x209;
    double x211 = x144 + x48;
    double x212 = x117 + x148 + 24.943387854459719*x209;
    double x213 = x123 + x151;
    double x214 = x110*(x106 + x171 + x202 + x203 + x205 + x208 + x55 + x88 + x90);
    double x215 = x161*x49;
    double x216 = n3*x82;
    double x217 = x86 + x89;
    double x218 = x217 - x87 + x88;
    double x219 = x110*(x109 + x218 + x67*(x216 + x81) + x156/n3);
    double x220 = x165*x49;
    double x221 = 3.0*x30;
    double x222 = x218 + x67*(x130 + x216);
    double x223 = x110*(x172 - x221 + x222);
    double x224 = x110*(x188 + x222);
    double x225 = n4*x82;
    double x226 = -x105 + x176/x28 + x67*(x28*x82 + x81);
    double x227 = -x103 + x175 + x226 + x94;
    double x228 = x110*(-0.5*x100*x168 + x169 + x221 + x227 + x67*(x225 + x81) + x92 + x99*(-1.0*x56 + x98) + x174/n4);
    double x229 = x110*(-x100*x167*x67 + x154 + x170 + x227 + x67*(x130 + x225));
    double x230 = x194*x49;
    double x231 = x198*x49;
    double x232 = x110*(x102 + x103 + x203 + x217 + x226 + x61 + x67*(n5*x82 + x81) - x88 + x93 + x190/n5);

if (x112) {
   result[0] = x48 - 0.16326530612244897*x79 + x80*(8.3144626181532395*x111 + 2.0*x14 + 16.628925236306479*x75);
}
else {
   result[0] = x123 - 0.054421768707482998*x127 + x128*(24.943387854459719*x111 + 6.0*x14 + 49.886775708919437*x75);
}
if (x112) {
   result[1] = x144 + x145 + x80*(x129 + 8.3144626181532395*x133 + x140 + x141);
}
else {
   result[1] = x128*(x118 + 24.943387854459719*x133 + x146 + x148) + x151 + x152;
}
if (x112) {
   result[2] = x145 + x162 + x80*(x141 + 8.3144626181532395*x155 + x160 + 24699.999999999996);
}
else {
   result[2] = x128*(x146 + 24.943387854459719*x155 + x164 + 74099.999999999985) + x152 + x166;
}
if (x112) {
   result[3] = x182 - 0.2857142857142857*x79 + x80*(3.5*x14 + 8.3144626181532395*x173 + x180 + 29.100619163536336*x75 + 40444.444444444438);
}
else {
   result[3] = -0.095238095238095247*x127 + x128*(10.5*x14 + 24.943387854459719*x173 + x184 + 87.301857490609009*x75 + 121333.33333333331) + x186;
}
if (x112) {
   result[4] = x145 + x195 + x80*(x141 + 8.3144626181532395*x189 + x193 + 24299.999999999996);
}
else {
   result[4] = x128*(x146 + 24.943387854459719*x189 + x197 + 72899.999999999985) + x152 + x199;
}
if (x112) {
   result[5] = -0.16326530612244897*x200 + x48 + x80*(-26.762699999999999*T + 16.628925236306479*x138 + 2.0*x16 + 8.3144626181532395*x206 + 89.209000000000003);
}
else {
   result[5] = x123 + x128*(2.0*x115 + 133.8135*x116 + 49.886775708919437*x138 + 6.0*x16 + 24.943387854459719*x206 - 133.8135) - 0.054421768707482998*x207;
}
if (x112) {
   result[6] = x162 + x211 + x80*(x160 + x210 + 24744.604499999998);
}
else {
   result[6] = x128*(x164 + x212 + 74033.093249999991) + x166 + x213;
}
if (x112) {
   result[7] = x182 - 0.2857142857142857*x200 + x80*(-46.834724999999999*T + 29.100619163536336*x138 + 3.5*x16 + x180 + 8.3144626181532395*x214 + 40600.560194444435);
}
else {
   result[7] = x128*(3.5*x115 + 234.17362500000002*x116 + 87.301857490609009*x138 + 10.5*x16 + x184 + 24.943387854459719*x214 + 121099.15970833332) + x186 - 0.095238095238095247*x207;
}
if (x112) {
   result[8] = x195 + x211 + x80*(x193 + x210 + 24344.604499999998);
}
else {
   result[8] = x128*(x197 + x212 + 72833.093249999991) + x199 + x213;
}
if (x112) {
   result[9] = -0.16326530612244897*x215 + x48 + x80*(16.628925236306479*x158 + 2.0*x18 + 8.3144626181532395*x219);
}
else {
   result[9] = x123 + x128*(49.886775708919437*x158 + 6.0*x18 + 24.943387854459719*x219) - 0.054421768707482998*x220;
}
if (x112) {
   result[10] = x182 - 0.2857142857142857*x215 + x80*(29.100619163536336*x158 + 3.5*x18 + x180 + 8.3144626181532395*x223 + 93488.888888888876);
}
else {
   result[10] = x128*(87.301857490609009*x158 + 10.5*x18 + x184 + 24.943387854459719*x223 + 280466.66666666663) + x186 - 0.095238095238095247*x220;
}
if (x112) {
   result[11] = x162 + x195 + x48 + x80*(x160 + x193 + 8.3144626181532395*x224 + 45999.999999999993);
}
else {
   result[11] = x123 + x128*(x164 + x197 + 24.943387854459719*x224 + 137999.99999999997) + x166 + x199;
}
if (x112) {
   result[12] = -0.5714285714285714*x181*x49 + 0.5714285714285714*x47 + x80*(58.201238327072673*x178 + 7.0*x20 + 8.3144626181532395*x228);
}
else {
   result[12] = 0.19047619047619049*x122 + x128*(174.60371498121802*x178 + 21.0*x20 + 24.943387854459719*x228) - 0.19047619047619049*x185*x49;
}
if (x112) {
   result[13] = x182 - 0.2857142857142857*x230 + x80*(x180 + 29.100619163536336*x191 + 3.5*x22 + 8.3144626181532395*x229 + 15555.555555555555);
}
else {
   result[13] = x128*(x184 + 87.301857490609009*x191 + 10.5*x22 + 24.943387854459719*x229 + 46666.666666666657) + x186 - 0.095238095238095247*x231;
}
if (x112) {
   result[14] = -0.16326530612244897*x230 + x48 + x80*(16.628925236306479*x191 + 2.0*x22 + 8.3144626181532395*x232);
}
else {
   result[14] = x123 + x128*(49.886775708919437*x191 + 6.0*x22 + 24.943387854459719*x232) - 0.054421768707482998*x231;
}
}
        
static void coder_d3gdn3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x1 = pow(x0, -4);
    double x2 = 444600.0*n3 + 728000.0*n4 + 437400.0*n5;
    double x3 = 0.027777777777777773*x2;
    double x4 = n3*(444600.0*n1 + 444600.0*n2 + 1682800.0*n4 + 828000.0*n5);
    double x5 = n4*(2369250.0*n1 + 2369250.0*n2 + 5476612.5*n3 + 911250.0*n5);
    double x6 = n5*(437400.0*n1 + 437400.0*n2 + 828000.0*n3 + 280000.0*n4);
    double x7 = 3.5*n4;
    double x8 = 1.0*n1;
    double x9 = 1.0*n2;
    double x10 = 1.0*n3;
    double x11 = 1.0*n5;
    double x12 = x10 + x11 + x8 + x9;
    double x13 = x12 + x7;
    double x14 = (*endmember[0].mu0)(T, P);
    double x15 = n1*x14;
    double x16 = (*endmember[1].mu0)(T, P);
    double x17 = n2*x16;
    double x18 = (*endmember[2].mu0)(T, P);
    double x19 = n3*x18;
    double x20 = (*endmember[3].mu0)(T, P);
    double x21 = n4*x20;
    double x22 = (*endmember[4].mu0)(T, P);
    double x23 = n5*x22;
    double x24 = 13.381349999999999*T;
    double x25 = x24 - 44.604500000000002;
    double x26 = n2*x25;
    double x27 = n4 + n5;
    double x28 = n1 + n3;
    double x29 = n2 + x27 + x28;
    double x30 = 1.0/x29;
    double x31 = log(n2*x30);
    double x32 = log(n3*x30);
    double x33 = log(n5*x30);
    double x34 = log(n4*x30);
    double x35 = 1.0*n4;
    double x36 = 1.0*log(x28*x30);
    double x37 = 1.0*log(x27*x30);
    double x38 = n1 + n2 + n4;
    double x39 = 1.0*log(x30*x38);
    double x40 = 2.0*n2;
    double x41 = 2.0*n3;
    double x42 = 2.0*n5;
    double x43 = 2.0*n1 + x35 + x40 + x41 + x42;
    double x44 = 0.5*n4 + x12;
    double x45 = log(x30*x44);
    double x46 = x10*x32 + x11*x33 + x27*x37 + x28*x36 + x31*x9 + x35*(x34 - 0.69314718055994495) + x38*x39 + x43*x45;
    double x47 = 8.3144626181532395*T;
    double x48 = x46*x47;
    double x49 = x1*(n1*x3 + n2*x3 + x13*(x15 + x17 + x19 + x21 + x23 - x26 + x48) + 0.027777777777777773*x4 + 0.0085352842554488641*x5 + 0.027777777777777773*x6);
    double x50 = 0.039983340274885454*x49;
    double x51 = -x50;
    double x52 = pow(x0, -3);
    double x53 = 2.0*x45;
    double x54 = -x30*x9;
    double x55 = -x10*x30;
    double x56 = 1.0*x30;
    double x57 = -n4*x56;
    double x58 = 1.0/x44;
    double x59 = -x56;
    double x60 = pow(x29, -2);
    double x61 = x44*x60;
    double x62 = -x59 - x61;
    double x63 = x58*x62;
    double x64 = x43*x63;
    double x65 = x29*x64;
    double x66 = x53 + x54 + x55 + x57 + x65;
    double x67 = -x27*x56;
    double x68 = -x30;
    double x69 = x38*x60;
    double x70 = -x68 - x69;
    double x71 = 1.0*x29;
    double x72 = x70*x71;
    double x73 = -x11*x30;
    double x74 = x39 + x72 + x73;
    double x75 = x67 + x74;
    double x76 = x28*x60;
    double x77 = -x68 - x76;
    double x78 = x71*x77;
    double x79 = x36 + x78;
    double x80 = x66 + x75 + x79;
    double x81 = x47*x80;
    double x82 = x10*x18 + x11*x22 + x14*x8 + x16*x9 + x20*x35 - x25*x9 + x48;
    double x83 = 24699.999999999996*n3 + 40444.444444444438*n4 + 24299.999999999996*n5 + x82;
    double x84 = x13*(x14 + x81) + x83;
    double x85 = x52*x84;
    double x86 = pow(x0, -2);
    double x87 = T*x80;
    double x88 = -2*x60;
    double x89 = pow(x29, -3);
    double x90 = 2*x89;
    double x91 = x38*x90;
    double x92 = x71*(x88 + x91);
    double x93 = 1.0/x38;
    double x94 = x70*x93;
    double x95 = x71*x94;
    double x96 = x60*x9;
    double x97 = x10*x60;
    double x98 = x11*x60;
    double x99 = 1.0*x69;
    double x100 = -x99;
    double x101 = x100 + x96 + x97 + x98;
    double x102 = x101 + x92 + x95;
    double x103 = 2.0*x30;
    double x104 = 1.0*x76;
    double x105 = -x104;
    double x106 = x28*x90;
    double x107 = x71*(x106 + x88);
    double x108 = 1.0/x28;
    double x109 = x108*x77;
    double x110 = 4.0*x29;
    double x111 = 2.0*x60;
    double x112 = -x111;
    double x113 = x44*x90;
    double x114 = x112 + x113;
    double x115 = x43*x58;
    double x116 = x114*x115;
    double x117 = pow(x44, -2);
    double x118 = x117*x62;
    double x119 = x118*x43;
    double x120 = x110*x63 + x116*x29 - x119*x71;
    double x121 = x35*x60;
    double x122 = x27*x60;
    double x123 = 1.0*x122;
    double x124 = x121 + x123 + x64;
    double x125 = x120 + x124;
    double x126 = x105 + x107 + x109*x71 + x125;
    double x127 = x103 + x126;
    double x128 = T*(x102 + x127);
    double x129 = 8.3144626181532395*x128;
    double x130 = x86*(x129*x13 + 2.0*x14 + 16.628925236306479*x87);
    double x131 = 1.0/x13;
    double x132 = 24.943387854459719*x128;
    double x133 = 1.0*x94;
    double x134 = 4.0*x89;
    double x135 = x134*x38;
    double x136 = -x40*x89;
    double x137 = -x41*x89;
    double x138 = -x42*x89;
    double x139 = x135 + x136 + x137 + x138;
    double x140 = x133 + x139;
    double x141 = -6*x89;
    double x142 = 6/((x29)*(x29)*(x29)*(x29));
    double x143 = x142*x38;
    double x144 = x71*(-x141 - x143) + x92*x93 - x72/((x38)*(x38));
    double x145 = x140 + x144;
    double x146 = 1.0*x109;
    double x147 = -8.0*x60;
    double x148 = x142*x28;
    double x149 = 2.0*x89;
    double x150 = -n4*x149;
    double x151 = -x149*x27 + x150;
    double x152 = x134*x28 + x151;
    double x153 = 6.0*x29;
    double x154 = x114*x58;
    double x155 = 2.0*x43;
    double x156 = x142*x44;
    double x157 = x115*x29;
    double x158 = x155*x29;
    double x159 = pow(x44, -3);
    double x160 = x159*x62;
    double x161 = x114*x117;
    double x162 = 2*x116 - x118*x153 - x118*x155 + x153*x154 + x157*(-x156 + 6.0*x89) + x158*x160 - x158*x161 + 6.0*x63;
    double x163 = x152 + x162;
    double x164 = x107*x108 + x163 + x71*(-x141 - x148) - x78/((x28)*(x28));
    double x165 = x146 + x147 + x164;
    double x166 = x13*(x145 + x165);
    double x167 = T >= 5.0;
    double x168 = 0.083333333333333315*x2;
    double x169 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x170 = (40.14405*T - 200.72024999999999)*(x169 - 1);
    double x171 = ((x169)*(x169)*(x169));
    double x172 = 66.906750000000002*x171;
    double x173 = x172 - 66.906750000000002;
    double x174 = x170 + x173;
    double x175 = n2*x174;
    double x176 = 24.943387854459719*T;
    double x177 = x176*x46;
    double x178 = x1*(n1*x168 + n2*x168 + x13*(3*x15 + 3*x17 + x175 + x177 + 3*x19 + 3*x21 + 3*x23) + 0.083333333333333315*x4 + 0.025605852766346592*x5 + 0.083333333333333315*x6);
    double x179 = 0.013327780091628489*x178;
    double x180 = -x179;
    double x181 = 24.943387854459719*x87;
    double x182 = 3.0*x15 + 3.0*x17 + x174*x9 + x177 + 3.0*x19 + 3.0*x21 + 3.0*x23;
    double x183 = 74099.999999999985*n3 + 121333.33333333331*n4 + 72899.999999999985*n5 + x182;
    double x184 = x13*(3*x14 + x181) + x183;
    double x185 = x184*x52;
    double x186 = x86*(x13*x132 + 6.0*x14 + 49.886775708919437*x87);
    double x187 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x188 = -x60;
    double x189 = x71*(x106 + x188);
    double x190 = x105 + x121 + x123 + x189 + x64;
    double x191 = x120 + x190;
    double x192 = x102 + x191;
    double x193 = T*x192;
    double x194 = 16.628925236306479*x193;
    double x195 = x108*x189;
    double x196 = -4*x89;
    double x197 = x71*(-x148 - x196);
    double x198 = x163 + x197;
    double x199 = x195 + x198;
    double x200 = x146 - 6.0*x60;
    double x201 = x13*(x145 + x199 + x200);
    double x202 = 1.0*x16;
    double x203 = x192*x47;
    double x204 = -n2*x60 - x68;
    double x205 = x204*x71;
    double x206 = -x28*x56;
    double x207 = x206 + x55;
    double x208 = x53 + x57 + x65;
    double x209 = x205 + x207 + x208 + 1.0*x31 + x75;
    double x210 = x209*x47 - x24;
    double x211 = x210 + 44.604500000000002;
    double x212 = 1.0*x14 + x81;
    double x213 = x13*x203 + x202 + x211 + x212;
    double x214 = 0.16326530612244897*x86;
    double x215 = x213*x214;
    double x216 = x13*(x16 + x211) + x83;
    double x217 = -0.046647230320699701*x216*x52 + x50;
    double x218 = 0.081632653061224483*x130 - 0.093294460641399402*x52*x84;
    double x219 = 49.886775708919437*x193;
    double x220 = x176*x192;
    double x221 = 3.0*x14 + x181;
    double x222 = x176*x209;
    double x223 = 3.0*x16 + 1.0*x170 + x222;
    double x224 = x13*x220 + x173 + x221 + x223;
    double x225 = 0.054421768707482998*x86;
    double x226 = x224*x225;
    double x227 = x13*(3*x16 + x174 + x222) + x183;
    double x228 = x179 - 0.01554907677356657*x227*x52;
    double x229 = -0.031098153547133141*x184*x52 + 0.027210884353741499*x186;
    double x230 = x71*(x188 + x91);
    double x231 = x101 + x230;
    double x232 = x126 + x231;
    double x233 = T*x232;
    double x234 = 16.628925236306479*x233;
    double x235 = x71*(-x143 - x196);
    double x236 = x230*x93 + x235;
    double x237 = x140 + x236;
    double x238 = x13*(x164 + x200 + x237);
    double x239 = x232*x47;
    double x240 = -n3*x60 - x68;
    double x241 = x240*x71;
    double x242 = -x38*x56;
    double x243 = x208 + x241 + x242 + 1.0*x32 + x54 + x67 + x73 + x79;
    double x244 = x243*x47;
    double x245 = 1.0*x18 + x244;
    double x246 = x13*x239 + x212 + x245 + 24699.999999999996;
    double x247 = x214*x246;
    double x248 = 24699.999999999996*n1 + 24699.999999999996*n2 + 93488.888888888876*n4 + 45999.999999999993*n5 + x13*(x18 + x244) + x82;
    double x249 = -0.046647230320699701*x248*x52;
    double x250 = x218 + x50;
    double x251 = 49.886775708919437*x233;
    double x252 = x176*x232;
    double x253 = x176*x243;
    double x254 = 3.0*x18 + x253;
    double x255 = x13*x252 + x221 + x254 + 74099.999999999985;
    double x256 = x225*x255;
    double x257 = 74099.999999999985*n1 + 74099.999999999985*n2 + 280466.66666666663*n4 + 137999.99999999997*n5 + x13*(3*x18 + x253) + x182;
    double x258 = -0.01554907677356657*x257*x52;
    double x259 = x179 + x229;
    double x260 = 0.5*x29;
    double x261 = 0.5*x30 - x61;
    double x262 = x261*x58;
    double x263 = 2.0*x262;
    double x264 = x263*x29;
    double x265 = x113 - 1.5*x60;
    double x266 = x115*x265;
    double x267 = x264 + x266*x29 + x63*x71;
    double x268 = -x119*x260 + x267;
    double x269 = x190 + x268;
    double x270 = x102 + x269 + x59;
    double x271 = T*x270;
    double x272 = x140 + x195;
    double x273 = x43*x71;
    double x274 = x117*x273;
    double x275 = -x265*x274;
    double x276 = x146 + x152 + x197 + x275;
    double x277 = x260*x43;
    double x278 = x265*x58;
    double x279 = x110*x278 + x154*x71 + x157*(-x156 + 5.0*x89);
    double x280 = x116 - 1.5*x119 + x160*x273 - x161*x277 + x266 + x279;
    double x281 = x118*x29;
    double x282 = -3.0*x281 + 5.0*x63;
    double x283 = x280 + x282;
    double x284 = x283 - 5.0*x60;
    double x285 = x13*(x144 + x272 + x276 + x284);
    double x286 = x270*x47;
    double x287 = -n4*x60 - x68;
    double x288 = x287*x71;
    double x289 = x115*x261;
    double x290 = -x122 - x68;
    double x291 = x290*x71;
    double x292 = x291 + x37;
    double x293 = x207 + x288 + x289*x29 + x292 + 1.0*x34 + 1.0*x45 + x54 + x74 - 0.69314718055994495;
    double x294 = x293*x47;
    double x295 = 1.0*x20 + x294;
    double x296 = x13*x286 + 3.5*x14 + x295 + 29.100619163536336*x87 + 40444.444444444438;
    double x297 = 0.1399416909620991*x49;
    double x298 = T*x46;
    double x299 = 40444.444444444438*n1 + 40444.444444444438*n2 + 93488.888888888876*n3 + 15555.555555555555*n5 + x13*(x20 + x294) + 3.5*x15 + 3.5*x17 + 3.5*x19 + x20*x7 + 3.5*x23 - 3.5*x26 + 29.100619163536336*x298;
    double x300 = x297 - 0.046647230320699701*x299*x52;
    double x301 = x176*x270;
    double x302 = x176*x293;
    double x303 = 3.0*x20 + x302;
    double x304 = x13*x301 + 10.5*x14 + x303 + 87.301857490609009*x87 + 121333.33333333331;
    double x305 = 0.046647230320699715*x178;
    double x306 = 121333.33333333331*n1 + 121333.33333333331*n2 + 280466.66666666663*n3 + 46666.666666666657*n5 + x13*(3*x20 + x302) + 10.5*x15 + 10.5*x17 + 3.5*x175 + 10.5*x19 + 10.5*x21 + 10.5*x23 + 87.301857490609009*x298;
    double x307 = -0.01554907677356657*x306*x52;
    double x308 = x305 + x307;
    double x309 = -x103;
    double x310 = x191 + x309;
    double x311 = x231 + x310;
    double x312 = T*x311;
    double x313 = 16.628925236306479*x312;
    double x314 = x198 + x236;
    double x315 = 4.0*x60;
    double x316 = -x315;
    double x317 = x146 + x316;
    double x318 = x13*(x272 + x314 + x317);
    double x319 = x311*x47;
    double x320 = -n5*x60 - x68;
    double x321 = x320*x71;
    double x322 = x206 + x242 + x292 + x321 + 1.0*x33 + x66;
    double x323 = x322*x47;
    double x324 = 1.0*x22 + x323;
    double x325 = x13*x319 + x212 + x324 + 24299.999999999996;
    double x326 = x214*x325;
    double x327 = 24299.999999999996*n1 + 24299.999999999996*n2 + 45999.999999999993*n3 + 15555.555555555555*n4 + x13*(x22 + x323) + x82;
    double x328 = -0.046647230320699701*x327*x52;
    double x329 = 49.886775708919437*x312;
    double x330 = x176*x311;
    double x331 = x176*x322;
    double x332 = 3.0*x22 + x331;
    double x333 = x13*x330 + x221 + x332 + 72899.999999999985;
    double x334 = x225*x333;
    double x335 = 72899.999999999985*n1 + 72899.999999999985*n2 + 137999.99999999997*n3 + 46666.666666666657*n4 + x13*(3*x22 + x331) + x182;
    double x336 = -0.01554907677356657*x335*x52;
    double x337 = n2*x90;
    double x338 = x71*(x337 + x88);
    double x339 = 1.0/n2;
    double x340 = -x96;
    double x341 = x104 + x97;
    double x342 = x100 + x125 + x340 + x341 + x98;
    double x343 = x92 + x95;
    double x344 = x103 + x205*x339 + x338 + x342 + x343;
    double x345 = x344*x47;
    double x346 = 3.0*x60;
    double x347 = -x346;
    double x348 = x140 + x347;
    double x349 = -2*x89;
    double x350 = x152 + x71*(-x148 - x349);
    double x351 = x162 + x350;
    double x352 = x13*(x144 + x348 + x351);
    double x353 = x51 + 0.046647230320699701*x85;
    double x354 = x216*x52;
    double x355 = T*x209;
    double x356 = -26.762699999999999*T + x13*x345 + 2.0*x16 + 16.628925236306479*x355 + 89.209000000000003;
    double x357 = 0.081632653061224483*x86;
    double x358 = 0.093294460641399402*x354 - x356*x357;
    double x359 = x176*x344;
    double x360 = x180 + 0.01554907677356657*x185;
    double x361 = x227*x52;
    double x362 = x13*x359 + 6.0*x16 + 2.0*x170 + 133.8135*x171 + 49.886775708919437*x355 - 133.8135;
    double x363 = 0.027210884353741499*x86;
    double x364 = 0.031098153547133141*x361 - x362*x363;
    double x365 = x13*(x314 + x348);
    double x366 = x71*(x188 + x337);
    double x367 = x230 + x309 + x342 + x366;
    double x368 = x367*x47;
    double x369 = x203 + x368;
    double x370 = 0.046647230320699701*x52;
    double x371 = x216*x370;
    double x372 = x13*x368 + x202 + x210;
    double x373 = x245 + x372 + 24744.604499999998;
    double x374 = -x357*x373 + x371;
    double x375 = -x213*x357 + x353;
    double x376 = x248*x370;
    double x377 = -x246*x357 + x376;
    double x378 = x176*x367;
    double x379 = x220 + x378;
    double x380 = 0.01554907677356657*x52;
    double x381 = x227*x380;
    double x382 = x13*x378 + x172 + x223;
    double x383 = x254 + x382 + 74033.093249999991;
    double x384 = -x363*x383 + x381;
    double x385 = -x224*x363 + x360;
    double x386 = x257*x380;
    double x387 = -x255*x363 + x386;
    double x388 = x100 + x124 + x268 + x340 + x341 + x343 + x366 + x59 + x98;
    double x389 = x388*x47;
    double x390 = x275 + x350;
    double x391 = x112 + x280;
    double x392 = x13*(x145 + x282 + x390 + x391);
    double x393 = 0.2857142857142857*x86;
    double x394 = -x297 + x299*x370;
    double x395 = -x296*x357 + x394 + 0.16326530612244897*x85;
    double x396 = -46.834724999999999*T + x13*x389 + 3.5*x16 + x295 + 29.100619163536336*x355 + 40600.560194444435;
    double x397 = 0.16326530612244897*x354 - x357*x396;
    double x398 = x176*x388;
    double x399 = 0.095238095238095247*x86;
    double x400 = x13*x398 + 10.5*x16 + 3.5*x170 + 234.17362500000002*x171 + x303 + 87.301857490609009*x355 + 121099.15970833332;
    double x401 = 0.054421768707482998*x361 - x363*x400;
    double x402 = x306*x380;
    double x403 = -x305 + x402;
    double x404 = 0.054421768707482998*x185 - x304*x363;
    double x405 = x403 + x404;
    double x406 = 1.0*x60;
    double x407 = -x406;
    double x408 = x13*(x237 + x351 + x407);
    double x409 = x324 + x372 + 24344.604499999998;
    double x410 = -x357*x409;
    double x411 = x327*x370;
    double x412 = -x325*x357 + x411;
    double x413 = x332 + x382 + 72833.093249999991;
    double x414 = -x363*x413;
    double x415 = x335*x380;
    double x416 = -x333*x363 + x415;
    double x417 = n3*x90;
    double x418 = x71*(x417 + x88);
    double x419 = 1.0/n3;
    double x420 = x96 + x99;
    double x421 = x420 - x97 + x98;
    double x422 = x127 + x241*x419 + x418 + x421;
    double x423 = x422*x47;
    double x424 = x71*(-x143 - x349);
    double x425 = x139 + x424;
    double x426 = x146 + x425;
    double x427 = x13*(x164 + x347 + x426);
    double x428 = x50 - 0.046647230320699701*x52*x84;
    double x429 = T*x243;
    double x430 = x13*x423 + 2.0*x18 + 16.628925236306479*x429;
    double x431 = -0.093294460641399402*x248*x52 + x357*x430;
    double x432 = x176*x422;
    double x433 = x179 - 0.01554907677356657*x184*x52;
    double x434 = x13*x432 + 6.0*x18 + 49.886775708919437*x429;
    double x435 = -0.031098153547133141*x257*x52 + x363*x434;
    double x436 = 3.0*x30;
    double x437 = x71*(x188 + x417);
    double x438 = x421 + x437;
    double x439 = x269 - x436 + x438;
    double x440 = x439*x47;
    double x441 = x235 + x282;
    double x442 = x195 + x276;
    double x443 = x13*(x139 + x391 + x441 + x442);
    double x444 = x248*x52;
    double x445 = x13*x440 + 3.5*x18 + x295 + 29.100619163536336*x429 + 93488.888888888876;
    double x446 = -x357*x445 + 0.16326530612244897*x444;
    double x447 = x176*x439;
    double x448 = x257*x52;
    double x449 = x13*x447 + 10.5*x18 + x303 + 87.301857490609009*x429 + 280466.66666666663;
    double x450 = -x363*x449 + 0.054421768707482998*x448;
    double x451 = x310 + x438;
    double x452 = x451*x47;
    double x453 = x13*(x199 + x407 + x426);
    double x454 = x13*x452 + x245 + x324 + 45999.999999999993;
    double x455 = -x357*x454;
    double x456 = x176*x451;
    double x457 = x13*x456 + x254 + x332 + 137999.99999999997;
    double x458 = -x363*x457;
    double x459 = n4*x90;
    double x460 = x71*(x459 + x88);
    double x461 = 1.0/n4;
    double x462 = x113 + x407;
    double x463 = x115*x462;
    double x464 = x117*x261;
    double x465 = x43*x464;
    double x466 = x71*(x27*x90 + x88);
    double x467 = 1.0/x27;
    double x468 = -x123 + x291*x467 + x466;
    double x469 = x104 - x121 + x289 + x468;
    double x470 = x102 - x260*x465 + x264 + x288*x461 + x29*x463 + x436 + x460 + x469;
    double x471 = x47*x470;
    double x472 = x263 + x390;
    double x473 = x464*x71;
    double x474 = -x118*x71 + 2*x266;
    double x475 = 2.0*x29;
    double x476 = x462*x58;
    double x477 = x157*(-x156 + 4.0*x89) + x278*x475 + x475*x476;
    double x478 = -1.0*x119 + x160*x277 - x473 + x474 + x477 + 2.0*x63;
    double x479 = x407 + x478;
    double x480 = x13*(x145 + x472 + x479);
    double x481 = 0.5714285714285714*x86;
    double x482 = T*x293;
    double x483 = x13*x471 + 7.0*x20 + 58.201238327072673*x482;
    double x484 = -0.32653061224489793*x299*x52 + x357*x483;
    double x485 = x484 + 0.48979591836734693*x49;
    double x486 = x176*x470;
    double x487 = 0.19047619047619049*x86;
    double x488 = x13*x486 + 21.0*x20 + 174.60371498121802*x482;
    double x489 = 0.16326530612244899*x178 - 0.108843537414966*x306*x52 + x363*x488;
    double x490 = x71*(x188 + x459);
    double x491 = x231 + x267 - x43*x473 + x469 + x490;
    double x492 = x47*x491;
    double x493 = -2.0*x281 - x464*x475 + 3.0*x63;
    double x494 = x280 + x493;
    double x495 = x13*(x237 + x472 + x494);
    double x496 = x327*x52;
    double x497 = T*x322;
    double x498 = x13*x492 + 3.5*x22 + x295 + 29.100619163536336*x497 + 15555.555555555555;
    double x499 = -x357*x498 + 0.16326530612244897*x496;
    double x500 = x176*x491;
    double x501 = x335*x52;
    double x502 = x13*x500 + 10.5*x22 + x303 + 87.301857490609009*x497 + 46666.666666666657;
    double x503 = 0.046647230320699708*x178;
    double x504 = -x363*x502 + x402 + 0.054421768707482998*x501 - x503;
    double x505 = x71*(n5*x90 + x88);
    double x506 = 1.0/n5;
    double x507 = x103 + x120 + x121 + x321*x506 + x341 + x420 + x468 + x505 + x64 - x98;
    double x508 = x47*x507;
    double x509 = x111 + x162;
    double x510 = x350 + x509;
    double x511 = x13*(x425 + x510);
    double x512 = x13*x508 + 2.0*x22 + 16.628925236306479*x497;
    double x513 = -0.093294460641399402*x327*x52 + x357*x512;
    double x514 = x176*x507;
    double x515 = x13*x514 + 6.0*x22 + 49.886775708919437*x497;
    double x516 = -0.031098153547133141*x335*x52 + x363*x515;
    double x517 = 0.24489795918367346*x86;
    double x518 = n2*x142;
    double x519 = 1.0*x204*x339;
    double x520 = -x149*x28;
    double x521 = x137 + x520;
    double x522 = n2*x134 + x135 + x138 + x151 + x521;
    double x523 = x162 + x519 + x522;
    double x524 = x133 + x144;
    double x525 = x13*(x147 + x338*x339 + x523 + x524 + x71*(-x141 - x518) - x205/((n2)*(n2)));
    double x526 = 0.081632653061224497*x86;
    double x527 = T*x344;
    double x528 = x214*x373;
    double x529 = x376 + x51;
    double x530 = T*x367;
    double x531 = 16.628925236306479*x530;
    double x532 = x133 + x236;
    double x533 = x339*x366 + x71*(-x196 - x518);
    double x534 = x13*(x316 + x523 + x532 + x533);
    double x535 = x131*(x345 + x47*x534 + x531) + x358;
    double x536 = x225*x383;
    double x537 = x180 + x386;
    double x538 = 49.886775708919437*x530;
    double x539 = x187*(x176*x534 + x359 + x538) + x364;
    double x540 = T*x388;
    double x541 = x13*(x275 + x284 + x519 + x522 + x524 + x533);
    double x542 = x214*x409;
    double x543 = x225*x413;
    double x544 = x522 + x71*(-x349 - x518);
    double x545 = x13*(x424 + x509 + x544);
    double x546 = x47*x545 + x531;
    double x547 = x176*x545 + x538;
    double x548 = x275 + x544;
    double x549 = x280 + x548;
    double x550 = x13*(x406 + x441 + x549);
    double x551 = x389 + 29.100619163536336*x530;
    double x552 = x394 + x397;
    double x553 = x398 + 87.301857490609009*x530;
    double x554 = x13*(x263 + x479 + x524 + x548);
    double x555 = x13*(x263 + x493 + x532 + x549);
    double x556 = n3*x142;
    double x557 = x136 - x149*x38;
    double x558 = n3*x134 + x138 + x557;
    double x559 = 1.0*x240*x419 + x558;
    double x560 = x13*(x165 + x418*x419 + x559 + x71*(-x141 - x556) - x241/((n3)*(n3)));
    double x561 = T*x422;
    double x562 = T*x439;
    double x563 = x419*x437 + x559 + x71*(-x196 - x556);
    double x564 = x13*(x283 + x347 + x442 + x563);
    double x565 = T*x451;
    double x566 = 16.628925236306479*x565;
    double x567 = x13*(x199 + x317 + x563);
    double x568 = x214*x454 + x50;
    double x569 = 49.886775708919437*x565;
    double x570 = x179 + x225*x457;
    double x571 = x558 + x71*(-x349 - x556);
    double x572 = x472 + x571;
    double x573 = x13*(x315 + x478 + x572);
    double x574 = x13*(x346 + x494 + x572);
    double x575 = x13*(x510 + x571);
    double x576 = T*x470;
    double x577 = n4*x142;
    double x578 = 3.0*x29;
    double x579 = x159*x261;
    double x580 = x134*x27 + 1.0*x290*x467 + x466*x467 + x71*(-x141 - x142*x27) - x291/((x27)*(x27));
    double x581 = n4*x134 + x520 + x580;
    double x582 = -x274*x462 + 1.0*x287*x461;
    double x583 = x13*(x145 + x157*(-x156 + 3.0*x89) + 3.0*x262 + x277*x579 - 1.5*x29*x464 + x460*x461 + 2*x463 - 1.0*x465 + x476*x578 + x581 + x582 - 12.0*x60 + x71*(-x141 - x577) - x288/((n4)*(n4)));
    double x584 = T*x491;
    double x585 = x117*x265;
    double x586 = 4.0*x262 + x581;
    double x587 = x13*(x237 + x266 + x273*x579 - x277*x585 + x461*x490 + x463 - x464*x578 - 1.5*x465 + x477 + x582 + x586 - 9.0*x60 + x71*(-x196 - x577));
    double x588 = T*x507;
    double x589 = x13*(-x110*x464 - x155*x464 + x158*x579 - x158*x585 + x279 + x316 + x425 + x474 + x586 + 1.0*x63 + x71*(-x349 - x577));
    double x590 = x13*(n5*x134 + x147 + x150 + x162 + 1.0*x320*x506 + x505*x506 + x521 + x557 + x580 + x71*(-n5*x142 - x141) - x321/((n5)*(n5)));

if (x167) {
   result[0] = -0.24489795918367346*x130 + x131*(x132 + x166*x47) + x51 + 0.1399416909620991*x85;
}
else {
   result[0] = x180 + 0.046647230320699715*x185 - 0.081632653061224497*x186 + x187*(74.830163563379159*x128 + x166*x176);
}
if (x167) {
   result[1] = x131*(x129 + x194 + x201*x47) - x215 - x217 - x218;
}
else {
   result[1] = x187*(x132 + x176*x201 + x219) - x226 - x228 - x229;
}
if (x167) {
   result[2] = x131*(x129 + x234 + x238*x47) - x247 - x249 - x250;
}
else {
   result[2] = x187*(x132 + x176*x238 + x251) - x256 - x258 - x259;
}
if (x167) {
   result[3] = -0.2857142857142857*x130 + x131*(29.100619163536336*x128 + 16.628925236306479*x271 + x285*x47) - x214*x296 - x300 + 0.32653061224489793*x52*x84;
}
else {
   result[3] = 0.108843537414966*x184*x52 - 0.095238095238095247*x186 + x187*(87.301857490609009*x128 + x176*x285 + 49.886775708919437*x271) - x225*x304 - x308;
}
if (x167) {
   result[4] = x131*(x129 + x313 + x318*x47) - x250 - x326 - x328;
}
else {
   result[4] = x187*(x132 + x176*x318 + x329) - x259 - x334 - x336;
}
if (x167) {
   result[5] = x131*(x194 + x345 + x352*x47) - x215 + x353 + x358;
}
else {
   result[5] = x187*(x176*x352 + x219 + x359) - x226 + x360 + x364;
}
if (x167) {
   result[6] = x131*(x239 + x365*x47 + x369) + x374 + x375 + x377;
}
else {
   result[6] = x187*(x176*x365 + x252 + x379) + x384 + x385 + x387;
}
if (x167) {
   result[7] = x131*(29.100619163536336*x193 + x286 + x389 + x392*x47) - x213*x393 + x395 + x397;
}
else {
   result[7] = x187*(x176*x392 + 87.301857490609009*x193 + x301 + x398) - x224*x399 + x401 + x405;
}
if (x167) {
   result[8] = x131*(x319 + x369 + x408*x47) + x371 + x375 + x410 + x412;
}
else {
   result[8] = x187*(x176*x408 + x330 + x379) + x381 + x385 + x414 + x416;
}
if (x167) {
   result[9] = x131*(x234 + x423 + x427*x47) - x247 - x428 - x431;
}
else {
   result[9] = x187*(x176*x427 + x251 + x432) - x256 - x433 - x435;
}
if (x167) {
   result[10] = x131*(29.100619163536336*x233 + x286 + x440 + x443*x47) - x246*x393 + x395 + x446;
}
else {
   result[10] = x187*(x176*x443 + 87.301857490609009*x233 + x301 + x447) - x255*x399 + x405 + x450;
}
if (x167) {
   result[11] = x131*(x239 + x319 + x452 + x453*x47) + x353 + x377 + x412 + x455;
}
else {
   result[11] = x187*(x176*x453 + x252 + x330 + x456) + x360 + x387 + x416 + x458;
}
if (x167) {
   result[12] = x131*(58.201238327072673*x271 + x47*x480 + x471) - x296*x481 - x485 + 0.5714285714285714*x52*x84;
}
else {
   result[12] = 0.19047619047619049*x184*x52 + x187*(x176*x480 + 174.60371498121802*x271 + x486) - x304*x487 - x489;
}
if (x167) {
   result[13] = x131*(x286 + 29.100619163536336*x312 + x47*x495 + x492) - x325*x393 + x395 + x499;
}
else {
   result[13] = x187*(x176*x495 + x301 + 87.301857490609009*x312 + x500) - x333*x399 + x404 + x504;
}
if (x167) {
   result[14] = x131*(x313 + x47*x511 + x508) - x326 - x428 - x513;
}
else {
   result[14] = x187*(x176*x511 + x329 + x514) - x334 - x433 - x516;
}
if (x167) {
   result[15] = x131*(x359 + x47*x525) + 0.1399416909620991*x354 - x356*x517 + x51;
}
else {
   result[15] = x180 + x187*(x176*x525 + 74.830163563379159*x527) + 0.046647230320699715*x361 - x362*x526;
}
if (x167) {
   result[16] = -x528 + x529 + x535;
}
else {
   result[16] = -x536 + x537 + x539;
}
if (x167) {
   result[17] = x131*(x47*x541 + 29.100619163536336*x527 + 16.628925236306479*x540) - x214*x396 + 0.32653061224489793*x354 - x356*x393 + x394;
}
else {
   result[17] = x187*(x176*x541 + 87.301857490609009*x527 + 49.886775708919437*x540) - x225*x400 + 0.108843537414966*x361 - x362*x399 + x403;
}
if (x167) {
   result[18] = x411 + x51 + x535 - x542;
}
else {
   result[18] = x180 + x415 + x539 - x543;
}
if (x167) {
   result[19] = x131*(x423 + x546) - x217 - x431 - x528;
}
else {
   result[19] = x187*(x432 + x547) - x228 - x435 - x536;
}
if (x167) {
   result[20] = x131*(x440 + x47*x550 + x551) - x373*x393 + x446 + x552;
}
else {
   result[20] = x187*(x176*x550 + x447 + x553) - x383*x399 + x401 + x403 + x450;
}
if (x167) {
   result[21] = x131*(x452 + x546) + x374 + x410 + x411 + x455 + x529;
}
else {
   result[21] = x187*(x456 + x547) + x384 + x414 + x415 + x458 + x537;
}
if (x167) {
   result[22] = x131*(x47*x554 + x471 + 58.201238327072673*x540) + 0.5714285714285714*x216*x52 - x396*x481 - x485;
}
else {
   result[22] = x187*(x176*x554 + x486 + 174.60371498121802*x540) + 0.19047619047619049*x227*x52 - x400*x487 - x489;
}
if (x167) {
   result[23] = x131*(x47*x555 + x492 + x551) - x393*x409 + x499 + x552;
}
else {
   result[23] = x187*(x176*x555 + x500 + x553) - x399*x413 + x401 + x504;
}
if (x167) {
   result[24] = x131*(x508 + x546) - x217 - x513 - x542;
}
else {
   result[24] = x187*(x514 + x547) - x228 - x516 - x543;
}
if (x167) {
   result[25] = x131*(x432 + x47*x560) - x430*x517 + 0.1399416909620991*x444 + x51;
}
else {
   result[25] = x180 + x187*(x176*x560 + 74.830163563379159*x561) - x434*x526 + 0.046647230320699715*x448;
}
if (x167) {
   result[26] = x131*(x47*x564 + 29.100619163536336*x561 + 16.628925236306479*x562) - x214*x445 + 0.32653061224489793*x248*x52 - x300 - x393*x430;
}
else {
   result[26] = x187*(x176*x564 + 87.301857490609009*x561 + 49.886775708919437*x562) - x225*x449 + 0.108843537414966*x257*x52 - x308 - x399*x434;
}
if (x167) {
   result[27] = x131*(x423 + x47*x567 + x566) - x328 - x431 - x568;
}
else {
   result[27] = x187*(x176*x567 + x432 + x569) - x336 - x435 - x570;
}
if (x167) {
   result[28] = x131*(x47*x573 + x471 + 58.201238327072673*x562) + 0.5714285714285714*x248*x52 - x445*x481 - x485;
}
else {
   result[28] = x187*(x176*x573 + x486 + 174.60371498121802*x562) + 0.19047619047619049*x257*x52 - x449*x487 - x489;
}
if (x167) {
   result[29] = x131*(x440 + x47*x574 + x492 + 29.100619163536336*x565) - x393*x454 + x394 + x446 + x499;
}
else {
   result[29] = x187*(x176*x574 + x447 + x500 + 87.301857490609009*x565) - x399*x457 + x450 + x504;
}
if (x167) {
   result[30] = x131*(x47*x575 + x508 + x566) - x249 - x513 - x568;
}
else {
   result[30] = x187*(x176*x575 + x514 + x569) - x258 - x516 - x570;
}
if (x167) {
   result[31] = x131*(x47*x583 + 87.301857490609009*x576) + 1.7142857142857142*x299*x52 - 0.8571428571428571*x483*x86 - 1.7142857142857142*x49;
}
else {
   result[31] = -0.57142857142857151*x178 + x187*(x176*x583 + 261.90557247182704*x576) + 0.57142857142857151*x306*x52 - 0.28571428571428575*x488*x86;
}
if (x167) {
   result[32] = x131*(x47*x587 + x471 + 58.201238327072673*x584) + 0.5714285714285714*x327*x52 - x481*x498 - x484 - 0.48979591836734687*x49;
}
else {
   result[32] = x187*(x176*x587 + x486 + 174.60371498121802*x584) + 0.19047619047619049*x335*x52 - x487*x502 - x489;
}
if (x167) {
   result[33] = x131*(x47*x589 + 16.628925236306479*x584 + 29.100619163536336*x588) - x214*x498 - x300 + 0.32653061224489793*x327*x52 - x393*x512;
}
else {
   result[33] = x187*(x176*x589 + 49.886775708919437*x584 + 87.301857490609009*x588) - x225*x502 - x307 + 0.108843537414966*x335*x52 - x399*x515 - x503;
}
if (x167) {
   result[34] = x131*(x47*x590 + x514) + 0.1399416909620991*x496 + x51 - x512*x517;
}
else {
   result[34] = x180 + x187*(x176*x590 + 74.830163563379159*x588) + 0.046647230320699715*x501 - x515*x526;
}
}
        
static double coder_dgdt(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].dmu0dT)(T, P);
    double x1 = n2*(*endmember[1].dmu0dT)(T, P);
    double x2 = n3*(*endmember[2].dmu0dT)(T, P);
    double x3 = n4*(*endmember[3].dmu0dT)(T, P);
    double x4 = n5*(*endmember[4].dmu0dT)(T, P);
    double x5 = n1 + n3;
    double x6 = n4 + n5;
    double x7 = 1.0/(n2 + x5 + x6);
    double x8 = n2*log(n2*x7);
    double x9 = n3*log(n3*x7);
    double x10 = n5*log(n5*x7);
    double x11 = n4*(log(n4*x7) - 0.69314718055994495);
    double x12 = x5*log(x5*x7);
    double x13 = x6*log(x6*x7);
    double x14 = n1 + n2 + n4;
    double x15 = x14*log(x14*x7);
    double x16 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 1.0*n5;
    double x17 = (2.0*n1 + 2.0*n2 + 2.0*n3 + 1.0*n4 + 2.0*n5)*log(x7*(0.5*n4 + x16));
    double x18 = sqrt(1 - 0.19999999999999998*T);
    double x19 = 1.0*x18;
    double x20 = fmin(4, x19);
    double x21 = (4 - x19 >= 0. ? 1. : 0.)/x18;

if (T >= 5.0) {
   result = -13.381349999999999*n2 + x0 + x1 + 8.3144626181532395*x10 + 8.3144626181532395*x11 + 8.3144626181532395*x12 + 8.3144626181532395*x13 + 8.3144626181532395*x15 + 8.3144626181532395*x17 + x2 + x3 + x4 + 8.3144626181532395*x8 + 8.3144626181532395*x9;
}
else {
   result = (3.5*n4 + x16)*(n2*(-20.072025*((x20)*(x20))*x21 + 40.14405*x20 - 0.099999999999999992*x21*(40.14405*T - 200.72024999999999) - 40.14405) + 3*x0 + 3*x1 + 24.943387854459719*x10 + 24.943387854459719*x11 + 24.943387854459719*x12 + 24.943387854459719*x13 + 24.943387854459719*x15 + 24.943387854459719*x17 + 3*x2 + 3*x3 + 3*x4 + 24.943387854459719*x8 + 24.943387854459719*x9)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = n1 + n3;
    double x2 = n4 + n5;
    double x3 = n2 + x1 + x2;
    double x4 = 1.0/x3;
    double x5 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 1.0*n5;
    double x6 = 0.5*n4 + x5;
    double x7 = log(x4*x6);
    double x8 = 16.628925236306479*x7;
    double x9 = n2*x4;
    double x10 = -8.3144626181532395*x9;
    double x11 = n3*x4;
    double x12 = -8.3144626181532395*x11;
    double x13 = n4*x4;
    double x14 = -8.3144626181532395*x13;
    double x15 = 8.3144626181532395*x3;
    double x16 = pow(x3, -2);
    double x17 = x16*x6;
    double x18 = -x17 + 1.0*x4;
    double x19 = 2.0*n1 + 2.0*n2 + 2.0*n3 + 1.0*n4 + 2.0*n5;
    double x20 = 1.0/x6;
    double x21 = x19*x20;
    double x22 = x18*x21;
    double x23 = x15*x22;
    double x24 = x10 + x12 + x14 + x23 + x8;
    double x25 = n1 + n2 + n4;
    double x26 = x25*x4;
    double x27 = log(x26);
    double x28 = -x4;
    double x29 = -x16*x25 - x28;
    double x30 = n5*x4;
    double x31 = -8.3144626181532395*x30;
    double x32 = x15*x29 + 8.3144626181532395*x27 + x31;
    double x33 = x1*x4;
    double x34 = log(x33);
    double x35 = -x1*x16 - x28;
    double x36 = x2*x4;
    double x37 = -8.3144626181532395*x36;
    double x38 = x15*x35 + 8.3144626181532395*x34 + x37;
    double x39 = T >= 5.0;
    double x40 = 3*x0;
    double x41 = 49.886775708919437*x7;
    double x42 = -24.943387854459719*x9;
    double x43 = 24.943387854459719*x11;
    double x44 = -x43;
    double x45 = 24.943387854459719*x13;
    double x46 = -x45;
    double x47 = 24.943387854459719*x3;
    double x48 = x22*x47;
    double x49 = x41 + x42 + x44 + x46 + x48;
    double x50 = 24.943387854459719*x27;
    double x51 = 24.943387854459719*x30;
    double x52 = -x51;
    double x53 = x29*x47 + x50 + x52;
    double x54 = 24.943387854459719*x34;
    double x55 = 24.943387854459719*x36;
    double x56 = x35*x47 + x54 - x55;
    double x57 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x58 = 3.5*n4 + x5;
    double x59 = x57*x58;
    double x60 = (*endmember[1].dmu0dT)(T, P);
    double x61 = (*endmember[2].dmu0dT)(T, P);
    double x62 = 3*x61;
    double x63 = (*endmember[3].dmu0dT)(T, P);
    double x64 = 3*x63;
    double x65 = (*endmember[4].dmu0dT)(T, P);
    double x66 = 3*x65;
    double x67 = log(x9);
    double x68 = log(x11);
    double x69 = 24.943387854459719*x68;
    double x70 = log(x30);
    double x71 = 24.943387854459719*x70;
    double x72 = log(x13);
    double x73 = log(x36);
    double x74 = 24.943387854459719*x73;
    double x75 = 24.943387854459719*x7;
    double x76 = sqrt(1 - 0.19999999999999998*T);
    double x77 = 1.0*x76;
    double x78 = fmin(4, x77);
    double x79 = (4 - x77 >= 0. ? 1. : 0.)/x76;
    double x80 = 20.072025*((x78)*(x78))*x79 - 40.14405*x78 + 0.099999999999999992*x79*(40.14405*T - 200.72024999999999) + 40.14405;
    double x81 = n1*x40 + 3*n2*x60 + 24.943387854459719*n2*x67 - n2*x80 + n3*x62 + n3*x69 + n4*x64 + 24.943387854459719*n4*(x72 - 0.69314718055994495) + n5*x66 + n5*x71 + x1*x54 + x19*x75 + x2*x74 + x25*x50;
    double x82 = x57*x81;
    double x83 = x58*x81/((0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5)*(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5));
    double x84 = 1.0*x82 - 0.027210884353741499*x83;
    double x85 = -8.3144626181532395*x33;
    double x86 = -n2*x16 - x28;
    double x87 = x14 + x23 + x8;
    double x88 = x12 + x32;
    double x89 = 24.943387854459719*x33;
    double x90 = -n3*x16 - x28;
    double x91 = -8.3144626181532395*x26;
    double x92 = -24.943387854459719*x26;
    double x93 = -n4*x16 - x28;
    double x94 = x21*(-x17 + 0.5*x4);
    double x95 = -x16*x2 - x28;
    double x96 = x15*x95 + 8.3144626181532395*x73 + x85;
    double x97 = x47*x95 + x74 - x89;
    double x98 = -n5*x16 - x28;

if (x39) {
   result[0] = x0 + x24 + x32 + x38;
}
else {
   result[0] = x59*(x40 + x49 + x53 + x56) + x84;
}
if (x39) {
   result[1] = x15*x86 + x37 + x60 + 8.3144626181532395*x67 + x85 + x87 + x88 - 13.381349999999999;
}
else {
   result[1] = x59*(24.943387854459719*x18*x19*x20*x3 + 24.943387854459719*x27 + 24.943387854459719*x29*x3 + 24.943387854459719*x3*x86 - x43 - x45 - x51 - x55 + 3*x60 + 24.943387854459719*x67 + 49.886775708919437*x7 - x80 - x89) + x84;
}
if (x39) {
   result[2] = x10 + x15*x90 + x31 + x38 + x61 + 8.3144626181532395*x68 + x87 + x91;
}
else {
   result[2] = x59*(x41 + x42 + x46 + x47*x90 + x48 + x52 + x56 + x62 + x69 + x92) + x84;
}
if (x39) {
   result[3] = x10 + x15*x93 + x15*x94 + x63 + 8.3144626181532395*x7 + 8.3144626181532395*x72 + x88 + x96 - 5.7631463216439762;
}
else {
   result[3] = x59*(x42 + x44 + x47*x93 + x47*x94 + x53 + x64 + 24.943387854459719*x72 + x75 + x97 - 17.289438964931929) + 3.5*x82 - 0.095238095238095247*x83;
}
if (x39) {
   result[4] = x15*x98 + x24 + x65 + 8.3144626181532395*x70 + x91 + x96;
}
else {
   result[4] = x59*(x47*x98 + x49 + x66 + x71 + x92 + x97) + x84;
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n4 + n5;
    double x1 = n1 + n3;
    double x2 = n2 + x0 + x1;
    double x3 = pow(x2, -2);
    double x4 = -2*x3;
    double x5 = n1 + n2 + n4;
    double x6 = 2/((x2)*(x2)*(x2));
    double x7 = x5*x6;
    double x8 = x4 + x7;
    double x9 = 8.3144626181532395*x2;
    double x10 = x8*x9;
    double x11 = 1.0/x2;
    double x12 = -x11;
    double x13 = x3*x5;
    double x14 = -x12 - x13;
    double x15 = 1.0/x5;
    double x16 = x14*x15*x9;
    double x17 = n2*x3;
    double x18 = 8.3144626181532395*x17;
    double x19 = n3*x3;
    double x20 = 8.3144626181532395*x19;
    double x21 = n5*x3;
    double x22 = 8.3144626181532395*x21;
    double x23 = 8.3144626181532395*x13;
    double x24 = -x23;
    double x25 = x18 + x20 + x22 + x24;
    double x26 = x10 + x16 + x25;
    double x27 = 16.628925236306479*x11;
    double x28 = x1*x3;
    double x29 = 8.3144626181532395*x28;
    double x30 = -x29;
    double x31 = x1*x6;
    double x32 = x31 + x4;
    double x33 = -x12 - x28;
    double x34 = 1.0/x1;
    double x35 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 1.0*n5;
    double x36 = 0.5*n4 + x35;
    double x37 = 1.0/x36;
    double x38 = x3*x36;
    double x39 = 1.0*x11 - x38;
    double x40 = x37*x39;
    double x41 = x2*x40;
    double x42 = 2.0*n1 + 2.0*n2 + 2.0*n3 + 1.0*n4 + 2.0*n5;
    double x43 = x42*x9;
    double x44 = x36*x6;
    double x45 = x37*(-2.0*x3 + x44);
    double x46 = pow(x36, -2);
    double x47 = x39*x46;
    double x48 = 33.257850472612958*x41 + x43*x45 - x43*x47;
    double x49 = n4*x3;
    double x50 = 8.3144626181532395*x49;
    double x51 = x0*x3;
    double x52 = 8.3144626181532395*x51;
    double x53 = x40*x42;
    double x54 = 8.3144626181532395*x53;
    double x55 = x50 + x52 + x54;
    double x56 = x48 + x55;
    double x57 = x30 + x32*x9 + x33*x34*x9 + x56;
    double x58 = x27 + x57;
    double x59 = T >= 5.0;
    double x60 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x61 = 3*(*endmember[0].dmu0dT)(T, P);
    double x62 = log(x11*x36);
    double x63 = 49.886775708919437*x62;
    double x64 = n2*x11;
    double x65 = -24.943387854459719*x64;
    double x66 = n3*x11;
    double x67 = 24.943387854459719*x66;
    double x68 = -x67;
    double x69 = n4*x11;
    double x70 = 24.943387854459719*x69;
    double x71 = -x70;
    double x72 = 24.943387854459719*x2;
    double x73 = x53*x72;
    double x74 = x63 + x65 + x68 + x71 + x73;
    double x75 = x11*x5;
    double x76 = log(x75);
    double x77 = 24.943387854459719*x76;
    double x78 = x14*x72;
    double x79 = n5*x11;
    double x80 = 24.943387854459719*x79;
    double x81 = -x80;
    double x82 = x77 + x78 + x81;
    double x83 = x1*x11;
    double x84 = 24.943387854459719*log(x83);
    double x85 = x33*x72;
    double x86 = x0*x11;
    double x87 = 24.943387854459719*x86;
    double x88 = x84 + x85 - x87;
    double x89 = x61 + x74 + x82 + x88;
    double x90 = x60*x89;
    double x91 = x72*x8;
    double x92 = x15*x78;
    double x93 = 24.943387854459719*x17;
    double x94 = 24.943387854459719*x19;
    double x95 = 24.943387854459719*x21;
    double x96 = 24.943387854459719*x13;
    double x97 = -x96;
    double x98 = x93 + x94 + x95 + x97;
    double x99 = x91 + x92 + x98;
    double x100 = 49.886775708919437*x11;
    double x101 = 24.943387854459719*x28;
    double x102 = -x101;
    double x103 = x42*x72;
    double x104 = x103*x45 - x103*x47 + 99.773551417838874*x41;
    double x105 = 24.943387854459719*x49;
    double x106 = 24.943387854459719*x51;
    double x107 = 24.943387854459719*x53;
    double x108 = x105 + x106 + x107;
    double x109 = x104 + x108;
    double x110 = x102 + x109 + x32*x72 + x34*x85;
    double x111 = x100 + x110;
    double x112 = 3.5*n4 + x35;
    double x113 = x112*x60;
    double x114 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x115 = pow(x114, -2);
    double x116 = x112*x115;
    double x117 = x116*x89;
    double x118 = (*endmember[1].dmu0dT)(T, P);
    double x119 = 3*(*endmember[2].dmu0dT)(T, P);
    double x120 = 3*(*endmember[3].dmu0dT)(T, P);
    double x121 = 3*(*endmember[4].dmu0dT)(T, P);
    double x122 = log(x64);
    double x123 = 24.943387854459719*log(x66);
    double x124 = 24.943387854459719*log(x79);
    double x125 = log(x69);
    double x126 = 24.943387854459719*log(x86);
    double x127 = 24.943387854459719*x62;
    double x128 = sqrt(1 - 0.19999999999999998*T);
    double x129 = 1.0*x128;
    double x130 = fmin(4, x129);
    double x131 = (4 - x129 >= 0. ? 1. : 0.)/x128;
    double x132 = 20.072025*((x130)*(x130))*x131 - 40.14405*x130 + 0.099999999999999992*x131*(40.14405*T - 200.72024999999999) + 40.14405;
    double x133 = n1*x61 + 3*n2*x118 + 24.943387854459719*n2*x122 - n2*x132 + n3*x119 + n3*x123 + n4*x120 + 24.943387854459719*n4*(x125 - 0.69314718055994495) + n5*x121 + n5*x124 + x0*x126 + x1*x84 + x127*x42 + x5*x77;
    double x134 = x115*x133;
    double x135 = x112*x133/((x114)*(x114)*(x114));
    double x136 = -0.054421768707482998*x134 + 0.01554907677356657*x135;
    double x137 = -x3;
    double x138 = x137 + x31;
    double x139 = x138*x9 + x30 + x50 + x52 + x54;
    double x140 = x139 + x48;
    double x141 = x102 + x105 + x106 + x107 + x138*x72;
    double x142 = x104 + x141;
    double x143 = -0.027210884353741499*x117 + x136 + 1.0*x90;
    double x144 = 24.943387854459719*x83;
    double x145 = -x12 - x17;
    double x146 = 3*x118 + 24.943387854459719*x122 - x132 + 24.943387854459719*x14*x2 - x144 + 24.943387854459719*x145*x2 + 24.943387854459719*x2*x37*x39*x42 + 49.886775708919437*x62 - x67 - x70 + 24.943387854459719*x76 - x80 - x87;
    double x147 = 1.0*x60;
    double x148 = 0.027210884353741499*x116;
    double x149 = x146*x147 - x146*x148;
    double x150 = x137 + x7;
    double x151 = x150*x9;
    double x152 = x151 + x25;
    double x153 = x150*x72;
    double x154 = x153 + x98;
    double x155 = -x12 - x19;
    double x156 = x155*x72;
    double x157 = -24.943387854459719*x75;
    double x158 = x119 + x123 + x156 + x157 + x63 + x65 + x71 + x73 + x81 + x88;
    double x159 = x147*x158 - x148*x158;
    double x160 = -8.3144626181532395*x11;
    double x161 = x2*x42;
    double x162 = x161*x47;
    double x163 = 0.5*x11 - x38;
    double x164 = x163*x37;
    double x165 = x164*x2;
    double x166 = 16.628925236306479*x165;
    double x167 = x37*(-1.5*x3 + x44);
    double x168 = x166 + x167*x43 + x40*x9;
    double x169 = -4.1572313090766198*x162 + x168;
    double x170 = x139 + x169;
    double x171 = 24.943387854459719*x11;
    double x172 = -x171;
    double x173 = 49.886775708919437*x165;
    double x174 = x103*x167 + x173 + x40*x72;
    double x175 = -12.471693927229859*x162 + x174;
    double x176 = x141 + x175;
    double x177 = -x12 - x49;
    double x178 = x177*x72;
    double x179 = x164*x42;
    double x180 = -x12 - x51;
    double x181 = x180*x72;
    double x182 = x126 - x144 + x181;
    double x183 = x120 + 24.943387854459719*x125 + x127 + x178 + x179*x72 + x182 + x65 + x68 + x82 - 17.289438964931929;
    double x184 = -0.19047619047619049*x134 + 0.054421768707482998*x135 + x147*x183 - x148*x183;
    double x185 = -x27;
    double x186 = x140 + x185;
    double x187 = -x100;
    double x188 = x142 + x187;
    double x189 = -x12 - x21;
    double x190 = x189*x72;
    double x191 = x121 + x124 + x157 + x182 + x190 + x74;
    double x192 = x147*x191 - x148*x191;
    double x193 = n2*x6;
    double x194 = x193 + x4;
    double x195 = 1.0/n2;
    double x196 = -x18;
    double x197 = x20 + x29;
    double x198 = x196 + x197 + x22 + x24 + x56;
    double x199 = x10 + x16;
    double x200 = x146*x60;
    double x201 = -x93;
    double x202 = x101 + x94;
    double x203 = x109 + x201 + x202 + x95 + x97;
    double x204 = x91 + x92;
    double x205 = x116*x146;
    double x206 = x137 + x193;
    double x207 = x206*x9;
    double x208 = x151 + x185 + x198 + x207;
    double x209 = x136 + x159;
    double x210 = x206*x72;
    double x211 = x113*(x153 + x187 + x203 + x210) + x149;
    double x212 = n3*x6;
    double x213 = x212 + x4;
    double x214 = 1.0/n3;
    double x215 = x18 + x23;
    double x216 = -x20 + x215 + x22;
    double x217 = x158*x60;
    double x218 = x93 + x96;
    double x219 = x218 - x94 + x95;
    double x220 = x116*x158;
    double x221 = x137 + x212;
    double x222 = x216 + x221*x9;
    double x223 = 74.830163563379159*x11;
    double x224 = x219 + x221*x72;
    double x225 = n4*x6;
    double x226 = x225 + x4;
    double x227 = 1.0/n4;
    double x228 = x37*(-1.0*x3 + x44);
    double x229 = x163*x46;
    double x230 = x161*x229;
    double x231 = x0*x6 + x4;
    double x232 = 1.0/x0;
    double x233 = x180*x232*x9 + x231*x9 - x52;
    double x234 = 8.3144626181532395*x179 + x233 + x29 - x50;
    double x235 = -x106 + x181*x232 + x231*x72;
    double x236 = x101 - x105 + 24.943387854459719*x179 + x235;
    double x237 = x137 + x225;
    double x238 = x191*x60;
    double x239 = x116*x191;
    double x240 = n5*x6 + x4;
    double x241 = 1.0/n5;

if (x59) {
   result[0] = x26 + x58;
}
else {
   result[0] = x113*(x111 + x99) - 0.054421768707482998*x117 + x136 + 2.0*x90;
}
if (x59) {
   result[1] = x140 + x26;
}
else {
   result[1] = x113*(x142 + x99) + x143 + x149;
}
if (x59) {
   result[2] = x152 + x57;
}
else {
   result[2] = x113*(x110 + x154) + x143 + x159;
}
if (x59) {
   result[3] = x160 + x170 + x26;
}
else {
   result[3] = x113*(x172 + x176 + x99) - 0.095238095238095247*x117 + x184 + 3.5*x90;
}
if (x59) {
   result[4] = x152 + x186;
}
else {
   result[4] = x113*(x154 + x188) + x143 + x192;
}
if (x59) {
   result[5] = x145*x195*x9 + x194*x9 + x198 + x199 + x27;
}
else {
   result[5] = x113*(x100 + x145*x195*x72 + x194*x72 + x203 + x204) + x136 + 2.0*x200 - 0.054421768707482998*x205;
}
if (x59) {
   result[6] = x208;
}
else {
   result[6] = x209 + x211;
}
if (x59) {
   result[7] = x160 + x169 + x196 + x197 + x199 + x207 + x22 + x24 + x55;
}
else {
   result[7] = x113*(x108 + x172 + x175 + x201 + x202 + x204 + x210 + x95 + x97) + x184 + 3.5*x200 - 0.095238095238095247*x205;
}
if (x59) {
   result[8] = x208;
}
else {
   result[8] = x136 + x192 + x211;
}
if (x59) {
   result[9] = x155*x214*x9 + x213*x9 + x216 + x58;
}
else {
   result[9] = x113*(x111 + x156*x214 + x213*x72 + x219) + x136 + 2.0*x217 - 0.054421768707482998*x220;
}
if (x59) {
   result[10] = x170 + x172 + x222;
}
else {
   result[10] = x113*(x176 - x223 + x224) + x184 + 3.5*x217 - 0.095238095238095247*x220;
}
if (x59) {
   result[11] = x186 + x222;
}
else {
   result[11] = x113*(x188 + x224) + x192 + x209;
}
if (x59) {
   result[12] = x166 + x171 + x177*x227*x9 + x226*x9 + x228*x43 - 4.1572313090766198*x230 + x234 + x26;
}
else {
   result[12] = x113*(x103*x228 + x173 + x178*x227 + x223 + x226*x72 - 12.471693927229859*x230 + x236 + x99) - 0.19047619047619049*x116*x183 - 0.66666666666666674*x134 + 0.19047619047619049*x135 + 7.0*x183*x60;
}
if (x59) {
   result[13] = x152 + x168 - x229*x43 + x234 + x237*x9;
}
else {
   result[13] = x113*(-x103*x229 + x154 + x174 + x236 + x237*x72) + x184 + 3.5*x238 - 0.095238095238095247*x239;
}
if (x59) {
   result[14] = x189*x241*x9 + x197 + x215 - x22 + x233 + x240*x9 + x27 + x48 + x50 + x54;
}
else {
   result[14] = x113*(x100 + x104 + x105 + x107 + x190*x241 + x202 + x218 + x235 + x240*x72 - x95) + x136 + 2.0*x238 - 0.054421768707482998*x239;
}
}
        
static void coder_d4gdn3dt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n1 + n2 + n4;
    double x1 = 1.0/x0;
    double x2 = n1 + n3;
    double x3 = n4 + n5;
    double x4 = n2 + x2 + x3;
    double x5 = 1.0/x4;
    double x6 = -x5;
    double x7 = pow(x4, -2);
    double x8 = x0*x7;
    double x9 = -x6 - x8;
    double x10 = x1*x9;
    double x11 = 8.3144626181532395*x10;
    double x12 = pow(x4, -3);
    double x13 = 33.257850472612958*x12;
    double x14 = x0*x13;
    double x15 = 16.628925236306479*x12;
    double x16 = -n2*x15;
    double x17 = -n3*x15;
    double x18 = -n5*x15;
    double x19 = x14 + x16 + x17 + x18;
    double x20 = x11 + x19;
    double x21 = -6*x12;
    double x22 = 6/((x4)*(x4)*(x4)*(x4));
    double x23 = x0*x22;
    double x24 = -x21 - x23;
    double x25 = 8.3144626181532395*x4;
    double x26 = -2*x7;
    double x27 = 2*x12;
    double x28 = x0*x27;
    double x29 = x26 + x28;
    double x30 = x1*x25;
    double x31 = pow(x0, -2);
    double x32 = x24*x25 - x25*x31*x9 + x29*x30;
    double x33 = x20 + x32;
    double x34 = 1.0/x2;
    double x35 = x2*x7;
    double x36 = -x35 - x6;
    double x37 = x34*x36;
    double x38 = 8.3144626181532395*x37;
    double x39 = -66.515700945225916*x7;
    double x40 = x2*x22;
    double x41 = -x21 - x40;
    double x42 = x2*x27;
    double x43 = x26 + x42;
    double x44 = x25*x34;
    double x45 = pow(x2, -2);
    double x46 = -n4*x15;
    double x47 = -x15*x3 + x46;
    double x48 = x13*x2 + x47;
    double x49 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 1.0*n5;
    double x50 = 0.5*n4 + x49;
    double x51 = 1.0/x50;
    double x52 = x50*x7;
    double x53 = 1.0*x5 - x52;
    double x54 = x51*x53;
    double x55 = 49.886775708919437*x54;
    double x56 = x27*x50;
    double x57 = x56 - 2.0*x7;
    double x58 = x51*x57;
    double x59 = 2.0*n1 + 2.0*n2 + 2.0*n3 + 1.0*n4 + 2.0*n5;
    double x60 = 16.628925236306479*x59;
    double x61 = 49.886775708919437*x4;
    double x62 = pow(x50, -2);
    double x63 = x53*x62;
    double x64 = -x61*x63;
    double x65 = x25*x59;
    double x66 = x22*x50;
    double x67 = x51*(6.0*x12 - x66);
    double x68 = x4*x60;
    double x69 = pow(x50, -3);
    double x70 = x53*x69;
    double x71 = x57*x62;
    double x72 = x55 + x58*x60 + x58*x61 - x60*x63 + x64 + x65*x67 + x68*x70 - x68*x71;
    double x73 = x48 + x72;
    double x74 = -x25*x36*x45 + x25*x41 + x43*x44 + x73;
    double x75 = x38 + x39 + x74;
    double x76 = T >= 5.0;
    double x77 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x78 = 24.943387854459719*x4;
    double x79 = x29*x78;
    double x80 = x10*x78;
    double x81 = n2*x7;
    double x82 = 24.943387854459719*x81;
    double x83 = n3*x7;
    double x84 = 24.943387854459719*x83;
    double x85 = n5*x7;
    double x86 = 24.943387854459719*x85;
    double x87 = 24.943387854459719*x8;
    double x88 = -x87;
    double x89 = x82 + x84 + x86 + x88;
    double x90 = x79 + x80 + x89;
    double x91 = 49.886775708919437*x5;
    double x92 = 24.943387854459719*x35;
    double x93 = -x92;
    double x94 = x43*x78;
    double x95 = 99.773551417838874*x4;
    double x96 = x58*x78;
    double x97 = x59*x63;
    double x98 = x54*x95 + x59*x96 - x78*x97;
    double x99 = n4*x7;
    double x100 = 24.943387854459719*x99;
    double x101 = x3*x7;
    double x102 = 24.943387854459719*x101;
    double x103 = 24.943387854459719*x54;
    double x104 = x103*x59;
    double x105 = x100 + x102 + x104;
    double x106 = x105 + x98;
    double x107 = x106 + x37*x78 + x93 + x94;
    double x108 = x107 + x91;
    double x109 = x108 + x90;
    double x110 = x109*x77;
    double x111 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x112 = pow(x111, -2);
    double x113 = 3*(*endmember[0].dmu0dT)(T, P);
    double x114 = log(x5*x50);
    double x115 = 49.886775708919437*x114;
    double x116 = n2*x5;
    double x117 = -24.943387854459719*x116;
    double x118 = n3*x5;
    double x119 = 24.943387854459719*x118;
    double x120 = -x119;
    double x121 = n4*x5;
    double x122 = 24.943387854459719*x121;
    double x123 = -x122;
    double x124 = x54*x78;
    double x125 = x124*x59;
    double x126 = x115 + x117 + x120 + x123 + x125;
    double x127 = x0*x5;
    double x128 = log(x127);
    double x129 = 24.943387854459719*x128;
    double x130 = x78*x9;
    double x131 = n5*x5;
    double x132 = 24.943387854459719*x131;
    double x133 = -x132;
    double x134 = x129 + x130 + x133;
    double x135 = x2*x5;
    double x136 = 24.943387854459719*log(x135);
    double x137 = x36*x78;
    double x138 = x3*x5;
    double x139 = 24.943387854459719*x138;
    double x140 = x136 + x137 - x139;
    double x141 = x113 + x126 + x134 + x140;
    double x142 = x112*x141;
    double x143 = 24.943387854459719*x10;
    double x144 = 99.773551417838874*x12;
    double x145 = x0*x144;
    double x146 = 49.886775708919437*x12;
    double x147 = -n2*x146;
    double x148 = -n3*x146;
    double x149 = -n5*x146;
    double x150 = x145 + x147 + x148 + x149;
    double x151 = x143 + x150;
    double x152 = x1*x79 - x130*x31 + x24*x78;
    double x153 = x151 + x152;
    double x154 = 24.943387854459719*x37;
    double x155 = -199.54710283567778*x7;
    double x156 = -n4*x146;
    double x157 = -x146*x3 + x156;
    double x158 = x144*x2 + x157;
    double x159 = 149.66032712675832*x4;
    double x160 = 49.886775708919437*x59;
    double x161 = x59*x78;
    double x162 = x59*x61;
    double x163 = x159*x58 - x159*x63 + x160*x58 - x160*x63 + x161*x67 + x162*x70 - x162*x71 + 149.66032712675832*x54;
    double x164 = x158 + x163;
    double x165 = -x137*x45 + x164 + x34*x94 + x41*x78;
    double x166 = x154 + x155 + x165;
    double x167 = 3.5*n4 + x49;
    double x168 = x167*x77;
    double x169 = pow(x111, -3);
    double x170 = x167*x169;
    double x171 = x141*x170;
    double x172 = x112*x167;
    double x173 = x109*x172;
    double x174 = (*endmember[1].dmu0dT)(T, P);
    double x175 = 3*(*endmember[2].dmu0dT)(T, P);
    double x176 = 3*(*endmember[3].dmu0dT)(T, P);
    double x177 = 3*(*endmember[4].dmu0dT)(T, P);
    double x178 = log(x116);
    double x179 = 24.943387854459719*log(x118);
    double x180 = 24.943387854459719*log(x131);
    double x181 = log(x121);
    double x182 = 24.943387854459719*log(x138);
    double x183 = 24.943387854459719*x114;
    double x184 = sqrt(1 - 0.19999999999999998*T);
    double x185 = 1.0*x184;
    double x186 = fmin(4, x185);
    double x187 = (4 - x185 >= 0. ? 1. : 0.)/x184;
    double x188 = 20.072025*((x186)*(x186))*x187 - 40.14405*x186 + 0.099999999999999992*x187*(40.14405*T - 200.72024999999999) + 40.14405;
    double x189 = n1*x113 + 3*n2*x174 + 24.943387854459719*n2*x178 - n2*x188 + n3*x175 + n3*x179 + n4*x176 + 24.943387854459719*n4*(x181 - 0.69314718055994495) + n5*x177 + n5*x180 + x0*x129 + x136*x2 + x182*x3 + x183*x59;
    double x190 = x169*x189;
    double x191 = x167*x189/((x111)*(x111)*(x111)*(x111));
    double x192 = 0.046647230320699715*x190 - 0.013327780091628489*x191;
    double x193 = -x7;
    double x194 = x193 + x42;
    double x195 = x194*x44;
    double x196 = -4*x12;
    double x197 = -x196 - x40;
    double x198 = x197*x25;
    double x199 = x198 + x73;
    double x200 = x195 + x199;
    double x201 = 49.886775708919444*x7;
    double x202 = -x201 + x38;
    double x203 = x194*x78;
    double x204 = x203*x34;
    double x205 = x197*x78;
    double x206 = x164 + x205;
    double x207 = x204 + x206;
    double x208 = x154 - 149.66032712675832*x7;
    double x209 = x100 + x102 + x104 + x203 + x93;
    double x210 = x209 + x98;
    double x211 = x210 + x90;
    double x212 = 2.0*x77;
    double x213 = 0.054421768707482998*x112;
    double x214 = x167*x213;
    double x215 = x192 + x211*x212 - x211*x214;
    double x216 = 24.943387854459719*x135;
    double x217 = -x6 - x81;
    double x218 = 49.886775708919437*x114 - x119 - x122 + 24.943387854459719*x128 - x132 - x139 + 3*x174 + 24.943387854459719*x178 - x188 - x216 + 24.943387854459719*x217*x4 + 24.943387854459719*x4*x51*x53*x59 + 24.943387854459719*x4*x9;
    double x219 = 0.01554907677356657*x170;
    double x220 = -x213*x218 + x218*x219;
    double x221 = 1.0*x110 - 0.108843537414966*x142 + 0.031098153547133141*x171 - 0.027210884353741499*x173;
    double x222 = -x196 - x23;
    double x223 = x222*x25;
    double x224 = x193 + x28;
    double x225 = x223 + x224*x30;
    double x226 = x20 + x225;
    double x227 = x222*x78;
    double x228 = x224*x78;
    double x229 = x1*x228 + x227;
    double x230 = x151 + x229;
    double x231 = x192 + x221;
    double x232 = x228 + x89;
    double x233 = x107 + x232;
    double x234 = x212*x233 - x214*x233;
    double x235 = -x6 - x83;
    double x236 = x235*x78;
    double x237 = -24.943387854459719*x127;
    double x238 = x115 + x117 + x123 + x125 + x133 + x140 + x175 + x179 + x236 + x237;
    double x239 = -x213*x238 + x219*x238;
    double x240 = x195 + x20;
    double x241 = x56 - 1.5*x7;
    double x242 = x241*x62;
    double x243 = -x242*x65;
    double x244 = x198 + x243 + x38 + x48;
    double x245 = 8.3144626181532395*x59;
    double x246 = x241*x51;
    double x247 = x245*x246;
    double x248 = 12.471693927229859*x97;
    double x249 = x4*x59;
    double x250 = x249*x71;
    double x251 = x246*x4;
    double x252 = x51*(5.0*x12 - x66);
    double x253 = x25*x58 + 33.257850472612958*x251 + x252*x65;
    double x254 = x245*x58 + x247 - x248 - 4.1572313090766198*x250 + x253 + x65*x70;
    double x255 = -x63*x78;
    double x256 = x255 + 41.572313090766201*x54;
    double x257 = x254 + x256;
    double x258 = x257 - 41.572313090766201*x7;
    double x259 = -24.943387854459719*x5;
    double x260 = 0.5*x5 - x52;
    double x261 = x260*x51;
    double x262 = 49.886775708919437*x261;
    double x263 = x262*x4;
    double x264 = x124 + x161*x246 + x263;
    double x265 = -x248*x4 + x264;
    double x266 = x209 + x265;
    double x267 = x259 + x266 + x90;
    double x268 = x151 + x204;
    double x269 = -x161*x242;
    double x270 = x154 + x158 + x205 + x269;
    double x271 = 24.943387854459719*x59;
    double x272 = x246*x271;
    double x273 = x161*x252 + x246*x95 + x96;
    double x274 = x161*x70 - 12.471693927229859*x250 + x271*x58 + x272 + x273 - 37.41508178168958*x97;
    double x275 = x4*x63;
    double x276 = -74.830163563379159*x275 + 124.71693927229859*x54;
    double x277 = x274 + x276;
    double x278 = x277 - 124.71693927229859*x7;
    double x279 = -x6 - x99;
    double x280 = x279*x78;
    double x281 = -x101 - x6;
    double x282 = x281*x78;
    double x283 = x182 - x216 + x282;
    double x284 = x117 + x120 + x134 + x161*x261 + x176 + 24.943387854459719*x181 + x183 + x280 + x283 - 17.289438964931929;
    double x285 = 0.16326530612244899*x190 - x213*x284 + x219*x284;
    double x286 = -0.046647230320699715*x191 + x285;
    double x287 = x199 + x225;
    double x288 = 33.257850472612958*x7;
    double x289 = -x288;
    double x290 = x289 + x38;
    double x291 = x206 + x229;
    double x292 = -99.773551417838874*x7;
    double x293 = x154 + x292;
    double x294 = -x91;
    double x295 = x210 + x294;
    double x296 = x232 + x295;
    double x297 = x212*x296 - x214*x296;
    double x298 = -x6 - x85;
    double x299 = x298*x78;
    double x300 = x126 + x177 + x180 + x237 + x283 + x299;
    double x301 = -x213*x300 + x219*x300;
    double x302 = 24.943387854459719*x7;
    double x303 = -x302;
    double x304 = x20 + x303;
    double x305 = -2*x12;
    double x306 = -x305 - x40;
    double x307 = x25*x306 + x48;
    double x308 = x307 + x72;
    double x309 = 74.830163563379159*x7;
    double x310 = -x309;
    double x311 = x151 + x310;
    double x312 = x158 + x306*x78;
    double x313 = x163 + x312;
    double x314 = -0.054421768707482998*x142 + 0.01554907677356657*x171;
    double x315 = n2*x27;
    double x316 = x26 + x315;
    double x317 = x316*x78;
    double x318 = 1.0/n2;
    double x319 = x217*x78;
    double x320 = -x82;
    double x321 = x84 + x92;
    double x322 = x106 + x320 + x321 + x86 + x88;
    double x323 = x79 + x80;
    double x324 = x317 + x318*x319 + x322 + x323 + x91;
    double x325 = 1.0*x77;
    double x326 = x112*x218;
    double x327 = x170*x218;
    double x328 = 0.027210884353741499*x172;
    double x329 = x324*x325 - x324*x328 - 0.108843537414966*x326 + 0.031098153547133141*x327;
    double x330 = x192 + x314;
    double x331 = x233*x325 - x233*x328 + x239 + x330;
    double x332 = x193 + x315;
    double x333 = x332*x78;
    double x334 = x228 + x294 + x322 + x333;
    double x335 = x211*x325 - x211*x328 + x220 + x325*x334 - x328*x334;
    double x336 = x243 + x307;
    double x337 = 16.628925236306479*x7;
    double x338 = x254 - x337;
    double x339 = 3.5*x77;
    double x340 = x269 + x312;
    double x341 = x274 - 49.886775708919437*x7;
    double x342 = 0.095238095238095247*x172;
    double x343 = x105 + x259 + x265 + x320 + x321 + x323 + x333 + x86 + x88;
    double x344 = x325*x343 - 0.19047619047619049*x326 + 0.054421768707482998*x327 - x328*x343;
    double x345 = -0.19047619047619049*x142 + 0.054421768707482998*x171 + x267*x325 - x267*x328;
    double x346 = x286 + x345;
    double x347 = 8.3144626181532395*x7;
    double x348 = -x347;
    double x349 = x296*x325 - x296*x328;
    double x350 = -x23 - x305;
    double x351 = x25*x350;
    double x352 = x19 + x351;
    double x353 = x352 + x38;
    double x354 = x350*x78;
    double x355 = x150 + x354;
    double x356 = x154 + x355;
    double x357 = n3*x27;
    double x358 = x26 + x357;
    double x359 = x358*x78;
    double x360 = 1.0/n3;
    double x361 = x82 + x87;
    double x362 = x361 - x84 + x86;
    double x363 = x108 + x236*x360 + x359 + x362;
    double x364 = x112*x238;
    double x365 = x170*x238;
    double x366 = x325*x363 - x328*x363 - 0.108843537414966*x364 + 0.031098153547133141*x365;
    double x367 = x223 + x256;
    double x368 = x195 + x244;
    double x369 = x227 + x276;
    double x370 = x204 + x270;
    double x371 = 74.830163563379159*x5;
    double x372 = x193 + x357;
    double x373 = x372*x78;
    double x374 = x362 + x373;
    double x375 = x266 - x371 + x374;
    double x376 = x325*x375 - x328*x375 - 0.19047619047619049*x364 + 0.054421768707482998*x365;
    double x377 = x295 + x374;
    double x378 = x301 + x325*x377 - x328*x377;
    double x379 = 16.628925236306479*x261;
    double x380 = x336 + x379;
    double x381 = x260*x62;
    double x382 = x249*x70;
    double x383 = x246*x60 - x25*x63;
    double x384 = x56 - 1.0*x7;
    double x385 = x384*x51;
    double x386 = 16.628925236306479*x4;
    double x387 = x51*(4.0*x12 - x66);
    double x388 = 16.628925236306479*x251 + x385*x386 + x387*x65;
    double x389 = -x245*x63 - x25*x381 + 4.1572313090766198*x382 + x383 + x388 + 16.628925236306479*x54;
    double x390 = x348 + x389;
    double x391 = 7.0*x77;
    double x392 = x262 + x340;
    double x393 = x381*x78;
    double x394 = -x393;
    double x395 = x160*x246 + x255;
    double x396 = x161*x387 + x246*x61 + x385*x61;
    double x397 = 12.471693927229859*x382 + x394 + x395 + x396 + x55 - 24.943387854459719*x97;
    double x398 = x397 - 24.943387854459711*x7;
    double x399 = 0.19047619047619049*x172;
    double x400 = n4*x27;
    double x401 = x26 + x400;
    double x402 = x401*x78;
    double x403 = 1.0/n4;
    double x404 = x385*x78;
    double x405 = x381*x4;
    double x406 = 12.471693927229859*x405;
    double x407 = 24.943387854459719*x261;
    double x408 = x26 + x27*x3;
    double x409 = x408*x78;
    double x410 = 1.0/x3;
    double x411 = -x102 + x282*x410 + x409;
    double x412 = -x100 + x407*x59 + x411 + x92;
    double x413 = x263 + x280*x403 + x371 + x402 + x404*x59 - x406*x59 + x412 + x90;
    double x414 = x112*x284;
    double x415 = x170*x284;
    double x416 = 0.57142857142857151*x190 - 0.16326530612244899*x191 + x325*x413 - x328*x413 - 0.38095238095238099*x414 + 0.108843537414966*x415;
    double x417 = x103 - 16.628925236306479*x275 - x381*x386;
    double x418 = x254 + x417;
    double x419 = 7.1054273576010019e-15*x7;
    double x420 = -x381*x61 + 74.830163563379159*x54 + x64;
    double x421 = x274 + x420;
    double x422 = x193 + x400;
    double x423 = x422*x78;
    double x424 = x232 + x264 - x393*x59 + x412 + x423;
    double x425 = x112*x300;
    double x426 = x170*x300;
    double x427 = -0.046647230320699708*x191 + x285;
    double x428 = x325*x424 - x328*x424 - 0.19047619047619049*x425 + 0.054421768707482998*x426 + x427;
    double x429 = x337 + x72;
    double x430 = x307 + x429;
    double x431 = x163 + x201;
    double x432 = x312 + x431;
    double x433 = n5*x27 + x26;
    double x434 = x433*x78;
    double x435 = 1.0/n5;
    double x436 = x100 + x104 + x299*x435 + x321 + x361 + x411 + x434 - x86 + x91 + x98;
    double x437 = x325*x436 - x328*x436 - 0.108843537414966*x425 + 0.031098153547133141*x426;
    double x438 = n2*x22;
    double x439 = -x21 - x438;
    double x440 = x25*x318;
    double x441 = pow(n2, -2);
    double x442 = x217*x318;
    double x443 = 8.3144626181532395*x442;
    double x444 = -x15*x2;
    double x445 = x17 + x444;
    double x446 = n2*x13 + x14 + x18 + x445 + x47;
    double x447 = x443 + x446 + x72;
    double x448 = x11 + x32;
    double x449 = 3.0*x77;
    double x450 = 24.943387854459719*x442;
    double x451 = -x146*x2;
    double x452 = x148 + x451;
    double x453 = n2*x144 + x145 + x149 + x157 + x452;
    double x454 = x163 + x450 + x453;
    double x455 = x143 + x152;
    double x456 = 0.081632653061224497*x172;
    double x457 = x11 + x225;
    double x458 = -x196 - x438;
    double x459 = x25*x458 + x332*x440;
    double x460 = x289 + x447 + x457 + x459;
    double x461 = x192 + x239;
    double x462 = x212*x334 - x214*x334;
    double x463 = x461 + x462;
    double x464 = x143 + x229;
    double x465 = x318*x333 + x458*x78;
    double x466 = x168*(x292 + x454 + x464 + x465) + x329;
    double x467 = x192 + x462;
    double x468 = -x305 - x438;
    double x469 = x25*x468 + x446;
    double x470 = x351 + x429 + x469;
    double x471 = x453 + x468*x78;
    double x472 = x168*(x354 + x431 + x471) + x220;
    double x473 = x467 + x472;
    double x474 = x243 + x469;
    double x475 = x254 + x474;
    double x476 = x269 + x471;
    double x477 = x274 + x476;
    double x478 = x334*x339 - x334*x342 + x344;
    double x479 = n3*x22;
    double x480 = -x21 - x479;
    double x481 = x25*x360;
    double x482 = pow(n3, -2);
    double x483 = x235*x360;
    double x484 = -x0*x15 + x16;
    double x485 = n3*x13 + x18 + x484;
    double x486 = 8.3144626181532395*x483 + x485;
    double x487 = -x0*x146 + x147;
    double x488 = n3*x144 + x149 + x487;
    double x489 = 24.943387854459719*x483 + x488;
    double x490 = -x196 - x479;
    double x491 = x25*x490 + x372*x481 + x486;
    double x492 = x360*x373 + x489 + x490*x78;
    double x493 = x212*x377 - x214*x377;
    double x494 = -x305 - x479;
    double x495 = x25*x494 + x485;
    double x496 = x380 + x495;
    double x497 = 99.773551417838888*x7;
    double x498 = x488 + x494*x78;
    double x499 = x392 + x498;
    double x500 = n4*x22;
    double x501 = -x21 - x500;
    double x502 = x25*x403;
    double x503 = pow(n4, -2);
    double x504 = x260*x69;
    double x505 = 4.1572313090766198*x249;
    double x506 = x51*(3.0*x12 - x66);
    double x507 = x281*x410;
    double x508 = -x21 - x22*x3;
    double x509 = pow(x3, -2);
    double x510 = x13*x3 - x25*x281*x509 + x25*x408*x410 + x25*x508 + 8.3144626181532395*x507;
    double x511 = n4*x13 + x444 + x510;
    double x512 = x279*x403;
    double x513 = x384*x62;
    double x514 = 8.3144626181532395*x512 - x513*x65;
    double x515 = 12.471693927229859*x249;
    double x516 = x144*x3 - x282*x509 + x409*x410 + 24.943387854459719*x507 + x508*x78;
    double x517 = n4*x144 + x451 + x516;
    double x518 = -x161*x513 + 24.943387854459719*x512;
    double x519 = -x196 - x500;
    double x520 = x381*x59;
    double x521 = 33.257850472612958*x261 + x511;
    double x522 = 99.773551417838874*x261 + x517;
    double x523 = -x305 - x500;
    double x524 = x298*x435;
    double x525 = -n5*x22 - x21;
    double x526 = pow(n5, -2);

if (x76) {
   result[0] = x33 + x75;
}
else {
   result[0] = 3.0*x110 - 0.16326530612244899*x142 + x168*(x153 + x166) + 0.046647230320699715*x171 - 0.081632653061224497*x173 + x192;
}
if (x76) {
   result[1] = x200 + x202 + x33;
}
else {
   result[1] = x168*(x153 + x207 + x208) + x215 + x220 + x221;
}
if (x76) {
   result[2] = x202 + x226 + x74;
}
else {
   result[2] = x168*(x165 + x208 + x230) + x231 + x234 + x239;
}
if (x76) {
   result[3] = x240 + x244 + x258 + x32;
}
else {
   result[3] = 3.5*x110 - 0.38095238095238099*x142 + x168*(x152 + x268 + x270 + x278) + 0.108843537414966*x171 - 0.095238095238095247*x173 + x212*x267 - x214*x267 + x286;
}
if (x76) {
   result[4] = x240 + x287 + x290;
}
else {
   result[4] = x168*(x268 + x291 + x293) + x231 + x297 + x301;
}
if (x76) {
   result[5] = x304 + x308 + x32;
}
else {
   result[5] = x168*(x152 + x311 + x313) + x215 + x314 + x329;
}
if (x76) {
   result[6] = x287 + x304;
}
else {
   result[6] = x168*(x291 + x311) + x331 + x335;
}
if (x76) {
   result[7] = x256 + x33 + x336 + x338;
}
else {
   result[7] = x168*(x153 + x276 + x340 + x341) + x211*x339 - x211*x342 + x344 + x346;
}
if (x76) {
   result[8] = x226 + x308 + x348;
}
else {
   result[8] = x168*(x230 + x303 + x313) + x301 + x330 + x335 + x349;
}
if (x76) {
   result[9] = x303 + x353 + x74;
}
else {
   result[9] = x168*(x165 + x310 + x356) + x234 + x330 + x366;
}
if (x76) {
   result[10] = x19 + x338 + x367 + x368;
}
else {
   result[10] = x168*(x150 + x341 + x369 + x370) + x233*x339 - x233*x342 + x346 + x376;
}
if (x76) {
   result[11] = x200 + x348 + x353;
}
else {
   result[11] = x168*(x207 + x303 + x356) + x331 + x349 + x378;
}
if (x76) {
   result[12] = x33 + x380 + x390;
}
else {
   result[12] = -0.66666666666666674*x142 + x168*(x153 + x392 + x398) + 0.19047619047619049*x171 + x267*x391 - x267*x399 + x416;
}
if (x76) {
   result[13] = x226 + x380 + x418;
}
else {
   result[13] = x168*(x230 + x392 + x419 + x421) + x296*x339 - x296*x342 + x345 + x428;
}
if (x76) {
   result[14] = x352 + x430;
}
else {
   result[14] = x168*(x355 + x432) + x297 + x330 + x437;
}
if (x76) {
   result[15] = -x217*x25*x441 + x25*x439 + x316*x440 + x39 + x447 + x448;
}
else {
   result[15] = x168*(x155 + x317*x318 - x319*x441 + x439*x78 + x454 + x455) + x192 + x324*x449 - x324*x456 - 0.16326530612244899*x326 + 0.046647230320699715*x327;
}
if (x76) {
   result[16] = x460;
}
else {
   result[16] = x463 + x466;
}
if (x76) {
   result[17] = x243 + x258 + x443 + x446 + x448 + x459;
}
else {
   result[17] = x168*(x269 + x278 + x450 + x453 + x455 + x465) + x212*x343 - x214*x343 + x286 + x324*x339 - x324*x342 - 0.38095238095238099*x326 + 0.108843537414966*x327;
}
if (x76) {
   result[18] = x460;
}
else {
   result[18] = x301 + x466 + x467;
}
if (x76) {
   result[19] = x470;
}
else {
   result[19] = x366 + x473;
}
if (x76) {
   result[20] = x347 + x367 + x475;
}
else {
   result[20] = x168*(x369 + x477 + 24.943387854459726*x7) + x286 + x376 + x478;
}
if (x76) {
   result[21] = x470;
}
else {
   result[21] = x378 + x463 + x472;
}
if (x76) {
   result[22] = x379 + x390 + x448 + x474;
}
else {
   result[22] = x168*(x262 + x398 + x455 + x476) - 0.66666666666666674*x326 + 0.19047619047619049*x327 + x343*x391 - x343*x399 + x416;
}
if (x76) {
   result[23] = x379 + x417 + x457 + x475;
}
else {
   result[23] = x168*(x262 + x419 + x420 + x464 + x477) + x428 + x478;
}
if (x76) {
   result[24] = x470;
}
else {
   result[24] = x437 + x473;
}
if (x76) {
   result[25] = -x235*x25*x482 + x25*x480 + x358*x481 + x486 + x75;
}
else {
   result[25] = x168*(x166 - x236*x482 + x359*x360 + x480*x78 + x489) + x192 + x363*x449 - x363*x456 - 0.16326530612244899*x364 + 0.046647230320699715*x365;
}
if (x76) {
   result[26] = x257 + x303 + x368 + x491;
}
else {
   result[26] = x168*(x277 + x310 + x370 + x492) + x212*x375 - x214*x375 + x286 + x339*x363 - x342*x363 - 0.38095238095238099*x364 + 0.108843537414966*x365;
}
if (x76) {
   result[27] = x200 + x290 + x491;
}
else {
   result[27] = x168*(x207 + x293 + x492) + x192 + x301 + x366 + x493;
}
if (x76) {
   result[28] = x288 + x389 + x496;
}
else {
   result[28] = x168*(x397 + x497 + x499) - 0.66666666666666674*x364 + 0.19047619047619049*x365 + x375*x391 - x375*x399 + x416;
}
if (x76) {
   result[29] = x302 + x418 + x496;
}
else {
   result[29] = x168*(x309 + x421 + x499) + x339*x377 - x342*x377 + x376 + x428;
}
if (x76) {
   result[30] = x430 + x495;
}
else {
   result[30] = x168*(x432 + x498) + x437 + x461 + x493;
}
if (x76) {
   result[31] = -x245*x381 - x25*x279*x503 + x25*x501 + x33 + x385*x60 + x401*x502 + x404 - x406 + x407 - x497 + x504*x505 + x506*x65 + x511 + x514;
}
else {
   result[31] = x168*(x153 + x160*x385 + x161*x506 + 74.830163563379159*x261 - x271*x381 - x280*x503 + 74.830163563379159*x385*x4 + x402*x403 - 37.41508178168958*x405 + x501*x78 + x504*x515 + x517 + x518 - 299.32065425351664*x7) - 0.28571428571428575*x172*x413 + 2.0*x190 - 0.57142857142857151*x191 + 10.5*x413*x77 - 2.0*x414 + 0.57142857142857151*x415;
}
if (x76) {
   result[32] = x226 - x242*x505 + x245*x385 + x247 + x25*x519 + x310 + x388 + x394 + x422*x502 + x504*x65 + x514 - 12.471693927229859*x520 + x521;
}
else {
   result[32] = x168*(x161*x504 + x230 - x242*x515 + x271*x385 + x272 + x396 + x403*x423 - 74.830163563379159*x405 + x518 + x519*x78 - 37.41508178168958*x520 + x522 - 224.49049069013748*x7) + x391*x424 - x399*x424 + x416 - 0.66666666666666674*x425 + 0.19047619047619049*x426;
}
if (x76) {
   result[33] = -x242*x68 + x25*x523 + x253 + x289 + x352 - x381*x60 + x383 - 33.257850472612958*x405 + x504*x68 + x521 + 8.3144626181532395*x54;
}
else {
   result[33] = x168*(x103 - x160*x381 - x162*x242 + x162*x504 + x273 + x292 + x355 - x381*x95 + x395 + x522 + x523*x78) + x212*x424 - x214*x424 + x339*x436 - x342*x436 - 0.38095238095238099*x425 + 0.108843537414966*x426 + x427;
}
if (x76) {
   result[34] = n5*x13 - x25*x298*x526 + x25*x433*x435 + x25*x525 + x39 + x445 + x46 + x484 + x510 + 8.3144626181532395*x524 + x72;
}
else {
   result[34] = x168*(n5*x144 + x155 + x156 + x163 - x299*x526 + x434*x435 + x452 + x487 + x516 + 24.943387854459719*x524 + x525*x78) + x192 - 0.16326530612244899*x425 + 0.046647230320699715*x426 + x436*x449 - x436*x456;
}
}
        
static double coder_dgdp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].dmu0dP)(T, P);
    double x1 = n2*(*endmember[1].dmu0dP)(T, P);
    double x2 = n3*(*endmember[2].dmu0dP)(T, P);
    double x3 = n4*(*endmember[3].dmu0dP)(T, P);
    double x4 = n5*(*endmember[4].dmu0dP)(T, P);

if (T >= 5.0) {
   result = x0 + x1 + x2 + x3 + x4;
}
else {
   result = (1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5)*(3*x0 + 3*x1 + 3*x2 + 3*x3 + 3*x4)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = T >= 5.0;
    double x2 = 3*x0;
    double x3 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x4 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x5 = x3*x4;
    double x6 = (*endmember[1].dmu0dP)(T, P);
    double x7 = 3*x6;
    double x8 = (*endmember[2].dmu0dP)(T, P);
    double x9 = 3*x8;
    double x10 = (*endmember[3].dmu0dP)(T, P);
    double x11 = 3*x10;
    double x12 = (*endmember[4].dmu0dP)(T, P);
    double x13 = 3*x12;
    double x14 = n1*x2 + n2*x7 + n3*x9 + n4*x11 + n5*x13;
    double x15 = x14*x3;
    double x16 = x14*x4/((0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5)*(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5));
    double x17 = 1.0*x15 - 0.027210884353741499*x16;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x17 + x2*x5;
}
if (x1) {
   result[1] = x6;
}
else {
   result[1] = x17 + x5*x7;
}
if (x1) {
   result[2] = x8;
}
else {
   result[2] = x17 + x5*x9;
}
if (x1) {
   result[3] = x10;
}
else {
   result[3] = x11*x5 + 3.5*x15 - 0.095238095238095247*x16;
}
if (x1) {
   result[4] = x12;
}
else {
   result[4] = x13*x5 + x17;
}
}
        
static void coder_d3gdn2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x2 = (*endmember[0].dmu0dP)(T, P);
    double x3 = x1*x2;
    double x4 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x2*x7;
    double x9 = (*endmember[1].dmu0dP)(T, P);
    double x10 = (*endmember[2].dmu0dP)(T, P);
    double x11 = (*endmember[3].dmu0dP)(T, P);
    double x12 = (*endmember[4].dmu0dP)(T, P);
    double x13 = 3*n1*x2 + 3*n2*x9 + 3*n3*x10 + 3*n4*x11 + 3*n5*x12;
    double x14 = x13*x5;
    double x15 = x13*x6/((x4)*(x4)*(x4));
    double x16 = -0.054421768707482998*x14 + 0.01554907677356657*x15;
    double x17 = x16 + 3.0*x3 - 0.081632653061224497*x8;
    double x18 = 3.0*x1;
    double x19 = 0.081632653061224497*x7;
    double x20 = x18*x9 - x19*x9;
    double x21 = x10*x18 - x10*x19;
    double x22 = x11*x18 - x11*x19 - 0.19047619047619049*x14 + 0.054421768707482998*x15;
    double x23 = x12*x18 - x12*x19;
    double x24 = x1*x9;
    double x25 = x7*x9;
    double x26 = x16 + x20;
    double x27 = x1*x10;
    double x28 = x10*x7;
    double x29 = x1*x12;
    double x30 = x12*x7;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x16 + 6.0*x3 - 0.16326530612244899*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x17 + x20;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 + x21;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x22 + 10.5*x3 - 0.2857142857142857*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 + x23;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x16 + 6.0*x24 - 0.16326530612244899*x25;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x21 + x26;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x22 + 10.5*x24 - 0.2857142857142857*x25;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x23 + x26;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x16 + 6.0*x27 - 0.16326530612244899*x28;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x22 + 10.5*x27 - 0.2857142857142857*x28;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x16 + x21 + x23;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 21.0*x1*x11 - 0.5714285714285714*x11*x7 - 0.66666666666666674*x14 + 0.19047619047619049*x15;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = x22 + 10.5*x29 - 0.28571428571428575*x30;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x16 + 6.0*x29 - 0.16326530612244899*x30;
}
}
        
static void coder_d4gdn3dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].dmu0dP)(T, P);
    double x2 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x6 = pow(x2, -3);
    double x7 = (*endmember[1].dmu0dP)(T, P);
    double x8 = (*endmember[2].dmu0dP)(T, P);
    double x9 = (*endmember[3].dmu0dP)(T, P);
    double x10 = (*endmember[4].dmu0dP)(T, P);
    double x11 = 3*n1*x1 + 3*n2*x7 + 3*n3*x8 + 3*n4*x9 + 3*n5*x10;
    double x12 = x11*x5/((x2)*(x2)*(x2)*(x2));
    double x13 = -0.046647230320699715*x11*x6 + 0.013327780091628489*x12;
    double x14 = 0.16326530612244899*x3;
    double x15 = x13 + x14*x7;
    double x16 = -0.093294460641399415*x1*x5*x6 + 0.32653061224489799*x4;
    double x17 = x13 + x16;
    double x18 = x14*x8;
    double x19 = x18 - 0.046647230320699715*x5*x6*x8;
    double x20 = -0.16326530612244899*x11*x6 + x14*x9;
    double x21 = 0.046647230320699715*x12 + x20 - 0.046647230320699715*x5*x6*x9;
    double x22 = x10*x14 - 0.046647230320699715*x10*x5*x6;
    double x23 = x3*x7;
    double x24 = x13 + 0.32653061224489799*x23;
    double x25 = -0.046647230320699708*x1*x5*x6 + 0.16326530612244899*x4;
    double x26 = x15 - 0.046647230320699708*x5*x6*x7;
    double x27 = x25 + x26;
    double x28 = 0.5714285714285714*x4;
    double x29 = -0.16326530612244899*x1*x5*x6 + x21 + x28;
    double x30 = 0.5714285714285714*x23;
    double x31 = x30 - 0.16326530612244899*x5*x6*x7;
    double x32 = x13 + x25;
    double x33 = x3*x8;
    double x34 = 0.32653061224489799*x33;
    double x35 = x34 - 0.093294460641399429*x5*x6*x8;
    double x36 = 0.5714285714285714*x33;
    double x37 = x36 - 0.16326530612244899*x5*x6*x8;
    double x38 = x18 - 0.046647230320699708*x5*x6*x8;
    double x39 = x22 + x38;
    double x40 = x3*x9;
    double x41 = -0.57142857142857151*x11*x6 + 0.16326530612244899*x12;
    double x42 = 1.142857142857143*x40 + x41 - 0.32653061224489799*x5*x6*x9;
    double x43 = x10*x3;
    double x44 = 0.046647230320699708*x12 + x20 - 0.046647230320699708*x5*x6*x9;
    double x45 = -0.16326530612244899*x10*x5*x6 + 0.57142857142857151*x43 + x44;
    double x46 = -0.093294460641399429*x10*x5*x6 + 0.32653061224489799*x43;
    double x47 = x24 - 0.093294460641399415*x5*x6*x7;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 0.13994169096209913*x1*x5*x6 - x13 - 0.48979591836734698*x4;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = -x15 - x16 + 0.046647230320699715*x5*x6*x7;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = -x17 - x19;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 0.32653061224489799*x1*x5*x6 - x21 - 1.1428571428571428*x4;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -x17 - x22;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = -x24 - x25 + 0.093294460641399429*x5*x6*x7;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = -x19 - x27;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = -x29 - x31;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -x22 - x27;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = -x32 - x35;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = -x29 - x37;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = -x32 - x39;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 0.5714285714285714*x1*x5*x6 - 2.0*x4 - x42;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = 0.16326530612244897*x1*x5*x6 - x28 - x45;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = -x32 - x46;
}
if (x0) {
   result[15] = 0;
}
else {
   result[15] = -x13 - 0.48979591836734698*x23 + 0.13994169096209913*x5*x6*x7;
}
if (x0) {
   result[16] = 0;
}
else {
   result[16] = -x19 - x47;
}
if (x0) {
   result[17] = 0;
}
else {
   result[17] = -x21 - 1.1428571428571428*x23 + 0.32653061224489799*x5*x6*x7;
}
if (x0) {
   result[18] = 0;
}
else {
   result[18] = -x22 - x47;
}
if (x0) {
   result[19] = 0;
}
else {
   result[19] = -x26 - x35;
}
if (x0) {
   result[20] = 0;
}
else {
   result[20] = -x21 - x31 - x37;
}
if (x0) {
   result[21] = 0;
}
else {
   result[21] = -x26 - x39;
}
if (x0) {
   result[22] = 0;
}
else {
   result[22] = -2.0*x23 - x42 + 0.5714285714285714*x5*x6*x7;
}
if (x0) {
   result[23] = 0;
}
else {
   result[23] = -x30 - x45 + 0.16326530612244897*x5*x6*x7;
}
if (x0) {
   result[24] = 0;
}
else {
   result[24] = -x26 - x46;
}
if (x0) {
   result[25] = 0;
}
else {
   result[25] = -x13 - 0.48979591836734698*x33 + 0.13994169096209913*x5*x6*x8;
}
if (x0) {
   result[26] = 0;
}
else {
   result[26] = -x21 - 1.1428571428571428*x33 + 0.32653061224489799*x5*x6*x8;
}
if (x0) {
   result[27] = 0;
}
else {
   result[27] = -x13 - x22 - x34 + 0.093294460641399415*x5*x6*x8;
}
if (x0) {
   result[28] = 0;
}
else {
   result[28] = -2.0*x33 - x42 + 0.5714285714285714*x5*x6*x8;
}
if (x0) {
   result[29] = 0;
}
else {
   result[29] = -x36 - x45 + 0.16326530612244897*x5*x6*x8;
}
if (x0) {
   result[30] = 0;
}
else {
   result[30] = -x13 - x38 - x46;
}
if (x0) {
   result[31] = 0;
}
else {
   result[31] = 2.0*x11*x6 - 0.57142857142857151*x12 - 6.0*x40 + 1.7142857142857144*x5*x6*x9;
}
if (x0) {
   result[32] = 0;
}
else {
   result[32] = 0.57142857142857151*x10*x5*x6 - 1.1428571428571428*x40 - x41 - 2.0*x43 + 0.32653061224489793*x5*x6*x9;
}
if (x0) {
   result[33] = 0;
}
else {
   result[33] = 0.32653061224489799*x10*x5*x6 - 1.142857142857143*x43 - x44;
}
if (x0) {
   result[34] = 0;
}
else {
   result[34] = 0.13994169096209913*x10*x5*x6 - x13 - 0.48979591836734698*x43;
}
}
        
static double coder_d2gdt2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dT2)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dT2)(T, P);
    double x3 = n4*(*endmember[3].d2mu0dT2)(T, P);
    double x4 = n5*(*endmember[4].d2mu0dT2)(T, P);
    double x5 = 0.19999999999999998*T - 1;
    double x6 = -x5;
    double x7 = sqrt(x6);
    double x8 = 1.0*x7;
    double x9 = x8 - 4;
    double x10 = (-x9 >= 0. ? 1. : 0.);
    double x11 = 0.40144049999999992*T - 2.0072024999999996;
    double x12 = 1.0/x5;
    double x13 = x12*0;
    double x14 = x10/pow(x6, 3.0/2.0);
    double x15 = fmin(4, x8);
    double x16 = 2.0072025*((x15)*(x15));

if (T >= 5.0) {
   result = x0 + x1 + x2 + x3 + x4;
}
else {
   result = (1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5)*(-n2*(4.014405*((x10)*(x10))*x12*x15 + 8.02881*x10/x7 - x11*x13 + x11*x14 - x13*x16 + x14*x16) + 3*x0 + 3*x1 + 3*x2 + 3*x3 + 3*x4)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = T >= 5.0;
    double x2 = 3*x0;
    double x3 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x4 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x5 = x3*x4;
    double x6 = (*endmember[1].d2mu0dT2)(T, P);
    double x7 = (*endmember[2].d2mu0dT2)(T, P);
    double x8 = 3*x7;
    double x9 = (*endmember[3].d2mu0dT2)(T, P);
    double x10 = 3*x9;
    double x11 = (*endmember[4].d2mu0dT2)(T, P);
    double x12 = 3*x11;
    double x13 = 0.19999999999999998*T - 1;
    double x14 = -x13;
    double x15 = sqrt(x14);
    double x16 = 1.0*x15;
    double x17 = x16 - 4;
    double x18 = (-x17 >= 0. ? 1. : 0.);
    double x19 = 0.40144049999999992*T - 2.0072024999999996;
    double x20 = 1.0/x13;
    double x21 = x20*0;
    double x22 = x18/pow(x14, 3.0/2.0);
    double x23 = fmin(4, x16);
    double x24 = 2.0072025*((x23)*(x23));
    double x25 = 4.014405*((x18)*(x18))*x20*x23 - x19*x21 + x19*x22 - x21*x24 + x22*x24 + 8.02881*x18/x15;
    double x26 = n1*x2 - n2*x25 + 3*n2*x6 + n3*x8 + n4*x10 + n5*x12;
    double x27 = x26*x3;
    double x28 = x26*x4/((0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5)*(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5));
    double x29 = 1.0*x27 - 0.027210884353741499*x28;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x2*x5 + x29;
}
if (x1) {
   result[1] = x6;
}
else {
   result[1] = x29 + x5*(-x25 + 3*x6);
}
if (x1) {
   result[2] = x7;
}
else {
   result[2] = x29 + x5*x8;
}
if (x1) {
   result[3] = x9;
}
else {
   result[3] = x10*x5 + 3.5*x27 - 0.095238095238095247*x28;
}
if (x1) {
   result[4] = x11;
}
else {
   result[4] = x12*x5 + x29;
}
}
        
static void coder_d4gdn2dt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x2 = (*endmember[0].d2mu0dT2)(T, P);
    double x3 = x1*x2;
    double x4 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x2*x7;
    double x9 = (*endmember[1].d2mu0dT2)(T, P);
    double x10 = (*endmember[2].d2mu0dT2)(T, P);
    double x11 = (*endmember[3].d2mu0dT2)(T, P);
    double x12 = (*endmember[4].d2mu0dT2)(T, P);
    double x13 = 0.19999999999999998*T - 1;
    double x14 = -x13;
    double x15 = sqrt(x14);
    double x16 = 1.0*x15;
    double x17 = x16 - 4;
    double x18 = (-x17 >= 0. ? 1. : 0.);
    double x19 = 0.40144049999999992*T - 2.0072024999999996;
    double x20 = 1.0/x13;
    double x21 = x20*0;
    double x22 = x18/pow(x14, 3.0/2.0);
    double x23 = fmin(4, x16);
    double x24 = 2.0072025*((x23)*(x23));
    double x25 = 4.014405*((x18)*(x18))*x20*x23 - x19*x21 + x19*x22 - x21*x24 + x22*x24 + 8.02881*x18/x15;
    double x26 = 3*n1*x2 - n2*x25 + 3*n2*x9 + 3*n3*x10 + 3*n4*x11 + 3*n5*x12;
    double x27 = x26*x5;
    double x28 = x26*x6/((x4)*(x4)*(x4));
    double x29 = -0.054421768707482998*x27 + 0.01554907677356657*x28;
    double x30 = x29 + 3.0*x3 - 0.081632653061224497*x8;
    double x31 = -x25 + 3*x9;
    double x32 = x1*x31;
    double x33 = x31*x7;
    double x34 = 1.0*x32 - 0.027210884353741499*x33;
    double x35 = 3.0*x1;
    double x36 = 0.081632653061224497*x7;
    double x37 = x10*x35 - x10*x36;
    double x38 = x11*x35 - x11*x36 - 0.19047619047619049*x27 + 0.054421768707482998*x28;
    double x39 = x12*x35 - x12*x36;
    double x40 = x29 + x34;
    double x41 = x1*x10;
    double x42 = x10*x7;
    double x43 = x1*x12;
    double x44 = x12*x7;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x29 + 6.0*x3 - 0.16326530612244899*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x30 + x34;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x30 + x37;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 10.5*x3 + x38 - 0.2857142857142857*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x30 + x39;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x29 + 2.0*x32 - 0.054421768707482998*x33;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x37 + x40;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = 3.5*x32 - 0.095238095238095247*x33 + x38;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x39 + x40;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x29 + 6.0*x41 - 0.16326530612244899*x42;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x38 + 10.5*x41 - 0.2857142857142857*x42;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x29 + x37 + x39;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 21.0*x1*x11 - 0.5714285714285714*x11*x7 - 0.66666666666666674*x27 + 0.19047619047619049*x28;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = x38 + 10.5*x43 - 0.28571428571428575*x44;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x29 + 6.0*x43 - 0.16326530612244899*x44;
}
}
        
static void coder_d5gdn3dt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dT2)(T, P);
    double x2 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x6 = pow(x2, -3);
    double x7 = (*endmember[1].d2mu0dT2)(T, P);
    double x8 = (*endmember[2].d2mu0dT2)(T, P);
    double x9 = (*endmember[3].d2mu0dT2)(T, P);
    double x10 = (*endmember[4].d2mu0dT2)(T, P);
    double x11 = 0.19999999999999998*T - 1;
    double x12 = -x11;
    double x13 = sqrt(x12);
    double x14 = 1.0*x13;
    double x15 = x14 - 4;
    double x16 = (-x15 >= 0. ? 1. : 0.);
    double x17 = 0.40144049999999992*T - 2.0072024999999996;
    double x18 = 1.0/x11;
    double x19 = x18*0;
    double x20 = x16/pow(x12, 3.0/2.0);
    double x21 = fmin(4, x14);
    double x22 = 2.0072025*((x21)*(x21));
    double x23 = 4.014405*((x16)*(x16))*x18*x21 - x17*x19 + x17*x20 - x19*x22 + x20*x22 + 8.02881*x16/x13;
    double x24 = 3*n1*x1 - n2*x23 + 3*n2*x7 + 3*n3*x8 + 3*n4*x9 + 3*n5*x10;
    double x25 = x24*x5/((x2)*(x2)*(x2)*(x2));
    double x26 = -0.046647230320699715*x24*x6 + 0.013327780091628489*x25;
    double x27 = -0.093294460641399415*x1*x5*x6 + x26 + 0.32653061224489799*x4;
    double x28 = -x23 + 3*x7;
    double x29 = x28*x3;
    double x30 = -0.01554907677356657*x28*x5*x6 + 0.054421768707482998*x29;
    double x31 = 0.16326530612244899*x3;
    double x32 = x31*x8;
    double x33 = x32 - 0.046647230320699715*x5*x6*x8;
    double x34 = -0.16326530612244899*x24*x6 + x31*x9;
    double x35 = 0.046647230320699715*x25 + x34 - 0.046647230320699715*x5*x6*x9;
    double x36 = x10*x31 - 0.046647230320699715*x10*x5*x6;
    double x37 = -0.046647230320699708*x1*x5*x6 + x26 + 0.16326530612244899*x4;
    double x38 = -0.031098153547133141*x28*x5*x6 + 0.108843537414966*x29;
    double x39 = x30 + x37;
    double x40 = -0.054421768707482998*x28*x5*x6 + 0.19047619047619049*x29;
    double x41 = 0.5714285714285714*x4;
    double x42 = -0.16326530612244899*x1*x5*x6 + x35 + x41;
    double x43 = x3*x8;
    double x44 = 0.32653061224489799*x43;
    double x45 = x44 - 0.093294460641399429*x5*x6*x8;
    double x46 = 0.5714285714285714*x43;
    double x47 = x46 - 0.16326530612244899*x5*x6*x8;
    double x48 = x32 - 0.046647230320699708*x5*x6*x8;
    double x49 = x36 + x48;
    double x50 = x3*x9;
    double x51 = -0.57142857142857151*x24*x6 + 0.16326530612244899*x25;
    double x52 = -0.32653061224489799*x5*x6*x9 + 1.142857142857143*x50 + x51;
    double x53 = x10*x3;
    double x54 = 0.046647230320699708*x25 + x34 - 0.046647230320699708*x5*x6*x9;
    double x55 = -0.16326530612244899*x10*x5*x6 + 0.57142857142857151*x53 + x54;
    double x56 = -0.093294460641399429*x10*x5*x6 + 0.32653061224489799*x53;
    double x57 = x26 + x38;
    double x58 = x26 + x30;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 0.13994169096209913*x1*x5*x6 - x26 - 0.48979591836734698*x4;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = -x27 - x30;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = -x27 - x33;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 0.32653061224489799*x1*x5*x6 - x35 - 1.1428571428571428*x4;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -x27 - x36;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = -x37 - x38;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = -x33 - x39;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = -x40 - x42;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -x36 - x39;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = -x37 - x45;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = -x42 - x47;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = -x37 - x49;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 0.5714285714285714*x1*x5*x6 - 2.0*x4 - x52;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = 0.16326530612244897*x1*x5*x6 - x41 - x55;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = -x37 - x56;
}
if (x0) {
   result[15] = 0;
}
else {
   result[15] = -x26 + 0.046647230320699715*x28*x5*x6 - 0.16326530612244899*x29;
}
if (x0) {
   result[16] = 0;
}
else {
   result[16] = -x33 - x57;
}
if (x0) {
   result[17] = 0;
}
else {
   result[17] = 0.108843537414966*x28*x5*x6 - 0.38095238095238099*x29 - x35;
}
if (x0) {
   result[18] = 0;
}
else {
   result[18] = -x36 - x57;
}
if (x0) {
   result[19] = 0;
}
else {
   result[19] = -x45 - x58;
}
if (x0) {
   result[20] = 0;
}
else {
   result[20] = -x35 - x40 - x47;
}
if (x0) {
   result[21] = 0;
}
else {
   result[21] = -x49 - x58;
}
if (x0) {
   result[22] = 0;
}
else {
   result[22] = 0.19047619047619049*x28*x5*x6 - 0.66666666666666674*x29 - x52;
}
if (x0) {
   result[23] = 0;
}
else {
   result[23] = -x40 - x55;
}
if (x0) {
   result[24] = 0;
}
else {
   result[24] = -x56 - x58;
}
if (x0) {
   result[25] = 0;
}
else {
   result[25] = -x26 - 0.48979591836734698*x43 + 0.13994169096209913*x5*x6*x8;
}
if (x0) {
   result[26] = 0;
}
else {
   result[26] = -x35 - 1.1428571428571428*x43 + 0.32653061224489799*x5*x6*x8;
}
if (x0) {
   result[27] = 0;
}
else {
   result[27] = -x26 - x36 - x44 + 0.093294460641399415*x5*x6*x8;
}
if (x0) {
   result[28] = 0;
}
else {
   result[28] = -2.0*x43 + 0.5714285714285714*x5*x6*x8 - x52;
}
if (x0) {
   result[29] = 0;
}
else {
   result[29] = -x46 + 0.16326530612244897*x5*x6*x8 - x55;
}
if (x0) {
   result[30] = 0;
}
else {
   result[30] = -x26 - x48 - x56;
}
if (x0) {
   result[31] = 0;
}
else {
   result[31] = 2.0*x24*x6 - 0.57142857142857151*x25 + 1.7142857142857144*x5*x6*x9 - 6.0*x50;
}
if (x0) {
   result[32] = 0;
}
else {
   result[32] = 0.57142857142857151*x10*x5*x6 + 0.32653061224489793*x5*x6*x9 - 1.1428571428571428*x50 - x51 - 2.0*x53;
}
if (x0) {
   result[33] = 0;
}
else {
   result[33] = 0.32653061224489799*x10*x5*x6 - 1.142857142857143*x53 - x54;
}
if (x0) {
   result[34] = 0;
}
else {
   result[34] = 0.13994169096209913*x10*x5*x6 - x26 - 0.48979591836734698*x53;
}
}
        
static double coder_d2gdtdp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P) + n3*(*endmember[2].d2mu0dTdP)(T, P) + n4*(*endmember[3].d2mu0dTdP)(T, P) + n5*(*endmember[4].d2mu0dTdP)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].d2mu0dTdP)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d2mu0dTdP)(T, P);
    double x6 = (*endmember[2].d2mu0dTdP)(T, P);
    double x7 = (*endmember[3].d2mu0dTdP)(T, P);
    double x8 = (*endmember[4].d2mu0dTdP)(T, P);
    double x9 = n1*x0 + n2*x5 + n3*x6 + n4*x7 + n5*x8;
    double x10 = x2*x9;
    double x11 = x3*x9/((0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5)*(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5));
    double x12 = 3.0*x10 - 0.081632653061224497*x11;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x12;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x12 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x12 + x4*x6;
}
if (x1) {
   result[3] = x7;
}
else {
   result[3] = 10.5*x10 - 0.2857142857142857*x11 + x4*x7;
}
if (x1) {
   result[4] = x8;
}
else {
   result[4] = x12 + x4*x8;
}
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dTdP)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = x1*x2;
    double x4 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = (*endmember[1].d2mu0dTdP)(T, P);
    double x10 = (*endmember[2].d2mu0dTdP)(T, P);
    double x11 = (*endmember[3].d2mu0dTdP)(T, P);
    double x12 = (*endmember[4].d2mu0dTdP)(T, P);
    double x13 = n1*x1 + n2*x9 + n3*x10 + n4*x11 + n5*x12;
    double x14 = x13*x5;
    double x15 = x13*x6/((x4)*(x4)*(x4));
    double x16 = -0.16326530612244899*x14 + 0.046647230320699708*x15;
    double x17 = x16 + 3.0*x3 - 0.081632653061224497*x8;
    double x18 = 3.0*x2;
    double x19 = 0.081632653061224497*x7;
    double x20 = x18*x9 - x19*x9;
    double x21 = x10*x18 - x10*x19;
    double x22 = x11*x18 - x11*x19 - 0.5714285714285714*x14;
    double x23 = 0.16326530612244899*x15 + x22;
    double x24 = x12*x18 - x12*x19;
    double x25 = x2*x9;
    double x26 = x7*x9;
    double x27 = x16 + x20;
    double x28 = x10*x2;
    double x29 = x10*x7;
    double x30 = x12*x2;
    double x31 = x12*x7;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x16 + 6.0*x3 - 0.16326530612244899*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x17 + x20;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 + x21;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x23 + 10.5*x3 - 0.2857142857142857*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 + x24;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x16 + 6.0*x25 - 0.16326530612244899*x26;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x21 + x27;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x23 + 10.5*x25 - 0.2857142857142857*x26;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x24 + x27;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x16 + 6.0*x28 - 0.16326530612244899*x29;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x23 + 10.5*x28 - 0.2857142857142857*x29;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x16 + x21 + x24;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 21.0*x11*x2 - 0.5714285714285714*x11*x7 - 2.0*x14 + 0.5714285714285714*x15;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = 0.16326530612244897*x15 + x22 + 10.5*x30 - 0.2857142857142857*x31;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x16 + 6.0*x30 - 0.16326530612244899*x31;
}
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dTdP)(T, P);
    double x2 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x6 = pow(x2, -3);
    double x7 = (*endmember[1].d2mu0dTdP)(T, P);
    double x8 = (*endmember[2].d2mu0dTdP)(T, P);
    double x9 = (*endmember[3].d2mu0dTdP)(T, P);
    double x10 = (*endmember[4].d2mu0dTdP)(T, P);
    double x11 = n1*x1 + n2*x7 + n3*x8 + n4*x9 + n5*x10;
    double x12 = x11*x5/((x2)*(x2)*(x2)*(x2));
    double x13 = -0.13994169096209913*x11*x6 + 0.039983340274885461*x12;
    double x14 = -0.093294460641399415*x1*x5*x6 + x13 + 0.32653061224489799*x4;
    double x15 = 0.16326530612244899*x3;
    double x16 = x15*x7 - 0.046647230320699708*x5*x6*x7;
    double x17 = x15*x8 - 0.046647230320699708*x5*x6*x8;
    double x18 = -0.48979591836734693*x11*x6 + x15*x9 - 0.046647230320699708*x5*x6*x9;
    double x19 = 0.13994169096209913*x12 + x18;
    double x20 = x10*x15 - 0.046647230320699708*x10*x5*x6;
    double x21 = -0.046647230320699708*x1*x5*x6 + x13 + 0.16326530612244899*x4;
    double x22 = x3*x7;
    double x23 = 0.32653061224489799*x22 - 0.093294460641399415*x5*x6*x7;
    double x24 = x16 + x21;
    double x25 = x19 + 0.5714285714285714*x4;
    double x26 = -0.16326530612244899*x1*x5*x6 + x25;
    double x27 = 0.5714285714285714*x22;
    double x28 = x27 - 0.16326530612244899*x5*x6*x7;
    double x29 = x3*x8;
    double x30 = 0.32653061224489799*x29 - 0.093294460641399415*x5*x6*x8;
    double x31 = 0.5714285714285714*x29;
    double x32 = x31 - 0.16326530612244899*x5*x6*x8;
    double x33 = x17 + x20;
    double x34 = x3*x9;
    double x35 = 1.1428571428571428*x34;
    double x36 = -1.7142857142857144*x11*x6 + 0.48979591836734698*x12 + x35 - 0.32653061224489799*x5*x6*x9;
    double x37 = x10*x3;
    double x38 = -0.16326530612244899*x10*x5*x6 + 0.5714285714285714*x37;
    double x39 = -0.093294460641399415*x10*x5*x6 + 0.32653061224489799*x37;
    double x40 = x13 + x23;
    double x41 = x13 + x16;
    double x42 = x19 + x38;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 0.13994169096209913*x1*x5*x6 - x13 - 0.48979591836734698*x4;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = -x14 - x16;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = -x14 - x17;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 0.32653061224489799*x1*x5*x6 - x19 - 1.1428571428571428*x4;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -x14 - x20;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = -x21 - x23;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = -x17 - x24;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = -x26 - x28;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -x20 - x24;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = -x21 - x30;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = -x26 - x32;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = -x21 - x33;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 0.5714285714285714*x1*x5*x6 - x36 - 2.0*x4;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = 0.16326530612244897*x1*x5*x6 - x25 - x38;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = -x21 - x39;
}
if (x0) {
   result[15] = 0;
}
else {
   result[15] = -x13 - 0.48979591836734698*x22 + 0.13994169096209913*x5*x6*x7;
}
if (x0) {
   result[16] = 0;
}
else {
   result[16] = -x17 - x40;
}
if (x0) {
   result[17] = 0;
}
else {
   result[17] = -x19 - 1.1428571428571428*x22 + 0.32653061224489799*x5*x6*x7;
}
if (x0) {
   result[18] = 0;
}
else {
   result[18] = -x20 - x40;
}
if (x0) {
   result[19] = 0;
}
else {
   result[19] = -x30 - x41;
}
if (x0) {
   result[20] = 0;
}
else {
   result[20] = -x19 - x28 - x32;
}
if (x0) {
   result[21] = 0;
}
else {
   result[21] = -x33 - x41;
}
if (x0) {
   result[22] = 0;
}
else {
   result[22] = -2.0*x22 - x36 + 0.5714285714285714*x5*x6*x7;
}
if (x0) {
   result[23] = 0;
}
else {
   result[23] = -x27 - x42 + 0.16326530612244897*x5*x6*x7;
}
if (x0) {
   result[24] = 0;
}
else {
   result[24] = -x39 - x41;
}
if (x0) {
   result[25] = 0;
}
else {
   result[25] = -x13 - 0.48979591836734698*x29 + 0.13994169096209913*x5*x6*x8;
}
if (x0) {
   result[26] = 0;
}
else {
   result[26] = -x19 - 1.1428571428571428*x29 + 0.32653061224489799*x5*x6*x8;
}
if (x0) {
   result[27] = 0;
}
else {
   result[27] = -x13 - x20 - x30;
}
if (x0) {
   result[28] = 0;
}
else {
   result[28] = -2.0*x29 - x36 + 0.5714285714285714*x5*x6*x8;
}
if (x0) {
   result[29] = 0;
}
else {
   result[29] = -x31 - x42 + 0.16326530612244897*x5*x6*x8;
}
if (x0) {
   result[30] = 0;
}
else {
   result[30] = -x13 - x17 - x39;
}
if (x0) {
   result[31] = 0;
}
else {
   result[31] = 6.0*x11*x6 - 1.7142857142857142*x12 - 6.0*x34 + 1.7142857142857142*x5*x6*x9;
}
if (x0) {
   result[32] = 0;
}
else {
   result[32] = 0.5714285714285714*x10*x5*x6 + 1.7142857142857142*x11*x6 - 0.48979591836734687*x12 - x35 - 2.0*x37 + 0.32653061224489793*x5*x6*x9;
}
if (x0) {
   result[33] = 0;
}
else {
   result[33] = 0.32653061224489793*x10*x5*x6 - 0.1399416909620991*x12 - x18 - 1.1428571428571428*x37;
}
if (x0) {
   result[34] = 0;
}
else {
   result[34] = 0.13994169096209913*x10*x5*x6 - x13 - 0.48979591836734698*x37;
}
}
        
static double coder_d2gdp2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P) + n3*(*endmember[2].d2mu0dP2)(T, P) + n4*(*endmember[3].d2mu0dP2)(T, P) + n5*(*endmember[4].d2mu0dP2)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].d2mu0dP2)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d2mu0dP2)(T, P);
    double x6 = (*endmember[2].d2mu0dP2)(T, P);
    double x7 = (*endmember[3].d2mu0dP2)(T, P);
    double x8 = (*endmember[4].d2mu0dP2)(T, P);
    double x9 = n1*x0 + n2*x5 + n3*x6 + n4*x7 + n5*x8;
    double x10 = x2*x9;
    double x11 = x3*x9/((0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5)*(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5));
    double x12 = 3.0*x10 - 0.081632653061224497*x11;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x12;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x12 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x12 + x4*x6;
}
if (x1) {
   result[3] = x7;
}
else {
   result[3] = 10.5*x10 - 0.2857142857142857*x11 + x4*x7;
}
if (x1) {
   result[4] = x8;
}
else {
   result[4] = x12 + x4*x8;
}
}
        
static void coder_d4gdn2dp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dP2)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = x1*x2;
    double x4 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = (*endmember[1].d2mu0dP2)(T, P);
    double x10 = (*endmember[2].d2mu0dP2)(T, P);
    double x11 = (*endmember[3].d2mu0dP2)(T, P);
    double x12 = (*endmember[4].d2mu0dP2)(T, P);
    double x13 = n1*x1 + n2*x9 + n3*x10 + n4*x11 + n5*x12;
    double x14 = x13*x5;
    double x15 = x13*x6/((x4)*(x4)*(x4));
    double x16 = -0.16326530612244899*x14 + 0.046647230320699708*x15;
    double x17 = x16 + 3.0*x3 - 0.081632653061224497*x8;
    double x18 = 3.0*x2;
    double x19 = 0.081632653061224497*x7;
    double x20 = x18*x9 - x19*x9;
    double x21 = x10*x18 - x10*x19;
    double x22 = x11*x18 - x11*x19 - 0.5714285714285714*x14;
    double x23 = 0.16326530612244899*x15 + x22;
    double x24 = x12*x18 - x12*x19;
    double x25 = x2*x9;
    double x26 = x7*x9;
    double x27 = x16 + x20;
    double x28 = x10*x2;
    double x29 = x10*x7;
    double x30 = x12*x2;
    double x31 = x12*x7;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x16 + 6.0*x3 - 0.16326530612244899*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x17 + x20;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 + x21;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x23 + 10.5*x3 - 0.2857142857142857*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 + x24;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x16 + 6.0*x25 - 0.16326530612244899*x26;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x21 + x27;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x23 + 10.5*x25 - 0.2857142857142857*x26;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x24 + x27;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x16 + 6.0*x28 - 0.16326530612244899*x29;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x23 + 10.5*x28 - 0.2857142857142857*x29;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x16 + x21 + x24;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 21.0*x11*x2 - 0.5714285714285714*x11*x7 - 2.0*x14 + 0.5714285714285714*x15;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = 0.16326530612244897*x15 + x22 + 10.5*x30 - 0.2857142857142857*x31;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x16 + 6.0*x30 - 0.16326530612244899*x31;
}
}
        
static void coder_d5gdn3dp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dP2)(T, P);
    double x2 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x6 = pow(x2, -3);
    double x7 = (*endmember[1].d2mu0dP2)(T, P);
    double x8 = (*endmember[2].d2mu0dP2)(T, P);
    double x9 = (*endmember[3].d2mu0dP2)(T, P);
    double x10 = (*endmember[4].d2mu0dP2)(T, P);
    double x11 = n1*x1 + n2*x7 + n3*x8 + n4*x9 + n5*x10;
    double x12 = x11*x5/((x2)*(x2)*(x2)*(x2));
    double x13 = -0.13994169096209913*x11*x6 + 0.039983340274885461*x12;
    double x14 = -0.093294460641399415*x1*x5*x6 + x13 + 0.32653061224489799*x4;
    double x15 = 0.16326530612244899*x3;
    double x16 = x15*x7 - 0.046647230320699708*x5*x6*x7;
    double x17 = x15*x8 - 0.046647230320699708*x5*x6*x8;
    double x18 = -0.48979591836734693*x11*x6 + x15*x9 - 0.046647230320699708*x5*x6*x9;
    double x19 = 0.13994169096209913*x12 + x18;
    double x20 = x10*x15 - 0.046647230320699708*x10*x5*x6;
    double x21 = -0.046647230320699708*x1*x5*x6 + x13 + 0.16326530612244899*x4;
    double x22 = x3*x7;
    double x23 = 0.32653061224489799*x22 - 0.093294460641399415*x5*x6*x7;
    double x24 = x16 + x21;
    double x25 = x19 + 0.5714285714285714*x4;
    double x26 = -0.16326530612244899*x1*x5*x6 + x25;
    double x27 = 0.5714285714285714*x22;
    double x28 = x27 - 0.16326530612244899*x5*x6*x7;
    double x29 = x3*x8;
    double x30 = 0.32653061224489799*x29 - 0.093294460641399415*x5*x6*x8;
    double x31 = 0.5714285714285714*x29;
    double x32 = x31 - 0.16326530612244899*x5*x6*x8;
    double x33 = x17 + x20;
    double x34 = x3*x9;
    double x35 = 1.1428571428571428*x34;
    double x36 = -1.7142857142857144*x11*x6 + 0.48979591836734698*x12 + x35 - 0.32653061224489799*x5*x6*x9;
    double x37 = x10*x3;
    double x38 = -0.16326530612244899*x10*x5*x6 + 0.5714285714285714*x37;
    double x39 = -0.093294460641399415*x10*x5*x6 + 0.32653061224489799*x37;
    double x40 = x13 + x23;
    double x41 = x13 + x16;
    double x42 = x19 + x38;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 0.13994169096209913*x1*x5*x6 - x13 - 0.48979591836734698*x4;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = -x14 - x16;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = -x14 - x17;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 0.32653061224489799*x1*x5*x6 - x19 - 1.1428571428571428*x4;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -x14 - x20;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = -x21 - x23;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = -x17 - x24;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = -x26 - x28;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -x20 - x24;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = -x21 - x30;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = -x26 - x32;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = -x21 - x33;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 0.5714285714285714*x1*x5*x6 - x36 - 2.0*x4;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = 0.16326530612244897*x1*x5*x6 - x25 - x38;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = -x21 - x39;
}
if (x0) {
   result[15] = 0;
}
else {
   result[15] = -x13 - 0.48979591836734698*x22 + 0.13994169096209913*x5*x6*x7;
}
if (x0) {
   result[16] = 0;
}
else {
   result[16] = -x17 - x40;
}
if (x0) {
   result[17] = 0;
}
else {
   result[17] = -x19 - 1.1428571428571428*x22 + 0.32653061224489799*x5*x6*x7;
}
if (x0) {
   result[18] = 0;
}
else {
   result[18] = -x20 - x40;
}
if (x0) {
   result[19] = 0;
}
else {
   result[19] = -x30 - x41;
}
if (x0) {
   result[20] = 0;
}
else {
   result[20] = -x19 - x28 - x32;
}
if (x0) {
   result[21] = 0;
}
else {
   result[21] = -x33 - x41;
}
if (x0) {
   result[22] = 0;
}
else {
   result[22] = -2.0*x22 - x36 + 0.5714285714285714*x5*x6*x7;
}
if (x0) {
   result[23] = 0;
}
else {
   result[23] = -x27 - x42 + 0.16326530612244897*x5*x6*x7;
}
if (x0) {
   result[24] = 0;
}
else {
   result[24] = -x39 - x41;
}
if (x0) {
   result[25] = 0;
}
else {
   result[25] = -x13 - 0.48979591836734698*x29 + 0.13994169096209913*x5*x6*x8;
}
if (x0) {
   result[26] = 0;
}
else {
   result[26] = -x19 - 1.1428571428571428*x29 + 0.32653061224489799*x5*x6*x8;
}
if (x0) {
   result[27] = 0;
}
else {
   result[27] = -x13 - x20 - x30;
}
if (x0) {
   result[28] = 0;
}
else {
   result[28] = -2.0*x29 - x36 + 0.5714285714285714*x5*x6*x8;
}
if (x0) {
   result[29] = 0;
}
else {
   result[29] = -x31 - x42 + 0.16326530612244897*x5*x6*x8;
}
if (x0) {
   result[30] = 0;
}
else {
   result[30] = -x13 - x17 - x39;
}
if (x0) {
   result[31] = 0;
}
else {
   result[31] = 6.0*x11*x6 - 1.7142857142857142*x12 - 6.0*x34 + 1.7142857142857142*x5*x6*x9;
}
if (x0) {
   result[32] = 0;
}
else {
   result[32] = 0.5714285714285714*x10*x5*x6 + 1.7142857142857142*x11*x6 - 0.48979591836734687*x12 - x35 - 2.0*x37 + 0.32653061224489793*x5*x6*x9;
}
if (x0) {
   result[33] = 0;
}
else {
   result[33] = 0.32653061224489793*x10*x5*x6 - 0.1399416909620991*x12 - x18 - 1.1428571428571428*x37;
}
if (x0) {
   result[34] = 0;
}
else {
   result[34] = 0.13994169096209913*x10*x5*x6 - x13 - 0.48979591836734698*x37;
}
}
        
static double coder_d3gdt3(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT3)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dT3)(T, P);
    double x3 = n4*(*endmember[3].d3mu0dT3)(T, P);
    double x4 = n5*(*endmember[4].d3mu0dT3)(T, P);
    double x5 = 0.19999999999999998*T - 1;
    double x6 = -x5;
    double x7 = 1.0*sqrt(x6);
    double x8 = x7 - 4;
    double x9 = 0;
    double x10 = pow(x6, -3.0/2.0);
    double x11 = (-x8 >= 0. ? 1. : 0.);
    double x12 = 1.2043214999999998*x10*x11;
    double x13 = 40.14405*T - 200.72024999999999;
    double x14 = pow(x5, -2);
    double x15 = x14*x9;
    double x16 = x11/pow(x6, 5.0/2.0);
    double x17 = x10*0;
    double x18 = fmin(4, x7);
    double x19 = ((x18)*(x18));

if (T >= 5.0) {
   result = x0 + x1 + x2 + x3 + x4;
}
else {
   result = (1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5)*(-n2*(0.40144049999999998*x10*((x11)*(x11)*(x11)) - 1.2043214999999998*((x11)*(x11))*x14*x18 - x12*x18*x9 + x12 + 0.0029999999999999992*x13*x15 + 0.0029999999999999996*x13*x16 - 0.0009999999999999998*x13*x17 + 0.60216074999999991*x15*x19 + 0.60216075000000002*x16*x19 - 0.20072024999999999*x17*x19 - 1.2043214999999998*x9/x5) + 3*x0 + 3*x1 + 3*x2 + 3*x3 + 3*x4)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = T >= 5.0;
    double x2 = 3*x0;
    double x3 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x4 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x5 = x3*x4;
    double x6 = (*endmember[1].d3mu0dT3)(T, P);
    double x7 = 3*x6;
    double x8 = (*endmember[2].d3mu0dT3)(T, P);
    double x9 = 3*x8;
    double x10 = (*endmember[3].d3mu0dT3)(T, P);
    double x11 = 3*x10;
    double x12 = (*endmember[4].d3mu0dT3)(T, P);
    double x13 = 3*x12;
    double x14 = 0.19999999999999998*T - 1;
    double x15 = -x14;
    double x16 = 1.0*sqrt(x15);
    double x17 = x16 - 4;
    double x18 = 0;
    double x19 = 1.2043214999999998*x18/x14;
    double x20 = pow(x15, -3.0/2.0);
    double x21 = (-x17 >= 0. ? 1. : 0.);
    double x22 = 1.2043214999999998*x20*x21;
    double x23 = 0.40144049999999998*x20*((x21)*(x21)*(x21));
    double x24 = 40.14405*T - 200.72024999999999;
    double x25 = pow(x14, -2);
    double x26 = x18*x25;
    double x27 = 0.0029999999999999992*x24*x26;
    double x28 = x21/pow(x15, 5.0/2.0);
    double x29 = 0.0029999999999999996*x24*x28;
    double x30 = x20*0;
    double x31 = 0.0009999999999999998*x24*x30;
    double x32 = fmin(4, x16);
    double x33 = ((x32)*(x32));
    double x34 = 0.60216074999999991*x26*x33;
    double x35 = 0.60216075000000002*x28*x33;
    double x36 = 0.20072024999999999*x30*x33;
    double x37 = 1.2043214999999998*((x21)*(x21))*x25*x32;
    double x38 = x18*x22*x32;
    double x39 = n1*x2 + n2*x7 - n2*(-x19 + x22 + x23 + x27 + x29 - x31 + x34 + x35 - x36 - x37 - x38) + n3*x9 + n4*x11 + n5*x13;
    double x40 = x3*x39;
    double x41 = x39*x4/((0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5)*(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5));
    double x42 = 1.0*x40 - 0.027210884353741499*x41;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x2*x5 + x42;
}
if (x1) {
   result[1] = x6;
}
else {
   result[1] = x42 + x5*(x19 - x22 - x23 - x27 - x29 + x31 - x34 - x35 + x36 + x37 + x38 + x7);
}
if (x1) {
   result[2] = x8;
}
else {
   result[2] = x42 + x5*x9;
}
if (x1) {
   result[3] = x10;
}
else {
   result[3] = x11*x5 + 3.5*x40 - 0.095238095238095247*x41;
}
if (x1) {
   result[4] = x12;
}
else {
   result[4] = x13*x5 + x42;
}
}
        
static void coder_d5gdn2dt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x2 = (*endmember[0].d3mu0dT3)(T, P);
    double x3 = x1*x2;
    double x4 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x2*x7;
    double x9 = 3*(*endmember[1].d3mu0dT3)(T, P);
    double x10 = (*endmember[2].d3mu0dT3)(T, P);
    double x11 = (*endmember[3].d3mu0dT3)(T, P);
    double x12 = (*endmember[4].d3mu0dT3)(T, P);
    double x13 = 0.19999999999999998*T - 1;
    double x14 = -x13;
    double x15 = 1.0*sqrt(x14);
    double x16 = x15 - 4;
    double x17 = 0;
    double x18 = 1.2043214999999998*x17/x13;
    double x19 = pow(x14, -3.0/2.0);
    double x20 = (-x16 >= 0. ? 1. : 0.);
    double x21 = 1.2043214999999998*x19*x20;
    double x22 = 0.40144049999999998*x19*((x20)*(x20)*(x20));
    double x23 = 40.14405*T - 200.72024999999999;
    double x24 = pow(x13, -2);
    double x25 = x17*x24;
    double x26 = 0.0029999999999999992*x23*x25;
    double x27 = x20/pow(x14, 5.0/2.0);
    double x28 = 0.0029999999999999996*x23*x27;
    double x29 = x19*0;
    double x30 = 0.0009999999999999998*x23*x29;
    double x31 = fmin(4, x15);
    double x32 = ((x31)*(x31));
    double x33 = 0.60216074999999991*x25*x32;
    double x34 = 0.60216075000000002*x27*x32;
    double x35 = 0.20072024999999999*x29*x32;
    double x36 = 1.2043214999999998*((x20)*(x20))*x24*x31;
    double x37 = x17*x21*x31;
    double x38 = 3*n1*x2 + n2*x9 - n2*(-x18 + x21 + x22 + x26 + x28 - x30 + x33 + x34 - x35 - x36 - x37) + 3*n3*x10 + 3*n4*x11 + 3*n5*x12;
    double x39 = x38*x5;
    double x40 = x38*x6/((x4)*(x4)*(x4));
    double x41 = -0.054421768707482998*x39 + 0.01554907677356657*x40;
    double x42 = 3.0*x3 + x41 - 0.081632653061224497*x8;
    double x43 = x18 - x21 - x22 - x26 - x28 + x30 - x33 - x34 + x35 + x36 + x37 + x9;
    double x44 = x1*x43;
    double x45 = x43*x7;
    double x46 = 1.0*x44 - 0.027210884353741499*x45;
    double x47 = 3.0*x1;
    double x48 = 0.081632653061224497*x7;
    double x49 = x10*x47 - x10*x48;
    double x50 = x11*x47 - x11*x48 - 0.19047619047619049*x39 + 0.054421768707482998*x40;
    double x51 = x12*x47 - x12*x48;
    double x52 = x41 + x46;
    double x53 = x1*x10;
    double x54 = x10*x7;
    double x55 = x1*x12;
    double x56 = x12*x7;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 6.0*x3 + x41 - 0.16326530612244899*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x42 + x46;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x42 + x49;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 10.5*x3 + x50 - 0.2857142857142857*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x42 + x51;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x41 + 2.0*x44 - 0.054421768707482998*x45;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x49 + x52;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = 3.5*x44 - 0.095238095238095247*x45 + x50;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x51 + x52;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x41 + 6.0*x53 - 0.16326530612244899*x54;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x50 + 10.5*x53 - 0.2857142857142857*x54;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x41 + x49 + x51;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 21.0*x1*x11 - 0.5714285714285714*x11*x7 - 0.66666666666666674*x39 + 0.19047619047619049*x40;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = x50 + 10.5*x55 - 0.28571428571428575*x56;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x41 + 6.0*x55 - 0.16326530612244899*x56;
}
}
        
static void coder_d6gdn3dt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dT3)(T, P);
    double x2 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x6 = pow(x2, -3);
    double x7 = 3*(*endmember[1].d3mu0dT3)(T, P);
    double x8 = (*endmember[2].d3mu0dT3)(T, P);
    double x9 = (*endmember[3].d3mu0dT3)(T, P);
    double x10 = (*endmember[4].d3mu0dT3)(T, P);
    double x11 = 0.19999999999999998*T - 1;
    double x12 = -x11;
    double x13 = 1.0*sqrt(x12);
    double x14 = x13 - 4;
    double x15 = 0;
    double x16 = 1.2043214999999998*x15/x11;
    double x17 = pow(x12, -3.0/2.0);
    double x18 = (-x14 >= 0. ? 1. : 0.);
    double x19 = 1.2043214999999998*x17*x18;
    double x20 = 0.40144049999999998*x17*((x18)*(x18)*(x18));
    double x21 = 40.14405*T - 200.72024999999999;
    double x22 = pow(x11, -2);
    double x23 = x15*x22;
    double x24 = 0.0029999999999999992*x21*x23;
    double x25 = x18/pow(x12, 5.0/2.0);
    double x26 = 0.0029999999999999996*x21*x25;
    double x27 = x17*0;
    double x28 = 0.0009999999999999998*x21*x27;
    double x29 = fmin(4, x13);
    double x30 = ((x29)*(x29));
    double x31 = 0.60216074999999991*x23*x30;
    double x32 = 0.60216075000000002*x25*x30;
    double x33 = 0.20072024999999999*x27*x30;
    double x34 = 1.2043214999999998*((x18)*(x18))*x22*x29;
    double x35 = x15*x19*x29;
    double x36 = 3*n1*x1 + n2*x7 - n2*(-x16 + x19 + x20 + x24 + x26 - x28 + x31 + x32 - x33 - x34 - x35) + 3*n3*x8 + 3*n4*x9 + 3*n5*x10;
    double x37 = x36*x5/((x2)*(x2)*(x2)*(x2));
    double x38 = -0.046647230320699715*x36*x6 + 0.013327780091628489*x37;
    double x39 = -0.093294460641399415*x1*x5*x6 + x38 + 0.32653061224489799*x4;
    double x40 = x16 - x19 - x20 - x24 - x26 + x28 - x31 - x32 + x33 + x34 + x35 + x7;
    double x41 = x3*x40;
    double x42 = -0.01554907677356657*x40*x5*x6 + 0.054421768707482998*x41;
    double x43 = 0.16326530612244899*x3;
    double x44 = x43*x8;
    double x45 = x44 - 0.046647230320699715*x5*x6*x8;
    double x46 = -0.16326530612244899*x36*x6 + x43*x9;
    double x47 = 0.046647230320699715*x37 + x46 - 0.046647230320699715*x5*x6*x9;
    double x48 = x10*x43 - 0.046647230320699715*x10*x5*x6;
    double x49 = -0.046647230320699708*x1*x5*x6 + x38 + 0.16326530612244899*x4;
    double x50 = -0.031098153547133141*x40*x5*x6 + 0.108843537414966*x41;
    double x51 = x42 + x49;
    double x52 = -0.054421768707482998*x40*x5*x6 + 0.19047619047619049*x41;
    double x53 = 0.5714285714285714*x4;
    double x54 = -0.16326530612244899*x1*x5*x6 + x47 + x53;
    double x55 = x3*x8;
    double x56 = 0.32653061224489799*x55;
    double x57 = -0.093294460641399429*x5*x6*x8 + x56;
    double x58 = 0.5714285714285714*x55;
    double x59 = -0.16326530612244899*x5*x6*x8 + x58;
    double x60 = x44 - 0.046647230320699708*x5*x6*x8;
    double x61 = x48 + x60;
    double x62 = x3*x9;
    double x63 = -0.57142857142857151*x36*x6 + 0.16326530612244899*x37;
    double x64 = -0.32653061224489799*x5*x6*x9 + 1.142857142857143*x62 + x63;
    double x65 = x10*x3;
    double x66 = 0.046647230320699708*x37 + x46 - 0.046647230320699708*x5*x6*x9;
    double x67 = -0.16326530612244899*x10*x5*x6 + 0.57142857142857151*x65 + x66;
    double x68 = -0.093294460641399429*x10*x5*x6 + 0.32653061224489799*x65;
    double x69 = x38 + x50;
    double x70 = x38 + x42;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 0.13994169096209913*x1*x5*x6 - x38 - 0.48979591836734698*x4;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = -x39 - x42;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = -x39 - x45;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 0.32653061224489799*x1*x5*x6 - 1.1428571428571428*x4 - x47;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -x39 - x48;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = -x49 - x50;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = -x45 - x51;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = -x52 - x54;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -x48 - x51;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = -x49 - x57;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = -x54 - x59;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = -x49 - x61;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 0.5714285714285714*x1*x5*x6 - 2.0*x4 - x64;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = 0.16326530612244897*x1*x5*x6 - x53 - x67;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = -x49 - x68;
}
if (x0) {
   result[15] = 0;
}
else {
   result[15] = -x38 + 0.046647230320699715*x40*x5*x6 - 0.16326530612244899*x41;
}
if (x0) {
   result[16] = 0;
}
else {
   result[16] = -x45 - x69;
}
if (x0) {
   result[17] = 0;
}
else {
   result[17] = 0.108843537414966*x40*x5*x6 - 0.38095238095238099*x41 - x47;
}
if (x0) {
   result[18] = 0;
}
else {
   result[18] = -x48 - x69;
}
if (x0) {
   result[19] = 0;
}
else {
   result[19] = -x57 - x70;
}
if (x0) {
   result[20] = 0;
}
else {
   result[20] = -x47 - x52 - x59;
}
if (x0) {
   result[21] = 0;
}
else {
   result[21] = -x61 - x70;
}
if (x0) {
   result[22] = 0;
}
else {
   result[22] = 0.19047619047619049*x40*x5*x6 - 0.66666666666666674*x41 - x64;
}
if (x0) {
   result[23] = 0;
}
else {
   result[23] = -x52 - x67;
}
if (x0) {
   result[24] = 0;
}
else {
   result[24] = -x68 - x70;
}
if (x0) {
   result[25] = 0;
}
else {
   result[25] = -x38 + 0.13994169096209913*x5*x6*x8 - 0.48979591836734698*x55;
}
if (x0) {
   result[26] = 0;
}
else {
   result[26] = -x47 + 0.32653061224489799*x5*x6*x8 - 1.1428571428571428*x55;
}
if (x0) {
   result[27] = 0;
}
else {
   result[27] = -x38 - x48 + 0.093294460641399415*x5*x6*x8 - x56;
}
if (x0) {
   result[28] = 0;
}
else {
   result[28] = 0.5714285714285714*x5*x6*x8 - 2.0*x55 - x64;
}
if (x0) {
   result[29] = 0;
}
else {
   result[29] = 0.16326530612244897*x5*x6*x8 - x58 - x67;
}
if (x0) {
   result[30] = 0;
}
else {
   result[30] = -x38 - x60 - x68;
}
if (x0) {
   result[31] = 0;
}
else {
   result[31] = 2.0*x36*x6 - 0.57142857142857151*x37 + 1.7142857142857144*x5*x6*x9 - 6.0*x62;
}
if (x0) {
   result[32] = 0;
}
else {
   result[32] = 0.57142857142857151*x10*x5*x6 + 0.32653061224489793*x5*x6*x9 - 1.1428571428571428*x62 - x63 - 2.0*x65;
}
if (x0) {
   result[33] = 0;
}
else {
   result[33] = 0.32653061224489799*x10*x5*x6 - 1.142857142857143*x65 - x66;
}
if (x0) {
   result[34] = 0;
}
else {
   result[34] = 0.13994169096209913*x10*x5*x6 - x38 - 0.48979591836734698*x65;
}
}
        
static double coder_d3gdt2dp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P) + n3*(*endmember[2].d3mu0dT2dP)(T, P) + n4*(*endmember[3].d3mu0dT2dP)(T, P) + n5*(*endmember[4].d3mu0dT2dP)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d3mu0dT2dP)(T, P);
    double x6 = (*endmember[2].d3mu0dT2dP)(T, P);
    double x7 = (*endmember[3].d3mu0dT2dP)(T, P);
    double x8 = (*endmember[4].d3mu0dT2dP)(T, P);
    double x9 = n1*x0 + n2*x5 + n3*x6 + n4*x7 + n5*x8;
    double x10 = x2*x9;
    double x11 = x3*x9/((0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5)*(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5));
    double x12 = 3.0*x10 - 0.081632653061224497*x11;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x12;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x12 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x12 + x4*x6;
}
if (x1) {
   result[3] = x7;
}
else {
   result[3] = 10.5*x10 - 0.2857142857142857*x11 + x4*x7;
}
if (x1) {
   result[4] = x8;
}
else {
   result[4] = x12 + x4*x8;
}
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = x1*x2;
    double x4 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = (*endmember[1].d3mu0dT2dP)(T, P);
    double x10 = (*endmember[2].d3mu0dT2dP)(T, P);
    double x11 = (*endmember[3].d3mu0dT2dP)(T, P);
    double x12 = (*endmember[4].d3mu0dT2dP)(T, P);
    double x13 = n1*x1 + n2*x9 + n3*x10 + n4*x11 + n5*x12;
    double x14 = x13*x5;
    double x15 = x13*x6/((x4)*(x4)*(x4));
    double x16 = -0.16326530612244899*x14 + 0.046647230320699708*x15;
    double x17 = x16 + 3.0*x3 - 0.081632653061224497*x8;
    double x18 = 3.0*x2;
    double x19 = 0.081632653061224497*x7;
    double x20 = x18*x9 - x19*x9;
    double x21 = x10*x18 - x10*x19;
    double x22 = x11*x18 - x11*x19 - 0.5714285714285714*x14;
    double x23 = 0.16326530612244899*x15 + x22;
    double x24 = x12*x18 - x12*x19;
    double x25 = x2*x9;
    double x26 = x7*x9;
    double x27 = x16 + x20;
    double x28 = x10*x2;
    double x29 = x10*x7;
    double x30 = x12*x2;
    double x31 = x12*x7;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x16 + 6.0*x3 - 0.16326530612244899*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x17 + x20;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 + x21;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x23 + 10.5*x3 - 0.2857142857142857*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 + x24;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x16 + 6.0*x25 - 0.16326530612244899*x26;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x21 + x27;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x23 + 10.5*x25 - 0.2857142857142857*x26;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x24 + x27;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x16 + 6.0*x28 - 0.16326530612244899*x29;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x23 + 10.5*x28 - 0.2857142857142857*x29;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x16 + x21 + x24;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 21.0*x11*x2 - 0.5714285714285714*x11*x7 - 2.0*x14 + 0.5714285714285714*x15;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = 0.16326530612244897*x15 + x22 + 10.5*x30 - 0.2857142857142857*x31;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x16 + 6.0*x30 - 0.16326530612244899*x31;
}
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x2 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x6 = pow(x2, -3);
    double x7 = (*endmember[1].d3mu0dT2dP)(T, P);
    double x8 = (*endmember[2].d3mu0dT2dP)(T, P);
    double x9 = (*endmember[3].d3mu0dT2dP)(T, P);
    double x10 = (*endmember[4].d3mu0dT2dP)(T, P);
    double x11 = n1*x1 + n2*x7 + n3*x8 + n4*x9 + n5*x10;
    double x12 = x11*x5/((x2)*(x2)*(x2)*(x2));
    double x13 = -0.13994169096209913*x11*x6 + 0.039983340274885461*x12;
    double x14 = -0.093294460641399415*x1*x5*x6 + x13 + 0.32653061224489799*x4;
    double x15 = 0.16326530612244899*x3;
    double x16 = x15*x7 - 0.046647230320699708*x5*x6*x7;
    double x17 = x15*x8 - 0.046647230320699708*x5*x6*x8;
    double x18 = -0.48979591836734693*x11*x6 + x15*x9 - 0.046647230320699708*x5*x6*x9;
    double x19 = 0.13994169096209913*x12 + x18;
    double x20 = x10*x15 - 0.046647230320699708*x10*x5*x6;
    double x21 = -0.046647230320699708*x1*x5*x6 + x13 + 0.16326530612244899*x4;
    double x22 = x3*x7;
    double x23 = 0.32653061224489799*x22 - 0.093294460641399415*x5*x6*x7;
    double x24 = x16 + x21;
    double x25 = x19 + 0.5714285714285714*x4;
    double x26 = -0.16326530612244899*x1*x5*x6 + x25;
    double x27 = 0.5714285714285714*x22;
    double x28 = x27 - 0.16326530612244899*x5*x6*x7;
    double x29 = x3*x8;
    double x30 = 0.32653061224489799*x29 - 0.093294460641399415*x5*x6*x8;
    double x31 = 0.5714285714285714*x29;
    double x32 = x31 - 0.16326530612244899*x5*x6*x8;
    double x33 = x17 + x20;
    double x34 = x3*x9;
    double x35 = 1.1428571428571428*x34;
    double x36 = -1.7142857142857144*x11*x6 + 0.48979591836734698*x12 + x35 - 0.32653061224489799*x5*x6*x9;
    double x37 = x10*x3;
    double x38 = -0.16326530612244899*x10*x5*x6 + 0.5714285714285714*x37;
    double x39 = -0.093294460641399415*x10*x5*x6 + 0.32653061224489799*x37;
    double x40 = x13 + x23;
    double x41 = x13 + x16;
    double x42 = x19 + x38;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 0.13994169096209913*x1*x5*x6 - x13 - 0.48979591836734698*x4;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = -x14 - x16;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = -x14 - x17;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 0.32653061224489799*x1*x5*x6 - x19 - 1.1428571428571428*x4;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -x14 - x20;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = -x21 - x23;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = -x17 - x24;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = -x26 - x28;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -x20 - x24;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = -x21 - x30;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = -x26 - x32;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = -x21 - x33;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 0.5714285714285714*x1*x5*x6 - x36 - 2.0*x4;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = 0.16326530612244897*x1*x5*x6 - x25 - x38;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = -x21 - x39;
}
if (x0) {
   result[15] = 0;
}
else {
   result[15] = -x13 - 0.48979591836734698*x22 + 0.13994169096209913*x5*x6*x7;
}
if (x0) {
   result[16] = 0;
}
else {
   result[16] = -x17 - x40;
}
if (x0) {
   result[17] = 0;
}
else {
   result[17] = -x19 - 1.1428571428571428*x22 + 0.32653061224489799*x5*x6*x7;
}
if (x0) {
   result[18] = 0;
}
else {
   result[18] = -x20 - x40;
}
if (x0) {
   result[19] = 0;
}
else {
   result[19] = -x30 - x41;
}
if (x0) {
   result[20] = 0;
}
else {
   result[20] = -x19 - x28 - x32;
}
if (x0) {
   result[21] = 0;
}
else {
   result[21] = -x33 - x41;
}
if (x0) {
   result[22] = 0;
}
else {
   result[22] = -2.0*x22 - x36 + 0.5714285714285714*x5*x6*x7;
}
if (x0) {
   result[23] = 0;
}
else {
   result[23] = -x27 - x42 + 0.16326530612244897*x5*x6*x7;
}
if (x0) {
   result[24] = 0;
}
else {
   result[24] = -x39 - x41;
}
if (x0) {
   result[25] = 0;
}
else {
   result[25] = -x13 - 0.48979591836734698*x29 + 0.13994169096209913*x5*x6*x8;
}
if (x0) {
   result[26] = 0;
}
else {
   result[26] = -x19 - 1.1428571428571428*x29 + 0.32653061224489799*x5*x6*x8;
}
if (x0) {
   result[27] = 0;
}
else {
   result[27] = -x13 - x20 - x30;
}
if (x0) {
   result[28] = 0;
}
else {
   result[28] = -2.0*x29 - x36 + 0.5714285714285714*x5*x6*x8;
}
if (x0) {
   result[29] = 0;
}
else {
   result[29] = -x31 - x42 + 0.16326530612244897*x5*x6*x8;
}
if (x0) {
   result[30] = 0;
}
else {
   result[30] = -x13 - x17 - x39;
}
if (x0) {
   result[31] = 0;
}
else {
   result[31] = 6.0*x11*x6 - 1.7142857142857142*x12 - 6.0*x34 + 1.7142857142857142*x5*x6*x9;
}
if (x0) {
   result[32] = 0;
}
else {
   result[32] = 0.5714285714285714*x10*x5*x6 + 1.7142857142857142*x11*x6 - 0.48979591836734687*x12 - x35 - 2.0*x37 + 0.32653061224489793*x5*x6*x9;
}
if (x0) {
   result[33] = 0;
}
else {
   result[33] = 0.32653061224489793*x10*x5*x6 - 0.1399416909620991*x12 - x18 - 1.1428571428571428*x37;
}
if (x0) {
   result[34] = 0;
}
else {
   result[34] = 0.13994169096209913*x10*x5*x6 - x13 - 0.48979591836734698*x37;
}
}
        
static double coder_d3gdtdp2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P) + n3*(*endmember[2].d3mu0dTdP2)(T, P) + n4*(*endmember[3].d3mu0dTdP2)(T, P) + n5*(*endmember[4].d3mu0dTdP2)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d3mu0dTdP2)(T, P);
    double x6 = (*endmember[2].d3mu0dTdP2)(T, P);
    double x7 = (*endmember[3].d3mu0dTdP2)(T, P);
    double x8 = (*endmember[4].d3mu0dTdP2)(T, P);
    double x9 = n1*x0 + n2*x5 + n3*x6 + n4*x7 + n5*x8;
    double x10 = x2*x9;
    double x11 = x3*x9/((0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5)*(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5));
    double x12 = 3.0*x10 - 0.081632653061224497*x11;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x12;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x12 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x12 + x4*x6;
}
if (x1) {
   result[3] = x7;
}
else {
   result[3] = 10.5*x10 - 0.2857142857142857*x11 + x4*x7;
}
if (x1) {
   result[4] = x8;
}
else {
   result[4] = x12 + x4*x8;
}
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = x1*x2;
    double x4 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = (*endmember[1].d3mu0dTdP2)(T, P);
    double x10 = (*endmember[2].d3mu0dTdP2)(T, P);
    double x11 = (*endmember[3].d3mu0dTdP2)(T, P);
    double x12 = (*endmember[4].d3mu0dTdP2)(T, P);
    double x13 = n1*x1 + n2*x9 + n3*x10 + n4*x11 + n5*x12;
    double x14 = x13*x5;
    double x15 = x13*x6/((x4)*(x4)*(x4));
    double x16 = -0.16326530612244899*x14 + 0.046647230320699708*x15;
    double x17 = x16 + 3.0*x3 - 0.081632653061224497*x8;
    double x18 = 3.0*x2;
    double x19 = 0.081632653061224497*x7;
    double x20 = x18*x9 - x19*x9;
    double x21 = x10*x18 - x10*x19;
    double x22 = x11*x18 - x11*x19 - 0.5714285714285714*x14;
    double x23 = 0.16326530612244899*x15 + x22;
    double x24 = x12*x18 - x12*x19;
    double x25 = x2*x9;
    double x26 = x7*x9;
    double x27 = x16 + x20;
    double x28 = x10*x2;
    double x29 = x10*x7;
    double x30 = x12*x2;
    double x31 = x12*x7;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x16 + 6.0*x3 - 0.16326530612244899*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x17 + x20;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 + x21;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x23 + 10.5*x3 - 0.2857142857142857*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 + x24;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x16 + 6.0*x25 - 0.16326530612244899*x26;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x21 + x27;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x23 + 10.5*x25 - 0.2857142857142857*x26;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x24 + x27;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x16 + 6.0*x28 - 0.16326530612244899*x29;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x23 + 10.5*x28 - 0.2857142857142857*x29;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x16 + x21 + x24;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 21.0*x11*x2 - 0.5714285714285714*x11*x7 - 2.0*x14 + 0.5714285714285714*x15;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = 0.16326530612244897*x15 + x22 + 10.5*x30 - 0.2857142857142857*x31;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x16 + 6.0*x30 - 0.16326530612244899*x31;
}
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x2 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x6 = pow(x2, -3);
    double x7 = (*endmember[1].d3mu0dTdP2)(T, P);
    double x8 = (*endmember[2].d3mu0dTdP2)(T, P);
    double x9 = (*endmember[3].d3mu0dTdP2)(T, P);
    double x10 = (*endmember[4].d3mu0dTdP2)(T, P);
    double x11 = n1*x1 + n2*x7 + n3*x8 + n4*x9 + n5*x10;
    double x12 = x11*x5/((x2)*(x2)*(x2)*(x2));
    double x13 = -0.13994169096209913*x11*x6 + 0.039983340274885461*x12;
    double x14 = -0.093294460641399415*x1*x5*x6 + x13 + 0.32653061224489799*x4;
    double x15 = 0.16326530612244899*x3;
    double x16 = x15*x7 - 0.046647230320699708*x5*x6*x7;
    double x17 = x15*x8 - 0.046647230320699708*x5*x6*x8;
    double x18 = -0.48979591836734693*x11*x6 + x15*x9 - 0.046647230320699708*x5*x6*x9;
    double x19 = 0.13994169096209913*x12 + x18;
    double x20 = x10*x15 - 0.046647230320699708*x10*x5*x6;
    double x21 = -0.046647230320699708*x1*x5*x6 + x13 + 0.16326530612244899*x4;
    double x22 = x3*x7;
    double x23 = 0.32653061224489799*x22 - 0.093294460641399415*x5*x6*x7;
    double x24 = x16 + x21;
    double x25 = x19 + 0.5714285714285714*x4;
    double x26 = -0.16326530612244899*x1*x5*x6 + x25;
    double x27 = 0.5714285714285714*x22;
    double x28 = x27 - 0.16326530612244899*x5*x6*x7;
    double x29 = x3*x8;
    double x30 = 0.32653061224489799*x29 - 0.093294460641399415*x5*x6*x8;
    double x31 = 0.5714285714285714*x29;
    double x32 = x31 - 0.16326530612244899*x5*x6*x8;
    double x33 = x17 + x20;
    double x34 = x3*x9;
    double x35 = 1.1428571428571428*x34;
    double x36 = -1.7142857142857144*x11*x6 + 0.48979591836734698*x12 + x35 - 0.32653061224489799*x5*x6*x9;
    double x37 = x10*x3;
    double x38 = -0.16326530612244899*x10*x5*x6 + 0.5714285714285714*x37;
    double x39 = -0.093294460641399415*x10*x5*x6 + 0.32653061224489799*x37;
    double x40 = x13 + x23;
    double x41 = x13 + x16;
    double x42 = x19 + x38;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 0.13994169096209913*x1*x5*x6 - x13 - 0.48979591836734698*x4;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = -x14 - x16;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = -x14 - x17;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 0.32653061224489799*x1*x5*x6 - x19 - 1.1428571428571428*x4;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -x14 - x20;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = -x21 - x23;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = -x17 - x24;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = -x26 - x28;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -x20 - x24;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = -x21 - x30;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = -x26 - x32;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = -x21 - x33;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 0.5714285714285714*x1*x5*x6 - x36 - 2.0*x4;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = 0.16326530612244897*x1*x5*x6 - x25 - x38;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = -x21 - x39;
}
if (x0) {
   result[15] = 0;
}
else {
   result[15] = -x13 - 0.48979591836734698*x22 + 0.13994169096209913*x5*x6*x7;
}
if (x0) {
   result[16] = 0;
}
else {
   result[16] = -x17 - x40;
}
if (x0) {
   result[17] = 0;
}
else {
   result[17] = -x19 - 1.1428571428571428*x22 + 0.32653061224489799*x5*x6*x7;
}
if (x0) {
   result[18] = 0;
}
else {
   result[18] = -x20 - x40;
}
if (x0) {
   result[19] = 0;
}
else {
   result[19] = -x30 - x41;
}
if (x0) {
   result[20] = 0;
}
else {
   result[20] = -x19 - x28 - x32;
}
if (x0) {
   result[21] = 0;
}
else {
   result[21] = -x33 - x41;
}
if (x0) {
   result[22] = 0;
}
else {
   result[22] = -2.0*x22 - x36 + 0.5714285714285714*x5*x6*x7;
}
if (x0) {
   result[23] = 0;
}
else {
   result[23] = -x27 - x42 + 0.16326530612244897*x5*x6*x7;
}
if (x0) {
   result[24] = 0;
}
else {
   result[24] = -x39 - x41;
}
if (x0) {
   result[25] = 0;
}
else {
   result[25] = -x13 - 0.48979591836734698*x29 + 0.13994169096209913*x5*x6*x8;
}
if (x0) {
   result[26] = 0;
}
else {
   result[26] = -x19 - 1.1428571428571428*x29 + 0.32653061224489799*x5*x6*x8;
}
if (x0) {
   result[27] = 0;
}
else {
   result[27] = -x13 - x20 - x30;
}
if (x0) {
   result[28] = 0;
}
else {
   result[28] = -2.0*x29 - x36 + 0.5714285714285714*x5*x6*x8;
}
if (x0) {
   result[29] = 0;
}
else {
   result[29] = -x31 - x42 + 0.16326530612244897*x5*x6*x8;
}
if (x0) {
   result[30] = 0;
}
else {
   result[30] = -x13 - x17 - x39;
}
if (x0) {
   result[31] = 0;
}
else {
   result[31] = 6.0*x11*x6 - 1.7142857142857142*x12 - 6.0*x34 + 1.7142857142857142*x5*x6*x9;
}
if (x0) {
   result[32] = 0;
}
else {
   result[32] = 0.5714285714285714*x10*x5*x6 + 1.7142857142857142*x11*x6 - 0.48979591836734687*x12 - x35 - 2.0*x37 + 0.32653061224489793*x5*x6*x9;
}
if (x0) {
   result[33] = 0;
}
else {
   result[33] = 0.32653061224489793*x10*x5*x6 - 0.1399416909620991*x12 - x18 - 1.1428571428571428*x37;
}
if (x0) {
   result[34] = 0;
}
else {
   result[34] = 0.13994169096209913*x10*x5*x6 - x13 - 0.48979591836734698*x37;
}
}
        
static double coder_d3gdp3(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P) + n3*(*endmember[2].d3mu0dP3)(T, P) + n4*(*endmember[3].d3mu0dP3)(T, P) + n5*(*endmember[4].d3mu0dP3)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5)/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
}
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = (*endmember[0].d3mu0dP3)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d3mu0dP3)(T, P);
    double x6 = (*endmember[2].d3mu0dP3)(T, P);
    double x7 = (*endmember[3].d3mu0dP3)(T, P);
    double x8 = (*endmember[4].d3mu0dP3)(T, P);
    double x9 = n1*x0 + n2*x5 + n3*x6 + n4*x7 + n5*x8;
    double x10 = x2*x9;
    double x11 = x3*x9/((0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5)*(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5));
    double x12 = 3.0*x10 - 0.081632653061224497*x11;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x12;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x12 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x12 + x4*x6;
}
if (x1) {
   result[3] = x7;
}
else {
   result[3] = 10.5*x10 - 0.2857142857142857*x11 + x4*x7;
}
if (x1) {
   result[4] = x8;
}
else {
   result[4] = x12 + x4*x8;
}
}
        
static void coder_d5gdn2dp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dP3)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 3.0*n3 + 10.5*n4 + 3.0*n5);
    double x3 = x1*x2;
    double x4 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = (*endmember[1].d3mu0dP3)(T, P);
    double x10 = (*endmember[2].d3mu0dP3)(T, P);
    double x11 = (*endmember[3].d3mu0dP3)(T, P);
    double x12 = (*endmember[4].d3mu0dP3)(T, P);
    double x13 = n1*x1 + n2*x9 + n3*x10 + n4*x11 + n5*x12;
    double x14 = x13*x5;
    double x15 = x13*x6/((x4)*(x4)*(x4));
    double x16 = -0.16326530612244899*x14 + 0.046647230320699708*x15;
    double x17 = x16 + 3.0*x3 - 0.081632653061224497*x8;
    double x18 = 3.0*x2;
    double x19 = 0.081632653061224497*x7;
    double x20 = x18*x9 - x19*x9;
    double x21 = x10*x18 - x10*x19;
    double x22 = x11*x18 - x11*x19 - 0.5714285714285714*x14;
    double x23 = 0.16326530612244899*x15 + x22;
    double x24 = x12*x18 - x12*x19;
    double x25 = x2*x9;
    double x26 = x7*x9;
    double x27 = x16 + x20;
    double x28 = x10*x2;
    double x29 = x10*x7;
    double x30 = x12*x2;
    double x31 = x12*x7;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x16 + 6.0*x3 - 0.16326530612244899*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x17 + x20;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 + x21;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x23 + 10.5*x3 - 0.2857142857142857*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 + x24;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x16 + 6.0*x25 - 0.16326530612244899*x26;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x21 + x27;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x23 + 10.5*x25 - 0.2857142857142857*x26;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = x24 + x27;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = x16 + 6.0*x28 - 0.16326530612244899*x29;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = x23 + 10.5*x28 - 0.2857142857142857*x29;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = x16 + x21 + x24;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 21.0*x11*x2 - 0.5714285714285714*x11*x7 - 2.0*x14 + 0.5714285714285714*x15;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = 0.16326530612244897*x15 + x22 + 10.5*x30 - 0.2857142857142857*x31;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = x16 + 6.0*x30 - 0.16326530612244899*x31;
}
}
        
static void coder_d6gdn3dp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dP3)(T, P);
    double x2 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4 + 0.2857142857142857*n5;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 3.5*n4 + 1.0*n5;
    double x6 = pow(x2, -3);
    double x7 = (*endmember[1].d3mu0dP3)(T, P);
    double x8 = (*endmember[2].d3mu0dP3)(T, P);
    double x9 = (*endmember[3].d3mu0dP3)(T, P);
    double x10 = (*endmember[4].d3mu0dP3)(T, P);
    double x11 = n1*x1 + n2*x7 + n3*x8 + n4*x9 + n5*x10;
    double x12 = x11*x5/((x2)*(x2)*(x2)*(x2));
    double x13 = -0.13994169096209913*x11*x6 + 0.039983340274885461*x12;
    double x14 = -0.093294460641399415*x1*x5*x6 + x13 + 0.32653061224489799*x4;
    double x15 = 0.16326530612244899*x3;
    double x16 = x15*x7 - 0.046647230320699708*x5*x6*x7;
    double x17 = x15*x8 - 0.046647230320699708*x5*x6*x8;
    double x18 = -0.48979591836734693*x11*x6 + x15*x9 - 0.046647230320699708*x5*x6*x9;
    double x19 = 0.13994169096209913*x12 + x18;
    double x20 = x10*x15 - 0.046647230320699708*x10*x5*x6;
    double x21 = -0.046647230320699708*x1*x5*x6 + x13 + 0.16326530612244899*x4;
    double x22 = x3*x7;
    double x23 = 0.32653061224489799*x22 - 0.093294460641399415*x5*x6*x7;
    double x24 = x16 + x21;
    double x25 = x19 + 0.5714285714285714*x4;
    double x26 = -0.16326530612244899*x1*x5*x6 + x25;
    double x27 = 0.5714285714285714*x22;
    double x28 = x27 - 0.16326530612244899*x5*x6*x7;
    double x29 = x3*x8;
    double x30 = 0.32653061224489799*x29 - 0.093294460641399415*x5*x6*x8;
    double x31 = 0.5714285714285714*x29;
    double x32 = x31 - 0.16326530612244899*x5*x6*x8;
    double x33 = x17 + x20;
    double x34 = x3*x9;
    double x35 = 1.1428571428571428*x34;
    double x36 = -1.7142857142857144*x11*x6 + 0.48979591836734698*x12 + x35 - 0.32653061224489799*x5*x6*x9;
    double x37 = x10*x3;
    double x38 = -0.16326530612244899*x10*x5*x6 + 0.5714285714285714*x37;
    double x39 = -0.093294460641399415*x10*x5*x6 + 0.32653061224489799*x37;
    double x40 = x13 + x23;
    double x41 = x13 + x16;
    double x42 = x19 + x38;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 0.13994169096209913*x1*x5*x6 - x13 - 0.48979591836734698*x4;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = -x14 - x16;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = -x14 - x17;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 0.32653061224489799*x1*x5*x6 - x19 - 1.1428571428571428*x4;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -x14 - x20;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = -x21 - x23;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = -x17 - x24;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = -x26 - x28;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -x20 - x24;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = -x21 - x30;
}
if (x0) {
   result[10] = 0;
}
else {
   result[10] = -x26 - x32;
}
if (x0) {
   result[11] = 0;
}
else {
   result[11] = -x21 - x33;
}
if (x0) {
   result[12] = 0;
}
else {
   result[12] = 0.5714285714285714*x1*x5*x6 - x36 - 2.0*x4;
}
if (x0) {
   result[13] = 0;
}
else {
   result[13] = 0.16326530612244897*x1*x5*x6 - x25 - x38;
}
if (x0) {
   result[14] = 0;
}
else {
   result[14] = -x21 - x39;
}
if (x0) {
   result[15] = 0;
}
else {
   result[15] = -x13 - 0.48979591836734698*x22 + 0.13994169096209913*x5*x6*x7;
}
if (x0) {
   result[16] = 0;
}
else {
   result[16] = -x17 - x40;
}
if (x0) {
   result[17] = 0;
}
else {
   result[17] = -x19 - 1.1428571428571428*x22 + 0.32653061224489799*x5*x6*x7;
}
if (x0) {
   result[18] = 0;
}
else {
   result[18] = -x20 - x40;
}
if (x0) {
   result[19] = 0;
}
else {
   result[19] = -x30 - x41;
}
if (x0) {
   result[20] = 0;
}
else {
   result[20] = -x19 - x28 - x32;
}
if (x0) {
   result[21] = 0;
}
else {
   result[21] = -x33 - x41;
}
if (x0) {
   result[22] = 0;
}
else {
   result[22] = -2.0*x22 - x36 + 0.5714285714285714*x5*x6*x7;
}
if (x0) {
   result[23] = 0;
}
else {
   result[23] = -x27 - x42 + 0.16326530612244897*x5*x6*x7;
}
if (x0) {
   result[24] = 0;
}
else {
   result[24] = -x39 - x41;
}
if (x0) {
   result[25] = 0;
}
else {
   result[25] = -x13 - 0.48979591836734698*x29 + 0.13994169096209913*x5*x6*x8;
}
if (x0) {
   result[26] = 0;
}
else {
   result[26] = -x19 - 1.1428571428571428*x29 + 0.32653061224489799*x5*x6*x8;
}
if (x0) {
   result[27] = 0;
}
else {
   result[27] = -x13 - x20 - x30;
}
if (x0) {
   result[28] = 0;
}
else {
   result[28] = -2.0*x29 - x36 + 0.5714285714285714*x5*x6*x8;
}
if (x0) {
   result[29] = 0;
}
else {
   result[29] = -x31 - x42 + 0.16326530612244897*x5*x6*x8;
}
if (x0) {
   result[30] = 0;
}
else {
   result[30] = -x13 - x17 - x39;
}
if (x0) {
   result[31] = 0;
}
else {
   result[31] = 6.0*x11*x6 - 1.7142857142857142*x12 - 6.0*x34 + 1.7142857142857142*x5*x6*x9;
}
if (x0) {
   result[32] = 0;
}
else {
   result[32] = 0.5714285714285714*x10*x5*x6 + 1.7142857142857142*x11*x6 - 0.48979591836734687*x12 - x35 - 2.0*x37 + 0.32653061224489793*x5*x6*x9;
}
if (x0) {
   result[33] = 0;
}
else {
   result[33] = 0.32653061224489793*x10*x5*x6 - 0.1399416909620991*x12 - x18 - 1.1428571428571428*x37;
}
if (x0) {
   result[34] = 0;
}
else {
   result[34] = 0.13994169096209913*x10*x5*x6 - x13 - 0.48979591836734698*x37;
}
}
        
static double coder_s(double T, double P, double n[5]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[5]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[5]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[5]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[5]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[5]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[5]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[5]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[5]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[5]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[5]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[5]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[5]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[5]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

