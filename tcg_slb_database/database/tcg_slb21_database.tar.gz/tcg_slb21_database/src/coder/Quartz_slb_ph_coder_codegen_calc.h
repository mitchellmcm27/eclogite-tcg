#include <math.h>


static double coder_g(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = 0.36660000000000004*P + 13121.723999999998;

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result = n1*x0;
}
else {
   result = n1*(x0*x1 - sqrt((2.793840199656692e-5*P - 0.0011806375442739081*T + 1)/(0.1222*P + 4373.9079999999994))*(2.9627737521971782*((P)*(P)) - 125.20264857893801*P*T + 176744.40557726749*P - 2987587.9227528935*T + 2530486970.571701))/x1;
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = 0.36660000000000004*P + 13121.723999999998;

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result[0] = x0;
}
else {
   result[0] = (x0*x1 - sqrt((2.793840199656692e-5*P - 0.0011806375442739081*T + 1)/(0.1222*P + 4373.9079999999994))*(2.9627737521971782*((P)*(P)) - 125.20264857893801*P*T + 176744.40557726749*P - 2987587.9227528935*T + 2530486970.571701))/x1;
}
}
        
static void coder_d2gdn2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d3gdn3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_dgdt(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = 0.36660000000000004*P + 13121.723999999998;
    double x2 = 125.20264857893801*P;
    double x3 = 2.793840199656692e-5*P - 0.0011806375442739081*T + 1;
    double x4 = sqrt(x3/(0.1222*P + 4373.9079999999994));

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result = n1*x0;
}
else {
   result = n1*(x0*x1 - x4*(-x2 - 2987587.9227528935) + 0.00059031877213695403*x4*(2.9627737521971782*((P)*(P)) + 176744.40557726749*P - T*x2 - 2987587.9227528935*T + 2530486970.571701)/x3)/x1;
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = 0.36660000000000004*P + 13121.723999999998;
    double x2 = 125.20264857893801*P;
    double x3 = 2.793840199656692e-5*P - 0.0011806375442739081*T + 1;
    double x4 = sqrt(x3/(0.1222*P + 4373.9079999999994));

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result[0] = x0;
}
else {
   result[0] = (x0*x1 - x4*(-x2 - 2987587.9227528935) + 0.00059031877213695403*x4*(2.9627737521971782*((P)*(P)) + 176744.40557726749*P - T*x2 - 2987587.9227528935*T + 2530486970.571701)/x3)/x1;
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d4gdn3dt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_dgdp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].dmu0dP)(T, P);
    double x2 = 2.793840199656692e-5*P + 1;
    double x3 = pow(x2, -2);
    double x4 = 0.36660000000000004*P + 13121.723999999998;
    double x5 = 125.20264857893801*T;
    double x6 = 0.1222*P + 4373.9079999999994;
    double x7 = 1.0/x6;
    double x8 = -0.0011806375442739081*T + x2;
    double x9 = sqrt(x7*x8);
    double x10 = x9*(2.9627737521971782*((P)*(P)) - P*x5 + 176744.40557726749*P - 2987587.9227528935*T + 2530486970.571701);

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result = n1*x1;
}
else {
   result = -2.1291715933490846e-9*n1*x3*(x0*x4 - x10) + n1*(0.36660000000000004*x0 + x1*x4 - x10*x6*(-3.1937573900236264e-9*x3*x8 + 1.396920099828346e-5*x7)/x8 - x9*(5.9255475043943564*P - x5 + 176744.40557726749))/x4;
}
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].dmu0dP)(T, P);
    double x2 = 2.793840199656692e-5*P + 1;
    double x3 = pow(x2, -2);
    double x4 = 0.36660000000000004*P + 13121.723999999998;
    double x5 = 125.20264857893801*T;
    double x6 = 0.1222*P + 4373.9079999999994;
    double x7 = 1.0/x6;
    double x8 = -0.0011806375442739081*T + x2;
    double x9 = sqrt(x7*x8);
    double x10 = x9*(2.9627737521971782*((P)*(P)) - P*x5 + 176744.40557726749*P - 2987587.9227528935*T + 2530486970.571701);

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result[0] = x1;
}
else {
   result[0] = -2.1291715933490846e-9*x3*(x0*x4 - x10) + (0.36660000000000004*x0 + x1*x4 - x10*x6*(-3.1937573900236264e-9*x3*x8 + 1.396920099828346e-5*x7)/x8 - x9*(5.9255475043943564*P - x5 + 176744.40557726749))/x4;
}
}
        
static void coder_d3gdn2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = 0.36660000000000004*P + 13121.723999999998;
    double x2 = 125.20264857893801*P;
    double x3 = 2.793840199656692e-5*P - 0.0011806375442739081*T + 1;
    double x4 = sqrt(x3/(0.1222*P + 4373.9079999999994));

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result = n1*x0;
}
else {
   result = n1*(x0*x1 - 0.0011806375442739081*x4*(x2 + 2987587.9227528935)/x3 + 3.4847625273728105e-7*x4*(2.9627737521971782*((P)*(P)) + 176744.40557726749*P - T*x2 - 2987587.9227528935*T + 2530486970.571701)/((x3)*(x3)))/x1;
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = 0.36660000000000004*P + 13121.723999999998;
    double x2 = 125.20264857893801*P;
    double x3 = 2.793840199656692e-5*P - 0.0011806375442739081*T + 1;
    double x4 = sqrt(x3/(0.1222*P + 4373.9079999999994));

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result[0] = x0;
}
else {
   result[0] = (x0*x1 - 0.0011806375442739081*x4*(x2 + 2987587.9227528935)/x3 + 3.4847625273728105e-7*x4*(2.9627737521971782*((P)*(P)) + 176744.40557726749*P - T*x2 - 2987587.9227528935*T + 2530486970.571701)/((x3)*(x3)))/x1;
}
}
        
static void coder_d4gdn2dt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d2mu0dTdP)(T, P);
    double x2 = 2.793840199656692e-5*P + 1;
    double x3 = pow(x2, -2);
    double x4 = 0.36660000000000004*P + 13121.723999999998;
    double x5 = (*endmember[0].dmu0dT)(T, P);
    double x6 = 0.1222*P + 4373.9079999999994;
    double x7 = 1.0/x6;
    double x8 = -0.0011806375442739081*T + x2;
    double x9 = sqrt(x7*x8);
    double x10 = x9*(125.20264857893801*P + 2987587.9227528935);
    double x11 = 125.20264857893801*T;
    double x12 = 2.9627737521971782*((P)*(P)) - P*x11 + 176744.40557726749*P - 2987587.9227528935*T + 2530486970.571701;
    double x13 = 1.0/x8;
    double x14 = x13*x9;
    double x15 = x12*x14;
    double x16 = x6*(-x3*(8.9228477841986438e-14*P - 3.7706698819641403e-12*T + 3.1937573900236264e-9) + 1.396920099828346e-5*x7);

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result = n1*x1;
}
else {
   result = n1*(-x3*(2.1291715933490846e-9*x10 + 1.2568899606547136e-12*x15 + 2.1291715933490846e-9*x4*x5) + (x1*x4 + x10*x13*x16 - 0.00059031877213695403*x12*x16*x9/((x8)*(x8)) + 0.00059031877213695403*x14*(5.9255475043943564*P - x11 + 176744.40557726749) - 3.7706698819641403e-12*x15*x3*x6 + 0.36660000000000004*x5 + 125.20264857893801*x9)/x4);
}
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d2mu0dTdP)(T, P);
    double x2 = 2.793840199656692e-5*P + 1;
    double x3 = pow(x2, -2);
    double x4 = 0.36660000000000004*P + 13121.723999999998;
    double x5 = (*endmember[0].dmu0dT)(T, P);
    double x6 = 0.1222*P + 4373.9079999999994;
    double x7 = 1.0/x6;
    double x8 = -0.0011806375442739081*T + x2;
    double x9 = sqrt(x7*x8);
    double x10 = x9*(125.20264857893801*P + 2987587.9227528935);
    double x11 = 125.20264857893801*T;
    double x12 = 2.9627737521971782*((P)*(P)) - P*x11 + 176744.40557726749*P - 2987587.9227528935*T + 2530486970.571701;
    double x13 = 1.0/x8;
    double x14 = x13*x9;
    double x15 = x12*x14;
    double x16 = x6*(-x3*(8.9228477841986438e-14*P - 3.7706698819641403e-12*T + 3.1937573900236264e-9) + 1.396920099828346e-5*x7);

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result[0] = x1;
}
else {
   result[0] = -x3*(2.1291715933490846e-9*x10 + 1.2568899606547136e-12*x15 + 2.1291715933490846e-9*x4*x5) + (x1*x4 + x10*x13*x16 - 0.00059031877213695403*x12*x16*x9/((x8)*(x8)) + 0.00059031877213695403*x14*(5.9255475043943564*P - x11 + 176744.40557726749) - 3.7706698819641403e-12*x15*x3*x6 + 0.36660000000000004*x5 + 125.20264857893801*x9)/x4;
}
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d2mu0dP2)(T, P);
    double x2 = 2.793840199656692e-5*P + 1;
    double x3 = 0.36660000000000004*P + 13121.723999999998;
    double x4 = 0.1222*P + 4373.9079999999994;
    double x5 = 1.0/x4;
    double x6 = -0.0011806375442739081*T + x2;
    double x7 = sqrt(x5*x6);
    double x8 = 125.20264857893801*T;
    double x9 = 2.9627737521971782*((P)*(P)) - P*x8 + 176744.40557726749*P - 2987587.9227528935*T + 2530486970.571701;
    double x10 = x7*x9;
    double x11 = ((x2)*(x2));
    double x12 = 1.0/x11;
    double x13 = (*endmember[0].dmu0dP)(T, P);
    double x14 = 5.9255475043943564*P - x8 + 176744.40557726749;
    double x15 = 4.2583431866981691e-9*x7;
    double x16 = 1.0/x6;
    double x17 = -x12*(8.9228477841986438e-14*P - 3.7706698819641403e-12*T + 3.1937573900236264e-9) + 1.396920099828346e-5*x5;
    double x18 = x16*x17;
    double x19 = x18*x4;
    double x20 = x10/((x6)*(x6));

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result = n1*x1;
}
else {
   result = n1*(x12*(-1.561108612243549e-9*x0 - 4.2583431866981691e-9*x13*x3 + x14*x15 + x15*x19*x9) - (-x1*x3 + 1.7845695568397288e-13*x10*x12*x16*x4*(-1 + x6/x2) + 0.1222*x10*x18 + 0.0037332100000000003*x11*x20*((-x12*(6.3875147800472529e-9*P - 2.6992738399479553e-7*T + 0.00022862849424359178) + x5)*(-x12*(6.3875147800472529e-9*P - 2.6992738399479553e-7*T + 0.00022862849424359178) + x5)) - 0.73320000000000007*x13 + 2*x14*x19*x7 - 2.793840199656692e-5*x17*x20*x4 + 5.9255475043943564*x7)/x3 - (-1.1897130378931526e-13*x0*x3 + 1.1897130378931526e-13*x10)/((x2)*(x2)*(x2)));
}
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d2mu0dP2)(T, P);
    double x2 = 2.793840199656692e-5*P + 1;
    double x3 = 0.36660000000000004*P + 13121.723999999998;
    double x4 = 0.1222*P + 4373.9079999999994;
    double x5 = 1.0/x4;
    double x6 = -0.0011806375442739081*T + x2;
    double x7 = sqrt(x5*x6);
    double x8 = 125.20264857893801*T;
    double x9 = 2.9627737521971782*((P)*(P)) - P*x8 + 176744.40557726749*P - 2987587.9227528935*T + 2530486970.571701;
    double x10 = x7*x9;
    double x11 = ((x2)*(x2));
    double x12 = 1.0/x11;
    double x13 = (*endmember[0].dmu0dP)(T, P);
    double x14 = 5.9255475043943564*P - x8 + 176744.40557726749;
    double x15 = 4.2583431866981691e-9*x7;
    double x16 = 1.0/x6;
    double x17 = -x12*(8.9228477841986438e-14*P - 3.7706698819641403e-12*T + 3.1937573900236264e-9) + 1.396920099828346e-5*x5;
    double x18 = x16*x17;
    double x19 = x18*x4;
    double x20 = x10/((x6)*(x6));

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result[0] = x1;
}
else {
   result[0] = x12*(-1.561108612243549e-9*x0 - 4.2583431866981691e-9*x13*x3 + x14*x15 + x15*x19*x9) - (-x1*x3 + 1.7845695568397288e-13*x10*x12*x16*x4*(-1 + x6/x2) + 0.1222*x10*x18 + 0.0037332100000000003*x11*x20*((-x12*(6.3875147800472529e-9*P - 2.6992738399479553e-7*T + 0.00022862849424359178) + x5)*(-x12*(6.3875147800472529e-9*P - 2.6992738399479553e-7*T + 0.00022862849424359178) + x5)) - 0.73320000000000007*x13 + 2*x14*x19*x7 - 2.793840199656692e-5*x17*x20*x4 + 5.9255475043943564*x7)/x3 - (-1.1897130378931526e-13*x0*x3 + 1.1897130378931526e-13*x10)/((x2)*(x2)*(x2));
}
}
        
static void coder_d4gdn2dp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = 0.36660000000000004*P + 13121.723999999998;
    double x2 = 125.20264857893801*P;
    double x3 = 2.793840199656692e-5*P - 0.0011806375442739081*T + 1;
    double x4 = sqrt(x3/(0.1222*P + 4373.9079999999994));

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result = n1*x0;
}
else {
   result = n1*(x0*x1 - 1.0454287582118431e-6*x4*(x2 + 2987587.9227528935)/((x3)*(x3)) + 6.1713622090427583e-10*x4*(2.9627737521971782*((P)*(P)) + 176744.40557726749*P - T*x2 - 2987587.9227528935*T + 2530486970.571701)/((x3)*(x3)*(x3)))/x1;
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = 0.36660000000000004*P + 13121.723999999998;
    double x2 = 125.20264857893801*P;
    double x3 = 2.793840199656692e-5*P - 0.0011806375442739081*T + 1;
    double x4 = sqrt(x3/(0.1222*P + 4373.9079999999994));

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result[0] = x0;
}
else {
   result[0] = (x0*x1 - 1.0454287582118431e-6*x4*(x2 + 2987587.9227528935)/((x3)*(x3)) + 6.1713622090427583e-10*x4*(2.9627737521971782*((P)*(P)) + 176744.40557726749*P - T*x2 - 2987587.9227528935*T + 2530486970.571701)/((x3)*(x3)*(x3)))/x1;
}
}
        
static void coder_d5gdn2dt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x2 = 2.793840199656692e-5*P + 1;
    double x3 = pow(x2, -2);
    double x4 = 0.36660000000000004*P + 13121.723999999998;
    double x5 = (*endmember[0].d2mu0dT2)(T, P);
    double x6 = 125.20264857893801*P;
    double x7 = x6 + 2987587.9227528935;
    double x8 = 0.1222*P + 4373.9079999999994;
    double x9 = 1.0/x8;
    double x10 = -0.0011806375442739081*T + x2;
    double x11 = sqrt(x10*x9);
    double x12 = 1.0/x10;
    double x13 = x11*x12*x7;
    double x14 = 2.9627737521971782*((P)*(P)) + 176744.40557726749*P - T*x6 - 2987587.9227528935*T + 2530486970.571701;
    double x15 = pow(x10, -2);
    double x16 = x11*x15;
    double x17 = -x3*(8.9228477841986438e-14*P - 3.7706698819641403e-12*T + 3.1937573900236264e-9) + 1.396920099828346e-5*x9;

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result = n1*x1;
}
else {
   result = -n1*(x3*(-2.5137799213094272e-12*x13 + 7.4196573828495504e-16*x14*x16 + 2.1291715933490846e-9*x4*x5) + (-x1*x4 + 0.14781894755482647*x11*x12 + 4.4517944297097297e-15*x11*x14*x15*x3*x8 - 7.5413397639282805e-12*x13*x3*x8 - 0.0011806375442739081*x16*x17*x7*x8 - 3.4847625273728105e-7*x16*(5.9255475043943564*P - 125.20264857893801*T + 176744.40557726749) - 0.36660000000000004*x5 + 1.0454287582118431e-6*x11*x14*x17*x8/((x10)*(x10)*(x10)))/x4);
}
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x2 = 2.793840199656692e-5*P + 1;
    double x3 = pow(x2, -2);
    double x4 = 0.36660000000000004*P + 13121.723999999998;
    double x5 = (*endmember[0].d2mu0dT2)(T, P);
    double x6 = 125.20264857893801*P;
    double x7 = x6 + 2987587.9227528935;
    double x8 = 0.1222*P + 4373.9079999999994;
    double x9 = 1.0/x8;
    double x10 = -0.0011806375442739081*T + x2;
    double x11 = sqrt(x10*x9);
    double x12 = 1.0/x10;
    double x13 = x11*x12*x7;
    double x14 = 2.9627737521971782*((P)*(P)) + 176744.40557726749*P - T*x6 - 2987587.9227528935*T + 2530486970.571701;
    double x15 = pow(x10, -2);
    double x16 = x11*x15;
    double x17 = -x3*(8.9228477841986438e-14*P - 3.7706698819641403e-12*T + 3.1937573900236264e-9) + 1.396920099828346e-5*x9;

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result[0] = x1;
}
else {
   result[0] = -x3*(-2.5137799213094272e-12*x13 + 7.4196573828495504e-16*x14*x16 + 2.1291715933490846e-9*x4*x5) - (-x1*x4 + 0.14781894755482647*x11*x12 + 4.4517944297097297e-15*x11*x14*x15*x3*x8 - 7.5413397639282805e-12*x13*x3*x8 - 0.0011806375442739081*x16*x17*x7*x8 - 3.4847625273728105e-7*x16*(5.9255475043943564*P - 125.20264857893801*T + 176744.40557726749) - 0.36660000000000004*x5 + 1.0454287582118431e-6*x11*x14*x17*x8/((x10)*(x10)*(x10)))/x4;
}
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x2 = 2.793840199656692e-5*P + 1;
    double x3 = pow(x2, -3);
    double x4 = 0.36660000000000004*P + 13121.723999999998;
    double x5 = (*endmember[0].dmu0dT)(T, P);
    double x6 = 0.1222*P + 4373.9079999999994;
    double x7 = 1.0/x6;
    double x8 = -0.0011806375442739081*T + x2;
    double x9 = sqrt(x7*x8);
    double x10 = 125.20264857893801*P;
    double x11 = x10 + 2987587.9227528935;
    double x12 = x11*x9;
    double x13 = 2.9627737521971782*((P)*(P)) + 176744.40557726749*P - T*x10 - 2987587.9227528935*T + 2530486970.571701;
    double x14 = 1.0/x8;
    double x15 = x14*x9;
    double x16 = x13*x15;
    double x17 = ((x2)*(x2));
    double x18 = 1.0/x17;
    double x19 = (*endmember[0].d2mu0dTdP)(T, P);
    double x20 = 5.9255475043943564*P - 125.20264857893801*T + 176744.40557726749;
    double x21 = -x18*(8.9228477841986438e-14*P - 3.7706698819641403e-12*T + 3.1937573900236264e-9) + 1.396920099828346e-5*x7;
    double x22 = x21*x6;
    double x23 = x12*x14;
    double x24 = pow(x8, -2);
    double x25 = x13*x24*x9;
    double x26 = x18*x6;
    double x27 = -1 + x8/x2;
    double x28 = -x18*(6.3875147800472529e-9*P - 2.6992738399479553e-7*T + 0.00022862849424359178) + x7;
    double x29 = ((x28)*(x28));
    double x30 = pow(x8, -3);

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result = n1*x1;
}
else {
   result = n1*(-x18*(2.5137799213094272e-12*x15*x20 - 1.6056806401149986e-20*x16*x18*x6 + 4.2583431866981691e-9*x19*x4 - 2.5137799213094272e-12*x21*x25*x6 + 4.2583431866981691e-9*x22*x23 + 1.561108612243549e-9*x5 + 5.3315584553268585e-7*x9) + x3*(1.1897130378931526e-13*x12 + 7.0230993972441127e-17*x16 + 1.1897130378931526e-13*x4*x5) - (-x1*x4 + 2.793840199656692e-5*x11*x21*x24*x6*x9 - 0.0037332100000000003*x12*x17*x24*x29 + 4.6077585957601793e-13*x13*x14*x18*x9 + 6.6113518299881948e-6*x13*x17*x29*x30*x9 + 1.0534649095866169e-16*x13*x18*x24*x27*x6*x9 + 7.213695395513578e-5*x13*x21*x24*x9 - 4.9477689486246025e-8*x13*x22*x30*x9 + 2.0153912184064213e-9*x13*x24*x28*x9 + 7.5413397639282805e-12*x14*x18*x20*x6*x9 - 250.40529715787602*x15*x22 - 0.0034979619270332687*x15 - 2.1069298191732338e-16*x16*x3*x6 - 0.73320000000000007*x19 + 0.0011806375442739081*x20*x21*x24*x6*x9 - 0.1222*x21*x23 - 1.7845695568397288e-13*x23*x26*x27 - 1.0534649095866169e-16*x25*x26)/x4);
}
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x2 = 2.793840199656692e-5*P + 1;
    double x3 = pow(x2, -3);
    double x4 = 0.36660000000000004*P + 13121.723999999998;
    double x5 = (*endmember[0].dmu0dT)(T, P);
    double x6 = 0.1222*P + 4373.9079999999994;
    double x7 = 1.0/x6;
    double x8 = -0.0011806375442739081*T + x2;
    double x9 = sqrt(x7*x8);
    double x10 = 125.20264857893801*P;
    double x11 = x10 + 2987587.9227528935;
    double x12 = x11*x9;
    double x13 = 2.9627737521971782*((P)*(P)) + 176744.40557726749*P - T*x10 - 2987587.9227528935*T + 2530486970.571701;
    double x14 = 1.0/x8;
    double x15 = x14*x9;
    double x16 = x13*x15;
    double x17 = ((x2)*(x2));
    double x18 = 1.0/x17;
    double x19 = (*endmember[0].d2mu0dTdP)(T, P);
    double x20 = 5.9255475043943564*P - 125.20264857893801*T + 176744.40557726749;
    double x21 = -x18*(8.9228477841986438e-14*P - 3.7706698819641403e-12*T + 3.1937573900236264e-9) + 1.396920099828346e-5*x7;
    double x22 = x21*x6;
    double x23 = x12*x14;
    double x24 = pow(x8, -2);
    double x25 = x13*x24*x9;
    double x26 = x18*x6;
    double x27 = -1 + x8/x2;
    double x28 = -x18*(6.3875147800472529e-9*P - 2.6992738399479553e-7*T + 0.00022862849424359178) + x7;
    double x29 = ((x28)*(x28));
    double x30 = pow(x8, -3);

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result[0] = x1;
}
else {
   result[0] = -x18*(2.5137799213094272e-12*x15*x20 - 1.6056806401149986e-20*x16*x18*x6 + 4.2583431866981691e-9*x19*x4 - 2.5137799213094272e-12*x21*x25*x6 + 4.2583431866981691e-9*x22*x23 + 1.561108612243549e-9*x5 + 5.3315584553268585e-7*x9) + x3*(1.1897130378931526e-13*x12 + 7.0230993972441127e-17*x16 + 1.1897130378931526e-13*x4*x5) - (-x1*x4 + 2.793840199656692e-5*x11*x21*x24*x6*x9 - 0.0037332100000000003*x12*x17*x24*x29 + 4.6077585957601793e-13*x13*x14*x18*x9 + 6.6113518299881948e-6*x13*x17*x29*x30*x9 + 1.0534649095866169e-16*x13*x18*x24*x27*x6*x9 + 7.213695395513578e-5*x13*x21*x24*x9 - 4.9477689486246025e-8*x13*x22*x30*x9 + 2.0153912184064213e-9*x13*x24*x28*x9 + 7.5413397639282805e-12*x14*x18*x20*x6*x9 - 250.40529715787602*x15*x22 - 0.0034979619270332687*x15 - 2.1069298191732338e-16*x16*x3*x6 - 0.73320000000000007*x19 + 0.0011806375442739081*x20*x21*x24*x6*x9 - 0.1222*x21*x23 - 1.7845695568397288e-13*x23*x26*x27 - 1.0534649095866169e-16*x25*x26)/x4;
}
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d3mu0dP3)(T, P);
    double x2 = 2.793840199656692e-5*P + 1;
    double x3 = 0.36660000000000004*P + 13121.723999999998;
    double x4 = 0.1222*P + 4373.9079999999994;
    double x5 = 1.0/x4;
    double x6 = -0.0011806375442739081*T + x2;
    double x7 = sqrt(x5*x6);
    double x8 = 125.20264857893801*T;
    double x9 = x7*(2.9627737521971782*((P)*(P)) - P*x8 + 176744.40557726749*P - 2987587.9227528935*T + 2530486970.571701);
    double x10 = 9.9716043339647247e-18*x9;
    double x11 = pow(x2, -3);
    double x12 = (*endmember[0].dmu0dP)(T, P);
    double x13 = x7*(5.9255475043943564*P - x8 + 176744.40557726749);
    double x14 = 1.0/x6;
    double x15 = ((x2)*(x2));
    double x16 = 1.0/x15;
    double x17 = -x16*(8.9228477841986438e-14*P - 3.7706698819641403e-12*T + 3.1937573900236264e-9) + 1.396920099828346e-5*x5;
    double x18 = x14*x17;
    double x19 = x18*x9;
    double x20 = (*endmember[0].d2mu0dP2)(T, P);
    double x21 = x13*x18;
    double x22 = x14*x9;
    double x23 = 1 - x6/x2;
    double x24 = -x23;
    double x25 = x16*x24;
    double x26 = x22*x25;
    double x27 = pow(x6, -2);
    double x28 = x27*x9;
    double x29 = x17*x28;
    double x30 = -x16*(6.3875147800472529e-9*P - 2.6992738399479553e-7*T + 0.00022862849424359178) + x5;
    double x31 = ((x30)*(x30));
    double x32 = x28*x31;
    double x33 = x25*x4;
    double x34 = x13*x27;
    double x35 = x17*x4;
    double x36 = x15*x31;
    double x37 = x9/((x6)*(x6)*(x6));
    double x38 = x35*x37;

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result = n1*x1;
}
else {
   result = n1*(-x11*(-1.3084463990748893e-13*x0 - 3.5691391136794575e-13*x12*x3 + 3.5691391136794575e-13*x13 + 3.5691391136794575e-13*x19*x4) + x16*(-4.6833258367306467e-9*x12 + 2.3845934052020208e-11*x15*x32 + 7.8055430612177438e-10*x19 - 6.3875147800472537e-9*x20*x3 + 1.2775029560094507e-8*x21*x4 + 1.1398964420336145e-21*x26*x4 - 1.784569556839729e-13*x29*x4 + 3.784952226419107e-8*x7) - (-x1*x3 - x10*x27*x33 + 1.4957406500947087e-17*x11*x22*x23*x4 + 5.3537086705191863e-13*x13*x14*x33 + 17.77664251318307*x18*x4*x7 - 1.0998000000000001*x20 + 0.36660000000000004*x21 + 9.5383736208080821e-11*x24*x28*x30 + 3.414072723980477e-6*x24*x29 + 4.3614879969162974e-14*x26 - 6.8281454479609556e-6*x29 + 2.3845934052020212e-11*x32*x4 + 1.9513857653044362e-10*x32*(0.029865680000000002*P + 1068.9831151999999) - 8.3815205989700757e-5*x34*x35 + 0.01119963*x34*x36 - 3.1289976515281083e-7*x36*x37 + 0.0037332100000000003*x36*x38 + 1.561108612243549e-9*x38)/x3 + (-9.9716043339647247e-18*x0*x3 + x10)/((x2)*(x2)*(x2)*(x2)));
}
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = (*endmember[0].d3mu0dP3)(T, P);
    double x2 = 2.793840199656692e-5*P + 1;
    double x3 = 0.36660000000000004*P + 13121.723999999998;
    double x4 = 0.1222*P + 4373.9079999999994;
    double x5 = 1.0/x4;
    double x6 = -0.0011806375442739081*T + x2;
    double x7 = sqrt(x5*x6);
    double x8 = 125.20264857893801*T;
    double x9 = x7*(2.9627737521971782*((P)*(P)) - P*x8 + 176744.40557726749*P - 2987587.9227528935*T + 2530486970.571701);
    double x10 = 9.9716043339647247e-18*x9;
    double x11 = pow(x2, -3);
    double x12 = (*endmember[0].dmu0dP)(T, P);
    double x13 = x7*(5.9255475043943564*P - x8 + 176744.40557726749);
    double x14 = 1.0/x6;
    double x15 = ((x2)*(x2));
    double x16 = 1.0/x15;
    double x17 = -x16*(8.9228477841986438e-14*P - 3.7706698819641403e-12*T + 3.1937573900236264e-9) + 1.396920099828346e-5*x5;
    double x18 = x14*x17;
    double x19 = x18*x9;
    double x20 = (*endmember[0].d2mu0dP2)(T, P);
    double x21 = x13*x18;
    double x22 = x14*x9;
    double x23 = 1 - x6/x2;
    double x24 = -x23;
    double x25 = x16*x24;
    double x26 = x22*x25;
    double x27 = pow(x6, -2);
    double x28 = x27*x9;
    double x29 = x17*x28;
    double x30 = -x16*(6.3875147800472529e-9*P - 2.6992738399479553e-7*T + 0.00022862849424359178) + x5;
    double x31 = ((x30)*(x30));
    double x32 = x28*x31;
    double x33 = x25*x4;
    double x34 = x13*x27;
    double x35 = x17*x4;
    double x36 = x15*x31;
    double x37 = x9/((x6)*(x6)*(x6));
    double x38 = x35*x37;

if (0.02366382649109218*P - 1.0*T <= -847.0) {
   result[0] = x1;
}
else {
   result[0] = -x11*(-1.3084463990748893e-13*x0 - 3.5691391136794575e-13*x12*x3 + 3.5691391136794575e-13*x13 + 3.5691391136794575e-13*x19*x4) + x16*(-4.6833258367306467e-9*x12 + 2.3845934052020208e-11*x15*x32 + 7.8055430612177438e-10*x19 - 6.3875147800472537e-9*x20*x3 + 1.2775029560094507e-8*x21*x4 + 1.1398964420336145e-21*x26*x4 - 1.784569556839729e-13*x29*x4 + 3.784952226419107e-8*x7) - (-x1*x3 - x10*x27*x33 + 1.4957406500947087e-17*x11*x22*x23*x4 + 5.3537086705191863e-13*x13*x14*x33 + 17.77664251318307*x18*x4*x7 - 1.0998000000000001*x20 + 0.36660000000000004*x21 + 9.5383736208080821e-11*x24*x28*x30 + 3.414072723980477e-6*x24*x29 + 4.3614879969162974e-14*x26 - 6.8281454479609556e-6*x29 + 2.3845934052020212e-11*x32*x4 + 1.9513857653044362e-10*x32*(0.029865680000000002*P + 1068.9831151999999) - 8.3815205989700757e-5*x34*x35 + 0.01119963*x34*x36 - 3.1289976515281083e-7*x36*x37 + 0.0037332100000000003*x36*x38 + 1.561108612243549e-9*x38)/x3 + (-9.9716043339647247e-18*x0*x3 + x10)/((x2)*(x2)*(x2)*(x2));
}
}
        
static void coder_d5gdn2dp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_s(double T, double P, double n[1]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[1]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[1]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[1]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[1]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[1]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[1]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[1]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[1]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[1]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[1]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[1]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[1]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[1]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

