#include <math.h>


static double coder_g(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = n1 + n2;
    double x1 = 1.0/x0;
    double x2 = 4700.0*n1*n2;
    double x3 = n1*(*endmember[0].mu0)(T, P);
    double x4 = n2*(*endmember[1].mu0)(T, P);
    double x5 = T*(n1*log(n1*x1) + n2*log(n2*x1));
    double x6 = fmin(4, 1.0000000000000002*sqrt(1 - 0.015384615384615385*T));

if (T >= 65.0) {
   result = x1*(1.0*x0*(-n2*(26.762699999999999*T - 1159.7169999999999) + x3 + x4 + 16.628925236306479*x5) + x2);
}
else {
   result = x1*(0.33333333333333331*x0*(n2*(1739.5754999999999*((x6)*(x6)*(x6)) + (80.2881*T - 5218.7264999999998)*(x6 - 1) - 1739.5754999999999) + 3*x3 + 3*x4 + 49.886775708919437*x5) + x2);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = pow(x0, -2);
    double x2 = 4700.0*n2;
    double x3 = n1*x2;
    double x4 = (*endmember[0].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[1].mu0)(T, P);
    double x7 = n2*x6;
    double x8 = 26.762699999999999*T;
    double x9 = x8 - 1159.7169999999999;
    double x10 = 1.0/x0;
    double x11 = n1*x10;
    double x12 = log(x11);
    double x13 = n2*x10;
    double x14 = log(x13);
    double x15 = n1*x12 + n2*x14;
    double x16 = 16.628925236306479*T;
    double x17 = x15*x16;
    double x18 = -x1*(1.0*x0*(-n2*x9 + x17 + x5 + x7) + x3);
    double x19 = 1.0*n1;
    double x20 = 1.0*n2;
    double x21 = x19 + x20;
    double x22 = x0*(-n1*x1 + x10) + x12 - x13;
    double x23 = -x20*x9;
    double x24 = x17 + x19*x4 + x20*x6;
    double x25 = x2 + x24;
    double x26 = T >= 65.0;
    double x27 = 49.886775708919437*T;
    double x28 = fmin(4, 1.0000000000000002*sqrt(1 - 0.015384615384615385*T));
    double x29 = 1739.5754999999999*((x28)*(x28)*(x28)) + (80.2881*T - 5218.7264999999998)*(x28 - 1) - 1739.5754999999999;
    double x30 = -x1*(0.33333333333333331*x0*(n2*x29 + x15*x27 + 3*x5 + 3*x7) + x3);
    double x31 = 0.33333333333333331*n2;
    double x32 = 0.33333333333333331*n1 + x31;
    double x33 = x29*x31;
    double x34 = x0*(-n2*x1 + x10) - x11 + x14;
    double x35 = 4700.0*n1 + x24;

if (x26) {
   result[0] = x10*(x21*(x16*x22 + x4) + x23 + x25) + x18;
}
else {
   result[0] = x10*(x25 + x32*(x22*x27 + 3*x4) + x33) + x30;
}
if (x26) {
   result[1] = x10*(x21*(x16*x34 + x6 - x8 + 1159.7169999999999) + x23 + x35) + x18;
}
else {
   result[1] = x10*(x32*(x27*x34 + x29 + 3*x6) + x33 + x35) + x30;
}
}
        
static void coder_d2gdn2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = 4700.0*n2;
    double x1 = n1*x0;
    double x2 = n1 + n2;
    double x3 = (*endmember[0].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = n2*x5;
    double x7 = 26.762699999999999*T;
    double x8 = x7 - 1159.7169999999999;
    double x9 = 1.0/x2;
    double x10 = n1*x9;
    double x11 = log(x10);
    double x12 = n2*x9;
    double x13 = log(x12);
    double x14 = T*(n1*x11 + n2*x13);
    double x15 = 16.628925236306479*x14;
    double x16 = 2/((x2)*(x2)*(x2));
    double x17 = x16*(x1 + 1.0*x2*(-n2*x8 + x15 + x4 + x6));
    double x18 = 1.0*n1;
    double x19 = 1.0*n2;
    double x20 = x18 + x19;
    double x21 = pow(x2, -2);
    double x22 = n1*x21;
    double x23 = -x22;
    double x24 = x23 + x9;
    double x25 = x2*x24;
    double x26 = T*(x11 - x12 + x25);
    double x27 = 16.628925236306479*x26;
    double x28 = -x19*x8;
    double x29 = x15 + x18*x3 + x19*x5;
    double x30 = x0 + x29;
    double x31 = x20*(x27 + x3) + x28 + x30;
    double x32 = 2*x21;
    double x33 = n2*x21;
    double x34 = -x32;
    double x35 = n1*x16;
    double x36 = T*(x2*(x34 + x35) + x24 + x33 + x25/n1);
    double x37 = 16.628925236306479*x20;
    double x38 = 33.257850472612958*x26 + 2.0*x3;
    double x39 = T >= 65.0;
    double x40 = fmin(4, 1.0000000000000002*sqrt(1 - 0.015384615384615385*T));
    double x41 = ((x40)*(x40)*(x40));
    double x42 = (80.2881*T - 5218.7264999999998)*(x40 - 1);
    double x43 = 1739.5754999999999*x41 + x42 - 1739.5754999999999;
    double x44 = x16*(x1 + 0.33333333333333331*x2*(n2*x43 + 49.886775708919437*x14 + 3*x4 + 3*x6));
    double x45 = 0.33333333333333331*n2;
    double x46 = 0.33333333333333331*n1 + x45;
    double x47 = 49.886775708919437*x46;
    double x48 = x43*x45;
    double x49 = x30 + x46*(49.886775708919437*x26 + 3*x3) + x48;
    double x50 = -x33 + x9;
    double x51 = x2*x50;
    double x52 = T*(-x10 + x13 + x51);
    double x53 = 16.628925236306479*x52;
    double x54 = x53 - x7;
    double x55 = 4700.0*n1 + x29;
    double x56 = x20*(x5 + x54 + 1159.7169999999999) + x28 + x55;
    double x57 = T*(x2*(-x21 + x35) + x23 + x33 - x9);
    double x58 = x27 + 1.0*x3 + 1.0*x5;
    double x59 = x46*(x43 + 3*x5 + 49.886775708919437*x52) + x48 + x55;
    double x60 = T*(x2*(n2*x16 + x34) + x22 + x50 + x51/n2);
    double x61 = 2.0*x5 + 33.257850472612958*x52;

if (x39) {
   result[0] = x17 - x31*x32 + x9*(x36*x37 + x38);
}
else {
   result[0] = -x32*x49 + x44 + x9*(x36*x47 + x38);
}
if (x39) {
   result[1] = x17 - x21*x31 - x21*x56 + x9*(x37*x57 + x54 + x58 + 5859.7169999999996);
}
else {
   result[1] = -x21*x49 - x21*x59 + x44 + x9*(579.85849999999994*x41 + 0.33333333333333331*x42 + x47*x57 + x53 + x58 + 4120.1414999999997);
}
if (x39) {
   result[2] = x17 - x32*x56 + x9*(-53.525399999999998*T + x37*x60 + x61 + 2319.4339999999997);
}
else {
   result[2] = -x32*x59 + x44 + x9*(1159.7169999999999*x41 + 0.66666666666666663*x42 + x47*x60 + x61 - 1159.7169999999999);
}
}
        
static void coder_d3gdn3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = 4700.0*n2;
    double x1 = n1*x0;
    double x2 = n1 + n2;
    double x3 = (*endmember[0].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = n2*x5;
    double x7 = 26.762699999999999*T;
    double x8 = x7 - 1159.7169999999999;
    double x9 = 1.0/x2;
    double x10 = n1*x9;
    double x11 = log(x10);
    double x12 = n2*x9;
    double x13 = log(x12);
    double x14 = n1*x11 + n2*x13;
    double x15 = 16.628925236306479*T;
    double x16 = x14*x15;
    double x17 = 6/((x2)*(x2)*(x2)*(x2));
    double x18 = -x17*(x1 + 1.0*x2*(-n2*x8 + x16 + x4 + x6));
    double x19 = 1.0*n1;
    double x20 = 1.0*n2;
    double x21 = x19 + x20;
    double x22 = pow(x2, -2);
    double x23 = n1*x22;
    double x24 = -x23;
    double x25 = x24 + x9;
    double x26 = x2*x25;
    double x27 = x11 - x12 + x26;
    double x28 = x15*x27;
    double x29 = -x20*x8;
    double x30 = x16 + x19*x3 + x20*x5;
    double x31 = x0 + x30;
    double x32 = x21*(x28 + x3) + x29 + x31;
    double x33 = pow(x2, -3);
    double x34 = 6*x33;
    double x35 = n2*x22;
    double x36 = 2*x22;
    double x37 = -x36;
    double x38 = 2*x33;
    double x39 = n1*x38;
    double x40 = x2*(x37 + x39);
    double x41 = 1.0/n1;
    double x42 = x25*x41;
    double x43 = x2*x42 + x25 + x35 + x40;
    double x44 = x15*x43;
    double x45 = 33.257850472612958*T;
    double x46 = x27*x45 + 2.0*x3;
    double x47 = x22*(x21*x44 + x46);
    double x48 = 49.886775708919437*T;
    double x49 = x43*x48;
    double x50 = -4*x22;
    double x51 = -n1*x17;
    double x52 = n2*x38;
    double x53 = 4*x33;
    double x54 = n1*x53 - x52;
    double x55 = x42 + x54;
    double x56 = x2*(x34 + x51) + x40*x41 + x50 + x55 - x26/((n1)*(n1));
    double x57 = x15*x21;
    double x58 = T >= 65.0;
    double x59 = fmin(4, 1.0000000000000002*sqrt(1 - 0.015384615384615385*T));
    double x60 = ((x59)*(x59)*(x59));
    double x61 = (80.2881*T - 5218.7264999999998)*(x59 - 1);
    double x62 = 1739.5754999999999*x60 + x61 - 1739.5754999999999;
    double x63 = -x17*(x1 + 0.33333333333333331*x2*(n2*x62 + x14*x48 + 3*x4 + 3*x6));
    double x64 = 0.33333333333333331*n2;
    double x65 = 0.33333333333333331*n1 + x64;
    double x66 = x22*(x46 + x49*x65);
    double x67 = x62*x64;
    double x68 = x31 + x65*(x27*x48 + 3*x3) + x67;
    double x69 = x48*x65;
    double x70 = x2*(-x22 + x39);
    double x71 = x2*(x51 + x53) + x37 + x41*x70 + x55;
    double x72 = x24 + x35 + x70 - x9;
    double x73 = x45*x72;
    double x74 = x44 + x73;
    double x75 = -x35 + x9;
    double x76 = x2*x75;
    double x77 = -x10 + x13 + x76;
    double x78 = x15*x77;
    double x79 = -x7 + x78;
    double x80 = 4700.0*n1 + x30;
    double x81 = x21*(x5 + x79 + 1159.7169999999999) + x29 + x80;
    double x82 = x28 + 1.0*x3 + 1.0*x5;
    double x83 = x18 - x36*(x57*x72 + x79 + x82 + 5859.7169999999996);
    double x84 = x65*(x48*x77 + 3*x5 + x62) + x67 + x80;
    double x85 = -x36*(579.85849999999994*x60 + 0.33333333333333331*x61 + x69*x72 + x78 + x82 + 4120.1414999999997) + x63;
    double x86 = x2*(x38 + x51) + x22 + x54;
    double x87 = x2*(x37 + x52);
    double x88 = 1.0/n2;
    double x89 = x23 + x75 + x76*x88 + x87;
    double x90 = x15*x89;
    double x91 = x73 + x90;
    double x92 = x45*x77 + 2.0*x5;
    double x93 = x22*(-53.525399999999998*T + x21*x90 + x92 + 2319.4339999999997);
    double x94 = x48*x89;
    double x95 = x22*(1159.7169999999999*x60 + 0.66666666666666663*x61 + x65*x94 + x92 - 1159.7169999999999);
    double x96 = n2*x53 + x2*(-n2*x17 + x34) - x39 + x50 + x75*x88 + x87*x88 - x76/((n2)*(n2));

if (x58) {
   result[0] = x18 + x32*x34 - 3*x47 + x9*(x49 + x56*x57);
}
else {
   result[0] = x34*x68 + x63 - 3*x66 + x9*(x49 + x56*x69);
}
if (x58) {
   result[1] = x32*x53 + x38*x81 - x47 + x83 + x9*(x57*x71 + x74);
}
else {
   result[1] = x38*x84 + x53*x68 - x66 + x85 + x9*(x69*x71 + x74);
}
if (x58) {
   result[2] = x32*x38 + x53*x81 + x83 + x9*(x57*x86 + x91) - x93;
}
else {
   result[2] = x38*x68 + x53*x84 + x85 + x9*(x69*x86 + x91) - x95;
}
if (x58) {
   result[3] = x18 + x34*x81 + x9*(x57*x96 + x94) - 3*x93;
}
else {
   result[3] = x34*x84 + x63 + x9*(x69*x96 + x94) - 3*x95;
}
}
        
static double coder_dgdt(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = 1.0/(n1 + n2);
    double x1 = n1*(*endmember[0].dmu0dT)(T, P);
    double x2 = n2*(*endmember[1].dmu0dT)(T, P);
    double x3 = n1*log(n1*x0);
    double x4 = n2*log(n2*x0);
    double x5 = sqrt(1 - 0.015384615384615385*T);
    double x6 = 1.0000000000000002*x5;
    double x7 = fmin(4, x6);
    double x8 = (4 - x6 >= 0. ? 1. : 0.)/x5;

if (T >= 65.0) {
   result = x0*(1.0*n1 + 1.0*n2)*(-26.762699999999999*n2 + x1 + x2 + 16.628925236306479*x3 + 16.628925236306479*x4);
}
else {
   result = x0*(0.33333333333333331*n1 + 0.33333333333333331*n2)*(n2*(-40.144050000000014*((x7)*(x7))*x8 + 80.2881*x7 - 0.0076923076923076945*x8*(80.2881*T - 5218.7264999999998) - 80.2881) + 3*x1 + 3*x2 + 49.886775708919437*x3 + 49.886775708919437*x4);
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = n1 + n2;
    double x2 = 1.0/x1;
    double x3 = n2*x2;
    double x4 = n1*x2;
    double x5 = log(x4);
    double x6 = 16.628925236306479*x5;
    double x7 = pow(x1, -2);
    double x8 = x1*(-n1*x7 + x2);
    double x9 = 1.0*n1 + 1.0*n2;
    double x10 = x2*x9;
    double x11 = n1*x0;
    double x12 = (*endmember[1].dmu0dT)(T, P);
    double x13 = n2*x12;
    double x14 = log(x3);
    double x15 = 16.628925236306479*x14;
    double x16 = n1*x6 + n2*x15 - 26.762699999999999*n2 + x11 + x13;
    double x17 = 1.0*x16*x2 - x16*x7*x9;
    double x18 = T >= 65.0;
    double x19 = 49.886775708919437*x5;
    double x20 = 0.33333333333333331*n1 + 0.33333333333333331*n2;
    double x21 = x2*x20;
    double x22 = 49.886775708919437*x14;
    double x23 = sqrt(1 - 0.015384615384615385*T);
    double x24 = 1.0000000000000002*x23;
    double x25 = fmin(4, x24);
    double x26 = (4 - x24 >= 0. ? 1. : 0.)/x23;
    double x27 = -40.144050000000014*((x25)*(x25))*x26 + 80.2881*x25 - 0.0076923076923076945*x26*(80.2881*T - 5218.7264999999998) - 80.2881;
    double x28 = n1*x19 + n2*x22 + n2*x27 + 3*x11 + 3*x13;
    double x29 = 0.33333333333333331*x2*x28 - x20*x28*x7;
    double x30 = x1*(-n2*x7 + x2);

if (x18) {
   result[0] = x10*(x0 - 16.628925236306479*x3 + x6 + 16.628925236306479*x8) + x17;
}
else {
   result[0] = x21*(3*x0 + x19 - 49.886775708919437*x3 + 49.886775708919437*x8) + x29;
}
if (x18) {
   result[1] = x10*(x12 + x15 + 16.628925236306479*x30 - 16.628925236306479*x4 - 26.762699999999999) + x17;
}
else {
   result[1] = x21*(3*x12 + x22 + x27 + 49.886775708919437*x30 - 49.886775708919437*x4) + x29;
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = 1.0/x0;
    double x2 = (*endmember[0].dmu0dT)(T, P);
    double x3 = n2*x1;
    double x4 = n1*x1;
    double x5 = log(x4);
    double x6 = 16.628925236306479*x5;
    double x7 = pow(x0, -2);
    double x8 = n1*x7;
    double x9 = x0*(x1 - x8);
    double x10 = 16.628925236306479*x9;
    double x11 = x10 + x2 - 16.628925236306479*x3 + x6;
    double x12 = x1*x11;
    double x13 = 16.628925236306479*x1;
    double x14 = 16.628925236306479*n2;
    double x15 = 16.628925236306479*n1 + x14;
    double x16 = 2*x7;
    double x17 = -x16;
    double x18 = 2/((x0)*(x0)*(x0));
    double x19 = n1*x18;
    double x20 = x17 + x19;
    double x21 = 1.0/n1;
    double x22 = x14*x7;
    double x23 = 16.628925236306479*x8;
    double x24 = x22 - x23;
    double x25 = 1.0*n1 + 1.0*n2;
    double x26 = x1*x25;
    double x27 = x16*x25;
    double x28 = n1*x2;
    double x29 = (*endmember[1].dmu0dT)(T, P);
    double x30 = n2*x29;
    double x31 = log(x3);
    double x32 = n1*x6 - 26.762699999999999*n2 + x14*x31 + x28 + x30;
    double x33 = x18*x25*x32 - 2.0*x32*x7;
    double x34 = T >= 65.0;
    double x35 = 49.886775708919437*x5;
    double x36 = 49.886775708919437*x9;
    double x37 = 3*x2 - 49.886775708919437*x3 + x35 + x36;
    double x38 = x1*x37;
    double x39 = 49.886775708919437*x1;
    double x40 = 49.886775708919437*n2;
    double x41 = 49.886775708919437*n1 + x40;
    double x42 = x40*x7;
    double x43 = 49.886775708919437*x8;
    double x44 = x42 - x43;
    double x45 = 0.33333333333333331*n1 + 0.33333333333333331*n2;
    double x46 = x1*x45;
    double x47 = x16*x45;
    double x48 = sqrt(1 - 0.015384615384615385*T);
    double x49 = 1.0000000000000002*x48;
    double x50 = fmin(4, x49);
    double x51 = (4 - x49 >= 0. ? 1. : 0.)/x48;
    double x52 = -40.144050000000014*((x50)*(x50))*x51 + 80.2881*x50 - 0.0076923076923076945*x51*(80.2881*T - 5218.7264999999998) - 80.2881;
    double x53 = n1*x35 + n2*x52 + 3*x28 + 3*x30 + x31*x40;
    double x54 = x18*x45*x53 - 0.66666666666666663*x53*x7;
    double x55 = x0*(-n2*x7 + x1);
    double x56 = 16.628925236306479*x55;
    double x57 = x29 + 16.628925236306479*x31 - 16.628925236306479*x4 + x56 - 26.762699999999999;
    double x58 = x1*x57;
    double x59 = x19 - x7;
    double x60 = x25*x7;
    double x61 = 49.886775708919437*x55;
    double x62 = 3*x29 + 49.886775708919437*x31 - 49.886775708919437*x4 + x52 + x61;
    double x63 = x1*x62;
    double x64 = x45*x7;
    double x65 = 1.0/n2;
    double x66 = n2*x18 + x17;

if (x34) {
   result[0] = -x11*x27 + 2.0*x12 + x26*(x10*x21 + x13 + x15*x20 + x24) + x33;
}
else {
   result[0] = -x37*x47 + 0.66666666666666663*x38 + x46*(x20*x41 + x21*x36 + x39 + x44) + x54;
}
if (x34) {
   result[1] = -x11*x60 + 1.0*x12 + x26*(-x13 + x15*x59 + x24) + x33 - x57*x60 + 1.0*x58;
}
else {
   result[1] = -x37*x64 + 0.33333333333333331*x38 + x46*(-x39 + x41*x59 + x44) + x54 - x62*x64 + 0.33333333333333331*x63;
}
if (x34) {
   result[2] = x26*(x13 + x15*x66 - x22 + x23 + x56*x65) - x27*x57 + x33 + 2.0*x58;
}
else {
   result[2] = x46*(x39 + x41*x66 - x42 + x43 + x61*x65) - x47*x62 + x54 + 0.66666666666666663*x63;
}
}
        
static void coder_d4gdn3dt(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = 1.0/x0;
    double x2 = 16.628925236306479*x1;
    double x3 = 16.628925236306479*n1;
    double x4 = 16.628925236306479*n2;
    double x5 = x3 + x4;
    double x6 = pow(x0, -2);
    double x7 = 2*x6;
    double x8 = -x7;
    double x9 = pow(x0, -3);
    double x10 = 2*x9;
    double x11 = n1*x10;
    double x12 = x11 + x8;
    double x13 = 1.0/n1;
    double x14 = n1*x6;
    double x15 = x1 - x14;
    double x16 = 16.628925236306479*x15;
    double x17 = x0*x16;
    double x18 = x4*x6;
    double x19 = x3*x6;
    double x20 = x18 - x19;
    double x21 = x12*x5 + x13*x17 + x2 + x20;
    double x22 = x1*x21;
    double x23 = (*endmember[0].dmu0dT)(T, P);
    double x24 = n1*x1;
    double x25 = log(x24);
    double x26 = -n2*x2 + x17 + x23 + 16.628925236306479*x25;
    double x27 = x26*x6;
    double x28 = -66.515700945225916*x6;
    double x29 = 6*x9;
    double x30 = 6/((x0)*(x0)*(x0)*(x0));
    double x31 = -n1*x30;
    double x32 = x29 + x31;
    double x33 = x0*x13;
    double x34 = x12*x33;
    double x35 = pow(n1, -2);
    double x36 = n1*x9;
    double x37 = n2*x9;
    double x38 = 66.515700945225916*x36 - 33.257850472612958*x37;
    double x39 = x13*x16 + x38;
    double x40 = 1.0*n1 + 1.0*n2;
    double x41 = x1*x40;
    double x42 = x40*x6;
    double x43 = x21*x42;
    double x44 = x26*x40;
    double x45 = n1*x23;
    double x46 = (*endmember[1].dmu0dT)(T, P);
    double x47 = n2*x46;
    double x48 = n2*x1;
    double x49 = log(x48);
    double x50 = -26.762699999999999*n2 + x25*x3 + x4*x49 + x45 + x47;
    double x51 = -x30*x40*x50 + 6.0*x50*x9;
    double x52 = T >= 65.0;
    double x53 = 49.886775708919437*x1;
    double x54 = 49.886775708919437*n1;
    double x55 = 49.886775708919437*n2;
    double x56 = x54 + x55;
    double x57 = 49.886775708919437*x15;
    double x58 = x0*x57;
    double x59 = x55*x6;
    double x60 = 49.886775708919437*x14;
    double x61 = x59 - x60;
    double x62 = x12*x56 + x13*x58 + x53 + x61;
    double x63 = x1*x62;
    double x64 = 3*x23 + 49.886775708919437*x25 - 49.886775708919437*x48 + x58;
    double x65 = 2.0*x6;
    double x66 = -199.54710283567775*x6;
    double x67 = 199.54710283567775*x36 - 99.773551417838874*x37;
    double x68 = x13*x57 + x67;
    double x69 = 0.33333333333333331*n1 + 0.33333333333333331*n2;
    double x70 = x1*x69;
    double x71 = x6*x69;
    double x72 = x62*x71;
    double x73 = x64*x69;
    double x74 = sqrt(1 - 0.015384615384615385*T);
    double x75 = 1.0000000000000002*x74;
    double x76 = fmin(4, x75);
    double x77 = (4 - x75 >= 0. ? 1. : 0.)/x74;
    double x78 = -40.144050000000014*((x76)*(x76))*x77 + 80.2881*x76 - 0.0076923076923076945*x77*(80.2881*T - 5218.7264999999998) - 80.2881;
    double x79 = n2*x78 + x25*x54 + 3*x45 + 3*x47 + x49*x55;
    double x80 = -x30*x69*x79 + 2.0*x79*x9;
    double x81 = -n2*x6 + x1;
    double x82 = x0*x81;
    double x83 = 16.628925236306479*x82;
    double x84 = -n1*x2 + x46 + 16.628925236306479*x49 + x83 - 26.762699999999999;
    double x85 = 4*x9;
    double x86 = x31 + x85;
    double x87 = x11 - x6;
    double x88 = x33*x87;
    double x89 = x40*x84;
    double x90 = -x2 + x20 + x5*x87;
    double x91 = 2.0*x1*x90 - x40*x7*x90 + x51;
    double x92 = 49.886775708919437*x82;
    double x93 = -49.886775708919437*x24 + 3*x46 + 49.886775708919437*x49 + x78 + x92;
    double x94 = 0.66666666666666663*x6;
    double x95 = 1.3333333333333333*x6;
    double x96 = x69*x93;
    double x97 = -x53 + x56*x87 + x61;
    double x98 = 0.66666666666666663*x1*x97 - x69*x7*x97 + x80;
    double x99 = 1.0/n2;
    double x100 = n2*x10 + x8;
    double x101 = x100*x5 - x18 + x19 + x2 + x83*x99;
    double x102 = x1*x101;
    double x103 = x6*x84;
    double x104 = x10 + x31;
    double x105 = x101*x42;
    double x106 = x100*x56 + x53 - x59 + x60 + x92*x99;
    double x107 = x1*x106;
    double x108 = x106*x71;
    double x109 = x81*x99;
    double x110 = pow(n2, -2);
    double x111 = -n2*x30 + x29;
    double x112 = x0*x100*x99;

if (x52) {
   result[0] = 3.0*x22 - 6.0*x27 + x29*x44 + x41*(-x17*x35 + x28 + x32*x5 + 16.628925236306479*x34 + x39) - 3*x43 + x51;
}
else {
   result[0] = x29*x73 + 1.0*x63 - x64*x65 + x70*(x32*x56 + 49.886775708919437*x34 - x35*x58 + x66 + x68) - 3*x72 + x80;
}
if (x52) {
   result[1] = x10*x89 + 1.0*x22 - 4.0*x27 + x41*(x39 + x5*x86 - 33.257850472612958*x6 + 16.628925236306479*x88) - x43 + x44*x85 - x65*x84 + x91;
}
else {
   result[1] = x10*x96 + 0.33333333333333331*x63 - x64*x95 + x70*(x56*x86 - 99.773551417838888*x6 + x68 + 49.886775708919437*x88) - x72 + x73*x85 - x93*x94 + x98;
}
if (x52) {
   result[2] = x10*x44 + 1.0*x102 - 4.0*x103 - x105 - 2.0*x27 + x41*(x104*x5 + x38 + 16.628925236306479*x6) + x85*x89 + x91;
}
else {
   result[2] = x10*x73 + 0.33333333333333331*x107 - x108 - x64*x94 + x70*(x104*x56 + 49.886775708919437*x6 + x67) + x85*x96 - x93*x95 + x98;
}
if (x52) {
   result[3] = 3.0*x102 - 6.0*x103 - 3*x105 + x29*x89 + x41*(16.628925236306479*x109 - x110*x83 + x111*x5 + 16.628925236306479*x112 + x28 - 33.257850472612958*x36 + 66.515700945225916*x37) + x51;
}
else {
   result[3] = 1.0*x107 - 3*x108 + x29*x96 - x65*x93 + x70*(49.886775708919437*x109 - x110*x92 + x111*x56 + 49.886775708919437*x112 - 99.773551417838874*x36 + 199.54710283567775*x37 + x66) + x80;
}
}
        
static double coder_dgdp(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = 1.0/(n1 + n2);
    double x1 = n1*(*endmember[0].dmu0dP)(T, P);
    double x2 = n2*(*endmember[1].dmu0dP)(T, P);

if (T >= 65.0) {
   result = x0*(1.0*n1 + 1.0*n2)*(x1 + x2);
}
else {
   result = x0*(0.33333333333333331*n1 + 0.33333333333333331*n2)*(3*x1 + 3*x2);
}
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2;
    double x2 = 1.0/x1;
    double x3 = 1.0*n1 + 1.0*n2;
    double x4 = x2*x3;
    double x5 = n1*x0;
    double x6 = (*endmember[1].dmu0dP)(T, P);
    double x7 = n2*x6;
    double x8 = x5 + x7;
    double x9 = pow(x1, -2);
    double x10 = 1.0*x2*x8 - x3*x8*x9;
    double x11 = T >= 65.0;
    double x12 = 0.33333333333333331*n1 + 0.33333333333333331*n2;
    double x13 = 3*x12*x2;
    double x14 = 3*x5 + 3*x7;
    double x15 = -x12*x14*x9 + 0.33333333333333331*x14*x2;

if (x11) {
   result[0] = x0*x4 + x10;
}
else {
   result[0] = x0*x13 + x15;
}
if (x11) {
   result[1] = x10 + x4*x6;
}
else {
   result[1] = x13*x6 + x15;
}
}
        
static void coder_d3gdn2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2;
    double x2 = 1.0/x1;
    double x3 = x0*x2;
    double x4 = 2.0*x3;
    double x5 = pow(x1, -2);
    double x6 = 1.0*n1 + 1.0*n2;
    double x7 = x5*x6;
    double x8 = x0*x7;
    double x9 = n1*x0;
    double x10 = (*endmember[1].dmu0dP)(T, P);
    double x11 = n2*x10;
    double x12 = x11 + x9;
    double x13 = 2/((x1)*(x1)*(x1));
    double x14 = x12*x13*x6 - 2.0*x12*x5;
    double x15 = T >= 65.0;
    double x16 = 0.33333333333333331*n1 + 0.33333333333333331*n2;
    double x17 = x16*x5;
    double x18 = x0*x17;
    double x19 = 3*x11 + 3*x9;
    double x20 = x13*x16*x19 - 0.66666666666666663*x19*x5;
    double x21 = x10*x7;
    double x22 = x10*x2;
    double x23 = 1.0*x22 + 1.0*x3;
    double x24 = x10*x17;
    double x25 = 2.0*x22;

if (x15) {
   result[0] = x14 + x4 - 2*x8;
}
else {
   result[0] = -6*x18 + x20 + x4;
}
if (x15) {
   result[1] = x14 - x21 + x23 - x8;
}
else {
   result[1] = -3*x18 + x20 + x23 - 3*x24;
}
if (x15) {
   result[2] = x14 - 2*x21 + x25;
}
else {
   result[2] = x20 - 6*x24 + x25;
}
}
        
static void coder_d4gdn3dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2;
    double x2 = pow(x1, -2);
    double x3 = x0*x2;
    double x4 = -6.0*x3;
    double x5 = 1.0*n1 + 1.0*n2;
    double x6 = 6*x5;
    double x7 = pow(x1, -3);
    double x8 = x0*x7;
    double x9 = n1*x0;
    double x10 = (*endmember[1].dmu0dP)(T, P);
    double x11 = n2*x10;
    double x12 = x11 + x9;
    double x13 = pow(x1, -4);
    double x14 = -x12*x13*x6 + 6.0*x12*x7;
    double x15 = T >= 65.0;
    double x16 = 0.33333333333333331*n1 + 0.33333333333333331*n2;
    double x17 = x16*x8;
    double x18 = 3*x11 + 3*x9;
    double x19 = 6*x16;
    double x20 = -x13*x18*x19 + 2.0*x18*x7;
    double x21 = x10*x7;
    double x22 = 2*x5;
    double x23 = 4*x5;
    double x24 = x10*x2;
    double x25 = -2.0*x24 - 4.0*x3;
    double x26 = -4.0*x24 - 2.0*x3;
    double x27 = x16*x21;
    double x28 = -6.0*x24;

if (x15) {
   result[0] = x14 + x4 + x6*x8;
}
else {
   result[0] = 18*x17 + x20 + x4;
}
if (x15) {
   result[1] = x14 + x21*x22 + x23*x8 + x25;
}
else {
   result[1] = 12*x17 + x19*x21 + x20 + x25;
}
if (x15) {
   result[2] = x14 + x21*x23 + x22*x8 + x26;
}
else {
   result[2] = x19*x8 + x20 + x26 + 12*x27;
}
if (x15) {
   result[3] = x14 + x21*x6 + x28;
}
else {
   result[3] = x20 + 18*x27 + x28;
}
}
        
static double coder_d2gdt2(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = 1.0*n1*(*endmember[0].d2mu0dT2)(T, P) + 1.0*n2*(*endmember[1].d2mu0dT2)(T, P);
    double x1 = 0.015384615384615385*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0000000000000002*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 80.2881*T - 5218.7264999999998;
    double x7 = 1.0/(x1 - 1);
    double x8 = x7*0;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = ((x10)*(x10));

if (T >= 65.0) {
   result = x0;
}
else {
   result = -0.33333333333333331*n2*(0.61760076923076968*x10*((x5)*(x5))*x7 - 0.30880038461538484*x11*x8 + 0.30880038461538473*x11*x9 - 5.9171597633136128e-5*x6*x8 + 5.9171597633136114e-5*x6*x9 + 1.2352015384615389*x5/x3) + x0;
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = 1.0*(*endmember[1].d2mu0dT2)(T, P);
    double x1 = 0.015384615384615385*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0000000000000002*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 80.2881*T - 5218.7264999999998;
    double x7 = 1.0/(x1 - 1);
    double x8 = x7*0;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = ((x10)*(x10));

result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
if (T >= 65.0) {
   result[1] = x0;
}
else {
   result[1] = x0 - 0.20586692307692323*x10*((x5)*(x5))*x7 + 0.10293346153846161*x11*x8 - 0.10293346153846157*x11*x9 + 1.972386587771204e-5*x6*x8 - 1.9723865877712037e-5*x6*x9 - 0.41173384615384628*x5/x3;
}
}
        
static void coder_d4gdn2dt2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dTdP)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dTdP)(T, P);

if (T >= 65.0) {
   result = 1.0*x0 + 1.0*x1;
}
else {
   result = x0 + x1;
}
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dP2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dP2)(T, P);

if (T >= 65.0) {
   result = 1.0*x0 + 1.0*x1;
}
else {
   result = x0 + x1;
}
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = 1.0*n1*(*endmember[0].d3mu0dT3)(T, P) + 1.0*n2*(*endmember[1].d3mu0dT3)(T, P);
    double x1 = 0.015384615384615385*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0000000000000002*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = pow(x3, -3.0/2.0);
    double x8 = (4 - x4 >= 0. ? 1. : 0.);
    double x9 = x7*x8;
    double x10 = 80.2881*T - 5218.7264999999998;
    double x11 = pow(x2, -2);
    double x12 = x11*x6;
    double x13 = x8/pow(x3, 5.0/2.0);
    double x14 = x7*0;
    double x15 = fmin(4, x4);
    double x16 = ((x15)*(x15));

if (T >= 65.0) {
   result = x0;
}
else {
   result = -0.33333333333333331*n2*(1.3654984069185262e-6*x10*x12 + 1.3654984069185257e-6*x10*x13 - 4.5516613563950879e-7*x10*x14 - 0.014252325443786993*x11*x15*((x8)*(x8)) + 0.0071261627218934965*x12*x16 + 0.0071261627218934939*x13*x16 - 0.0023753875739644993*x14*x16 - 0.014252325443786996*x15*x6*x9 + 0.0047507751479289985*x7*((x8)*(x8)*(x8)) + 0.014252325443786988*x9 - 0.01425232544378699*x6/x2) + x0;
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = 1.0*(*endmember[1].d3mu0dT3)(T, P);
    double x1 = 0.015384615384615385*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0000000000000002*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = pow(x3, -3.0/2.0);
    double x8 = (4 - x4 >= 0. ? 1. : 0.);
    double x9 = x7*x8;
    double x10 = 80.2881*T - 5218.7264999999998;
    double x11 = pow(x2, -2);
    double x12 = x11*x6;
    double x13 = x8/pow(x3, 5.0/2.0);
    double x14 = x7*0;
    double x15 = fmin(4, x4);
    double x16 = ((x15)*(x15));

result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
if (T >= 65.0) {
   result[1] = x0;
}
else {
   result[1] = x0 - 4.5516613563950868e-7*x10*x12 - 4.5516613563950858e-7*x10*x13 + 1.517220452131696e-7*x10*x14 + 0.0047507751479289977*x11*x15*((x8)*(x8)) - 0.0023753875739644988*x12*x16 - 0.002375387573964498*x13*x16 + 0.00079179585798816639*x14*x16 + 0.0047507751479289985*x15*x6*x9 - 0.0015835917159763328*x7*((x8)*(x8)*(x8)) - 0.0047507751479289959*x9 + 0.0047507751479289959*x6/x2;
}
}
        
static void coder_d5gdn2dt3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT2dP)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT2dP)(T, P);

if (T >= 65.0) {
   result = 1.0*x0 + 1.0*x1;
}
else {
   result = x0 + x1;
}
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dTdP2)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dTdP2)(T, P);

if (T >= 65.0) {
   result = 1.0*x0 + 1.0*x1;
}
else {
   result = x0 + x1;
}
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dP3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dP3)(T, P);

if (T >= 65.0) {
   result = 1.0*x0 + 1.0*x1;
}
else {
   result = x0 + x1;
}
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_s(double T, double P, double n[2]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[2]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[2]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[2]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[2]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[2]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[2]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[2]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[2]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[2]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[2]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[2]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[2]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[2]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

