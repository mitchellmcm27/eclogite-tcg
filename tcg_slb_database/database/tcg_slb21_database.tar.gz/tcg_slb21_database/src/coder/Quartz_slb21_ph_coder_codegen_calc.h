#include <math.h>


static double coder_g(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = fmin(4, 1.0*sqrt(2.7855667060212511e-5*P - 0.0011806375442739079*T + 1));

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result = n1*(0.13589999999999997*P - 5.7599999999999998*T + x0 + 3252.48);
}
else {
   result = (1.0/3.0)*n1*(3*x0 + 4878.7200000000003*((x1)*(x1)*(x1)) - (x1 - 1)*(0.40769999999999995*P - 17.280000000000001*T + 14636.160000000002) - 4878.7200000000003);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = fmin(4, 1.0*sqrt(2.7855667060212511e-5*P - 0.0011806375442739079*T + 1));

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result[0] = 0.13589999999999997*P - 5.7599999999999998*T + x0 + 3252.48;
}
else {
   result[0] = x0 + 1626.24*((x1)*(x1)*(x1)) - 1.0/3.0*(x1 - 1)*(0.40769999999999995*P - 17.280000000000001*T + 14636.160000000002) - 1626.24;
}
}
        
static void coder_d2gdn2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d3gdn3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_dgdt(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = sqrt(2.7855667060212511e-5*P - 0.0011806375442739079*T + 1);
    double x2 = 1.0*x1;
    double x3 = fmin(4, x2);
    double x4 = (4 - x2 >= 0. ? 1. : 0.)/x1;

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result = n1*(x0 - 5.7599999999999998);
}
else {
   result = (1.0/3.0)*n1*(3*x0 - 8.6399999999999988*((x3)*(x3))*x4 + 17.280000000000001*x3 + 0.00059031877213695393*x4*(0.40769999999999995*P - 17.280000000000001*T + 14636.160000000002) - 17.280000000000001);
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].dmu0dT)(T, P) - 5.7599999999999998;
    double x1 = sqrt(2.7855667060212511e-5*P - 0.0011806375442739079*T + 1);
    double x2 = 1.0*x1;
    double x3 = fmin(4, x2);
    double x4 = (4 - x2 >= 0. ? 1. : 0.)/x1;

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - 2.8799999999999994*((x3)*(x3))*x4 + 5.7599999999999998*x3 + 0.00019677292404565131*x4*(0.40769999999999995*P - 17.280000000000001*T + 14636.160000000002);
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d4gdn3dt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_dgdp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = sqrt(2.7855667060212511e-5*P - 0.0011806375442739079*T + 1);
    double x2 = 1.0*x1;
    double x3 = fmin(4, x2);
    double x4 = (4 - x2 >= 0. ? 1. : 0.)/x1;

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result = n1*(x0 + 0.13589999999999997);
}
else {
   result = (1.0/3.0)*n1*(3*x0 + 0.20384999999999998*((x3)*(x3))*x4 - 0.40769999999999995*x3 - 1.3927833530106255e-5*x4*(0.40769999999999995*P - 17.280000000000001*T + 14636.160000000002) + 0.40769999999999995);
}
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].dmu0dP)(T, P) + 0.13589999999999997;
    double x1 = sqrt(2.7855667060212511e-5*P - 0.0011806375442739079*T + 1);
    double x2 = 1.0*x1;
    double x3 = fmin(4, x2);
    double x4 = (4 - x2 >= 0. ? 1. : 0.)/x1;

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result[0] = x0;
}
else {
   result[0] = x0 + 0.067949999999999983*((x3)*(x3))*x4 - 0.13589999999999997*x3 - 4.6426111767020846e-6*x4*(0.40769999999999995*P - 17.280000000000001*T + 14636.160000000002);
}
}
        
static void coder_d3gdn2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = 2.7855667060212511e-5*P - 0.0011806375442739079*T + 1;
    double x2 = sqrt(x1);
    double x3 = 1.0*x2;
    double x4 = (4 - x3 >= 0. ? 1. : 0.);
    double x5 = 1.4207376824098943e-7*P - 6.0216696473002156e-6*T + 0.0051003541912632826;
    double x6 = 1.0/x1;
    double x7 = x6*0;
    double x8 = x4/pow(x1, 3.0/2.0);
    double x9 = fmin(4, x3);
    double x10 = 0.0051003541912632809*((x9)*(x9));

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result = n1*x0;
}
else {
   result = (1.0/3.0)*n1*(3*x0 - x10*x7 - x10*x8 + 0.010200708382526562*((x4)*(x4))*x6*x9 + x5*x7 + x5*x8 - 0.020401416765053131*x4/x2);
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = 2.7855667060212511e-5*P - 0.0011806375442739079*T + 1;
    double x2 = sqrt(x1);
    double x3 = 1.0*x2;
    double x4 = (4 - x3 >= 0. ? 1. : 0.);
    double x5 = 4.7357922746996478e-8*P - 2.0072232157667385e-6*T + 0.0017001180637544275;
    double x6 = 1.0/x1;
    double x7 = x6*0;
    double x8 = x4/pow(x1, 3.0/2.0);
    double x9 = fmin(4, x3);
    double x10 = 0.0017001180637544269*((x9)*(x9));

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - x10*x7 - x10*x8 + 0.0034002361275088538*((x4)*(x4))*x6*x9 + x5*x7 + x5*x8 - 0.0068004722550177102*x4/x2;
}
}
        
static void coder_d4gdn2dt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d2mu0dTdP)(T, P);
    double x1 = 2.7855667060212511e-5*P - 0.0011806375442739079*T + 1;
    double x2 = sqrt(x1);
    double x3 = 1.0*x2;
    double x4 = (4 - x3 >= 0. ? 1. : 0.);
    double x5 = 1.0/x1;
    double x6 = x5*0;
    double x7 = 3.3520529694358438e-9*P - 1.4207376824098943e-7*T + 0.00012033648170011805;
    double x8 = x4/pow(x1, 3.0/2.0);
    double x9 = fmin(4, x3);
    double x10 = 0.00012033648170011805*((x9)*(x9));

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result = n1*x0;
}
else {
   result = (1.0/3.0)*n1*(3*x0 + x10*x6 + x10*x8 - 0.00024067296340023609*((x4)*(x4))*x5*x9 - x6*x7 - x7*x8 + 0.00048134592680047219*x4/x2);
}
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d2mu0dTdP)(T, P);
    double x1 = 2.7855667060212511e-5*P - 0.0011806375442739079*T + 1;
    double x2 = sqrt(x1);
    double x3 = 1.0*x2;
    double x4 = (4 - x3 >= 0. ? 1. : 0.);
    double x5 = 1.0/x1;
    double x6 = x5*0;
    double x7 = 1.1173509898119477e-9*P - 4.7357922746996471e-8*T + 4.0112160566706014e-5;
    double x8 = x4/pow(x1, 3.0/2.0);
    double x9 = fmin(4, x3);
    double x10 = 4.0112160566706014e-5*((x9)*(x9));

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result[0] = x0;
}
else {
   result[0] = x0 + x10*x6 + x10*x8 - 8.0224321133412027e-5*((x4)*(x4))*x5*x9 - x6*x7 - x7*x8 + 0.00016044864226682405*x4/x2;
}
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d2mu0dP2)(T, P);
    double x1 = 2.7855667060212511e-5*P - 0.0011806375442739079*T + 1;
    double x2 = sqrt(x1);
    double x3 = 1.0*x2;
    double x4 = (4 - x3 >= 0. ? 1. : 0.);
    double x5 = 7.9087499747626936e-11*P - 3.3520529694358442e-9*T + 2.8391888651121599e-6;
    double x6 = 1.0/x1;
    double x7 = x6*0;
    double x8 = x4/pow(x1, 3.0/2.0);
    double x9 = fmin(4, x3);
    double x10 = 2.8391888651121599e-6*((x9)*(x9));

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result = n1*x0;
}
else {
   result = (1.0/3.0)*n1*(3*x0 - x10*x7 - x10*x8 + 5.6783777302243198e-6*((x4)*(x4))*x6*x9 + x5*x7 + x5*x8 - 1.135675546044864e-5*x4/x2);
}
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d2mu0dP2)(T, P);
    double x1 = 2.7855667060212511e-5*P - 0.0011806375442739079*T + 1;
    double x2 = sqrt(x1);
    double x3 = 1.0*x2;
    double x4 = (4 - x3 >= 0. ? 1. : 0.);
    double x5 = 2.6362499915875643e-11*P - 1.1173509898119481e-9*T + 9.4639628837072e-7;
    double x6 = 1.0/x1;
    double x7 = x6*0;
    double x8 = x4/pow(x1, 3.0/2.0);
    double x9 = fmin(4, x3);
    double x10 = 9.4639628837071989e-7*((x9)*(x9));

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - x10*x7 - x10*x8 + 1.8927925767414398e-6*((x4)*(x4))*x6*x9 + x5*x7 + x5*x8 - 3.7855851534828796e-6*x4/x2;
}
}
        
static void coder_d4gdn2dp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = 2.7855667060212511e-5*P - 0.0011806375442739079*T + 1;
    double x2 = 1.0*sqrt(x1);
    double x3 = x2 - 4;
    double x4 = 0;
    double x5 = pow(x1, -3.0/2.0);
    double x6 = (4 - x2 >= 0. ? 1. : 0.);
    double x7 = x5*x6;
    double x8 = 0.40769999999999995*P - 17.280000000000001*T + 14636.160000000002;
    double x9 = 6.1713622090427552e-10*x8;
    double x10 = pow(x1, -2);
    double x11 = x10*x4;
    double x12 = x6/pow(x1, 5.0/2.0);
    double x13 = x5*0;
    double x14 = fmin(4, x2);
    double x15 = ((x14)*(x14));
    double x16 = 9.03250447095032e-6*x15;
    double x17 = 1.806500894190064e-5*x14;

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result = n1*x0;
}
else {
   result = (1.0/3.0)*n1*(3*x0 + x10*x17*((x6)*(x6)) - x11*x16 + x11*x9 - x12*x16 + x12*x9 + 3.0108348236501065e-6*x13*x15 - 2.0571207363475851e-10*x13*x8 + x17*x4*x7 - 6.021669647300213e-6*x5*((x6)*(x6)*(x6)) - 1.8065008941900647e-5*x7 - 1.8065008941900647e-5*x4/x1);
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = 2.7855667060212511e-5*P - 0.0011806375442739079*T + 1;
    double x2 = 1.0*sqrt(x1);
    double x3 = x2 - 4;
    double x4 = 0;
    double x5 = pow(x1, -3.0/2.0);
    double x6 = (4 - x2 >= 0. ? 1. : 0.);
    double x7 = x5*x6;
    double x8 = 0.40769999999999995*P - 17.280000000000001*T + 14636.160000000002;
    double x9 = 2.0571207363475851e-10*x8;
    double x10 = pow(x1, -2);
    double x11 = x10*x4;
    double x12 = x6/pow(x1, 5.0/2.0);
    double x13 = x5*0;
    double x14 = fmin(4, x2);
    double x15 = ((x14)*(x14));
    double x16 = 3.0108348236501065e-6*x15;
    double x17 = 6.021669647300213e-6*x14;

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result[0] = x0;
}
else {
   result[0] = x0 + x10*x17*((x6)*(x6)) - x11*x16 + x11*x9 - x12*x16 + x12*x9 + 1.0036116078833688e-6*x13*x15 - 6.8570691211586164e-11*x13*x8 + x17*x4*x7 - 2.0072232157667377e-6*x5*((x6)*(x6)*(x6)) - 6.0216696473002156e-6*x7 - 6.0216696473002156e-6*x4/x1;
}
}
        
static void coder_d5gdn2dt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x1 = 2.7855667060212511e-5*P - 0.0011806375442739079*T + 1;
    double x2 = 1.0*sqrt(x1);
    double x3 = x2 - 4;
    double x4 = 0;
    double x5 = 4.2622130472296828e-7*x4;
    double x6 = pow(x1, -3.0/2.0);
    double x7 = (4 - x2 >= 0. ? 1. : 0.);
    double x8 = x6*x7;
    double x9 = pow(x1, -2);
    double x10 = x4*x9;
    double x11 = 0.40769999999999995*P - 17.280000000000001*T + 14636.160000000002;
    double x12 = 1.4560557711960248e-11*x11;
    double x13 = x7/pow(x1, 5.0/2.0);
    double x14 = x6*0;
    double x15 = fmin(4, x2);
    double x16 = ((x15)*(x15));

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result = n1*x0;
}
else {
   result = (1.0/3.0)*n1*(3*x0 - x10*x12 + 2.1311065236148414e-7*x10*x16 + 4.8535192373200826e-12*x11*x14 - x12*x13 + 2.1311065236148411e-7*x13*x16 - 7.1036884120494717e-8*x14*x16 - x15*x5*x8 - 4.2622130472296828e-7*x15*((x7)*(x7))*x9 + 1.4207376824098943e-7*x6*((x7)*(x7)*(x7)) + 4.2622130472296828e-7*x8 + x5/x1);
}
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x1 = 2.7855667060212511e-5*P - 0.0011806375442739079*T + 1;
    double x2 = 1.0*sqrt(x1);
    double x3 = x2 - 4;
    double x4 = 0;
    double x5 = 1.4207376824098941e-7*x4;
    double x6 = pow(x1, -3.0/2.0);
    double x7 = (4 - x2 >= 0. ? 1. : 0.);
    double x8 = x6*x7;
    double x9 = pow(x1, -2);
    double x10 = x4*x9;
    double x11 = 0.40769999999999995*P - 17.280000000000001*T + 14636.160000000002;
    double x12 = 4.8535192373200826e-12*x11;
    double x13 = x7/pow(x1, 5.0/2.0);
    double x14 = x6*0;
    double x15 = fmin(4, x2);
    double x16 = ((x15)*(x15));
    double x17 = 7.1036884120494704e-8*x16;

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - x10*x12 + x10*x17 + 1.6178397457733609e-12*x11*x14 - x12*x13 + x13*x17 - 2.3678961373498239e-8*x14*x16 - x15*x5*x8 - 1.4207376824098941e-7*x15*((x7)*(x7))*x9 + 4.7357922746996478e-8*x6*((x7)*(x7)*(x7)) + 1.4207376824098941e-7*x8 + x5/x1;
}
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x1 = 2.7855667060212511e-5*P - 0.0011806375442739079*T + 1;
    double x2 = 1.0*sqrt(x1);
    double x3 = x2 - 4;
    double x4 = 0;
    double x5 = pow(x1, -3.0/2.0);
    double x6 = (4 - x2 >= 0. ? 1. : 0.);
    double x7 = x5*x6;
    double x8 = 0.40769999999999995*P - 17.280000000000001*T + 14636.160000000002;
    double x9 = pow(x1, -2);
    double x10 = x4*x9;
    double x11 = x6/pow(x1, 5.0/2.0);
    double x12 = x5*0;
    double x13 = fmin(4, x2);
    double x14 = ((x13)*(x13));
    double x15 = 5.0280794541537653e-9*x14;
    double x16 = 1.0056158908307531e-8*x13;

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result = n1*x0;
}
else {
   result = (1.0/3.0)*n1*(3*x0 - x10*x15 + 3.4353815851656213e-13*x10*x8 - x11*x15 + 3.4353815851656208e-13*x11*x8 + 1.6760264847179219e-9*x12*x14 - 1.145127195055207e-13*x12*x8 + x16*x4*x7 + x16*((x6)*(x6))*x9 - 3.3520529694358438e-9*x5*((x6)*(x6)*(x6)) - 1.0056158908307532e-8*x7 - 1.0056158908307532e-8*x4/x1);
}
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x1 = 2.7855667060212511e-5*P - 0.0011806375442739079*T + 1;
    double x2 = 1.0*sqrt(x1);
    double x3 = x2 - 4;
    double x4 = 0;
    double x5 = pow(x1, -3.0/2.0);
    double x6 = (4 - x2 >= 0. ? 1. : 0.);
    double x7 = x5*x6;
    double x8 = 0.40769999999999995*P - 17.280000000000001*T + 14636.160000000002;
    double x9 = pow(x1, -2);
    double x10 = x4*x9;
    double x11 = x6/pow(x1, 5.0/2.0);
    double x12 = x5*0;
    double x13 = fmin(4, x2);
    double x14 = ((x13)*(x13));
    double x15 = 1.6760264847179217e-9*x14;
    double x16 = 3.3520529694358434e-9*x13;

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - x10*x15 + 1.145127195055207e-13*x10*x8 - x11*x15 + 1.1451271950552068e-13*x11*x8 + 5.5867549490597393e-10*x12*x14 - 3.817090650184023e-14*x12*x8 + x16*x4*x7 + x16*((x6)*(x6))*x9 - 1.1173509898119479e-9*x5*((x6)*(x6)*(x6)) - 3.3520529694358438e-9*x7 - 3.3520529694358438e-9*x4/x1;
}
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d3mu0dP3)(T, P);
    double x1 = 2.7855667060212511e-5*P - 0.0011806375442739079*T + 1;
    double x2 = 1.0*sqrt(x1);
    double x3 = x2 - 4;
    double x4 = 0;
    double x5 = 2.372624992428808e-10*x4;
    double x6 = pow(x1, -3.0/2.0);
    double x7 = (4 - x2 >= 0. ? 1. : 0.);
    double x8 = x6*x7;
    double x9 = pow(x1, -2);
    double x10 = x4*x9;
    double x11 = 0.40769999999999995*P - 17.280000000000001*T + 14636.160000000002;
    double x12 = 8.1053534275001361e-15*x11;
    double x13 = x7/pow(x1, 5.0/2.0);
    double x14 = x6*0;
    double x15 = fmin(4, x2);
    double x16 = ((x15)*(x15));
    double x17 = 1.186312496214404e-10*x16;

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result = n1*x0;
}
else {
   result = (1.0/3.0)*n1*(3*x0 - x10*x12 + x10*x17 + 2.7017844758333786e-15*x11*x14 - x12*x13 + x13*x17 - 3.9543749873813468e-11*x14*x16 - x15*x5*x8 - 2.372624992428808e-10*x15*((x7)*(x7))*x9 + 7.9087499747626936e-11*x6*((x7)*(x7)*(x7)) + 2.372624992428808e-10*x8 + x5/x1);
}
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d3mu0dP3)(T, P);
    double x1 = 2.7855667060212511e-5*P - 0.0011806375442739079*T + 1;
    double x2 = 1.0*sqrt(x1);
    double x3 = x2 - 4;
    double x4 = 0;
    double x5 = 7.9087499747626923e-11*x4;
    double x6 = pow(x1, -3.0/2.0);
    double x7 = (4 - x2 >= 0. ? 1. : 0.);
    double x8 = x6*x7;
    double x9 = pow(x1, -2);
    double x10 = x4*x9;
    double x11 = 0.40769999999999995*P - 17.280000000000001*T + 14636.160000000002;
    double x12 = 2.7017844758333786e-15*x11;
    double x13 = x7/pow(x1, 5.0/2.0);
    double x14 = x6*0;
    double x15 = fmin(4, x2);
    double x16 = ((x15)*(x15));
    double x17 = 3.9543749873813462e-11*x16;

if (0.023593749999999997*P - 1.0*T <= -847.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - x10*x12 + x10*x17 + 9.0059482527779286e-16*x11*x14 - x12*x13 + x13*x17 - 1.3181249957937822e-11*x14*x16 - x15*x5*x8 - 7.9087499747626923e-11*x15*((x7)*(x7))*x9 + 2.6362499915875643e-11*x6*((x7)*(x7)*(x7)) + 7.9087499747626923e-11*x8 + x5/x1;
}
}
        
static void coder_d5gdn2dp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_s(double T, double P, double n[1]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[1]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[1]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[1]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[1]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[1]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[1]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[1]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[1]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[1]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[1]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[1]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[1]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[1]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

