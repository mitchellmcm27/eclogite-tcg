#include <math.h>


static double coder_g(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = n1 + n2;
    double x1 = 1.0/x0;

result = 1.0*x1*(13000.0*n1*n2 + 1.0*x0*(8.3144626181532395*T*(n1*log(n1*x1) + n2*log(n2*x1)) + n1*(*endmember[0].mu0)(T, P) + n2*(*endmember[1].mu0)(T, P)));
    return result;
}
        
static void coder_dgdn(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = pow(x0, -2);
    double x2 = 13000.0*n2;
    double x3 = (*endmember[0].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = n2*x5;
    double x7 = 1.0/x0;
    double x8 = n1*x7;
    double x9 = log(x8);
    double x10 = n2*x7;
    double x11 = log(x10);
    double x12 = 8.3144626181532395*T;
    double x13 = x12*(n1*x9 + n2*x11);
    double x14 = 1.0*x0;
    double x15 = -1.0*x1*(n1*x2 + x14*(x13 + x4 + x6));
    double x16 = -x7;
    double x17 = x13 + 1.0*x4 + 1.0*x6;
    double x18 = 1.0*x7;

result[0] = x15 + x18*(x14*(x12*(x0*(-n1*x1 - x16) - x10 + x9) + x3) + x17 + x2);
result[1] = x15 + x18*(13000.0*n1 + x14*(x12*(x0*(-n2*x1 - x16) + x11 - x8) + x5) + x17);
}
        
static void coder_d2gdn2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = pow(x0, -3);
    double x2 = 13000.0*n2;
    double x3 = (*endmember[0].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = n2*x5;
    double x7 = 1.0/x0;
    double x8 = n1*x7;
    double x9 = log(x8);
    double x10 = n2*x7;
    double x11 = log(x10);
    double x12 = 8.3144626181532395*T;
    double x13 = x12*(n1*x9 + n2*x11);
    double x14 = 1.0*x0;
    double x15 = 2.0*x1*(n1*x2 + x14*(x13 + x4 + x6));
    double x16 = pow(x0, -2);
    double x17 = n1*x16;
    double x18 = -x7;
    double x19 = x0*(-x17 - x18);
    double x20 = T*(-x10 + x19 + x9);
    double x21 = 8.3144626181532395*x20;
    double x22 = x13 + 1.0*x4 + 1.0*x6;
    double x23 = x16*(x14*(x21 + x3) + x2 + x22);
    double x24 = n2*x16;
    double x25 = -2*x16;
    double x26 = 2*x1;
    double x27 = n1*x26;
    double x28 = x0*x12;
    double x29 = 1.0*x7;
    double x30 = x0*(-x18 - x24);
    double x31 = x11 + x30 - x8;
    double x32 = x12*x31;
    double x33 = x16*(13000.0*n1 + x14*(x32 + x5) + x22);
    double x34 = x17 - x24 + x7;

result[0] = x15 - 2.0*x23 + x29*(16.628925236306479*x20 + x28*(x0*(x25 + x27) - x17 + x24 + x7 + x19/n1) + 2.0*x3);
result[1] = x15 - 1.0*x23 + x29*(x21 + x28*(x0*(-x16 + x27) - x34) + 1.0*x3 + x32 + 1.0*x5 + 13000.0) - 1.0*x33;
result[2] = x15 + x29*(16.628925236306479*T*x31 + x28*(x0*(n2*x26 + x25) + x34 + x30/n2) + 2.0*x5) - 2.0*x33;
}
        
static void coder_d3gdn3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = pow(x0, -4);
    double x2 = 13000.0*n2;
    double x3 = (*endmember[0].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = n2*x5;
    double x7 = 1.0/x0;
    double x8 = n1*x7;
    double x9 = log(x8);
    double x10 = n2*x7;
    double x11 = log(x10);
    double x12 = 8.3144626181532395*T;
    double x13 = x12*(n1*x9 + n2*x11);
    double x14 = 1.0*x0;
    double x15 = -6.0*x1*(n1*x2 + x14*(x13 + x4 + x6));
    double x16 = pow(x0, -3);
    double x17 = pow(x0, -2);
    double x18 = n1*x17;
    double x19 = -x7;
    double x20 = -x18 - x19;
    double x21 = x0*x20;
    double x22 = -x10 + x21 + x9;
    double x23 = x12*x22;
    double x24 = x13 + 1.0*x4 + 1.0*x6;
    double x25 = x16*(x14*(x23 + x3) + x2 + x24);
    double x26 = 16.628925236306479*T;
    double x27 = n2*x17;
    double x28 = -2*x17;
    double x29 = 2*x16;
    double x30 = n1*x29;
    double x31 = x0*(x28 + x30);
    double x32 = 1.0/n1;
    double x33 = x20*x32;
    double x34 = T*(x0*x33 - x18 + x27 + x31 + x7);
    double x35 = 8.3144626181532395*x34;
    double x36 = x17*(x0*x35 + x22*x26 + 2.0*x3);
    double x37 = -4*x17;
    double x38 = -6*x16;
    double x39 = 6*x1;
    double x40 = n1*x39;
    double x41 = n2*x29;
    double x42 = 4*x16;
    double x43 = n1*x42 - x41;
    double x44 = x33 + x43;
    double x45 = x0*x12;
    double x46 = 1.0*x7;
    double x47 = -x17 + x30;
    double x48 = x18 - x27 + x7;
    double x49 = x0*x47 - x48;
    double x50 = x26*x49;
    double x51 = -x19 - x27;
    double x52 = x0*x51;
    double x53 = x11 + x52 - x8;
    double x54 = x12*x53;
    double x55 = x16*(13000.0*n1 + x14*(x5 + x54) + x24);
    double x56 = x15 - 2.0*x17*(x23 + 1.0*x3 + x45*x49 + 1.0*x5 + x54 + 13000.0);
    double x57 = x0*(x28 + x41);
    double x58 = 1.0/n2;
    double x59 = x48 + x52*x58 + x57;
    double x60 = x12*x59;
    double x61 = x17*(x0*x60 + x26*x53 + 2.0*x5);

result[0] = x15 + 6.0*x25 - 3.0*x36 + x46*(24.943387854459719*x34 + x45*(x0*(-x38 - x40) + x31*x32 + x37 + x44 - x21/((n1)*(n1))));
result[1] = 4.0*x25 - 1.0*x36 + x46*(x35 + x45*(x0*x32*x47 + x0*(4*x16 - x40) + x28 + x44) + x50) + 2.0*x55 + x56;
result[2] = 2.0*x25 + x46*(x45*(x0*(2*x16 - x40) + x17 + x43) + x50 + x60) + 4.0*x55 + x56 - 1.0*x61;
result[3] = x15 + x46*(24.943387854459719*T*x59 + x45*(n2*x42 + x0*(-n2*x39 - x38) - x30 + x37 + x51*x58 + x57*x58 - x52/((n2)*(n2)))) + 6.0*x55 - 3.0*x61;
}
        
static double coder_dgdt(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = 1.0/(n1 + n2);

result = 8.3144626181532395*n1*log(n1*x0) + 1.0*n1*(*endmember[0].dmu0dT)(T, P) + 8.3144626181532395*n2*log(n2*x0) + 1.0*n2*(*endmember[1].dmu0dT)(T, P);
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = 1.0/x0;
    double x2 = n2*x1;
    double x3 = n1*x1;
    double x4 = pow(x0, -2);
    double x5 = -x1;
    double x6 = 8.3144626181532395*x0;

result[0] = -8.3144626181532395*x2 + x6*(-n1*x4 - x5) + 8.3144626181532395*log(x3) + 1.0*(*endmember[0].dmu0dT)(T, P);
result[1] = -8.3144626181532395*x3 + x6*(-n2*x4 - x5) + 8.3144626181532395*log(x2) + 1.0*(*endmember[1].dmu0dT)(T, P);
}
        
static void coder_d3gdn2dt(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = 1.0/x0;
    double x2 = 8.3144626181532395*x1;
    double x3 = pow(x0, -2);
    double x4 = n1*x3;
    double x5 = 8.3144626181532395*x4;
    double x6 = n2*x3;
    double x7 = 8.3144626181532395*x6;
    double x8 = -2*x3;
    double x9 = 2/((x0)*(x0)*(x0));
    double x10 = n1*x9;
    double x11 = 8.3144626181532395*x0;
    double x12 = -x1;
    double x13 = x2 + x5 - x7;

result[0] = x11*(x10 + x8) + x2 - x5 + x7 + x11*(-x12 - x4)/n1;
result[1] = 8.3144626181532395*x0*(x10 - x3) - x13;
result[2] = x11*(n2*x9 + x8) + x13 + x11*(-x12 - x6)/n2;
}
        
static void coder_d4gdn3dt(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = pow(x0, -2);
    double x2 = -33.257850472612958*x1;
    double x3 = pow(x0, -3);
    double x4 = -6*x3;
    double x5 = 6/((x0)*(x0)*(x0)*(x0));
    double x6 = n1*x5;
    double x7 = 8.3144626181532395*x0;
    double x8 = -2*x1;
    double x9 = 2*x3;
    double x10 = n1*x9;
    double x11 = 8.3144626181532395/n1;
    double x12 = x0*x11;
    double x13 = -1/x0;
    double x14 = -n1*x1 - x13;
    double x15 = 33.257850472612958*x3;
    double x16 = 16.628925236306479*x3;
    double x17 = n1*x15 - n2*x16;
    double x18 = x11*x14 + x17;
    double x19 = 1.0/n2;
    double x20 = -n2*x1 - x13;

result[0] = x12*(x10 + x8) + x18 + x2 + x7*(-x4 - x6) - x14*x7/((n1)*(n1));
result[1] = -16.628925236306479*x1 + x12*(-x1 + x10) + x18 + x7*(4*x3 - x6);
result[2] = 8.3144626181532395*x1 + x17 + x7*(2*x3 - x6);
result[3] = -n1*x16 + n2*x15 + 8.3144626181532395*x19*x20 + x19*x7*(n2*x9 + x8) + x2 + x7*(-n2*x5 - x4) - x20*x7/((n2)*(n2));
}
        
static double coder_dgdp(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*n1*(*endmember[0].dmu0dP)(T, P) + 1.0*n2*(*endmember[1].dmu0dP)(T, P);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].dmu0dP)(T, P);
result[1] = 1.0*(*endmember[1].dmu0dP)(T, P);
}
        
static void coder_d3gdn2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dT2)(T, P) + n2*(*endmember[1].d2mu0dT2)(T, P));
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P));
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P));
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dT3)(T, P) + n2*(*endmember[1].d3mu0dT3)(T, P));
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P));
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P));
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P));
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_s(double T, double P, double n[2]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[2]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[2]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[2]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[2]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[2]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[2]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[2]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[2]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[2]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[2]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[2]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[2]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[2]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

