#include <math.h>


static double coder_g(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = fmin(4, 0.99999999999999989*sqrt(0.00023529411764705883*T + 1));

if (T >= -4250.0) {
   result = n1*(-4.0000000000000003e-5*T + x0 - 0.11333333333333334);
}
else {
   result = (1.0/3.0)*n1*(3*x0 - 0.17000000000000001*((x1)*(x1)*(x1)) + (0.00012000000000000002*T + 0.51000000000000012)*(x1 - 1) + 0.17000000000000001);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = fmin(4, 0.99999999999999989*sqrt(0.00023529411764705883*T + 1));

if (T >= -4250.0) {
   result[0] = -4.0000000000000003e-5*T + x0 - 0.11333333333333334;
}
else {
   result[0] = x0 - 0.056666666666666671*((x1)*(x1)*(x1)) + (1.0/3.0)*(0.00012000000000000002*T + 0.51000000000000012)*(x1 - 1) + 0.056666666666666671;
}
}
        
static void coder_d2gdn2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d3gdn3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_dgdt(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = sqrt(0.00023529411764705883*T + 1);
    double x2 = 0.99999999999999989*x1;
    double x3 = fmin(4, x2);
    double x4 = (4 - x2 >= 0. ? 1. : 0.)/x1;

if (T >= -4250.0) {
   result = n1*(x0 - 4.0000000000000003e-5);
}
else {
   result = (1.0/3.0)*n1*(3*x0 - 6.0000000000000002e-5*((x3)*(x3))*x4 + 0.00012000000000000002*x3 + 0.0001176470588235294*x4*(0.00012000000000000002*T + 0.51000000000000012) - 0.00012000000000000002);
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].dmu0dT)(T, P) - 4.0000000000000003e-5;
    double x1 = sqrt(0.00023529411764705883*T + 1);
    double x2 = 0.99999999999999989*x1;
    double x3 = fmin(4, x2);
    double x4 = (4 - x2 >= 0. ? 1. : 0.)/x1;

if (T >= -4250.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - 1.9999999999999998e-5*((x3)*(x3))*x4 + 4.0000000000000003e-5*x3 + 3.9215686274509798e-5*x4*(0.00012000000000000002*T + 0.51000000000000012);
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d4gdn3dt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_dgdp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].dmu0dP)(T, P);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].dmu0dP)(T, P);
}
        
static void coder_d3gdn2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = 0.00023529411764705883*T + 1;
    double x2 = sqrt(x1);
    double x3 = 0.99999999999999989*x2;
    double x4 = x3 - 4;
    double x5 = (-x4 >= 0. ? 1. : 0.);
    double x6 = 0.00012000000000000002*T + 0.51000000000000012;
    double x7 = 1.0/x1;
    double x8 = x7*0;
    double x9 = x5/pow(x1, 3.0/2.0);
    double x10 = fmin(4, x3);
    double x11 = ((x10)*(x10));

if (T >= -4250.0) {
   result = n1*x0;
}
else {
   result = (1.0/3.0)*n1*(3*x0 - 1.4117647058823529e-8*x10*((x5)*(x5))*x7 + 7.0588235294117646e-9*x11*x8 + 7.0588235294117654e-9*x11*x9 - 1.3840830449826988e-8*x6*x8 - 1.384083044982699e-8*x6*x9 + 2.8235294117647062e-8*x5/x2);
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = 0.00023529411764705883*T + 1;
    double x2 = sqrt(x1);
    double x3 = 0.99999999999999989*x2;
    double x4 = x3 - 4;
    double x5 = (-x4 >= 0. ? 1. : 0.);
    double x6 = 0.00012000000000000002*T + 0.51000000000000012;
    double x7 = 1.0/x1;
    double x8 = x7*0;
    double x9 = x5/pow(x1, 3.0/2.0);
    double x10 = fmin(4, x3);
    double x11 = ((x10)*(x10));

if (T >= -4250.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - 4.7058823529411761e-9*x10*((x5)*(x5))*x7 + 2.3529411764705881e-9*x11*x8 + 2.3529411764705885e-9*x11*x9 - 4.6136101499423288e-9*x6*x8 - 4.6136101499423296e-9*x6*x9 + 9.4117647058823539e-9*x5/x2;
}
}
        
static void coder_d4gdn2dt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d2mu0dTdP)(T, P);
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d2mu0dP2)(T, P);
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = 0.00023529411764705883*T + 1;
    double x2 = 0.99999999999999989*sqrt(x1);
    double x3 = x2 - 4;
    double x4 = 0;
    double x5 = pow(x1, -3.0/2.0);
    double x6 = (-x3 >= 0. ? 1. : 0.);
    double x7 = x5*x6;
    double x8 = 0.00012000000000000002*T + 0.51000000000000012;
    double x9 = pow(x1, -2);
    double x10 = x4*x9;
    double x11 = x6/pow(x1, 5.0/2.0);
    double x12 = x5*0;
    double x13 = fmin(4, x2);
    double x14 = ((x13)*(x13));

if (T >= -4250.0) {
   result = n1*x0;
}
else {
   result = (1.0/3.0)*n1*(3*x0 - 2.4913494809688581e-12*x10*x14 + 4.8849989822918779e-12*x10*x8 - 2.4913494809688585e-12*x11*x14 + 4.8849989822918787e-12*x11*x8 + 8.3044982698961924e-13*x12*x14 - 1.6283329940972926e-12*x12*x8 + 4.9826989619377155e-12*x13*x4*x7 + 4.9826989619377163e-12*x13*((x6)*(x6))*x9 - 1.6608996539792385e-12*x5*((x6)*(x6)*(x6)) - 4.9826989619377163e-12*x7 - 4.9826989619377163e-12*x4/x1);
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = 0.00023529411764705883*T + 1;
    double x2 = 0.99999999999999989*sqrt(x1);
    double x3 = x2 - 4;
    double x4 = 0;
    double x5 = pow(x1, -3.0/2.0);
    double x6 = (-x3 >= 0. ? 1. : 0.);
    double x7 = x5*x6;
    double x8 = 0.00012000000000000002*T + 0.51000000000000012;
    double x9 = pow(x1, -2);
    double x10 = x4*x9;
    double x11 = x6/pow(x1, 5.0/2.0);
    double x12 = x5*0;
    double x13 = fmin(4, x2);
    double x14 = ((x13)*(x13));

if (T >= -4250.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - 8.3044982698961935e-13*x10*x14 + 1.6283329940972926e-12*x10*x8 - 8.3044982698961945e-13*x11*x14 + 1.6283329940972928e-12*x11*x8 + 2.7681660899653971e-13*x12*x14 - 5.4277766469909752e-13*x12*x8 + 1.6608996539792385e-12*x13*x4*x7 + 1.6608996539792387e-12*x13*((x6)*(x6))*x9 - 5.5363321799307943e-13*x5*((x6)*(x6)*(x6)) - 1.6608996539792387e-12*x7 - 1.6608996539792387e-12*x4/x1;
}
}
        
static void coder_d5gdn2dt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d3mu0dT2dP)(T, P);
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d3mu0dTdP2)(T, P);
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d3mu0dP3)(T, P);
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_s(double T, double P, double n[1]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[1]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[1]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[1]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[1]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[1]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[1]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[1]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[1]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[1]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[1]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[1]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[1]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[1]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

