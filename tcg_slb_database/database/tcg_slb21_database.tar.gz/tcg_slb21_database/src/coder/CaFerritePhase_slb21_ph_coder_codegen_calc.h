#include <math.h>


static double coder_g(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = 1.0/x1;
    double x3 = n1*(*endmember[0].mu0)(T, P);
    double x4 = n2*(*endmember[1].mu0)(T, P);
    double x5 = n3*(*endmember[2].mu0)(T, P);
    double x6 = 1.0*n1;
    double x7 = 1.0*n2;
    double x8 = log(n3*x2);
    double x9 = 1.0*n3;
    double x10 = T*(x6*log(n1*x2) + x7*log(n2*x2) + x8*x9 + x9*(x8 - 0.69314718055994495) + (2.0*n1 + 2.0*n2 + x9)*log(x2*(0.5*n3 + x6 + x7)));
    double x11 = 30500.0*n3;
    double x12 = n1*x11 + n2*x11 + x0*x11;
    double x13 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));

if (T >= 5.0) {
   result = x2*(1.0*x1*(-n2*(13.381349999999999*T - 44.604500000000002) + 8.3144626181532395*x10 + x3 + x4 + x5) + x12);
}
else {
   result = x2*(0.33333333333333331*x1*(n2*(66.906750000000002*((x13)*(x13)*(x13)) + (40.14405*T - 200.72024999999999)*(x13 - 1) - 66.906750000000002) + 24.943387854459719*x10 + 3*x3 + 3*x4 + 3*x5) + x12);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = pow(x1, -2);
    double x3 = (*endmember[0].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = n2*x5;
    double x7 = (*endmember[2].mu0)(T, P);
    double x8 = n3*x7;
    double x9 = 13.381349999999999*T;
    double x10 = x9 - 44.604500000000002;
    double x11 = 1.0/x1;
    double x12 = n1*x11;
    double x13 = 1.0*log(x12);
    double x14 = log(n2*x11);
    double x15 = 1.0*n2;
    double x16 = n3*x11;
    double x17 = log(x16);
    double x18 = 1.0*n3;
    double x19 = 2.0*n1 + 2.0*n2 + x18;
    double x20 = 1.0*n1;
    double x21 = 0.5*n3 + x15 + x20;
    double x22 = log(x11*x21);
    double x23 = n1*x13 + x14*x15 + x17*x18 + x18*(x17 - 0.69314718055994495) + x19*x22;
    double x24 = 8.3144626181532395*T;
    double x25 = x23*x24;
    double x26 = 1.0*x1;
    double x27 = 30500.0*n3;
    double x28 = n1*x27 + n2*x27 + x0*x27;
    double x29 = -x2*(x26*(-n2*x10 + x25 + x4 + x6 + x8) + x28);
    double x30 = -x11;
    double x31 = -x11*x15;
    double x32 = x2*x21;
    double x33 = x1*x19/x21;
    double x34 = -2.0*x16 + 2.0*x22 + x33*(1.0*x11 - x32);
    double x35 = x13 + x26*(-n1*x2 - x30) + x31 + x34;
    double x36 = -x10*x15;
    double x37 = x15*x5 + x18*x7 + x20*x3 + x25;
    double x38 = 61000.0*n3 + x37;
    double x39 = x36 + x38;
    double x40 = T >= 5.0;
    double x41 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x42 = 66.906750000000002*((x41)*(x41)*(x41)) + (40.14405*T - 200.72024999999999)*(x41 - 1) - 66.906750000000002;
    double x43 = n2*x42;
    double x44 = 24.943387854459719*T;
    double x45 = 0.33333333333333331*x1;
    double x46 = -x2*(x28 + x45*(x23*x44 + 3*x4 + x43 + 3*x6 + 3*x8));
    double x47 = 0.33333333333333331*x43;
    double x48 = x38 + x47;
    double x49 = -1.0*x12;
    double x50 = 1.0*x14 + x26*(-n2*x2 - x30) + x34 + x49;
    double x51 = 2.0*x1*(-n3*x2 - x30) + 2.0*x17 + 1.0*x22 + x31 + x33*(0.5*x11 - x32) + x49 - 0.69314718055994495;
    double x52 = 61000.0*n1 + 61000.0*n2 + x37;

if (x40) {
   result[0] = x11*(x26*(x24*x35 + x3) + x39) + x29;
}
else {
   result[0] = x11*(x45*(3*x3 + x35*x44) + x48) + x46;
}
if (x40) {
   result[1] = x11*(x26*(x24*x50 + x5 - x9 + 44.604500000000002) + x39) + x29;
}
else {
   result[1] = x11*(x45*(x42 + x44*x50 + 3*x5) + x48) + x46;
}
if (x40) {
   result[2] = x11*(x26*(x24*x51 + x7) + x36 + x52) + x29;
}
else {
   result[2] = x11*(x45*(x44*x51 + 3*x7) + x47 + x52) + x46;
}
}
        
static void coder_d2gdn2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n3*x4;
    double x6 = 13.381349999999999*T;
    double x7 = x6 - 44.604500000000002;
    double x8 = n1 + n2;
    double x9 = n3 + x8;
    double x10 = 1.0/x9;
    double x11 = n1*x10;
    double x12 = 1.0*log(x11);
    double x13 = log(n2*x10);
    double x14 = 1.0*n2;
    double x15 = n3*x10;
    double x16 = log(x15);
    double x17 = 1.0*n3;
    double x18 = 2.0*n1 + 2.0*n2 + x17;
    double x19 = 1.0*n1;
    double x20 = 0.5*n3 + x14 + x19;
    double x21 = log(x10*x20);
    double x22 = T*(n1*x12 + x13*x14 + x16*x17 + x17*(x16 - 0.69314718055994495) + x18*x21);
    double x23 = 8.3144626181532395*x22;
    double x24 = 1.0*x9;
    double x25 = 30500.0*n3;
    double x26 = n1*x25 + n2*x25 + x25*x8;
    double x27 = 2/((x9)*(x9)*(x9));
    double x28 = x27*(x24*(-n2*x7 + x1 + x23 + x3 + x5) + x26);
    double x29 = pow(x9, -2);
    double x30 = -x10;
    double x31 = x24*(-n1*x29 - x30);
    double x32 = -x10*x14;
    double x33 = 1.0*x10;
    double x34 = -x33;
    double x35 = x20*x29;
    double x36 = -x34 - x35;
    double x37 = 1.0/x20;
    double x38 = x18*x37;
    double x39 = x36*x38;
    double x40 = -2.0*x15 + 2.0*x21 + x39*x9;
    double x41 = T*(x12 + x31 + x32 + x40);
    double x42 = 8.3144626181532395*x41;
    double x43 = -x14*x7;
    double x44 = x0*x19 + x14*x2 + x17*x4 + x23;
    double x45 = 61000.0*n3 + x44;
    double x46 = x43 + x45;
    double x47 = x24*(x0 + x42) + x46;
    double x48 = 2*x29;
    double x49 = x14*x29;
    double x50 = x19*x29;
    double x51 = -x50;
    double x52 = -x48;
    double x53 = n1*x27;
    double x54 = 2.0*x29;
    double x55 = n3*x54;
    double x56 = x39 + x55;
    double x57 = x36*x37;
    double x58 = x20*x27;
    double x59 = x38*x9;
    double x60 = x18/((x20)*(x20));
    double x61 = x36*x60;
    double x62 = -x24*x61 + 4.0*x57*x9 + x59*(-x54 + x58);
    double x63 = x33 + x56 + x62;
    double x64 = 8.3144626181532395*T*x9;
    double x65 = x10*(2.0*x0 + 16.628925236306479*x41 + x64*(x24*(x52 + x53) + x49 + x51 + x63 + x31/n1));
    double x66 = T >= 5.0;
    double x67 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x68 = ((x67)*(x67)*(x67));
    double x69 = (40.14405*T - 200.72024999999999)*(x67 - 1);
    double x70 = 66.906750000000002*x68 + x69 - 66.906750000000002;
    double x71 = n2*x70;
    double x72 = 0.33333333333333331*x9;
    double x73 = x27*(x26 + x72*(3*x1 + 24.943387854459719*x22 + 3*x3 + 3*x5 + x71));
    double x74 = 0.33333333333333331*x71;
    double x75 = x45 + x74;
    double x76 = x72*(3*x0 + 24.943387854459719*x41) + x75;
    double x77 = x24*(-n2*x29 - x30);
    double x78 = -1.0*x11;
    double x79 = T*(1.0*x13 + x40 + x77 + x78);
    double x80 = 8.3144626181532395*x79;
    double x81 = -x6 + x80;
    double x82 = x81 + 44.604500000000002;
    double x83 = 1.0*x2;
    double x84 = -x29;
    double x85 = x24*(x53 + x84) + x49 + x51 + x56;
    double x86 = 1.0*x0 + x42;
    double x87 = x64*(x34 + x62 + x85) + x83 + x86;
    double x88 = x24*(x2 + x82) + x46;
    double x89 = -x29*x88;
    double x90 = x28 - x29*x47;
    double x91 = 22.302250000000001*x68 + 0.33333333333333331*x69 + x80;
    double x92 = x72*(3*x2 + x70 + 24.943387854459719*x79) + x75;
    double x93 = -x29*x92;
    double x94 = -x29*x76 + x73;
    double x95 = 2.0*x10;
    double x96 = 0.5*x10 - x35;
    double x97 = 2.0*x9;
    double x98 = x37*x96*x97;
    double x99 = 0.5*x9;
    double x100 = x24*x57 + x59*(-1.5*x29 + x58) - x61*x99 - x95 + x98;
    double x101 = x97*(-n3*x29 - x30);
    double x102 = x38*x96;
    double x103 = T*(x101 + x102*x9 + 2.0*x16 + 1.0*x21 + x32 + x78 - 0.69314718055994495);
    double x104 = 8.3144626181532395*x103;
    double x105 = x104 + 1.0*x4;
    double x106 = x10*(x105 + x64*(x100 + x85) + x86 + 61000.0);
    double x107 = 61000.0*n1 + 61000.0*n2 + x44;
    double x108 = x107 + x24*(x104 + x4) + x43;
    double x109 = -x108*x29;
    double x110 = x107 + x72*(24.943387854459719*x103 + 3*x4) + x74;
    double x111 = -x110*x29;
    double x112 = n2*x27;
    double x113 = -x49 + x50;
    double x114 = 2.0*x2 + x64*(x113 + x24*(x112 + x52) + x63 + x77/n2) + 16.628925236306479*x79;
    double x115 = x105 + x64*(x100 + x113 + x24*(x112 + x84) + x56) + x83;
    double x116 = x10*(16.628925236306479*x103 + 2.0*x4 + x64*(x102 + x49 + x50 - x55 + x59*(-1.0*x29 + x58) - x60*x96*x99 + x95 + x97*(n3*x27 + x52) + x98 + x101/n3));

if (x66) {
   result[0] = x28 - x47*x48 + x65;
}
else {
   result[0] = -x48*x76 + x65 + x73;
}
if (x66) {
   result[1] = x10*(x82 + x87) + x89 + x90;
}
else {
   result[1] = x10*(x87 + x91 - 22.302250000000001) + x93 + x94;
}
if (x66) {
   result[2] = x106 + x109 + x90;
}
else {
   result[2] = x106 + x111 + x94;
}
if (x66) {
   result[3] = x10*(-26.762699999999999*T + x114 + 89.209000000000003) + x28 - x48*x88;
}
else {
   result[3] = x10*(x114 + 44.604500000000002*x68 + 0.66666666666666663*x69 - 44.604500000000002) - x48*x92 + x73;
}
if (x66) {
   result[4] = x10*(x115 + x81 + 61044.604500000001) + x109 + x28 + x89;
}
else {
   result[4] = x10*(x115 + x91 + 60977.697749999999) + x111 + x73 + x93;
}
if (x66) {
   result[5] = -x108*x48 + x116 + x28;
}
else {
   result[5] = -x110*x48 + x116 + x73;
}
}
        
static void coder_d3gdn3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n3*x4;
    double x6 = 13.381349999999999*T;
    double x7 = x6 - 44.604500000000002;
    double x8 = n1 + n2;
    double x9 = n3 + x8;
    double x10 = 1.0/x9;
    double x11 = log(n1*x10);
    double x12 = 1.0*n1;
    double x13 = log(n2*x10);
    double x14 = 1.0*n2;
    double x15 = n3*x10;
    double x16 = log(x15);
    double x17 = 1.0*n3;
    double x18 = 2.0*n1;
    double x19 = 2.0*n2;
    double x20 = x17 + x18 + x19;
    double x21 = 0.5*n3 + x12 + x14;
    double x22 = log(x10*x21);
    double x23 = x11*x12 + x13*x14 + x16*x17 + x17*(x16 - 0.69314718055994495) + x20*x22;
    double x24 = 8.3144626181532395*T;
    double x25 = x23*x24;
    double x26 = 1.0*x9;
    double x27 = 30500.0*n3;
    double x28 = n1*x27 + n2*x27 + x27*x8;
    double x29 = 6/((x9)*(x9)*(x9)*(x9));
    double x30 = -x29*(x26*(-n2*x7 + x1 + x25 + x3 + x5) + x28);
    double x31 = pow(x9, -2);
    double x32 = -x10;
    double x33 = -n1*x31 - x32;
    double x34 = x26*x33;
    double x35 = 1.0*x10;
    double x36 = -n2*x35;
    double x37 = 1.0/x21;
    double x38 = -x35;
    double x39 = x21*x31;
    double x40 = -x38 - x39;
    double x41 = x37*x40;
    double x42 = x20*x41;
    double x43 = -2.0*x15 + 2.0*x22 + x42*x9;
    double x44 = 1.0*x11 + x34 + x36 + x43;
    double x45 = x24*x44;
    double x46 = -x14*x7;
    double x47 = x0*x12 + x14*x2 + x17*x4 + x25;
    double x48 = 61000.0*n3 + x47;
    double x49 = x46 + x48;
    double x50 = x26*(x0 + x45) + x49;
    double x51 = pow(x9, -3);
    double x52 = 6*x51;
    double x53 = x14*x31;
    double x54 = x12*x31;
    double x55 = -x54;
    double x56 = 2*x31;
    double x57 = -x56;
    double x58 = 2*x51;
    double x59 = n1*x58;
    double x60 = x26*(x57 + x59);
    double x61 = 1.0/n1;
    double x62 = x33*x61;
    double x63 = 2.0*x31;
    double x64 = n3*x63;
    double x65 = x42 + x64;
    double x66 = 4.0*x9;
    double x67 = -x63;
    double x68 = x21*x58;
    double x69 = x67 + x68;
    double x70 = x20*x37;
    double x71 = x69*x70;
    double x72 = pow(x21, -2);
    double x73 = x40*x72;
    double x74 = x20*x73;
    double x75 = -x26*x74 + x41*x66 + x71*x9;
    double x76 = x35 + x65 + x75;
    double x77 = x26*x62 + x53 + x55 + x60 + x76;
    double x78 = 24.943387854459719*T;
    double x79 = -4.0*x31;
    double x80 = -6*x51;
    double x81 = n1*x29;
    double x82 = 1.0*x62;
    double x83 = 4.0*x51;
    double x84 = -x19*x51;
    double x85 = -n3*x83;
    double x86 = n1*x83 + x84 + x85;
    double x87 = 6.0*x9;
    double x88 = x37*x69;
    double x89 = x21*x29;
    double x90 = x70*x9;
    double x91 = 2.0*x9;
    double x92 = x20*x91;
    double x93 = pow(x21, -3);
    double x94 = x40*x93;
    double x95 = x69*x72;
    double x96 = 6.0*x41 + 2*x71 - x73*x87 - 2.0*x74 + x87*x88 + x90*(6.0*x51 - x89) + x92*x94 - x92*x95;
    double x97 = x82 + x86 + x96;
    double x98 = x24*x9;
    double x99 = 16.628925236306479*T;
    double x100 = x24*x77;
    double x101 = x31*(2.0*x0 + x100*x9 + x44*x99);
    double x102 = x10*(x77*x78 + x98*(x26*(-x80 - x81) + x60*x61 + x79 + x97 - x34/((n1)*(n1)))) - 3*x101;
    double x103 = T >= 5.0;
    double x104 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x105 = ((x104)*(x104)*(x104));
    double x106 = (40.14405*T - 200.72024999999999)*(x104 - 1);
    double x107 = 66.906750000000002*x105 + x106 - 66.906750000000002;
    double x108 = n2*x107;
    double x109 = 0.33333333333333331*x9;
    double x110 = -x29*(x109*(3*x1 + x108 + x23*x78 + 3*x3 + 3*x5) + x28);
    double x111 = 0.33333333333333331*x108;
    double x112 = x111 + x48;
    double x113 = x109*(3*x0 + x44*x78) + x112;
    double x114 = -n2*x31 - x32;
    double x115 = x114*x26;
    double x116 = -n1*x35;
    double x117 = x115 + x116 + 1.0*x13 + x43;
    double x118 = x117*x24;
    double x119 = x118 - x6;
    double x120 = x119 + 44.604500000000002;
    double x121 = x26*(x120 + x2) + x49;
    double x122 = x121*x58;
    double x123 = 4*x51;
    double x124 = x123*x50;
    double x125 = -x31;
    double x126 = x26*(x125 + x59);
    double x127 = x126 + x53 + x55 + x65;
    double x128 = x127 + x38 + x75;
    double x129 = x128*x99;
    double x130 = -4*x51;
    double x131 = x126*x61 + x26*(-x130 - x81);
    double x132 = -x101;
    double x133 = x10*(x100 + x129 + x98*(x131 + x67 + x97)) + x132;
    double x134 = 1.0*x2;
    double x135 = x128*x24;
    double x136 = 1.0*x0 + x45;
    double x137 = x134 + x135*x9 + x136;
    double x138 = x120 + x137;
    double x139 = -x138*x56 + x30;
    double x140 = 22.302250000000001*x105 + 0.33333333333333331*x106 + x118;
    double x141 = x137 + x140 - 22.302250000000001;
    double x142 = -x141*x56;
    double x143 = x109*(x107 + x117*x78 + 3*x2) + x112;
    double x144 = x143*x58;
    double x145 = x110 + x113*x123;
    double x146 = -n3*x31 - x32;
    double x147 = x146*x91;
    double x148 = 0.5*x10 - x39;
    double x149 = x148*x70;
    double x150 = x116 + x147 + x149*x9 + 2.0*x16 + 1.0*x22 + x36 - 0.69314718055994495;
    double x151 = x150*x24;
    double x152 = 61000.0*n1 + 61000.0*n2 + x47;
    double x153 = x152 + x26*(x151 + x4) + x46;
    double x154 = x153*x58;
    double x155 = 2.0*x10;
    double x156 = x148*x37;
    double x157 = x156*x91;
    double x158 = -1.5*x31 + x68;
    double x159 = x158*x70;
    double x160 = 0.5*x9;
    double x161 = -x155 + x157 + x159*x9 - x160*x74 + x26*x41;
    double x162 = x127 + x161;
    double x163 = x162*x24;
    double x164 = x151 + 1.0*x4;
    double x165 = x136 + x163*x9 + x164 + 61000.0;
    double x166 = -x165*x56;
    double x167 = x166 + x30;
    double x168 = x162*x99;
    double x169 = 1.0*x31;
    double x170 = -x169;
    double x171 = x20*x26;
    double x172 = x171*x72;
    double x173 = -x158*x172;
    double x174 = x158*x37;
    double x175 = 3.0*x9;
    double x176 = x160*x20;
    double x177 = x159 + x171*x94 + x174*x66 - x175*x73 - x176*x95 + x26*x88 + 5.0*x41 + x71 - 1.5*x74 + x90*(5.0*x51 - x89);
    double x178 = x170 + x173 + x177;
    double x179 = x10*(x100 + x168 + x98*(x131 + x178 + x82 + x86)) + x132;
    double x180 = x109*(x150*x78 + 3*x4) + x111 + x152;
    double x181 = x180*x58;
    double x182 = n2*x58;
    double x183 = x26*(x182 + x57);
    double x184 = 1.0/n2;
    double x185 = -x53 + x54;
    double x186 = x115*x184 + x183 + x185 + x76;
    double x187 = x186*x24;
    double x188 = -2*x51;
    double x189 = x26*(-x188 - x81) + x86;
    double x190 = x10*(x129 + x187 + x98*(x169 + x189 + x96));
    double x191 = x50*x58;
    double x192 = x117*x99 + x187*x9 + 2.0*x2;
    double x193 = x31*(-26.762699999999999*T + x192 + 89.209000000000003);
    double x194 = x121*x123 - x193;
    double x195 = x110 + x113*x58;
    double x196 = x31*(44.604500000000002*x105 + 0.66666666666666663*x106 + x192 - 44.604500000000002);
    double x197 = x123*x143 - x196;
    double x198 = x26*(x125 + x182);
    double x199 = x161 + x185 + x198 + x65;
    double x200 = x199*x24;
    double x201 = x134 + x164 + x200*x9;
    double x202 = x119 + x201 + 61044.604500000001;
    double x203 = x173 + x189;
    double x204 = x10*(x135 + x163 + x200 + x98*(x177 + x203 + x63)) - x165*x31;
    double x205 = x140 + x201 + 60977.697749999999;
    double x206 = x123*x153;
    double x207 = x91*(n3*x58 + x57);
    double x208 = 1.0/n3;
    double x209 = x170 + x68;
    double x210 = x148*x72;
    double x211 = x20*x210;
    double x212 = x147*x208 + x149 + x155 + x157 - x160*x211 + x207 + x209*x90 + x53 + x54 - x64;
    double x213 = x212*x24;
    double x214 = x209*x37;
    double x215 = 2.0*x156 + 2*x159 + x174*x91 + x176*x94 - x210*x26 + x214*x91 - x26*x73 + 3.0*x31 + 2.0*x41 - 1.0*x74 + x90*(4.0*x51 - x89);
    double x216 = x31*(x150*x99 + x213*x9 + 2.0*x4);
    double x217 = -x216;
    double x218 = x10*(x168 + x213 + x98*(x203 + x215)) + x217;
    double x219 = x123*x180;
    double x220 = n2*x29;
    double x221 = -x18*x51;
    double x222 = n2*x83 + x221 + x85;
    double x223 = 1.0*x114*x184 + x222;
    double x224 = x10*(x186*x78 + x98*(x183*x184 + x223 + x26*(-x220 - x80) + x79 + x96 - x115/((n2)*(n2))));
    double x225 = x199*x99;
    double x226 = x10*(x187 + x225 + x98*(x178 + x184*x198 + x223 + x26*(-x130 - x220)));
    double x227 = -x202*x56 + x30;
    double x228 = x110 - x205*x56;
    double x229 = x10*(x213 + x225 + x98*(x173 + x215 + x222 + x26*(-x188 - x220))) + x217;
    double x230 = x10*(x212*x78 + x98*(8.0*n3*x51 + 2.0*x146*x208 + x148*x176*x93 + 3.0*x156 - x172*x209 + x175*x214 + x207*x208 + 2*x209*x70 - 1.5*x210*x9 - 1.0*x211 + x221 - 8.0*x31 + x84 + x90*(3.0*x51 - x89) + x91*(-n3*x29 - x80) - x147/((n3)*(n3)))) - 3*x216;

if (x103) {
   result[0] = x102 + x30 + x50*x52;
}
else {
   result[0] = x102 + x110 + x113*x52;
}
if (x103) {
   result[1] = x122 + x124 + x133 + x139;
}
else {
   result[1] = x133 + x142 + x144 + x145;
}
if (x103) {
   result[2] = x124 + x154 + x167 + x179;
}
else {
   result[2] = x145 + x166 + x179 + x181;
}
if (x103) {
   result[3] = x139 + x190 + x191 + x194;
}
else {
   result[3] = x142 + x190 + x195 + x197;
}
if (x103) {
   result[4] = x122 - x138*x31 + x154 + x191 - x202*x31 + x204 + x30;
}
else {
   result[4] = -x141*x31 + x144 + x181 + x195 + x204 - x205*x31;
}
if (x103) {
   result[5] = x167 + x191 + x206 + x218;
}
else {
   result[5] = x166 + x195 + x218 + x219;
}
if (x103) {
   result[6] = x121*x52 - 3*x193 + x224 + x30;
}
else {
   result[6] = x110 + x143*x52 - 3*x196 + x224;
}
if (x103) {
   result[7] = x154 + x194 + x226 + x227;
}
else {
   result[7] = x181 + x197 + x226 + x228;
}
if (x103) {
   result[8] = x122 + x206 + x227 + x229;
}
else {
   result[8] = x144 + x219 + x228 + x229;
}
if (x103) {
   result[9] = x153*x52 + x230 + x30;
}
else {
   result[9] = x110 + x180*x52 + x230;
}
}
        
static double coder_dgdt(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = 1.0*n1;
    double x1 = 1.0*n2;
    double x2 = 1.0*n3;
    double x3 = 1.0/(n1 + n2 + n3);
    double x4 = log(n3*x3);
    double x5 = 8.3144626181532395*n3;
    double x6 = 8.3144626181532395*n1*log(n1*x3) + 8.3144626181532395*n2*log(n2*x3) + x0*(*endmember[0].dmu0dT)(T, P) + x1*(*endmember[1].dmu0dT)(T, P) + x2*(*endmember[2].dmu0dT)(T, P) + x4*x5 + x5*(x4 - 0.69314718055994495) + 8.3144626181532395*(2.0*n1 + 2.0*n2 + x2)*log(x3*(0.5*n3 + x0 + x1));
    double x7 = sqrt(1 - 0.19999999999999998*T);
    double x8 = 1.0*x7;
    double x9 = fmin(4, x8);
    double x10 = (4 - x8 >= 0. ? 1. : 0.)/x7;

if (T >= 5.0) {
   result = -13.381349999999999*n2 + x6;
}
else {
   result = 0.33333333333333331*n2*(-20.072025*x10*((x9)*(x9)) - 0.099999999999999992*x10*(40.14405*T - 200.72024999999999) + 40.14405*x9 - 40.14405) + x6;
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = 1.0/x0;
    double x2 = n1*x1;
    double x3 = pow(x0, -2);
    double x4 = -x1;
    double x5 = 8.3144626181532395*x0;
    double x6 = n2*x1;
    double x7 = -8.3144626181532395*x6;
    double x8 = 1.0*n1 + 1.0*n2 + 0.5*n3;
    double x9 = log(x1*x8);
    double x10 = n3*x1;
    double x11 = x3*x8;
    double x12 = x5*(2.0*n1 + 2.0*n2 + 1.0*n3)/x8;
    double x13 = -16.628925236306479*x10 + x12*(1.0*x1 - x11) + 16.628925236306479*x9;
    double x14 = -8.3144626181532395*x2;
    double x15 = x13 + x14 + x5*(-n2*x3 - x4) + 8.3144626181532395*log(x6) + 1.0*(*endmember[1].dmu0dT)(T, P) - 13.381349999999999;
    double x16 = sqrt(1 - 0.19999999999999998*T);
    double x17 = 1.0*x16;
    double x18 = fmin(4, x17);
    double x19 = (4 - x17 >= 0. ? 1. : 0.)/x16;

result[0] = x13 + x5*(-n1*x3 - x4) + x7 + 8.3144626181532395*log(x2) + 1.0*(*endmember[0].dmu0dT)(T, P);
if (T >= 5.0) {
   result[1] = x15;
}
else {
   result[1] = x15 - 6.6906749999999997*((x18)*(x18))*x19 + 13.381349999999999*x18 - 0.033333333333333326*x19*(40.14405*T - 200.72024999999999);
}
result[2] = 16.628925236306479*x0*(-n3*x3 - x4) + x12*(0.5*x1 - x11) + x14 + x7 + 8.3144626181532395*x9 + 16.628925236306479*log(x10) + 1.0*(*endmember[2].dmu0dT)(T, P) - 5.7631463216439762;
}
        
static void coder_d3gdn2dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = pow(x0, -2);
    double x2 = n2*x1;
    double x3 = 8.3144626181532395*x2;
    double x4 = n1*x1;
    double x5 = 8.3144626181532395*x4;
    double x6 = -x5;
    double x7 = -2*x1;
    double x8 = 2/((x0)*(x0)*(x0));
    double x9 = n1*x8;
    double x10 = 8.3144626181532395*x0;
    double x11 = 1.0/x0;
    double x12 = -x11;
    double x13 = 8.3144626181532395*x11;
    double x14 = n3*x1;
    double x15 = 16.628925236306479*x14;
    double x16 = 1.0*n1 + 1.0*n2 + 0.5*n3;
    double x17 = 1.0/x16;
    double x18 = x1*x16;
    double x19 = 1.0*x11 - x18;
    double x20 = x17*x19;
    double x21 = 2.0*n1 + 2.0*n2 + 1.0*n3;
    double x22 = 8.3144626181532395*x21;
    double x23 = x15 + x20*x22;
    double x24 = x16*x8;
    double x25 = x10*x21;
    double x26 = x17*x25;
    double x27 = pow(x16, -2);
    double x28 = x19*x27;
    double x29 = 33.257850472612958*x0*x20 - x25*x28 + x26*(-2.0*x1 + x24);
    double x30 = x13 + x23 + x29;
    double x31 = -x1;
    double x32 = x10*(x31 + x9) + x23 + x3 + x6;
    double x33 = 16.628925236306479*x11;
    double x34 = 16.628925236306479*x0;
    double x35 = 0.5*x11 - x18;
    double x36 = x17*x35;
    double x37 = x34*x36;
    double x38 = 4.1572313090766198*x0*x21;
    double x39 = x10*x20 + x26*(-1.5*x1 + x24) - x28*x38 - x33 + x37;
    double x40 = n2*x8;
    double x41 = -x3 + x5;

result[0] = x10*(x7 + x9) + x3 + x30 + x6 + x10*(-x12 - x4)/n1;
result[1] = -x13 + x29 + x32;
result[2] = x32 + x39;
result[3] = x10*(x40 + x7) + x30 + x41 + x10*(-x12 - x2)/n2;
result[4] = x10*(x31 + x40) + x23 + x39 + x41;
result[5] = -x15 + x22*x36 + x26*(-1.0*x1 + x24) - x27*x35*x38 + x3 + x33 + x34*(n3*x8 + x7) + x37 + x5 + x34*(-x12 - x14)/n3;
}
        
static void coder_d4gdn3dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = pow(x0, -2);
    double x2 = -33.257850472612958*x1;
    double x3 = pow(x0, -3);
    double x4 = -6*x3;
    double x5 = 6/((x0)*(x0)*(x0)*(x0));
    double x6 = n1*x5;
    double x7 = 8.3144626181532395*x0;
    double x8 = -2*x1;
    double x9 = 2*x3;
    double x10 = n1*x9;
    double x11 = 8.3144626181532395/n1;
    double x12 = x0*x11;
    double x13 = 1.0/x0;
    double x14 = -x13;
    double x15 = -n1*x1 - x14;
    double x16 = x11*x15;
    double x17 = 33.257850472612958*x3;
    double x18 = 16.628925236306479*x3;
    double x19 = -n2*x18;
    double x20 = -n3*x17;
    double x21 = n1*x17 + x19 + x20;
    double x22 = 1.0*n1 + 1.0*n2 + 0.5*n3;
    double x23 = 1.0/x22;
    double x24 = x1*x22;
    double x25 = 1.0*x13 - x24;
    double x26 = x23*x25;
    double x27 = x22*x9;
    double x28 = -2.0*x1 + x27;
    double x29 = x23*x28;
    double x30 = 2.0*n1 + 2.0*n2 + 1.0*n3;
    double x31 = 16.628925236306479*x30;
    double x32 = 49.886775708919437*x0;
    double x33 = pow(x22, -2);
    double x34 = x25*x33;
    double x35 = x22*x5;
    double x36 = x30*x7;
    double x37 = x23*x36;
    double x38 = 16.628925236306479*x0;
    double x39 = x30*x38;
    double x40 = pow(x22, -3);
    double x41 = x25*x40;
    double x42 = x28*x33;
    double x43 = 49.886775708919437*x26 + x29*x31 + x29*x32 - x31*x34 - x32*x34 + x37*(6.0*x3 - x35) + x39*x41 - x39*x42;
    double x44 = x16 + x21 + x43;
    double x45 = 16.628925236306479*x1;
    double x46 = -4*x3;
    double x47 = -x1;
    double x48 = x12*(x10 + x47) + x7*(-x46 - x6);
    double x49 = -1.5*x1 + x27;
    double x50 = x33*x36;
    double x51 = -x49*x50;
    double x52 = 8.3144626181532395*x1;
    double x53 = 8.3144626181532395*x30;
    double x54 = x23*x49;
    double x55 = 24.943387854459719*x0;
    double x56 = 4.1572313090766198*x0*x30;
    double x57 = 33.257850472612958*x0*x54 + 41.572313090766201*x26 + x29*x53 + x29*x7 - 12.471693927229859*x30*x34 - x34*x55 + x36*x41 + x37*(5.0*x3 - x35) - x42*x56 + x53*x54;
    double x58 = x51 - x52 + x57;
    double x59 = -2*x3;
    double x60 = x21 + x7*(-x59 - x6);
    double x61 = x51 + x60;
    double x62 = 0.5*x13 - x24;
    double x63 = x23*x62;
    double x64 = -1.0*x1 + x27;
    double x65 = x23*x64;
    double x66 = x33*x62;
    double x67 = 24.943387854459719*x1 + 16.628925236306479*x26 + x31*x54 - x34*x53 - x34*x7 + x37*(4.0*x3 - x35) + x38*x54 + x38*x65 + x41*x56 + 16.628925236306479*x63 - x66*x7;
    double x68 = n2*x5;
    double x69 = n2*x9;
    double x70 = 1.0/n2;
    double x71 = x7*x70;
    double x72 = -n2*x1 - x14;
    double x73 = -n1*x18;
    double x74 = n2*x17 + x20 + x73;
    double x75 = 8.3144626181532395*x70*x72 + x74;
    double x76 = -n3*x1 - x14;
    double x77 = 16.628925236306479/n3;

result[0] = x12*(x10 + x8) + x2 + x44 + x7*(-x4 - x6) - x15*x7/((n1)*(n1));
result[1] = x44 - x45 + x48;
result[2] = x16 + x21 + x48 + x58;
result[3] = x43 + x52 + x60;
result[4] = x45 + x57 + x61;
result[5] = x61 + x67;
result[6] = x2 + x43 + x7*(-x4 - x68) + x71*(x69 + x8) + x75 - x7*x72/((n2)*(n2));
result[7] = x58 + x7*(-x46 - x68) + x71*(x47 + x69) + x75;
result[8] = x51 + x67 + x7*(-x59 - x68) + x74;
result[9] = 66.515700945225916*n3*x3 - 12.471693927229859*x0*x66 + x0*x77*(n3*x9 + x8) - 66.515700945225916*x1 + x19 + x31*x65 + x37*(3.0*x3 - x35) + x38*(-n3*x5 - x4) + x40*x56*x62 - x50*x64 - x53*x66 + x55*x65 + 24.943387854459719*x63 + x73 + x76*x77 - x38*x76/((n3)*(n3));
}
        
static double coder_dgdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*n1*(*endmember[0].dmu0dP)(T, P) + 1.0*n2*(*endmember[1].dmu0dP)(T, P) + 1.0*n3*(*endmember[2].dmu0dP)(T, P);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].dmu0dP)(T, P);
result[1] = 1.0*(*endmember[1].dmu0dP)(T, P);
result[2] = 1.0*(*endmember[2].dmu0dP)(T, P);
}
        
static void coder_d3gdn2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dT2)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dT2)(T, P);
    double x3 = 0.19999999999999998*T - 1;
    double x4 = -x3;
    double x5 = sqrt(x4);
    double x6 = 1.0*x5;
    double x7 = x6 - 4;
    double x8 = (-x7 >= 0. ? 1. : 0.);
    double x9 = 0.40144049999999992*T - 2.0072024999999996;
    double x10 = 1.0/x3;
    double x11 = x10*0;
    double x12 = x8/pow(x4, 3.0/2.0);
    double x13 = fmin(4, x6);
    double x14 = 2.0072025*((x13)*(x13));

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = -0.33333333333333331*n2*(4.014405*x10*x13*((x8)*(x8)) - x11*x14 - x11*x9 + x12*x14 + x12*x9 + 8.02881*x8/x5) + 1.0*x0 + 1.0*x1 + 1.0*x2;
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[1].d2mu0dT2)(T, P);
    double x1 = 0.19999999999999998*T - 1;
    double x2 = -x1;
    double x3 = sqrt(x2);
    double x4 = 1.0*x3;
    double x5 = x4 - 4;
    double x6 = (-x5 >= 0. ? 1. : 0.);
    double x7 = 40.14405*T - 200.72024999999999;
    double x8 = 1.0/x1;
    double x9 = 0;
    double x10 = x6/pow(x2, 3.0/2.0);
    double x11 = fmin(4, x4);
    double x12 = ((x11)*(x11));

result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
if (T >= 5.0) {
   result[1] = 1.0*x0;
}
else {
   result[1] = 1.0*x0 - 0.66906749999999993*x10*x12 - 0.0033333333333333327*x10*x7 - 1.3381349999999999*x11*((x6)*(x6))*x8 + 0.66906749999999993*x12*x8*x9 + 0.0033333333333333327*x7*x8*x9 - 2.6762699999999997*x6/x3;
}
result[2] = 1.0*(*endmember[2].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P) + n3*(*endmember[2].d2mu0dTdP)(T, P));
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P) + n3*(*endmember[2].d2mu0dP2)(T, P));
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT3)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dT3)(T, P);
    double x3 = 0.19999999999999998*T - 1;
    double x4 = -x3;
    double x5 = 1.0*sqrt(x4);
    double x6 = x5 - 4;
    double x7 = 0;
    double x8 = pow(x4, -3.0/2.0);
    double x9 = (-x6 >= 0. ? 1. : 0.);
    double x10 = 1.2043214999999998*x8*x9;
    double x11 = 40.14405*T - 200.72024999999999;
    double x12 = pow(x3, -2);
    double x13 = x12*x7;
    double x14 = x9/pow(x4, 5.0/2.0);
    double x15 = x8*0;
    double x16 = fmin(4, x5);
    double x17 = ((x16)*(x16));

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = -0.33333333333333331*n2*(-x10*x16*x7 + x10 + 0.0029999999999999992*x11*x13 + 0.0029999999999999996*x11*x14 - 0.0009999999999999998*x11*x15 - 1.2043214999999998*x12*x16*((x9)*(x9)) + 0.60216074999999991*x13*x17 + 0.60216075000000002*x14*x17 - 0.20072024999999999*x15*x17 + 0.40144049999999998*x8*((x9)*(x9)*(x9)) - 1.2043214999999998*x7/x3) + 1.0*x0 + 1.0*x1 + 1.0*x2;
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 1.0*(*endmember[1].d3mu0dT3)(T, P);
    double x1 = 0.19999999999999998*T - 1;
    double x2 = -x1;
    double x3 = 1.0*sqrt(x2);
    double x4 = x3 - 4;
    double x5 = 0;
    double x6 = 0.40144049999999992*x5;
    double x7 = pow(x2, -3.0/2.0);
    double x8 = (-x4 >= 0. ? 1. : 0.);
    double x9 = x7*x8;
    double x10 = 40.14405*T - 200.72024999999999;
    double x11 = pow(x1, -2);
    double x12 = x11*x5;
    double x13 = x8/pow(x2, 5.0/2.0);
    double x14 = x7*0;
    double x15 = fmin(4, x3);
    double x16 = ((x15)*(x15));

result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
if (T >= 5.0) {
   result[1] = x0;
}
else {
   result[1] = x0 - 0.00099999999999999959*x10*x12 - 0.0009999999999999998*x10*x13 + 0.00033333333333333327*x10*x14 + 0.40144049999999992*x11*x15*((x8)*(x8)) - 0.20072024999999996*x12*x16 - 0.20072024999999999*x13*x16 + 0.066906749999999987*x14*x16 + x15*x6*x9 - 0.13381349999999997*x7*((x8)*(x8)*(x8)) - 0.40144049999999992*x9 + x6/x1;
}
result[2] = 1.0*(*endmember[2].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P) + n3*(*endmember[2].d3mu0dT2dP)(T, P));
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P) + n3*(*endmember[2].d3mu0dTdP2)(T, P));
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P) + n3*(*endmember[2].d3mu0dP3)(T, P));
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_s(double T, double P, double n[3]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[3]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[3]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[3]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[3]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[3]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

