#include <math.h>


static double coder_g(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = 1.0*n1;
    double x1 = 1.0*n2;
    double x2 = 0.39000000000000001*n3 + x0 + x1;
    double x3 = n1*n2;
    double x4 = n1*n3;
    double x5 = n1*(15846.000000000002*n2 - 27300.0*n3);
    double x6 = n1*(*endmember[0].mu0)(T, P);
    double x7 = n2*(*endmember[1].mu0)(T, P);
    double x8 = n3*(*endmember[2].mu0)(T, P);
    double x9 = n1 + n2;
    double x10 = 1.0/(n3 + x9);
    double x11 = T*(2.0*n3*log(n3*x10) + x0*log(n1*x10) + x1*log(n2*x10) + 1.0*x9*log(x10*x9));
    double x12 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));

if (T >= 5.0) {
   result = (x2*(-n2*(13.381349999999999*T - 44.604500000000002) + 8.3144626181532395*x11 + x6 + x7 + x8) - 5700.0*x3 + 9820.1438848920843*x4 - 0.35971223021582727*x5)/x2;
}
else {
   result = (x2*(n2*(66.906750000000002*((x12)*(x12)*(x12)) + (40.14405*T - 200.72024999999999)*(x12 - 1) - 66.906750000000002) + 24.943387854459719*x11 + 3*x6 + 3*x7 + 3*x8) - 17100.0*x3 + 29460.431654676253*x4 - 1.0791366906474817*x5)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 0.39000000000000001*n3;
    double x1 = 1.0*n1;
    double x2 = 1.0*n2;
    double x3 = x1 + x2;
    double x4 = x0 + x3;
    double x5 = n1*n2;
    double x6 = n1*n3;
    double x7 = n1*(15846.000000000002*n2 - 27300.0*n3);
    double x8 = (*endmember[0].mu0)(T, P);
    double x9 = n1*x8;
    double x10 = (*endmember[1].mu0)(T, P);
    double x11 = n2*x10;
    double x12 = (*endmember[2].mu0)(T, P);
    double x13 = n3*x12;
    double x14 = 13.381349999999999*T;
    double x15 = x14 - 44.604500000000002;
    double x16 = n2*x15;
    double x17 = n1 + n2;
    double x18 = n3 + x17;
    double x19 = 1.0/x18;
    double x20 = log(n1*x19);
    double x21 = log(n2*x19);
    double x22 = n3*x19;
    double x23 = 2.0*log(x22);
    double x24 = 1.0*log(x17*x19);
    double x25 = n3*x23 + x1*x20 + x17*x24 + x2*x21;
    double x26 = 8.3144626181532395*T;
    double x27 = x25*x26;
    double x28 = (x4*(x11 + x13 - x16 + x27 + x9) - 5700.0*x5 + 9820.1438848920843*x6 - 0.35971223021582727*x7)/((x4)*(x4));
    double x29 = -1.0*x28;
    double x30 = 1.0/x4;
    double x31 = -x19*x2;
    double x32 = pow(x18, -2);
    double x33 = 1.0*x18;
    double x34 = -2.0*x22 + x24 + x18*x3*(-x17*x32 + x19)/x17;
    double x35 = 1.0*x20 + x31 + x33*(-n1*x32 + x19) + x34;
    double x36 = x1*x8 + x10*x2 + 1.0*x13 - x15*x2 + x27;
    double x37 = T >= 5.0;
    double x38 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x39 = 66.906750000000002*((x38)*(x38)*(x38)) + (40.14405*T - 200.72024999999999)*(x38 - 1) - 66.906750000000002;
    double x40 = n2*x39;
    double x41 = 24.943387854459719*T;
    double x42 = x25*x41;
    double x43 = (x4*(3*x11 + 3*x13 + x40 + x42 + 3*x9) - 17100.0*x5 + 29460.431654676253*x6 - 1.0791366906474817*x7)/((0.38999999999999996*n3 + x17)*(0.38999999999999996*n3 + x17));
    double x44 = -0.33333333333333331*x43;
    double x45 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x46 = 3.0*x11 + 3.0*x13 + x2*x39 + x42 + 3.0*x9;
    double x47 = -x1*x19;
    double x48 = 1.0*x21 + x33*(-n2*x32 + x19) + x34 + x47;
    double x49 = T*x25;
    double x50 = 2.0*x18*(-n3*x32 + x19) - x19*x3 + x23 + x31 + x47;

if (x37) {
   result[0] = x29 + x30*(-11400.0*n2 + 19640.287769784169*n3 + x36 + x4*(x26*x35 + x8));
}
else {
   result[0] = x44 + x45*(-34200.0*n2 + 58920.863309352506*n3 + x4*(x35*x41 + 3*x8) + x46);
}
if (x37) {
   result[1] = x29 + x30*(-11400.0*n1 + x36 + x4*(x10 - x14 + x26*x48 + 44.604500000000002));
}
else {
   result[1] = x44 + x45*(-34200.0*n1 + x4*(3*x10 + x39 + x41*x48) + x46);
}
if (x37) {
   result[2] = -0.39000000000000001*x28 + x30*(19640.287769784169*n1 + x0*x12 + 0.39000000000000001*x11 - 0.39000000000000001*x16 + x4*(x12 + x26*x50) + 3.2426404210797637*x49 + 0.39000000000000001*x9);
}
else {
   result[2] = -0.12999999999999998*x43 + x45*(58920.863309352506*n1 + 1.1699999999999999*x11 + 1.1699999999999999*x13 + x4*(3*x12 + x41*x50) + 0.39000000000000001*x40 + 9.7279212632392902*x49 + 1.1699999999999999*x9);
}
}
        
static void coder_d2gdn2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 0.39000000000000001*n3;
    double x1 = 1.0*n1;
    double x2 = 1.0*n2;
    double x3 = x1 + x2;
    double x4 = x0 + x3;
    double x5 = n1*n2;
    double x6 = n1*n3;
    double x7 = n1*(15846.000000000002*n2 - 27300.0*n3);
    double x8 = (*endmember[0].mu0)(T, P);
    double x9 = n1*x8;
    double x10 = (*endmember[1].mu0)(T, P);
    double x11 = n2*x10;
    double x12 = (*endmember[2].mu0)(T, P);
    double x13 = n3*x12;
    double x14 = 13.381349999999999*T;
    double x15 = x14 - 44.604500000000002;
    double x16 = n2*x15;
    double x17 = n1 + n2;
    double x18 = n3 + x17;
    double x19 = 1.0/x18;
    double x20 = log(n1*x19);
    double x21 = log(n2*x19);
    double x22 = n3*x19;
    double x23 = 2.0*log(x22);
    double x24 = 1.0*log(x17*x19);
    double x25 = T*(n3*x23 + x1*x20 + x17*x24 + x2*x21);
    double x26 = 8.3144626181532395*x25;
    double x27 = (x4*(x11 + x13 - x16 + x26 + x9) - 5700.0*x5 + 9820.1438848920843*x6 - 0.35971223021582727*x7)/((x4)*(x4)*(x4));
    double x28 = 2.0*x27;
    double x29 = pow(x4, -2);
    double x30 = -x19*x2;
    double x31 = pow(x18, -2);
    double x32 = 1.0*x18;
    double x33 = x32*(-n1*x31 + x19);
    double x34 = 1.0/x17;
    double x35 = -x17*x31 + x19;
    double x36 = x34*x35;
    double x37 = x3*x36;
    double x38 = x18*x37 - 2.0*x22 + x24;
    double x39 = T*(1.0*x20 + x30 + x33 + x38);
    double x40 = 8.3144626181532395*x39;
    double x41 = x1*x8 + x10*x2 + 1.0*x13 - x15*x2 + x26;
    double x42 = x29*(-11400.0*n2 + 19640.287769784169*n3 + x4*(x40 + x8) + x41);
    double x43 = 1.0/x4;
    double x44 = 2.0*x31;
    double x45 = -x44;
    double x46 = pow(x18, -3);
    double x47 = 2.0*x46;
    double x48 = n1*x47;
    double x49 = x2*x31;
    double x50 = x1*x31;
    double x51 = x49 - x50;
    double x52 = 1.0*x19;
    double x53 = 2.0*x18;
    double x54 = 2*x17*x46;
    double x55 = x18*x3;
    double x56 = x34*x55;
    double x57 = n3*x44;
    double x58 = x37 + x57;
    double x59 = x36*x53 + x56*(-2*x31 + x54) + x58 - x35*x55/((x17)*(x17));
    double x60 = x52 + x59;
    double x61 = T*x4;
    double x62 = x61*(x18*(x45 + x48) + x51 + x60 + x33/n1);
    double x63 = T >= 5.0;
    double x64 = 0.38999999999999996*n3 + x17;
    double x65 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x66 = ((x65)*(x65)*(x65));
    double x67 = 66.906750000000002*x66;
    double x68 = (40.14405*T - 200.72024999999999)*(x65 - 1);
    double x69 = x67 + x68 - 66.906750000000002;
    double x70 = n2*x69;
    double x71 = 24.943387854459719*x25;
    double x72 = (x4*(3*x11 + 3*x13 + x70 + x71 + 3*x9) - 17100.0*x5 + 29460.431654676253*x6 - 1.0791366906474817*x7)/((x64)*(x64)*(x64));
    double x73 = 0.66666666666666663*x72;
    double x74 = pow(x64, -2);
    double x75 = 24.943387854459719*x39;
    double x76 = 3.0*x11 + 3.0*x13 + x2*x69 + x71 + 3.0*x9;
    double x77 = x74*(-34200.0*n2 + 58920.863309352506*n3 + x4*(x75 + 3*x8) + x76);
    double x78 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x79 = -x1*x19;
    double x80 = x32*(-n2*x31 + x19);
    double x81 = T*(1.0*x21 + x38 + x79 + x80);
    double x82 = -x14 + 8.3144626181532395*x81;
    double x83 = -11400.0*n1 + x4*(x10 + x82 + 44.604500000000002) + x41;
    double x84 = 1.0*x29;
    double x85 = -1.0*x31;
    double x86 = x18*(x48 + x85) + x51;
    double x87 = x61*(-x52 + x59 + x86);
    double x88 = 24.943387854459719*x81;
    double x89 = -34200.0*n1 + x4*(3*x10 + x69 + x88) + x76;
    double x90 = 0.33333333333333331*x74;
    double x91 = -3.0*x19 + x56*(-x31 + x54) + x58;
    double x92 = x61*(x86 + x91);
    double x93 = x53*(-n3*x31 + x19);
    double x94 = T*(-x19*x3 + x23 + x30 + x79 + x93);
    double x95 = 8.3144626181532395*x94;
    double x96 = 1.0*x12 + x95;
    double x97 = 19640.287769784169*n1 + x0*x12 + 0.39000000000000001*x11 - 0.39000000000000001*x16 + 3.2426404210797637*x25 + x4*(x12 + x95) + 0.39000000000000001*x9;
    double x98 = 0.78000000000000003*x27 - x84*x97;
    double x99 = 24.943387854459719*x94;
    double x100 = 3.0*x12 + x99;
    double x101 = 58920.863309352506*n1 + 1.1699999999999999*x11 + 1.1699999999999999*x13 + 9.7279212632392902*x25 + x4*(3*x12 + x99) + 0.39000000000000001*x70 + 1.1699999999999999*x9;
    double x102 = -x101*x90 + 0.25999999999999995*x72;
    double x103 = x29*x83;
    double x104 = n2*x47;
    double x105 = -x49 + x50;
    double x106 = x61*(x105 + x18*(x104 + x45) + x60 + x80/n2);
    double x107 = x74*x89;
    double x108 = x61*(x105 + x18*(x104 + x85) + x91);
    double x109 = x61*(x18*(4.0*n3*x46 - 4.0*x31) + 2.0*x19 + x3*x31 + x49 + x50 - x57 + x93/n3);

if (x63) {
   result[0] = x28 - 2.0*x42 + x43*(16.628925236306479*x39 + 8.3144626181532395*x62 + 2.0*x8);
}
else {
   result[0] = x73 - 0.66666666666666663*x77 + x78*(49.886775708919437*x39 + 24.943387854459719*x62 + 6.0*x8);
}
if (x63) {
   result[1] = x28 - 1.0*x42 + x43*(1.0*x10 + x40 + 1.0*x8 + x82 + 8.3144626181532395*x87 - 11355.395500000001) - x83*x84;
}
else {
   result[1] = x73 - 0.33333333333333331*x77 + x78*(3.0*x10 + x67 + 1.0*x68 + x75 + 3.0*x8 + 24.943387854459719*x87 + x88 - 34266.906750000002) - x89*x90;
}
if (x63) {
   result[2] = -0.39000000000000001*x42 + x43*(3.2426404210797637*x39 + 0.39000000000000001*x8 + 8.3144626181532395*x92 + x96 + 19640.287769784169) + x98;
}
else {
   result[2] = x102 - 0.12999999999999998*x77 + x78*(x100 + 9.7279212632392902*x39 + 1.1699999999999999*x8 + 24.943387854459719*x92 + 58920.863309352506);
}
if (x63) {
   result[3] = -2.0*x103 + x28 + x43*(-26.762699999999999*T + 2.0*x10 + 8.3144626181532395*x106 + 16.628925236306479*x81 + 89.209000000000003);
}
else {
   result[3] = -0.66666666666666663*x107 + x73 + x78*(6.0*x10 + 24.943387854459719*x106 + 133.8135*x66 + 2.0*x68 + 49.886775708919437*x81 - 133.8135);
}
if (x63) {
   result[4] = -0.39000000000000001*x103 + x43*(-5.2187264999999998*T + 0.39000000000000001*x10 + 8.3144626181532395*x108 + 3.2426404210797637*x81 + x96 + 17.395755000000001) + x98;
}
else {
   result[4] = x102 - 0.12999999999999998*x107 + x78*(1.1699999999999999*x10 + x100 + 24.943387854459719*x108 + 26.093632500000002*x66 + 0.39000000000000001*x68 + 9.7279212632392902*x81 - 26.093632500000002);
}
if (x63) {
   result[5] = 0.30420000000000003*x27 - 0.78000000000000003*x29*x97 + x43*(8.3144626181532395*x109 + 0.78000000000000003*x12 + 6.4852808421595274*x94);
}
else {
   result[5] = -0.25999999999999995*x101*x74 + 0.10139999999999998*x72 + x78*(24.943387854459719*x109 + 2.3399999999999999*x12 + 19.45584252647858*x94);
}
}
        
static void coder_d3gdn3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 0.39000000000000001*n3;
    double x1 = 1.0*n1;
    double x2 = 1.0*n2;
    double x3 = x1 + x2;
    double x4 = x0 + x3;
    double x5 = n1*n2;
    double x6 = n1*n3;
    double x7 = n1*(15846.000000000002*n2 - 27300.0*n3);
    double x8 = (*endmember[0].mu0)(T, P);
    double x9 = n1*x8;
    double x10 = (*endmember[1].mu0)(T, P);
    double x11 = n2*x10;
    double x12 = (*endmember[2].mu0)(T, P);
    double x13 = n3*x12;
    double x14 = 13.381349999999999*T;
    double x15 = x14 - 44.604500000000002;
    double x16 = n2*x15;
    double x17 = n1 + n2;
    double x18 = n3 + x17;
    double x19 = 1.0/x18;
    double x20 = log(n1*x19);
    double x21 = log(n2*x19);
    double x22 = n3*x19;
    double x23 = 2.0*log(x22);
    double x24 = 1.0*log(x17*x19);
    double x25 = n3*x23 + x1*x20 + x17*x24 + x2*x21;
    double x26 = 8.3144626181532395*T;
    double x27 = x25*x26;
    double x28 = (x4*(x11 + x13 - x16 + x27 + x9) - 5700.0*x5 + 9820.1438848920843*x6 - 0.35971223021582727*x7)/((x4)*(x4)*(x4)*(x4));
    double x29 = -6.0*x28;
    double x30 = pow(x4, -3);
    double x31 = -x19*x2;
    double x32 = pow(x18, -2);
    double x33 = -1.0*n1*x32 + 1.0*x19;
    double x34 = x18*x33;
    double x35 = 1.0/x17;
    double x36 = -x17*x32 + x19;
    double x37 = x35*x36;
    double x38 = x3*x37;
    double x39 = x18*x38 - 2.0*x22 + x24;
    double x40 = 1.0*x20 + x31 + x34 + x39;
    double x41 = x26*x40;
    double x42 = x1*x8 + x10*x2 + 1.0*x13 - x15*x2 + x27;
    double x43 = x30*(-11400.0*n2 + 19640.287769784169*n3 + x4*(x41 + x8) + x42);
    double x44 = pow(x4, -2);
    double x45 = T*x40;
    double x46 = 2.0*x32;
    double x47 = -x46;
    double x48 = pow(x18, -3);
    double x49 = 2.0*x48;
    double x50 = n1*x49;
    double x51 = 1.0/n1;
    double x52 = x33*x51;
    double x53 = x2*x32;
    double x54 = x1*x32;
    double x55 = x53 - x54;
    double x56 = 1.0*x19;
    double x57 = 2.0*x37;
    double x58 = -2*x32;
    double x59 = 2*x48;
    double x60 = x17*x59;
    double x61 = x58 + x60;
    double x62 = x3*x35;
    double x63 = x61*x62;
    double x64 = pow(x17, -2);
    double x65 = x36*x64;
    double x66 = x3*x65;
    double x67 = n3*x46;
    double x68 = x38 + x67;
    double x69 = x18*x57 + x18*x63 - x18*x66 + x68;
    double x70 = x56 + x69;
    double x71 = T*(x18*x52 + x18*(x47 + x50) + x55 + x70);
    double x72 = 8.3144626181532395*x71;
    double x73 = x44*(x4*x72 + 16.628925236306479*x45 + 2.0*x8);
    double x74 = 1.0/x4;
    double x75 = 24.943387854459719*x71;
    double x76 = 6.0*x48;
    double x77 = pow(x18, -4);
    double x78 = 6.0*x77;
    double x79 = -n1*x78;
    double x80 = n1*x59;
    double x81 = 1.0*x18;
    double x82 = x51*x81;
    double x83 = 4.0*x48;
    double x84 = n2*x49;
    double x85 = -x84;
    double x86 = n3*x83;
    double x87 = -x86;
    double x88 = n1*x83 + x85 + x87;
    double x89 = x52 + x88;
    double x90 = 4.0*x32;
    double x91 = -x90;
    double x92 = 3.0*x18;
    double x93 = -6*x17*x77;
    double x94 = x18*x62;
    double x95 = x3*x64;
    double x96 = 2*x18;
    double x97 = x35*x61*x92 + 3.0*x37 - x61*x95*x96 + 2*x63 - x65*x92 - 2*x66 + x94*(6*x48 + x93) + x3*x36*x96/((x17)*(x17)*(x17));
    double x98 = x91 + x97;
    double x99 = x4*(x18*(x76 + x79) + x82*(x58 + x80) + x89 + x98 - x34/((n1)*(n1)));
    double x100 = T >= 5.0;
    double x101 = 0.38999999999999996*n3 + x17;
    double x102 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x103 = ((x102)*(x102)*(x102));
    double x104 = 66.906750000000002*x103;
    double x105 = (40.14405*T - 200.72024999999999)*(x102 - 1);
    double x106 = x104 + x105 - 66.906750000000002;
    double x107 = n2*x106;
    double x108 = 24.943387854459719*T;
    double x109 = x108*x25;
    double x110 = (x4*(x107 + x109 + 3*x11 + 3*x13 + 3*x9) - 17100.0*x5 + 29460.431654676253*x6 - 1.0791366906474817*x7)/((x101)*(x101)*(x101)*(x101));
    double x111 = -2.0*x110;
    double x112 = pow(x101, -3);
    double x113 = 24.943387854459719*x45;
    double x114 = x106*x2 + x109 + 3.0*x11 + 3.0*x13 + 3.0*x9;
    double x115 = x112*(-34200.0*n2 + 58920.863309352506*n3 + x114 + x4*(x113 + 3*x8));
    double x116 = pow(x101, -2);
    double x117 = x116*(x4*x75 + 49.886775708919437*x45 + 6.0*x8);
    double x118 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x119 = 1.0*x32;
    double x120 = -x119;
    double x121 = x18*(x120 + x50) + x55;
    double x122 = x121 - x56 + x69;
    double x123 = T*x122;
    double x124 = 16.628925236306479*x123;
    double x125 = -x32;
    double x126 = x18*(x79 + x83) + x82*(x125 + x80) + x89;
    double x127 = x126 + x47 + x97;
    double x128 = x26*x4;
    double x129 = -x1*x19;
    double x130 = -1.0*n2*x32 + 1.0*x19;
    double x131 = x130*x18;
    double x132 = x129 + x131 + 1.0*x21 + x39;
    double x133 = x132*x26 - x14;
    double x134 = -11400.0*n1 + x4*(x10 + x133 + 44.604500000000002) + x42;
    double x135 = 2.0*x30;
    double x136 = 1.0*x10 + x122*x128 + x133 + x41 + 1.0*x8 - 11355.395500000001;
    double x137 = 2.0*x44;
    double x138 = -x136*x137 + x29;
    double x139 = 49.886775708919437*x123;
    double x140 = x108*x4;
    double x141 = x108*x132;
    double x142 = -34200.0*n1 + x114 + x4*(3*x10 + x106 + x141);
    double x143 = 0.66666666666666663*x112;
    double x144 = 3.0*x10 + x104 + 1.0*x105 + x113 + x122*x140 + x141 + 3.0*x8 - 34266.906750000002;
    double x145 = 0.66666666666666663*x116;
    double x146 = x111 - x144*x145;
    double x147 = x125 + x60;
    double x148 = x147*x62;
    double x149 = x148*x18 - 3.0*x19 + x68;
    double x150 = x121 + x149;
    double x151 = T*x150;
    double x152 = x147*x18;
    double x153 = x148 + 2.0*x152*x35 - x152*x95 + x57 + x63 - x66 + x94*(4*x48 + x93);
    double x154 = x120 + x153;
    double x155 = x126 + x154;
    double x156 = x150*x26;
    double x157 = -2.0*n3*x32 + 2.0*x19;
    double x158 = x157*x18;
    double x159 = x129 + x158 - x19*x3 + x23 + x31;
    double x160 = x159*x26;
    double x161 = 1.0*x12 + x160;
    double x162 = x156*x4 + x161 + 3.2426404210797637*x45 + 0.39000000000000001*x8 + 19640.287769784169;
    double x163 = T*x25;
    double x164 = 19640.287769784169*n1 + x0*x12 + 0.39000000000000001*x11 - 0.39000000000000001*x16 + 3.2426404210797637*x163 + x4*(x12 + x160) + 0.39000000000000001*x9;
    double x165 = x135*x164 - 2.3399999999999999*x28;
    double x166 = x108*x150;
    double x167 = x108*x159;
    double x168 = 3.0*x12 + x167;
    double x169 = x166*x4 + x168 + 9.7279212632392902*x45 + 1.1699999999999999*x8 + 58920.863309352506;
    double x170 = 58920.863309352506*n1 + 0.39000000000000001*x107 + 1.1699999999999999*x11 + 1.1699999999999999*x13 + 9.7279212632392902*x163 + x4*(3*x12 + x167) + 1.1699999999999999*x9;
    double x171 = -0.77999999999999992*x110 + x143*x170;
    double x172 = 1.0/n2;
    double x173 = -x53 + x54;
    double x174 = x131*x172 + x173 + x18*(x47 + x84) + x70;
    double x175 = x174*x26;
    double x176 = x18*(x49 + x79) + x88;
    double x177 = x119 + x176 + x97;
    double x178 = x134*x30;
    double x179 = T*x132;
    double x180 = -26.762699999999999*T + 2.0*x10 + x175*x4 + 16.628925236306479*x179 + 89.209000000000003;
    double x181 = 1.0*x44;
    double x182 = x108*x174;
    double x183 = x112*x142;
    double x184 = 6.0*x10 + 133.8135*x103 + 2.0*x105 + 49.886775708919437*x179 + x182*x4 - 133.8135;
    double x185 = 0.33333333333333331*x116;
    double x186 = x149 + x173 + x18*(x120 + x84);
    double x187 = x186*x26;
    double x188 = x153 + x176 + x46;
    double x189 = -5.2187264999999998*T + 0.39000000000000001*x10 + x161 + 3.2426404210797637*x179 + x187*x4 + 17.395755000000001;
    double x190 = 0.39000000000000001*x44;
    double x191 = x108*x186;
    double x192 = 0.12999999999999998*x116;
    double x193 = 1.1699999999999999*x10 + 26.093632500000002*x103 + 0.39000000000000001*x105 + x168 + 9.7279212632392902*x179 + x191*x4 - 26.093632500000002;
    double x194 = 1.0/n3;
    double x195 = x158*x194 + x18*(x86 + x91) + 2.0*x19 + x3*x32 + x53 + x54 - x67;
    double x196 = x195*x26;
    double x197 = 2*x148 + x90 + x94*(x59 + x93);
    double x198 = x176 + x197;
    double x199 = 0.78000000000000003*x44;
    double x200 = x164*x30;
    double x201 = T*x159;
    double x202 = 0.78000000000000003*x12 + x196*x4 + 6.4852808421595274*x201;
    double x203 = -x181*x202 + 1.5600000000000001*x200 - 0.91259999999999997*x28;
    double x204 = x108*x195;
    double x205 = 0.25999999999999995*x116;
    double x206 = x112*x170;
    double x207 = 2.3399999999999999*x12 + 19.45584252647858*x201 + x204*x4;
    double x208 = -0.30419999999999991*x110 - x185*x207 + 0.51999999999999991*x206;
    double x209 = -n2*x78;
    double x210 = n2*x59;
    double x211 = x172*x81;
    double x212 = -x50;
    double x213 = n2*x83 + x212 + x87;
    double x214 = x130*x172 + x213;
    double x215 = x18*(x209 + x76) + x211*(x210 + x58) + x214 + x98 - x131/((n2)*(n2));
    double x216 = T*x174;
    double x217 = T*x186;
    double x218 = x154 + x18*(x209 + x83) + x211*(x125 + x210) + x214;
    double x219 = x18*(x209 + x49) + x197 + x213;
    double x220 = T*x195;
    double x221 = 8.0*n3*x48 + x157*x194 + 2.0*x18*x194*(n3*x59 + x58) + x18*(-12.0*n3*x77 + 12.0*x48) + x212 - x3*x59 - 8.0*x32 + x85 - x158/((n3)*(n3));

if (x100) {
   result[0] = x29 + 6.0*x43 - 3.0*x73 + x74*(x26*x99 + x75);
}
else {
   result[0] = x111 + 2.0*x115 - 1.0*x117 + x118*(x108*x99 + 74.830163563379159*x71);
}
if (x100) {
   result[1] = x134*x135 + x138 + 4.0*x43 - 1.0*x73 + x74*(x124 + x127*x128 + x72);
}
else {
   result[1] = 1.3333333333333333*x115 - 0.33333333333333331*x117 + x118*(x127*x140 + x139 + x75) + x142*x143 + x146;
}
if (x100) {
   result[2] = -x137*x162 + x165 + 1.5600000000000001*x43 - 0.39000000000000001*x73 + x74*(x128*x155 + 16.628925236306479*x151 + 3.2426404210797637*x71);
}
else {
   result[2] = 0.51999999999999991*x115 - 0.12999999999999998*x117 + x118*(x140*x155 + 49.886775708919437*x151 + 9.7279212632392902*x71) - x145*x169 + x171;
}
if (x100) {
   result[3] = x138 + 4.0*x178 - x180*x181 + 2.0*x43 + x74*(x124 + x128*x177 + x175);
}
else {
   result[3] = 0.66666666666666663*x115 + x118*(x139 + x140*x177 + x182) + x146 + 1.3333333333333333*x183 - x184*x185;
}
if (x100) {
   result[4] = -x136*x190 - x162*x181 + x165 + 0.78000000000000003*x178 - x181*x189 + 0.78000000000000003*x43 + x74*(3.2426404210797637*x123 + x128*x188 + x156 + x187);
}
else {
   result[4] = 0.25999999999999995*x115 + x118*(9.7279212632392902*x123 + x140*x188 + x166 + x191) - x144*x192 - x169*x185 + x171 + 0.25999999999999995*x183 - x185*x193;
}
if (x100) {
   result[5] = -x162*x199 + x203 + 0.30420000000000003*x43 + x74*(x128*x198 + 6.4852808421595274*x151 + x196);
}
else {
   result[5] = 0.10139999999999998*x115 + x118*(x140*x198 + 19.45584252647858*x151 + x204) - x169*x205 + x208;
}
if (x100) {
   result[6] = 6.0*x178 - 3.0*x180*x44 + x29 + x74*(x128*x215 + x182);
}
else {
   result[6] = x111 - 1.0*x116*x184 + x118*(x140*x215 + 74.830163563379159*x216) + 2.0*x183;
}
if (x100) {
   result[7] = -x137*x189 + x165 + 1.5600000000000001*x178 - x180*x190 + x74*(x128*x218 + 3.2426404210797637*x216 + 16.628925236306479*x217);
}
else {
   result[7] = x118*(x140*x218 + 9.7279212632392902*x216 + 49.886775708919437*x217) - x145*x193 + x171 + 0.51999999999999991*x183 - x184*x192;
}
if (x100) {
   result[8] = 0.30420000000000003*x178 - x189*x199 + x203 + x74*(x128*x219 + x196 + 6.4852808421595274*x217);
}
else {
   result[8] = x118*(x140*x219 + x204 + 19.45584252647858*x217) + 0.10139999999999998*x183 - x193*x205 + x208;
}
if (x100) {
   result[9] = 0.91260000000000008*x200 - 1.1699999999999999*x202*x44 - 0.35591400000000001*x28 + x74*(x128*x221 + 9.727921263239292*x220);
}
else {
   result[9] = -0.11863799999999997*x110 - 0.3899999999999999*x116*x207 + x118*(x140*x221 + 29.183763789717872*x220) + 0.30419999999999991*x206;
}
}
        
static double coder_dgdt(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].dmu0dT)(T, P);
    double x1 = n2*(*endmember[1].dmu0dT)(T, P);
    double x2 = n3*(*endmember[2].dmu0dT)(T, P);
    double x3 = n1 + n2;
    double x4 = 1.0/(n3 + x3);
    double x5 = n1*log(n1*x4);
    double x6 = n2*log(n2*x4);
    double x7 = n3*log(n3*x4);
    double x8 = x3*log(x3*x4);
    double x9 = sqrt(1 - 0.19999999999999998*T);
    double x10 = 1.0*x9;
    double x11 = fmin(4, x10);
    double x12 = (4 - x10 >= 0. ? 1. : 0.)/x9;

if (T >= 5.0) {
   result = -13.381349999999999*n2 + x0 + x1 + x2 + 8.3144626181532395*x5 + 8.3144626181532395*x6 + 16.628925236306479*x7 + 8.3144626181532395*x8;
}
else {
   result = (1.0*n1 + 1.0*n2 + 0.39000000000000001*n3)*(n2*(-20.072025*((x11)*(x11))*x12 + 40.14405*x11 - 0.099999999999999992*x12*(40.14405*T - 200.72024999999999) - 40.14405) + 3*x0 + 3*x1 + 3*x2 + 24.943387854459719*x5 + 24.943387854459719*x6 + 49.886775708919437*x7 + 24.943387854459719*x8)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = 1.0/x1;
    double x3 = 8.3144626181532395*n2;
    double x4 = -x2*x3;
    double x5 = n1*x2;
    double x6 = log(x5);
    double x7 = pow(x1, -2);
    double x8 = x1*(-n1*x7 + x2);
    double x9 = (*endmember[0].dmu0dT)(T, P);
    double x10 = log(x0*x2);
    double x11 = n3*x2;
    double x12 = 8.3144626181532395*n1 + x3;
    double x13 = x1*(-x0*x7 + x2)/x0;
    double x14 = 8.3144626181532395*x10 - 16.628925236306479*x11 + x12*x13;
    double x15 = T >= 5.0;
    double x16 = n2*x2;
    double x17 = -24.943387854459719*x16;
    double x18 = 3*x9;
    double x19 = 24.943387854459719*x6;
    double x20 = 24.943387854459719*x10;
    double x21 = 24.943387854459719*n2;
    double x22 = 24.943387854459719*n1 + x21;
    double x23 = -49.886775708919437*x11 + x13*x22 + x20;
    double x24 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x25 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x26 = x24*x25;
    double x27 = (*endmember[1].dmu0dT)(T, P);
    double x28 = 3*x27;
    double x29 = (*endmember[2].dmu0dT)(T, P);
    double x30 = 3*x29;
    double x31 = log(x16);
    double x32 = log(x11);
    double x33 = 49.886775708919437*x32;
    double x34 = sqrt(1 - 0.19999999999999998*T);
    double x35 = 1.0*x34;
    double x36 = fmin(4, x35);
    double x37 = (4 - x35 >= 0. ? 1. : 0.)/x34;
    double x38 = -20.072025*((x36)*(x36))*x37 + 40.14405*x36 - 0.099999999999999992*x37*(40.14405*T - 200.72024999999999) - 40.14405;
    double x39 = n1*x18 + n1*x19 + n2*x28 + n2*x38 + n3*x30 + n3*x33 + x0*x20 + x21*x31;
    double x40 = x24*x39;
    double x41 = x25*x39/((0.38999999999999996*n3 + x0)*(0.38999999999999996*n3 + x0));
    double x42 = 1.0*x40 - 0.33333333333333331*x41;
    double x43 = -8.3144626181532395*x5;
    double x44 = x1*(-n2*x7 + x2);
    double x45 = -24.943387854459719*x5;
    double x46 = x1*(-n3*x7 + x2);

if (x15) {
   result[0] = x14 + x4 + 8.3144626181532395*x6 + 8.3144626181532395*x8 + x9;
}
else {
   result[0] = x26*(x17 + x18 + x19 + x23 + 24.943387854459719*x8) + x42;
}
if (x15) {
   result[1] = x14 + x27 + 8.3144626181532395*x31 + x43 + 8.3144626181532395*x44 - 13.381349999999999;
}
else {
   result[1] = x26*(x23 + x28 + 24.943387854459719*x31 + x38 + 24.943387854459719*x44 + x45) + x42;
}
if (x15) {
   result[2] = -x12*x2 + x29 + 16.628925236306479*x32 + x4 + x43 + 16.628925236306479*x46;
}
else {
   result[2] = x26*(x17 - x2*x22 + x30 + x33 + x45 + 49.886775708919437*x46) + 0.39000000000000001*x40 - 0.12999999999999998*x41;
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = pow(x1, -2);
    double x3 = 16.628925236306479*x2;
    double x4 = -x3;
    double x5 = pow(x1, -3);
    double x6 = n1*x5;
    double x7 = 16.628925236306479*x6;
    double x8 = 1.0/x1;
    double x9 = n1*x2;
    double x10 = x8 - x9;
    double x11 = 1.0/n1;
    double x12 = 8.3144626181532395*x1;
    double x13 = 8.3144626181532395*n2;
    double x14 = x13*x2;
    double x15 = 8.3144626181532395*n1;
    double x16 = x15*x2;
    double x17 = x14 - x16;
    double x18 = 8.3144626181532395*x8;
    double x19 = 1.0/x0;
    double x20 = -x0*x2 + x8;
    double x21 = x19*x20;
    double x22 = 16.628925236306479*x1;
    double x23 = x13 + x15;
    double x24 = x1*x23;
    double x25 = 2*x0*x5;
    double x26 = x19*(-2*x2 + x25);
    double x27 = x20/((x0)*(x0));
    double x28 = n3*x3;
    double x29 = x21*x23 + x28;
    double x30 = x21*x22 + x24*x26 - x24*x27 + x29;
    double x31 = x18 + x30;
    double x32 = T >= 5.0;
    double x33 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x34 = 24.943387854459719*n2;
    double x35 = -x34*x8;
    double x36 = 3*(*endmember[0].dmu0dT)(T, P);
    double x37 = n1*x8;
    double x38 = 24.943387854459719*log(x37);
    double x39 = 24.943387854459719*x1;
    double x40 = x10*x39;
    double x41 = 24.943387854459719*log(x0*x8);
    double x42 = n3*x8;
    double x43 = 24.943387854459719*n1 + x34;
    double x44 = x21*x43;
    double x45 = x1*x44 + x41 - 49.886775708919437*x42;
    double x46 = x35 + x36 + x38 + x40 + x45;
    double x47 = x33*x46;
    double x48 = 49.886775708919437*x2;
    double x49 = -x48;
    double x50 = 49.886775708919437*x6;
    double x51 = x2*x34;
    double x52 = 24.943387854459719*x9;
    double x53 = x51 - x52;
    double x54 = 24.943387854459719*x8;
    double x55 = 49.886775708919437*x1;
    double x56 = x1*x43;
    double x57 = n3*x48;
    double x58 = x44 + x57;
    double x59 = x21*x55 + x26*x56 - x27*x56 + x58;
    double x60 = x54 + x59;
    double x61 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x62 = x33*x61;
    double x63 = 0.66666666666666663*x61;
    double x64 = 0.38999999999999996*n3 + x0;
    double x65 = pow(x64, -2);
    double x66 = x46*x65;
    double x67 = 3*(*endmember[1].dmu0dT)(T, P);
    double x68 = 3*(*endmember[2].dmu0dT)(T, P);
    double x69 = log(n2*x8);
    double x70 = 49.886775708919437*log(x42);
    double x71 = sqrt(1 - 0.19999999999999998*T);
    double x72 = 1.0*x71;
    double x73 = fmin(4, x72);
    double x74 = (4 - x72 >= 0. ? 1. : 0.)/x71;
    double x75 = -20.072025*((x73)*(x73))*x74 + 40.14405*x73 - 0.099999999999999992*x74*(40.14405*T - 200.72024999999999) - 40.14405;
    double x76 = n1*x36 + n1*x38 + n2*x67 + n2*x75 + n3*x68 + n3*x70 + x0*x41 + x34*x69;
    double x77 = x65*x76;
    double x78 = x76/((x64)*(x64)*(x64));
    double x79 = x63*x78 - 0.66666666666666663*x77;
    double x80 = -8.3144626181532395*x2;
    double x81 = x1*(x7 + x80) + x17;
    double x82 = -24.943387854459719*x37;
    double x83 = -n2*x2 + x8;
    double x84 = x39*x83;
    double x85 = x45 + x67 + 24.943387854459719*x69 + x75 + x82 + x84;
    double x86 = 1.0*x33;
    double x87 = -x54;
    double x88 = -24.943387854459719*x2;
    double x89 = x1*(x50 + x88) + x53;
    double x90 = 0.33333333333333331*x61;
    double x91 = x65*x90;
    double x92 = x19*(-x2 + x25);
    double x93 = x24*x92 + x29 + x87;
    double x94 = x56*x92 + x58 - 74.830163563379159*x8;
    double x95 = 0.12999999999999998*x61;
    double x96 = -n3*x2 + x8;
    double x97 = x55*x96;
    double x98 = x35 - x43*x8 + x68 + x70 + x82 + x97;
    double x99 = x61*x78;
    double x100 = -0.26000000000000001*x77 + x86*x98 - x91*x98 + 0.25999999999999995*x99;
    double x101 = n2*x5;
    double x102 = 16.628925236306479*x101;
    double x103 = 1.0/n2;
    double x104 = -x14 + x16;
    double x105 = x33*x85;
    double x106 = 49.886775708919437*x101;
    double x107 = -x51 + x52;
    double x108 = x65*x85;
    double x109 = n3*x5;
    double x110 = 1.0/n3;

if (x32) {
   result[0] = x1*(x4 + x7) + x10*x11*x12 + x17 + x31;
}
else {
   result[0] = 2.0*x47 + x62*(x1*(x49 + x50) + x11*x40 + x53 + x60) - x63*x66 + x79;
}
if (x32) {
   result[1] = -x18 + x30 + x81;
}
else {
   result[1] = 1.0*x47 + x62*(x59 + x87 + x89) - x66*x90 + x79 + x85*x86 - x85*x91;
}
if (x32) {
   result[2] = x81 + x93;
}
else {
   result[2] = x100 + 0.39000000000000001*x47 + x62*(x89 + x94) - x66*x95;
}
if (x32) {
   result[3] = x1*(x102 + x4) + x103*x12*x83 + x104 + x31;
}
else {
   result[3] = 2.0*x105 - x108*x63 + x62*(x1*(x106 + x49) + x103*x84 + x107 + x60) + x79;
}
if (x32) {
   result[4] = x1*(x102 + x80) + x104 + x93;
}
else {
   result[4] = x100 + 0.39000000000000001*x105 - x108*x95 + x62*(x1*(x106 + x88) + x107 + x94);
}
if (x32) {
   result[5] = x1*(33.257850472612958*x109 - 33.257850472612958*x2) + x110*x22*x96 + x14 + x16 + x2*x23 - x28 + 16.628925236306479*x8;
}
else {
   result[5] = 0.78000000000000003*x33*x98 - 0.25999999999999995*x61*x65*x98 + x62*(x1*(99.773551417838874*x109 - 99.773551417838874*x2) + x110*x97 + x2*x43 + x51 + x52 - x57 + 49.886775708919437*x8) - 0.10139999999999999*x77 + 0.10139999999999998*x99;
}
}
        
static void coder_d4gdn3dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = pow(x1, -3);
    double x3 = 49.886775708919437*x2;
    double x4 = pow(x1, -4);
    double x5 = n1*x4;
    double x6 = -49.886775708919437*x5;
    double x7 = 8.3144626181532395*x1;
    double x8 = 1.0/n1;
    double x9 = pow(x1, -2);
    double x10 = -2*x9;
    double x11 = 2*x2;
    double x12 = n1*x11;
    double x13 = x8*(x10 + x12);
    double x14 = 1.0/x1;
    double x15 = n1*x9;
    double x16 = x14 - x15;
    double x17 = pow(n1, -2);
    double x18 = x16*x8;
    double x19 = 33.257850472612958*x2;
    double x20 = 16.628925236306479*x2;
    double x21 = -n2*x20;
    double x22 = -n3*x19;
    double x23 = n1*x19 + x21 + x22;
    double x24 = 8.3144626181532395*x18 + x23;
    double x25 = 33.257850472612958*x9;
    double x26 = 1.0/x0;
    double x27 = -x0*x9 + x14;
    double x28 = x26*x27;
    double x29 = 8.3144626181532395*n1 + 8.3144626181532395*n2;
    double x30 = pow(x0, -2);
    double x31 = x27*x30;
    double x32 = x29*x31;
    double x33 = x0*x11;
    double x34 = x10 + x33;
    double x35 = x26*x29;
    double x36 = x34*x35;
    double x37 = 24.943387854459719*x1;
    double x38 = x26*x34;
    double x39 = -6*x0*x4;
    double x40 = x1*(6*x2 + x39);
    double x41 = 2*x1;
    double x42 = x29*x41;
    double x43 = x30*x34;
    double x44 = x27/((x0)*(x0)*(x0));
    double x45 = 24.943387854459719*x28 - x31*x37 - 2*x32 + x35*x40 + 2*x36 + x37*x38 - x42*x43 + x42*x44;
    double x46 = -x25 + x45;
    double x47 = T >= 5.0;
    double x48 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x49 = 49.886775708919437*x9;
    double x50 = -x49;
    double x51 = n1*x3;
    double x52 = 24.943387854459719*n2;
    double x53 = x52*x9;
    double x54 = 24.943387854459719*x15;
    double x55 = x53 - x54;
    double x56 = 24.943387854459719*x14;
    double x57 = 49.886775708919437*x28;
    double x58 = 24.943387854459719*n1;
    double x59 = x52 + x58;
    double x60 = x26*x59;
    double x61 = x34*x60;
    double x62 = x31*x59;
    double x63 = n3*x49;
    double x64 = x28*x59;
    double x65 = x63 + x64;
    double x66 = x1*x57 + x1*x61 - x1*x62 + x65;
    double x67 = x56 + x66;
    double x68 = x1*(x50 + x51) + x18*x37 + x55 + x67;
    double x69 = x48*x68;
    double x70 = 0.38999999999999996*n3 + x0;
    double x71 = pow(x70, -2);
    double x72 = n2*x14;
    double x73 = -24.943387854459719*x72;
    double x74 = 3*(*endmember[0].dmu0dT)(T, P);
    double x75 = n1*x14;
    double x76 = log(x75);
    double x77 = x16*x37;
    double x78 = 24.943387854459719*log(x0*x14);
    double x79 = n3*x14;
    double x80 = x1*x64 + x78 - 49.886775708919437*x79;
    double x81 = x73 + x74 + 24.943387854459719*x76 + x77 + x80;
    double x82 = x71*x81;
    double x83 = 149.66032712675832*x2;
    double x84 = -149.66032712675832*x5;
    double x85 = 99.773551417838874*x2;
    double x86 = n2*x3;
    double x87 = -x86;
    double x88 = n3*x85;
    double x89 = -x88;
    double x90 = n1*x85 + x87 + x89;
    double x91 = 24.943387854459719*x18 + x90;
    double x92 = -99.773551417838874*x9;
    double x93 = 74.830163563379159*x1;
    double x94 = x41*x59;
    double x95 = 74.830163563379159*x28 - x31*x93 + x38*x93 + x40*x60 - x43*x94 + x44*x94 + 2*x61 - 2*x62;
    double x96 = x92 + x95;
    double x97 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x98 = x48*x97;
    double x99 = 2.0*x97;
    double x100 = pow(x70, -3);
    double x101 = x100*x81;
    double x102 = x71*x97;
    double x103 = x102*x68;
    double x104 = 3*(*endmember[1].dmu0dT)(T, P);
    double x105 = 3*(*endmember[2].dmu0dT)(T, P);
    double x106 = log(x72);
    double x107 = 49.886775708919437*log(x79);
    double x108 = sqrt(1 - 0.19999999999999998*T);
    double x109 = 1.0*x108;
    double x110 = fmin(4, x109);
    double x111 = (4 - x109 >= 0. ? 1. : 0.)/x108;
    double x112 = -20.072025*((x110)*(x110))*x111 + 40.14405*x110 - 0.099999999999999992*x111*(40.14405*T - 200.72024999999999) - 40.14405;
    double x113 = n1*x74 + n2*x104 + n2*x112 + n3*x105 + n3*x107 + x0*x78 + x106*x52 + x58*x76;
    double x114 = x100*x113;
    double x115 = x113/((x70)*(x70)*(x70)*(x70));
    double x116 = 2.0*x114 - x115*x99;
    double x117 = 16.628925236306479*x9;
    double x118 = -x9;
    double x119 = x8*(x118 + x12);
    double x120 = x1*(x19 + x6) + x119*x7 + x24;
    double x121 = -24.943387854459719*x75;
    double x122 = -n2*x9 + x14;
    double x123 = x122*x37;
    double x124 = x104 + 24.943387854459719*x106 + x112 + x121 + x123 + x80;
    double x125 = 0.66666666666666663*x71;
    double x126 = x1*(x84 + x85) + x119*x37 + x91;
    double x127 = 0.66666666666666663*x97;
    double x128 = x100*x124;
    double x129 = x101*x97;
    double x130 = 24.943387854459719*x9;
    double x131 = -x130;
    double x132 = x1*(x131 + x51) + x55;
    double x133 = x132 - x56 + x66;
    double x134 = 2.0*x48;
    double x135 = x125*x97;
    double x136 = x116 + x133*x134 - x133*x135;
    double x137 = 8.3144626181532395*x9;
    double x138 = x118 + x33;
    double x139 = x138*x35;
    double x140 = x1*x138;
    double x141 = x140*x26;
    double x142 = x1*(4*x2 + x39);
    double x143 = x140*x30;
    double x144 = x139 + 16.628925236306479*x141 + x142*x35 - x143*x29 + 16.628925236306479*x28 - x32 + x36;
    double x145 = -x137 + x144;
    double x146 = x138*x60;
    double x147 = x1*x146 - 74.830163563379159*x14 + x65;
    double x148 = x132 + x147;
    double x149 = 49.886775708919437*x141 + x142*x60 - x143*x59 + x146 + x57 + x61 - x62;
    double x150 = x149 - 24.943387854459722*x9;
    double x151 = -n3*x9 + x14;
    double x152 = 49.886775708919437*x151;
    double x153 = x1*x152;
    double x154 = x105 + x107 + x121 - x14*x59 + x153 + x73;
    double x155 = x100*x154;
    double x156 = x115*x97;
    double x157 = 0.77999999999999992*x114 - x125*x154 + x127*x155 - 0.77999999999999992*x156;
    double x158 = x1*(x20 + x6) + x23;
    double x159 = 1.0/n2;
    double x160 = -x53 + x54;
    double x161 = x1*(x50 + x86) + x123*x159 + x160 + x67;
    double x162 = 1.0*x48;
    double x163 = x124*x71;
    double x164 = x1*(x3 + x84) + x90;
    double x165 = x128*x97;
    double x166 = 0.33333333333333331*x102;
    double x167 = x1*(x131 + x86) + x147 + x160;
    double x168 = 0.39000000000000001*x48;
    double x169 = 0.12999999999999998*x102;
    double x170 = x1*(x11 + x39);
    double x171 = 2*x139 + x170*x35 + x25;
    double x172 = 0.78000000000000003*x48;
    double x173 = 2*x146 + x170*x60 + 99.773551417838888*x9;
    double x174 = 0.25999999999999995*x102;
    double x175 = 1.0/n3;
    double x176 = x1*(x88 + x92) + 49.886775708919437*x14 + x153*x175 + x53 + x54 + x59*x9 - x63;
    double x177 = x154*x71;
    double x178 = x155*x97;
    double x179 = 0.30419999999999997*x114 - 0.30419999999999991*x156 + x162*x176 - x166*x176 - 0.52000000000000002*x177 + 0.51999999999999991*x178;
    double x180 = n2*x4;
    double x181 = -49.886775708919437*x180;
    double x182 = n2*x11;
    double x183 = x159*(x10 + x182);
    double x184 = pow(n2, -2);
    double x185 = x122*x159;
    double x186 = -n1*x20;
    double x187 = n2*x19 + x186 + x22;
    double x188 = 8.3144626181532395*x185 + x187;
    double x189 = -149.66032712675832*x180;
    double x190 = -x51;
    double x191 = n2*x85 + x190 + x89;
    double x192 = 24.943387854459719*x185 + x191;
    double x193 = x159*(x118 + x182);
    double x194 = n3*x2;
    double x195 = 16.628925236306479*x175;
    double x196 = n3*x4;
    double x197 = pow(n3, -2);
    double x198 = x1*(n3*x11 + x10);

if (x47) {
   result[0] = x1*(x3 + x6) + x13*x7 - x16*x17*x7 + x24 + x46;
}
else {
   result[0] = x101*x99 - 1.0*x103 + x116 + 3.0*x69 - 2.0*x82 + x98*(x1*(x83 + x84) + x13*x37 - x17*x77 + x91 + x96);
}
if (x47) {
   result[1] = -x117 + x120 + x45;
}
else {
   result[1] = -0.33333333333333331*x103 - x124*x125 + x127*x128 + 1.3333333333333333*x129 + x136 + 1.0*x69 - 1.3333333333333333*x82 + x98*(x126 - 49.886775708919444*x9 + x95);
}
if (x47) {
   result[2] = x120 + x145;
}
else {
   result[2] = -0.12999999999999998*x103 + 0.51999999999999991*x129 + x134*x148 - x135*x148 + x157 + 0.39000000000000001*x69 - 0.52000000000000002*x82 + x98*(x126 + x150);
}
if (x47) {
   result[3] = x137 + x158 + x45;
}
else {
   result[3] = x101*x127 + x136 + x161*x162 - x161*x166 - 1.3333333333333333*x163 + 1.3333333333333333*x165 - 0.66666666666666663*x82 + x98*(x130 + x164 + x95);
}
if (x47) {
   result[4] = x117 + x144 + x158;
}
else {
   result[4] = 0.25999999999999995*x129 + x133*x168 - x133*x169 + x148*x162 - x148*x166 + x157 + x162*x167 - 0.26000000000000001*x163 + 0.25999999999999995*x165 - x166*x167 - 0.26000000000000001*x82 + x98*(x149 + x164 + x49);
}
if (x47) {
   result[5] = x158 + x171;
}
else {
   result[5] = 0.10139999999999998*x129 + x148*x172 - x148*x174 + x179 - 0.10139999999999999*x82 + x98*(x164 + x173);
}
if (x47) {
   result[6] = x1*(x181 + x3) - x122*x184*x7 + x183*x7 + x188 + x46;
}
else {
   result[6] = -1.0*x102*x161 + x116 + x128*x99 + 3.0*x161*x48 - 2.0*x163 + x98*(x1*(x189 + x83) - x123*x184 + x183*x37 + x192 + x96);
}
if (x47) {
   result[7] = x1*(x181 + x19) + x145 + x188 + x193*x7;
}
else {
   result[7] = x134*x167 - x135*x167 + x157 + x161*x168 - x161*x169 - 0.52000000000000002*x163 + 0.51999999999999991*x165 + x98*(x1*(x189 + x85) + x150 + x192 + x193*x37);
}
if (x47) {
   result[8] = x1*(x181 + x20) + x171 + x187;
}
else {
   result[8] = -0.10139999999999999*x163 + 0.10139999999999998*x165 + x167*x172 - x167*x174 + x179 + x98*(x1*(x189 + x3) + x173 + x191);
}
if (x47) {
   result[9] = -16.628925236306479*x1*x151*x197 + x1*(-99.773551417838874*x196 + x85) - x11*x29 + x151*x195 + x186 + 66.515700945225916*x194 + x195*x198 + x21 - 66.515700945225916*x9;
}
else {
   result[9] = -0.3899999999999999*x102*x176 + 0.11863799999999997*x114 - 0.11863799999999997*x156 + 1.1699999999999999*x176*x48 - 0.30419999999999997*x177 + 0.30419999999999991*x178 + x98*(x1*(-299.32065425351664*x196 + 299.32065425351664*x2) - x11*x59 + x152*x175 - x153*x197 + 49.886775708919437*x175*x198 + x190 + 199.54710283567775*x194 + x87 - 199.54710283567775*x9);
}
}
        
static double coder_dgdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].dmu0dP)(T, P);
    double x1 = n2*(*endmember[1].dmu0dP)(T, P);
    double x2 = n3*(*endmember[2].dmu0dP)(T, P);

if (T >= 5.0) {
   result = x0 + x1 + x2;
}
else {
   result = (1.0*n1 + 1.0*n2 + 0.39000000000000001*n3)*(3*x0 + 3*x1 + 3*x2)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = T >= 5.0;
    double x2 = 3*x0;
    double x3 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x4 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x5 = x3*x4;
    double x6 = (*endmember[1].dmu0dP)(T, P);
    double x7 = 3*x6;
    double x8 = (*endmember[2].dmu0dP)(T, P);
    double x9 = 3*x8;
    double x10 = n1*x2 + n2*x7 + n3*x9;
    double x11 = x10*x3;
    double x12 = x10*x4/((n1 + n2 + 0.38999999999999996*n3)*(n1 + n2 + 0.38999999999999996*n3));
    double x13 = 1.0*x11 - 0.33333333333333331*x12;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x13 + x2*x5;
}
if (x1) {
   result[1] = x6;
}
else {
   result[1] = x13 + x5*x7;
}
if (x1) {
   result[2] = x8;
}
else {
   result[2] = 0.39000000000000001*x11 - 0.12999999999999998*x12 + x5*x9;
}
}
        
static void coder_d3gdn2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x2 = (*endmember[0].dmu0dP)(T, P);
    double x3 = x1*x2;
    double x4 = n1 + n2 + 0.38999999999999996*n3;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x7 = x5*x6;
    double x8 = x2*x7;
    double x9 = (*endmember[1].dmu0dP)(T, P);
    double x10 = (*endmember[2].dmu0dP)(T, P);
    double x11 = 3*n1*x2 + 3*n2*x9 + 3*n3*x10;
    double x12 = x11*x5;
    double x13 = x11*x6/((x4)*(x4)*(x4));
    double x14 = -0.66666666666666663*x12 + 0.66666666666666663*x13;
    double x15 = 3.0*x1;
    double x16 = 1.0*x7;
    double x17 = x10*x15 - x10*x16 - 0.26000000000000001*x12 + 0.25999999999999995*x13;
    double x18 = x1*x9;
    double x19 = x7*x9;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x14 + 6.0*x3 - 2.0*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x14 + x15*x9 - x16*x9 + 3.0*x3 - 1.0*x8;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 + 1.1699999999999999*x3 - 0.38999999999999996*x8;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x14 + 6.0*x18 - 2.0*x19;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 + 1.1699999999999999*x18 - 0.38999999999999996*x19;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 2.3399999999999999*x1*x10 - 0.7799999999999998*x10*x7 - 0.10139999999999999*x12 + 0.10139999999999998*x13;
}
}
        
static void coder_d4gdn3dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].dmu0dP)(T, P);
    double x2 = n1 + n2 + 0.38999999999999996*n3;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = pow(x2, -3);
    double x6 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = (*endmember[1].dmu0dP)(T, P);
    double x10 = (*endmember[2].dmu0dP)(T, P);
    double x11 = 3*n1*x1 + 3*n2*x9 + 3*n3*x10;
    double x12 = x11*x5;
    double x13 = x11*x6/((x2)*(x2)*(x2)*(x2));
    double x14 = 2.0*x12 - 2.0*x13;
    double x15 = 2.0*x3;
    double x16 = 2.0*x7;
    double x17 = -x10*x15 + x10*x16 + 0.77999999999999992*x12 - 0.77999999999999992*x13;
    double x18 = x3*x9;
    double x19 = x7*x9;
    double x20 = x10*x3;
    double x21 = x10*x7;
    double x22 = 0.30419999999999997*x12 - 0.30419999999999991*x13 - 1.5600000000000001*x20 + 1.5599999999999996*x21;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x14 - 6.0*x4 + 6.0*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x14 - x15*x9 + x16*x9 - 4.0*x4 + 4.0*x8;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 - 1.5600000000000001*x4 + 1.5599999999999998*x8;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x14 - 4.0*x18 + 4.0*x19 - 2.0*x4 + 2.0*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 - 0.78000000000000003*x18 + 0.77999999999999992*x19 - 0.78000000000000003*x4 + 0.77999999999999992*x8;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x22 - 0.30419999999999991*x4 + 0.30419999999999991*x8;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x14 - 6.0*x18 + 6.0*x19;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x17 - 1.5600000000000001*x18 + 1.5599999999999998*x19;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -0.30419999999999991*x18 + 0.30419999999999991*x19 + x22;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = 0.11863799999999997*x12 - 0.11863799999999997*x13 - 0.91259999999999974*x20 + 0.91259999999999974*x21;
}
}
        
static double coder_d2gdt2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dT2)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dT2)(T, P);
    double x3 = 0.19999999999999998*T;
    double x4 = 1 - x3;
    double x5 = sqrt(x4);
    double x6 = 1.0*x5;
    double x7 = (4 - x6 >= 0. ? 1. : 0.);
    double x8 = 0.40144049999999992*T - 2.0072024999999996;
    double x9 = 1.0/(x3 - 1);
    double x10 = x9*0;
    double x11 = x7/pow(x4, 3.0/2.0);
    double x12 = fmin(4, x6);
    double x13 = 2.0072025*((x12)*(x12));

if (T >= 5.0) {
   result = x0 + x1 + x2;
}
else {
   result = (1.0*n1 + 1.0*n2 + 0.39000000000000001*n3)*(-n2*(-x10*x13 - x10*x8 + x11*x13 + x11*x8 + 4.014405*x12*((x7)*(x7))*x9 + 8.02881*x7/x5) + 3*x0 + 3*x1 + 3*x2)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = T >= 5.0;
    double x2 = 3*x0;
    double x3 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x4 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x5 = x3*x4;
    double x6 = (*endmember[1].d2mu0dT2)(T, P);
    double x7 = 3*x6;
    double x8 = (*endmember[2].d2mu0dT2)(T, P);
    double x9 = 3*x8;
    double x10 = 0.19999999999999998*T;
    double x11 = 1 - x10;
    double x12 = sqrt(x11);
    double x13 = 1.0*x12;
    double x14 = (4 - x13 >= 0. ? 1. : 0.);
    double x15 = 8.02881*x14/x12;
    double x16 = 0.40144049999999992*T - 2.0072024999999996;
    double x17 = 1.0/(x10 - 1);
    double x18 = x17*0;
    double x19 = x16*x18;
    double x20 = x14/pow(x11, 3.0/2.0);
    double x21 = x16*x20;
    double x22 = fmin(4, x13);
    double x23 = 2.0072025*((x22)*(x22));
    double x24 = x18*x23;
    double x25 = x20*x23;
    double x26 = 4.014405*((x14)*(x14))*x17*x22;
    double x27 = n1*x2 + n2*x7 - n2*(x15 - x19 + x21 - x24 + x25 + x26) + n3*x9;
    double x28 = x27*x3;
    double x29 = x27*x4/((n1 + n2 + 0.38999999999999996*n3)*(n1 + n2 + 0.38999999999999996*n3));
    double x30 = 1.0*x28 - 0.33333333333333331*x29;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x2*x5 + x30;
}
if (x1) {
   result[1] = x6;
}
else {
   result[1] = x30 + x5*(-x15 + x19 - x21 + x24 - x25 - x26 + x7);
}
if (x1) {
   result[2] = x8;
}
else {
   result[2] = 0.39000000000000001*x28 - 0.12999999999999998*x29 + x5*x9;
}
}
        
static void coder_d4gdn2dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x2 = (*endmember[0].d2mu0dT2)(T, P);
    double x3 = x1*x2;
    double x4 = n1 + n2 + 0.38999999999999996*n3;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x7 = x5*x6;
    double x8 = x2*x7;
    double x9 = 3*(*endmember[1].d2mu0dT2)(T, P);
    double x10 = (*endmember[2].d2mu0dT2)(T, P);
    double x11 = 0.19999999999999998*T;
    double x12 = 1 - x11;
    double x13 = sqrt(x12);
    double x14 = 1.0*x13;
    double x15 = (4 - x14 >= 0. ? 1. : 0.);
    double x16 = 8.02881*x15/x13;
    double x17 = 0.40144049999999992*T - 2.0072024999999996;
    double x18 = 1.0/(x11 - 1);
    double x19 = x18*0;
    double x20 = x17*x19;
    double x21 = x15/pow(x12, 3.0/2.0);
    double x22 = x17*x21;
    double x23 = fmin(4, x14);
    double x24 = 2.0072025*((x23)*(x23));
    double x25 = x19*x24;
    double x26 = x21*x24;
    double x27 = 4.014405*((x15)*(x15))*x18*x23;
    double x28 = 3*n1*x2 + n2*x9 - n2*(x16 - x20 + x22 - x25 + x26 + x27) + 3*n3*x10;
    double x29 = x28*x5;
    double x30 = 0.66666666666666663*x6;
    double x31 = x28/((x4)*(x4)*(x4));
    double x32 = -0.66666666666666663*x29 + x30*x31;
    double x33 = -x16 + x20 - x22 + x25 - x26 - x27 + x9;
    double x34 = x1*x33;
    double x35 = x33*x7;
    double x36 = x1*x10;
    double x37 = x31*x6;
    double x38 = x10*x7;
    double x39 = -0.26000000000000001*x29 + 3.0*x36 + 0.25999999999999995*x37 - 1.0*x38;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 6.0*x3 + x32 - 2.0*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = 3.0*x3 + x32 + 1.0*x34 - 0.33333333333333331*x35 - 1.0*x8;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = 1.1699999999999999*x3 + x39 - 0.38999999999999996*x8;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = -x30*x33*x5 + x32 + 2.0*x34;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = 0.39000000000000001*x34 - 0.12999999999999998*x35 + x39;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = -0.10139999999999999*x29 + 2.3399999999999999*x36 + 0.10139999999999998*x37 - 0.7799999999999998*x38;
}
}
        
static void coder_d5gdn3dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dT2)(T, P);
    double x2 = n1 + n2 + 0.38999999999999996*n3;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = pow(x2, -3);
    double x6 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = 3*(*endmember[1].d2mu0dT2)(T, P);
    double x10 = (*endmember[2].d2mu0dT2)(T, P);
    double x11 = 0.19999999999999998*T;
    double x12 = 1 - x11;
    double x13 = sqrt(x12);
    double x14 = 1.0*x13;
    double x15 = (4 - x14 >= 0. ? 1. : 0.);
    double x16 = 8.02881*x15/x13;
    double x17 = 0.40144049999999992*T - 2.0072024999999996;
    double x18 = 1.0/(x11 - 1);
    double x19 = x18*0;
    double x20 = x17*x19;
    double x21 = x15/pow(x12, 3.0/2.0);
    double x22 = x17*x21;
    double x23 = fmin(4, x14);
    double x24 = 2.0072025*((x23)*(x23));
    double x25 = x19*x24;
    double x26 = x21*x24;
    double x27 = 4.014405*((x15)*(x15))*x18*x23;
    double x28 = 3*n1*x1 + n2*x9 - n2*(x16 - x20 + x22 - x25 + x26 + x27) + 3*n3*x10;
    double x29 = x28*x5;
    double x30 = x28*x6/((x2)*(x2)*(x2)*(x2));
    double x31 = 2.0*x29 - 2.0*x30;
    double x32 = -x16 + x20 - x22 + x25 - x26 - x27 + x9;
    double x33 = x3*x32;
    double x34 = x32*x7;
    double x35 = x10*x3;
    double x36 = x10*x7;
    double x37 = 0.77999999999999992*x29 - 0.77999999999999992*x30 - 2.0*x35 + 2.0*x36;
    double x38 = 0.30419999999999997*x29 - 0.30419999999999991*x30 - 1.5600000000000001*x35 + 1.5599999999999996*x36;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x31 - 6.0*x4 + 6.0*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x31 - 0.66666666666666663*x33 + 0.66666666666666663*x34 - 4.0*x4 + 4.0*x8;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x37 - 1.5600000000000001*x4 + 1.5599999999999998*x8;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x31 - 1.3333333333333333*x33 + 1.3333333333333333*x34 - 2.0*x4 + 2.0*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -0.26000000000000001*x33 + 0.25999999999999995*x34 + x37 - 0.78000000000000003*x4 + 0.77999999999999992*x8;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = x38 - 0.30419999999999991*x4 + 0.30419999999999991*x8;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x31 - 2.0*x33 + 2.0*x34;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = -0.52000000000000002*x33 + 0.51999999999999991*x34 + x37;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -0.10139999999999999*x33 + 0.10139999999999998*x34 + x38;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = 0.11863799999999997*x29 - 0.11863799999999997*x30 - 0.91259999999999974*x35 + 0.91259999999999974*x36;
}
}
        
static double coder_d2gdtdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P) + n3*(*endmember[2].d2mu0dTdP)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 0.39000000000000001*n3)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].d2mu0dTdP)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d2mu0dTdP)(T, P);
    double x6 = (*endmember[2].d2mu0dTdP)(T, P);
    double x7 = n1*x0 + n2*x5 + n3*x6;
    double x8 = x2*x7;
    double x9 = x3*x7/((n1 + n2 + 0.38999999999999996*n3)*(n1 + n2 + 0.38999999999999996*n3));
    double x10 = 3.0*x8 - 1.0*x9;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x10;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x10 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x4*x6 + 1.1699999999999999*x8 - 0.38999999999999996*x9;
}
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dTdP)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = x1*x2;
    double x4 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x5 = 2.0*x4;
    double x6 = n1 + n2 + 0.38999999999999996*n3;
    double x7 = pow(x6, -2);
    double x8 = x1*x7;
    double x9 = (*endmember[1].d2mu0dTdP)(T, P);
    double x10 = (*endmember[2].d2mu0dTdP)(T, P);
    double x11 = n1*x1 + n2*x9 + n3*x10;
    double x12 = x11*x7;
    double x13 = x11/((x6)*(x6)*(x6));
    double x14 = -2.0*x12 + x13*x5;
    double x15 = 3.0*x2;
    double x16 = 1.0*x4;
    double x17 = x16*x7;
    double x18 = 0.38999999999999996*x4;
    double x19 = x13*x4;
    double x20 = x10*x15 - x10*x17 - 0.78000000000000003*x12 + 0.77999999999999992*x19;
    double x21 = x2*x9;
    double x22 = x7*x9;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x14 + 6.0*x3 - x5*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x14 + x15*x9 - x16*x8 - x17*x9 + 3.0*x3;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = -x18*x8 + x20 + 1.1699999999999999*x3;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x14 + 6.0*x21 - x22*x5;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -x18*x22 + x20 + 1.1699999999999999*x21;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 2.3399999999999999*x10*x2 - 0.77999999999999992*x10*x4*x7 - 0.30419999999999991*x12 + 0.30419999999999991*x19;
}
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dTdP)(T, P);
    double x2 = n1 + n2 + 0.38999999999999996*n3;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x6 = 6.0*x5;
    double x7 = pow(x2, -3);
    double x8 = x1*x7;
    double x9 = (*endmember[1].d2mu0dTdP)(T, P);
    double x10 = (*endmember[2].d2mu0dTdP)(T, P);
    double x11 = n1*x1 + n2*x9 + n3*x10;
    double x12 = x11*x7;
    double x13 = x11/((x2)*(x2)*(x2)*(x2));
    double x14 = 6.0*x12 - x13*x6;
    double x15 = 2.0*x3;
    double x16 = 2.0*x5;
    double x17 = x7*x9;
    double x18 = x5*x8;
    double x19 = x10*x7;
    double x20 = x13*x5;
    double x21 = -x10*x15 + 2.3399999999999999*x12 + x16*x19 - 2.3399999999999999*x20;
    double x22 = x3*x9;
    double x23 = x17*x5;
    double x24 = x10*x3;
    double x25 = x19*x5;
    double x26 = 0.91259999999999986*x12 - 0.91259999999999986*x20 - 1.5600000000000001*x24 + 1.5599999999999998*x25;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x14 - 6.0*x4 + x6*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x14 - x15*x9 + x16*x17 + 4.0*x18 - 4.0*x4;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = 1.5599999999999998*x18 + x21 - 1.5600000000000001*x4;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x14 + x16*x8 - 4.0*x22 + 4.0*x23 - 2.0*x4;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = 0.77999999999999992*x18 + x21 - 0.78000000000000003*x22 + 0.77999999999999992*x23 - 0.78000000000000003*x4;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 0.30419999999999991*x18 + x26 - 0.30419999999999991*x4;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x14 + x17*x6 - 6.0*x22;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x21 - 1.5600000000000001*x22 + 1.5599999999999998*x23;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -0.30419999999999991*x22 + 0.30419999999999991*x23 + x26;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = 0.35591399999999984*x12 - 0.3559139999999999*x20 - 0.91259999999999986*x24 + 0.91259999999999974*x25;
}
}
        
static double coder_d2gdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P) + n3*(*endmember[2].d2mu0dP2)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 0.39000000000000001*n3)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].d2mu0dP2)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d2mu0dP2)(T, P);
    double x6 = (*endmember[2].d2mu0dP2)(T, P);
    double x7 = n1*x0 + n2*x5 + n3*x6;
    double x8 = x2*x7;
    double x9 = x3*x7/((n1 + n2 + 0.38999999999999996*n3)*(n1 + n2 + 0.38999999999999996*n3));
    double x10 = 3.0*x8 - 1.0*x9;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x10;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x10 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x4*x6 + 1.1699999999999999*x8 - 0.38999999999999996*x9;
}
}
        
static void coder_d4gdn2dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dP2)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = x1*x2;
    double x4 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x5 = 2.0*x4;
    double x6 = n1 + n2 + 0.38999999999999996*n3;
    double x7 = pow(x6, -2);
    double x8 = x1*x7;
    double x9 = (*endmember[1].d2mu0dP2)(T, P);
    double x10 = (*endmember[2].d2mu0dP2)(T, P);
    double x11 = n1*x1 + n2*x9 + n3*x10;
    double x12 = x11*x7;
    double x13 = x11/((x6)*(x6)*(x6));
    double x14 = -2.0*x12 + x13*x5;
    double x15 = 3.0*x2;
    double x16 = 1.0*x4;
    double x17 = x16*x7;
    double x18 = 0.38999999999999996*x4;
    double x19 = x13*x4;
    double x20 = x10*x15 - x10*x17 - 0.78000000000000003*x12 + 0.77999999999999992*x19;
    double x21 = x2*x9;
    double x22 = x7*x9;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x14 + 6.0*x3 - x5*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x14 + x15*x9 - x16*x8 - x17*x9 + 3.0*x3;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = -x18*x8 + x20 + 1.1699999999999999*x3;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x14 + 6.0*x21 - x22*x5;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -x18*x22 + x20 + 1.1699999999999999*x21;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 2.3399999999999999*x10*x2 - 0.77999999999999992*x10*x4*x7 - 0.30419999999999991*x12 + 0.30419999999999991*x19;
}
}
        
static void coder_d5gdn3dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dP2)(T, P);
    double x2 = n1 + n2 + 0.38999999999999996*n3;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x6 = 6.0*x5;
    double x7 = pow(x2, -3);
    double x8 = x1*x7;
    double x9 = (*endmember[1].d2mu0dP2)(T, P);
    double x10 = (*endmember[2].d2mu0dP2)(T, P);
    double x11 = n1*x1 + n2*x9 + n3*x10;
    double x12 = x11*x7;
    double x13 = x11/((x2)*(x2)*(x2)*(x2));
    double x14 = 6.0*x12 - x13*x6;
    double x15 = 2.0*x3;
    double x16 = 2.0*x5;
    double x17 = x7*x9;
    double x18 = x5*x8;
    double x19 = x10*x7;
    double x20 = x13*x5;
    double x21 = -x10*x15 + 2.3399999999999999*x12 + x16*x19 - 2.3399999999999999*x20;
    double x22 = x3*x9;
    double x23 = x17*x5;
    double x24 = x10*x3;
    double x25 = x19*x5;
    double x26 = 0.91259999999999986*x12 - 0.91259999999999986*x20 - 1.5600000000000001*x24 + 1.5599999999999998*x25;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x14 - 6.0*x4 + x6*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x14 - x15*x9 + x16*x17 + 4.0*x18 - 4.0*x4;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = 1.5599999999999998*x18 + x21 - 1.5600000000000001*x4;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x14 + x16*x8 - 4.0*x22 + 4.0*x23 - 2.0*x4;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = 0.77999999999999992*x18 + x21 - 0.78000000000000003*x22 + 0.77999999999999992*x23 - 0.78000000000000003*x4;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 0.30419999999999991*x18 + x26 - 0.30419999999999991*x4;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x14 + x17*x6 - 6.0*x22;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x21 - 1.5600000000000001*x22 + 1.5599999999999998*x23;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -0.30419999999999991*x22 + 0.30419999999999991*x23 + x26;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = 0.35591399999999984*x12 - 0.3559139999999999*x20 - 0.91259999999999986*x24 + 0.91259999999999974*x25;
}
}
        
static double coder_d3gdt3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT3)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dT3)(T, P);
    double x3 = 0.19999999999999998*T;
    double x4 = x3 - 1;
    double x5 = 1 - x3;
    double x6 = 1.0*sqrt(x5);
    double x7 = x6 - 4;
    double x8 = 0;
    double x9 = pow(x5, -3.0/2.0);
    double x10 = (4 - x6 >= 0. ? 1. : 0.);
    double x11 = 1.2043214999999998*x10*x9;
    double x12 = 40.14405*T - 200.72024999999999;
    double x13 = pow(x4, -2);
    double x14 = x13*x8;
    double x15 = x10/pow(x5, 5.0/2.0);
    double x16 = x9*0;
    double x17 = fmin(4, x6);
    double x18 = ((x17)*(x17));

if (T >= 5.0) {
   result = x0 + x1 + x2;
}
else {
   result = (1.0*n1 + 1.0*n2 + 0.39000000000000001*n3)*(-n2*(0.40144049999999998*((x10)*(x10)*(x10))*x9 - 1.2043214999999998*((x10)*(x10))*x13*x17 - x11*x17*x8 + x11 + 0.0029999999999999992*x12*x14 + 0.0029999999999999996*x12*x15 - 0.0009999999999999998*x12*x16 + 0.60216074999999991*x14*x18 + 0.60216075000000002*x15*x18 - 0.20072024999999999*x16*x18 - 1.2043214999999998*x8/x4) + 3*x0 + 3*x1 + 3*x2)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = T >= 5.0;
    double x2 = 3*x0;
    double x3 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x4 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x5 = x3*x4;
    double x6 = (*endmember[1].d3mu0dT3)(T, P);
    double x7 = 3*x6;
    double x8 = (*endmember[2].d3mu0dT3)(T, P);
    double x9 = 3*x8;
    double x10 = 0.19999999999999998*T;
    double x11 = x10 - 1;
    double x12 = 1 - x10;
    double x13 = 1.0*sqrt(x12);
    double x14 = x13 - 4;
    double x15 = 0;
    double x16 = 1.2043214999999998*x15/x11;
    double x17 = pow(x12, -3.0/2.0);
    double x18 = (4 - x13 >= 0. ? 1. : 0.);
    double x19 = 1.2043214999999998*x17*x18;
    double x20 = 0.40144049999999998*x17*((x18)*(x18)*(x18));
    double x21 = 40.14405*T - 200.72024999999999;
    double x22 = pow(x11, -2);
    double x23 = x15*x22;
    double x24 = 0.0029999999999999992*x21*x23;
    double x25 = x18/pow(x12, 5.0/2.0);
    double x26 = 0.0029999999999999996*x21*x25;
    double x27 = x17*0;
    double x28 = 0.0009999999999999998*x21*x27;
    double x29 = fmin(4, x13);
    double x30 = ((x29)*(x29));
    double x31 = 0.60216074999999991*x23*x30;
    double x32 = 0.60216075000000002*x25*x30;
    double x33 = 0.20072024999999999*x27*x30;
    double x34 = 1.2043214999999998*((x18)*(x18))*x22*x29;
    double x35 = x15*x19*x29;
    double x36 = n1*x2 + n2*x7 - n2*(-x16 + x19 + x20 + x24 + x26 - x28 + x31 + x32 - x33 - x34 - x35) + n3*x9;
    double x37 = x3*x36;
    double x38 = x36*x4/((n1 + n2 + 0.38999999999999996*n3)*(n1 + n2 + 0.38999999999999996*n3));
    double x39 = 1.0*x37 - 0.33333333333333331*x38;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x2*x5 + x39;
}
if (x1) {
   result[1] = x6;
}
else {
   result[1] = x39 + x5*(x16 - x19 - x20 - x24 - x26 + x28 - x31 - x32 + x33 + x34 + x35 + x7);
}
if (x1) {
   result[2] = x8;
}
else {
   result[2] = 0.39000000000000001*x37 - 0.12999999999999998*x38 + x5*x9;
}
}
        
static void coder_d5gdn2dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x2 = (*endmember[0].d3mu0dT3)(T, P);
    double x3 = x1*x2;
    double x4 = n1 + n2 + 0.38999999999999996*n3;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x7 = x5*x6;
    double x8 = x2*x7;
    double x9 = 3*(*endmember[1].d3mu0dT3)(T, P);
    double x10 = (*endmember[2].d3mu0dT3)(T, P);
    double x11 = 0.19999999999999998*T;
    double x12 = x11 - 1;
    double x13 = 1 - x11;
    double x14 = 1.0*sqrt(x13);
    double x15 = x14 - 4;
    double x16 = 0;
    double x17 = 1.2043214999999998*x16/x12;
    double x18 = pow(x13, -3.0/2.0);
    double x19 = (4 - x14 >= 0. ? 1. : 0.);
    double x20 = 1.2043214999999998*x18*x19;
    double x21 = 0.40144049999999998*x18*((x19)*(x19)*(x19));
    double x22 = 40.14405*T - 200.72024999999999;
    double x23 = pow(x12, -2);
    double x24 = x16*x23;
    double x25 = 0.0029999999999999992*x22*x24;
    double x26 = x19/pow(x13, 5.0/2.0);
    double x27 = 0.0029999999999999996*x22*x26;
    double x28 = x18*0;
    double x29 = 0.0009999999999999998*x22*x28;
    double x30 = fmin(4, x14);
    double x31 = ((x30)*(x30));
    double x32 = 0.60216074999999991*x24*x31;
    double x33 = 0.60216075000000002*x26*x31;
    double x34 = 0.20072024999999999*x28*x31;
    double x35 = 1.2043214999999998*((x19)*(x19))*x23*x30;
    double x36 = x16*x20*x30;
    double x37 = 3*n1*x2 + n2*x9 - n2*(-x17 + x20 + x21 + x25 + x27 - x29 + x32 + x33 - x34 - x35 - x36) + 3*n3*x10;
    double x38 = x37*x5;
    double x39 = 0.66666666666666663*x6;
    double x40 = x37/((x4)*(x4)*(x4));
    double x41 = -0.66666666666666663*x38 + x39*x40;
    double x42 = x17 - x20 - x21 - x25 - x27 + x29 - x32 - x33 + x34 + x35 + x36 + x9;
    double x43 = x1*x42;
    double x44 = x42*x7;
    double x45 = x1*x10;
    double x46 = x40*x6;
    double x47 = x10*x7;
    double x48 = -0.26000000000000001*x38 + 3.0*x45 + 0.25999999999999995*x46 - 1.0*x47;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 6.0*x3 + x41 - 2.0*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = 3.0*x3 + x41 + 1.0*x43 - 0.33333333333333331*x44 - 1.0*x8;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = 1.1699999999999999*x3 + x48 - 0.38999999999999996*x8;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = -x39*x42*x5 + x41 + 2.0*x43;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = 0.39000000000000001*x43 - 0.12999999999999998*x44 + x48;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = -0.10139999999999999*x38 + 2.3399999999999999*x45 + 0.10139999999999998*x46 - 0.7799999999999998*x47;
}
}
        
static void coder_d6gdn3dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dT3)(T, P);
    double x2 = n1 + n2 + 0.38999999999999996*n3;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = pow(x2, -3);
    double x6 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x7 = x5*x6;
    double x8 = x1*x7;
    double x9 = 3*(*endmember[1].d3mu0dT3)(T, P);
    double x10 = (*endmember[2].d3mu0dT3)(T, P);
    double x11 = 0.19999999999999998*T;
    double x12 = x11 - 1;
    double x13 = 1 - x11;
    double x14 = 1.0*sqrt(x13);
    double x15 = x14 - 4;
    double x16 = 0;
    double x17 = 1.2043214999999998*x16/x12;
    double x18 = pow(x13, -3.0/2.0);
    double x19 = (4 - x14 >= 0. ? 1. : 0.);
    double x20 = 1.2043214999999998*x18*x19;
    double x21 = 0.40144049999999998*x18*((x19)*(x19)*(x19));
    double x22 = 40.14405*T - 200.72024999999999;
    double x23 = pow(x12, -2);
    double x24 = x16*x23;
    double x25 = 0.0029999999999999992*x22*x24;
    double x26 = x19/pow(x13, 5.0/2.0);
    double x27 = 0.0029999999999999996*x22*x26;
    double x28 = x18*0;
    double x29 = 0.0009999999999999998*x22*x28;
    double x30 = fmin(4, x14);
    double x31 = ((x30)*(x30));
    double x32 = 0.60216074999999991*x24*x31;
    double x33 = 0.60216075000000002*x26*x31;
    double x34 = 0.20072024999999999*x28*x31;
    double x35 = 1.2043214999999998*((x19)*(x19))*x23*x30;
    double x36 = x16*x20*x30;
    double x37 = 3*n1*x1 + n2*x9 - n2*(-x17 + x20 + x21 + x25 + x27 - x29 + x32 + x33 - x34 - x35 - x36) + 3*n3*x10;
    double x38 = x37*x5;
    double x39 = x37*x6/((x2)*(x2)*(x2)*(x2));
    double x40 = 2.0*x38 - 2.0*x39;
    double x41 = x17 - x20 - x21 - x25 - x27 + x29 - x32 - x33 + x34 + x35 + x36 + x9;
    double x42 = x3*x41;
    double x43 = x41*x7;
    double x44 = x10*x3;
    double x45 = x10*x7;
    double x46 = 0.77999999999999992*x38 - 0.77999999999999992*x39 - 2.0*x44 + 2.0*x45;
    double x47 = 0.30419999999999997*x38 - 0.30419999999999991*x39 - 1.5600000000000001*x44 + 1.5599999999999996*x45;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = -6.0*x4 + x40 + 6.0*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = -4.0*x4 + x40 - 0.66666666666666663*x42 + 0.66666666666666663*x43 + 4.0*x8;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = -1.5600000000000001*x4 + x46 + 1.5599999999999998*x8;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = -2.0*x4 + x40 - 1.3333333333333333*x42 + 1.3333333333333333*x43 + 2.0*x8;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -0.78000000000000003*x4 - 0.26000000000000001*x42 + 0.25999999999999995*x43 + x46 + 0.77999999999999992*x8;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = -0.30419999999999991*x4 + x47 + 0.30419999999999991*x8;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x40 - 2.0*x42 + 2.0*x43;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = -0.52000000000000002*x42 + 0.51999999999999991*x43 + x46;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -0.10139999999999999*x42 + 0.10139999999999998*x43 + x47;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = 0.11863799999999997*x38 - 0.11863799999999997*x39 - 0.91259999999999974*x44 + 0.91259999999999974*x45;
}
}
        
static double coder_d3gdt2dp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P) + n3*(*endmember[2].d3mu0dT2dP)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 0.39000000000000001*n3)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d3mu0dT2dP)(T, P);
    double x6 = (*endmember[2].d3mu0dT2dP)(T, P);
    double x7 = n1*x0 + n2*x5 + n3*x6;
    double x8 = x2*x7;
    double x9 = x3*x7/((n1 + n2 + 0.38999999999999996*n3)*(n1 + n2 + 0.38999999999999996*n3));
    double x10 = 3.0*x8 - 1.0*x9;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x10;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x10 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x4*x6 + 1.1699999999999999*x8 - 0.38999999999999996*x9;
}
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = x1*x2;
    double x4 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x5 = 2.0*x4;
    double x6 = n1 + n2 + 0.38999999999999996*n3;
    double x7 = pow(x6, -2);
    double x8 = x1*x7;
    double x9 = (*endmember[1].d3mu0dT2dP)(T, P);
    double x10 = (*endmember[2].d3mu0dT2dP)(T, P);
    double x11 = n1*x1 + n2*x9 + n3*x10;
    double x12 = x11*x7;
    double x13 = x11/((x6)*(x6)*(x6));
    double x14 = -2.0*x12 + x13*x5;
    double x15 = 3.0*x2;
    double x16 = 1.0*x4;
    double x17 = x16*x7;
    double x18 = 0.38999999999999996*x4;
    double x19 = x13*x4;
    double x20 = x10*x15 - x10*x17 - 0.78000000000000003*x12 + 0.77999999999999992*x19;
    double x21 = x2*x9;
    double x22 = x7*x9;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x14 + 6.0*x3 - x5*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x14 + x15*x9 - x16*x8 - x17*x9 + 3.0*x3;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = -x18*x8 + x20 + 1.1699999999999999*x3;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x14 + 6.0*x21 - x22*x5;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -x18*x22 + x20 + 1.1699999999999999*x21;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 2.3399999999999999*x10*x2 - 0.77999999999999992*x10*x4*x7 - 0.30419999999999991*x12 + 0.30419999999999991*x19;
}
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x2 = n1 + n2 + 0.38999999999999996*n3;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x6 = 6.0*x5;
    double x7 = pow(x2, -3);
    double x8 = x1*x7;
    double x9 = (*endmember[1].d3mu0dT2dP)(T, P);
    double x10 = (*endmember[2].d3mu0dT2dP)(T, P);
    double x11 = n1*x1 + n2*x9 + n3*x10;
    double x12 = x11*x7;
    double x13 = x11/((x2)*(x2)*(x2)*(x2));
    double x14 = 6.0*x12 - x13*x6;
    double x15 = 2.0*x3;
    double x16 = 2.0*x5;
    double x17 = x7*x9;
    double x18 = x5*x8;
    double x19 = x10*x7;
    double x20 = x13*x5;
    double x21 = -x10*x15 + 2.3399999999999999*x12 + x16*x19 - 2.3399999999999999*x20;
    double x22 = x3*x9;
    double x23 = x17*x5;
    double x24 = x10*x3;
    double x25 = x19*x5;
    double x26 = 0.91259999999999986*x12 - 0.91259999999999986*x20 - 1.5600000000000001*x24 + 1.5599999999999998*x25;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x14 - 6.0*x4 + x6*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x14 - x15*x9 + x16*x17 + 4.0*x18 - 4.0*x4;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = 1.5599999999999998*x18 + x21 - 1.5600000000000001*x4;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x14 + x16*x8 - 4.0*x22 + 4.0*x23 - 2.0*x4;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = 0.77999999999999992*x18 + x21 - 0.78000000000000003*x22 + 0.77999999999999992*x23 - 0.78000000000000003*x4;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 0.30419999999999991*x18 + x26 - 0.30419999999999991*x4;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x14 + x17*x6 - 6.0*x22;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x21 - 1.5600000000000001*x22 + 1.5599999999999998*x23;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -0.30419999999999991*x22 + 0.30419999999999991*x23 + x26;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = 0.35591399999999984*x12 - 0.3559139999999999*x20 - 0.91259999999999986*x24 + 0.91259999999999974*x25;
}
}
        
static double coder_d3gdtdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P) + n3*(*endmember[2].d3mu0dTdP2)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 0.39000000000000001*n3)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d3mu0dTdP2)(T, P);
    double x6 = (*endmember[2].d3mu0dTdP2)(T, P);
    double x7 = n1*x0 + n2*x5 + n3*x6;
    double x8 = x2*x7;
    double x9 = x3*x7/((n1 + n2 + 0.38999999999999996*n3)*(n1 + n2 + 0.38999999999999996*n3));
    double x10 = 3.0*x8 - 1.0*x9;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x10;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x10 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x4*x6 + 1.1699999999999999*x8 - 0.38999999999999996*x9;
}
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = x1*x2;
    double x4 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x5 = 2.0*x4;
    double x6 = n1 + n2 + 0.38999999999999996*n3;
    double x7 = pow(x6, -2);
    double x8 = x1*x7;
    double x9 = (*endmember[1].d3mu0dTdP2)(T, P);
    double x10 = (*endmember[2].d3mu0dTdP2)(T, P);
    double x11 = n1*x1 + n2*x9 + n3*x10;
    double x12 = x11*x7;
    double x13 = x11/((x6)*(x6)*(x6));
    double x14 = -2.0*x12 + x13*x5;
    double x15 = 3.0*x2;
    double x16 = 1.0*x4;
    double x17 = x16*x7;
    double x18 = 0.38999999999999996*x4;
    double x19 = x13*x4;
    double x20 = x10*x15 - x10*x17 - 0.78000000000000003*x12 + 0.77999999999999992*x19;
    double x21 = x2*x9;
    double x22 = x7*x9;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x14 + 6.0*x3 - x5*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x14 + x15*x9 - x16*x8 - x17*x9 + 3.0*x3;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = -x18*x8 + x20 + 1.1699999999999999*x3;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x14 + 6.0*x21 - x22*x5;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -x18*x22 + x20 + 1.1699999999999999*x21;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 2.3399999999999999*x10*x2 - 0.77999999999999992*x10*x4*x7 - 0.30419999999999991*x12 + 0.30419999999999991*x19;
}
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x2 = n1 + n2 + 0.38999999999999996*n3;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x6 = 6.0*x5;
    double x7 = pow(x2, -3);
    double x8 = x1*x7;
    double x9 = (*endmember[1].d3mu0dTdP2)(T, P);
    double x10 = (*endmember[2].d3mu0dTdP2)(T, P);
    double x11 = n1*x1 + n2*x9 + n3*x10;
    double x12 = x11*x7;
    double x13 = x11/((x2)*(x2)*(x2)*(x2));
    double x14 = 6.0*x12 - x13*x6;
    double x15 = 2.0*x3;
    double x16 = 2.0*x5;
    double x17 = x7*x9;
    double x18 = x5*x8;
    double x19 = x10*x7;
    double x20 = x13*x5;
    double x21 = -x10*x15 + 2.3399999999999999*x12 + x16*x19 - 2.3399999999999999*x20;
    double x22 = x3*x9;
    double x23 = x17*x5;
    double x24 = x10*x3;
    double x25 = x19*x5;
    double x26 = 0.91259999999999986*x12 - 0.91259999999999986*x20 - 1.5600000000000001*x24 + 1.5599999999999998*x25;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x14 - 6.0*x4 + x6*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x14 - x15*x9 + x16*x17 + 4.0*x18 - 4.0*x4;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = 1.5599999999999998*x18 + x21 - 1.5600000000000001*x4;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x14 + x16*x8 - 4.0*x22 + 4.0*x23 - 2.0*x4;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = 0.77999999999999992*x18 + x21 - 0.78000000000000003*x22 + 0.77999999999999992*x23 - 0.78000000000000003*x4;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 0.30419999999999991*x18 + x26 - 0.30419999999999991*x4;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x14 + x17*x6 - 6.0*x22;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x21 - 1.5600000000000001*x22 + 1.5599999999999998*x23;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -0.30419999999999991*x22 + 0.30419999999999991*x23 + x26;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = 0.35591399999999984*x12 - 0.3559139999999999*x20 - 0.91259999999999986*x24 + 0.91259999999999974*x25;
}
}
        
static double coder_d3gdp3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P) + n3*(*endmember[2].d3mu0dP3)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 0.39000000000000001*n3)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].d3mu0dP3)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d3mu0dP3)(T, P);
    double x6 = (*endmember[2].d3mu0dP3)(T, P);
    double x7 = n1*x0 + n2*x5 + n3*x6;
    double x8 = x2*x7;
    double x9 = x3*x7/((n1 + n2 + 0.38999999999999996*n3)*(n1 + n2 + 0.38999999999999996*n3));
    double x10 = 3.0*x8 - 1.0*x9;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x10;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x10 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x4*x6 + 1.1699999999999999*x8 - 0.38999999999999996*x9;
}
}
        
static void coder_d5gdn2dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dP3)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = x1*x2;
    double x4 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x5 = 2.0*x4;
    double x6 = n1 + n2 + 0.38999999999999996*n3;
    double x7 = pow(x6, -2);
    double x8 = x1*x7;
    double x9 = (*endmember[1].d3mu0dP3)(T, P);
    double x10 = (*endmember[2].d3mu0dP3)(T, P);
    double x11 = n1*x1 + n2*x9 + n3*x10;
    double x12 = x11*x7;
    double x13 = x11/((x6)*(x6)*(x6));
    double x14 = -2.0*x12 + x13*x5;
    double x15 = 3.0*x2;
    double x16 = 1.0*x4;
    double x17 = x16*x7;
    double x18 = 0.38999999999999996*x4;
    double x19 = x13*x4;
    double x20 = x10*x15 - x10*x17 - 0.78000000000000003*x12 + 0.77999999999999992*x19;
    double x21 = x2*x9;
    double x22 = x7*x9;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x14 + 6.0*x3 - x5*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x14 + x15*x9 - x16*x8 - x17*x9 + 3.0*x3;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = -x18*x8 + x20 + 1.1699999999999999*x3;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x14 + 6.0*x21 - x22*x5;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -x18*x22 + x20 + 1.1699999999999999*x21;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 2.3399999999999999*x10*x2 - 0.77999999999999992*x10*x4*x7 - 0.30419999999999991*x12 + 0.30419999999999991*x19;
}
}
        
static void coder_d6gdn3dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dP3)(T, P);
    double x2 = n1 + n2 + 0.38999999999999996*n3;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x6 = 6.0*x5;
    double x7 = pow(x2, -3);
    double x8 = x1*x7;
    double x9 = (*endmember[1].d3mu0dP3)(T, P);
    double x10 = (*endmember[2].d3mu0dP3)(T, P);
    double x11 = n1*x1 + n2*x9 + n3*x10;
    double x12 = x11*x7;
    double x13 = x11/((x2)*(x2)*(x2)*(x2));
    double x14 = 6.0*x12 - x13*x6;
    double x15 = 2.0*x3;
    double x16 = 2.0*x5;
    double x17 = x7*x9;
    double x18 = x5*x8;
    double x19 = x10*x7;
    double x20 = x13*x5;
    double x21 = -x10*x15 + 2.3399999999999999*x12 + x16*x19 - 2.3399999999999999*x20;
    double x22 = x3*x9;
    double x23 = x17*x5;
    double x24 = x10*x3;
    double x25 = x19*x5;
    double x26 = 0.91259999999999986*x12 - 0.91259999999999986*x20 - 1.5600000000000001*x24 + 1.5599999999999998*x25;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x14 - 6.0*x4 + x6*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x14 - x15*x9 + x16*x17 + 4.0*x18 - 4.0*x4;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = 1.5599999999999998*x18 + x21 - 1.5600000000000001*x4;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x14 + x16*x8 - 4.0*x22 + 4.0*x23 - 2.0*x4;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = 0.77999999999999992*x18 + x21 - 0.78000000000000003*x22 + 0.77999999999999992*x23 - 0.78000000000000003*x4;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 0.30419999999999991*x18 + x26 - 0.30419999999999991*x4;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = x14 + x17*x6 - 6.0*x22;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = x21 - 1.5600000000000001*x22 + 1.5599999999999998*x23;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -0.30419999999999991*x22 + 0.30419999999999991*x23 + x26;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = 0.35591399999999984*x12 - 0.3559139999999999*x20 - 0.91259999999999986*x24 + 0.91259999999999974*x25;
}
}
        
static double coder_s(double T, double P, double n[3]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[3]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[3]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[3]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[3]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[3]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

