#include <math.h>


static double coder_g(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = 1.0*n1;
    double x1 = 1.0*n2;
    double x2 = 0.39000000000000001*n3 + x0 + x1;
    double x3 = n1*n2;
    double x4 = n1*(15846.000000000002*n2 - 27300.0*n3);
    double x5 = n1*(*endmember[0].mu0)(T, P);
    double x6 = n2*(*endmember[1].mu0)(T, P);
    double x7 = n3*(*endmember[2].mu0)(T, P);
    double x8 = n1 + n2;
    double x9 = 1.0/(n3 + x8);
    double x10 = T*(2.0*n3*log(n3*x9) + x0*log(n1*x9) + x1*log(n2*x9) + 1.0*x8*log(x8*x9));
    double x11 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));

if (T >= 5.0) {
   result = (9820.1438848920843*n1*n3 + x2*(-n2*(13.381349999999999*T - 44.604500000000002) + 8.3144626181532395*x10 + x5 + x6 + x7) - 5700.0*x3 - 0.35971223021582727*x4)/x2;
}
else {
   result = (29460.431654676253*n1*n3 + x2*(n2*(66.906750000000002*((x11)*(x11)*(x11)) + (40.14405*T - 200.72024999999999)*(x11 - 1) - 66.906750000000002) + 24.943387854459719*x10 + 3*x5 + 3*x6 + 3*x7) - 17100.0*x3 - 1.0791366906474817*x4)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 1.0*n1;
    double x1 = 1.0*n2;
    double x2 = 0.39000000000000001*n3;
    double x3 = x0 + x1 + x2;
    double x4 = n1*n2;
    double x5 = n1*(15846.000000000002*n2 - 27300.0*n3);
    double x6 = (*endmember[0].mu0)(T, P);
    double x7 = n1*x6;
    double x8 = (*endmember[1].mu0)(T, P);
    double x9 = n2*x8;
    double x10 = (*endmember[2].mu0)(T, P);
    double x11 = n3*x10;
    double x12 = 13.381349999999999*T;
    double x13 = x12 - 44.604500000000002;
    double x14 = n2*x13;
    double x15 = n1 + n2;
    double x16 = n3 + x15;
    double x17 = 1.0/x16;
    double x18 = log(n1*x17);
    double x19 = log(n2*x17);
    double x20 = n3*x17;
    double x21 = log(x20);
    double x22 = x15*x17;
    double x23 = 1.0*log(x22);
    double x24 = 2.0*n3*x21 + x0*x18 + x1*x19 + x15*x23;
    double x25 = 8.3144626181532395*T;
    double x26 = x24*x25;
    double x27 = (9820.1438848920843*n1*n3 + x3*(x11 - x14 + x26 + x7 + x9) - 5700.0*x4 - 0.35971223021582727*x5)/((x3)*(x3));
    double x28 = -1.0*x27;
    double x29 = 1.0/x3;
    double x30 = pow(x16, -2);
    double x31 = -x17;
    double x32 = 1.0*x16;
    double x33 = x1*x17;
    double x34 = -2.0*x20 + x23 + x32*(-x15*x30 - x31);
    double x35 = 1.0*x18 + x32*(-n1*x30 - x31) - x33 + x34;
    double x36 = x0*x6 - x1*x13 + x1*x8 + 1.0*x11 + x26;
    double x37 = T >= 5.0;
    double x38 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x39 = 66.906750000000002*((x38)*(x38)*(x38)) + (40.14405*T - 200.72024999999999)*(x38 - 1) - 66.906750000000002;
    double x40 = n2*x39;
    double x41 = 24.943387854459719*T;
    double x42 = x24*x41;
    double x43 = (29460.431654676253*n1*n3 + x3*(3*x11 + x40 + x42 + 3*x7 + 3*x9) - 17100.0*x4 - 1.0791366906474817*x5)/((0.38999999999999996*n3 + x15)*(0.38999999999999996*n3 + x15));
    double x44 = -0.33333333333333331*x43;
    double x45 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x46 = x1*x39 + 3.0*x11 + x42 + 3.0*x7 + 3.0*x9;
    double x47 = x0*x17;
    double x48 = 1.0*x19 + x32*(-n2*x30 - x31) + x34 - x47;
    double x49 = T*x24;
    double x50 = 2.0*x16*(-n3*x30 - x31) + 2.0*x21 - 1.0*x22 - x33 - x47;

if (x37) {
   result[0] = x28 + x29*(-11400.0*n2 + 19640.287769784169*n3 + x3*(x25*x35 + x6) + x36);
}
else {
   result[0] = x44 + x45*(-34200.0*n2 + 58920.863309352506*n3 + x3*(x35*x41 + 3*x6) + x46);
}
if (x37) {
   result[1] = x28 + x29*(-11400.0*n1 + x3*(-x12 + x25*x48 + x8 + 44.604500000000002) + x36);
}
else {
   result[1] = x44 + x45*(-34200.0*n1 + x3*(x39 + x41*x48 + 3*x8) + x46);
}
if (x37) {
   result[2] = -0.39000000000000001*x27 + x29*(19640.287769784169*n1 + x10*x2 - 0.39000000000000001*x14 + x3*(x10 + x25*x50) + 3.2426404210797637*x49 + 0.39000000000000001*x7 + 0.39000000000000001*x9);
}
else {
   result[2] = -0.12999999999999998*x43 + x45*(58920.863309352506*n1 + 1.1699999999999999*x11 + x3*(3*x10 + x41*x50) + 0.39000000000000001*x40 + 9.7279212632392902*x49 + 1.1699999999999999*x7 + 1.1699999999999999*x9);
}
}
        
static void coder_d2gdn2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 1.0*n1;
    double x1 = 1.0*n2;
    double x2 = 0.39000000000000001*n3;
    double x3 = x0 + x1 + x2;
    double x4 = n1*n2;
    double x5 = n1*(15846.000000000002*n2 - 27300.0*n3);
    double x6 = (*endmember[0].mu0)(T, P);
    double x7 = n1*x6;
    double x8 = (*endmember[1].mu0)(T, P);
    double x9 = n2*x8;
    double x10 = (*endmember[2].mu0)(T, P);
    double x11 = n3*x10;
    double x12 = 13.381349999999999*T;
    double x13 = x12 - 44.604500000000002;
    double x14 = n2*x13;
    double x15 = n1 + n2;
    double x16 = n3 + x15;
    double x17 = 1.0/x16;
    double x18 = log(n1*x17);
    double x19 = log(n2*x17);
    double x20 = log(n3*x17);
    double x21 = x15*x17;
    double x22 = 1.0*log(x21);
    double x23 = T*(2.0*n3*x20 + x0*x18 + x1*x19 + x15*x22);
    double x24 = 8.3144626181532395*x23;
    double x25 = (9820.1438848920843*n1*n3 + x3*(x11 - x14 + x24 + x7 + x9) - 5700.0*x4 - 0.35971223021582727*x5)/((x3)*(x3)*(x3));
    double x26 = 2.0*x25;
    double x27 = pow(x3, -2);
    double x28 = pow(x16, -2);
    double x29 = -x17;
    double x30 = 1.0*x16;
    double x31 = x30*(-n1*x28 - x29);
    double x32 = x1*x17;
    double x33 = x15*x28;
    double x34 = x30*(-x29 - x33);
    double x35 = 2.0*x17;
    double x36 = -n3*x35 + x22 + x34;
    double x37 = T*(1.0*x18 + x31 - x32 + x36);
    double x38 = 8.3144626181532395*x37;
    double x39 = x0*x6 - x1*x13 + x1*x8 + 1.0*x11 + x24;
    double x40 = x27*(-11400.0*n2 + 19640.287769784169*n3 + x3*(x38 + x6) + x39);
    double x41 = 1.0/x3;
    double x42 = x0*x28;
    double x43 = -x42;
    double x44 = -2*x28;
    double x45 = 2/((x16)*(x16)*(x16));
    double x46 = n1*x45;
    double x47 = x15*x45;
    double x48 = n3*x28;
    double x49 = 2.0*x48;
    double x50 = 1.0*x33;
    double x51 = x49 - x50;
    double x52 = x30*(x44 + x47) + x51 + x34/x15;
    double x53 = x1*x28;
    double x54 = x35 + x53;
    double x55 = T*x3;
    double x56 = x55*(x30*(x44 + x46) + x43 + x52 + x54 + x31/n1);
    double x57 = T >= 5.0;
    double x58 = 0.38999999999999996*n3 + x15;
    double x59 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x60 = ((x59)*(x59)*(x59));
    double x61 = 66.906750000000002*x60;
    double x62 = (40.14405*T - 200.72024999999999)*(x59 - 1);
    double x63 = x61 + x62 - 66.906750000000002;
    double x64 = n2*x63;
    double x65 = 24.943387854459719*x23;
    double x66 = (29460.431654676253*n1*n3 + x3*(3*x11 + x64 + x65 + 3*x7 + 3*x9) - 17100.0*x4 - 1.0791366906474817*x5)/((x58)*(x58)*(x58));
    double x67 = 0.66666666666666663*x66;
    double x68 = pow(x58, -2);
    double x69 = 24.943387854459719*x37;
    double x70 = x1*x63 + 3.0*x11 + x65 + 3.0*x7 + 3.0*x9;
    double x71 = x68*(-34200.0*n2 + 58920.863309352506*n3 + x3*(3*x6 + x69) + x70);
    double x72 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x73 = x30*(-n2*x28 - x29);
    double x74 = x0*x17;
    double x75 = T*(1.0*x19 + x36 + x73 - x74);
    double x76 = -x12 + 8.3144626181532395*x75;
    double x77 = -11400.0*n1 + x3*(x76 + x8 + 44.604500000000002) + x39;
    double x78 = 1.0*x27;
    double x79 = -x28;
    double x80 = x30*(x46 + x79) + x43 + x53;
    double x81 = x55*(x52 + x80);
    double x82 = 24.943387854459719*x75;
    double x83 = -34200.0*n1 + x3*(x63 + 3*x8 + x82) + x70;
    double x84 = 0.33333333333333331*x68;
    double x85 = x30*(x47 + x79) - x35 + x51;
    double x86 = x55*(x80 + x85);
    double x87 = -x29 - x48;
    double x88 = T*(2.0*x16*x87 + 2.0*x20 - 1.0*x21 - x32 - x74);
    double x89 = 8.3144626181532395*x88;
    double x90 = 1.0*x10 + x89;
    double x91 = 19640.287769784169*n1 + x10*x2 - 0.39000000000000001*x14 + 3.2426404210797637*x23 + x3*(x10 + x89) + 0.39000000000000001*x7 + 0.39000000000000001*x9;
    double x92 = 0.78000000000000003*x25 - x78*x91;
    double x93 = 24.943387854459719*x88;
    double x94 = 3.0*x10 + x93;
    double x95 = 58920.863309352506*n1 + 1.1699999999999999*x11 + 9.7279212632392902*x23 + x3*(3*x10 + x93) + 0.39000000000000001*x64 + 1.1699999999999999*x7 + 1.1699999999999999*x9;
    double x96 = 0.25999999999999995*x66 - x84*x95;
    double x97 = x27*x77;
    double x98 = n2*x45;
    double x99 = x42 - x53;
    double x100 = x55*(x30*(x44 + x98) + x35 + x52 + x99 + x73/n2);
    double x101 = x68*x83;
    double x102 = x55*(x30*(x79 + x98) + x85 + x99);
    double x103 = 2.0*x16;
    double x104 = x55*(x103*(n3*x45 + x44) + x42 - x49 + x50 + x54 + x103*x87/n3);

if (x57) {
   result[0] = x26 - 2.0*x40 + x41*(16.628925236306479*x37 + 8.3144626181532395*x56 + 2.0*x6);
}
else {
   result[0] = x67 - 0.66666666666666663*x71 + x72*(49.886775708919437*x37 + 24.943387854459719*x56 + 6.0*x6);
}
if (x57) {
   result[1] = x26 - 1.0*x40 + x41*(x38 + 1.0*x6 + x76 + 1.0*x8 + 8.3144626181532395*x81 - 11355.395500000001) - x77*x78;
}
else {
   result[1] = x67 - 0.33333333333333331*x71 + x72*(3.0*x6 + x61 + 1.0*x62 + x69 + 3.0*x8 + 24.943387854459719*x81 + x82 - 34266.906750000002) - x83*x84;
}
if (x57) {
   result[2] = -0.39000000000000001*x40 + x41*(3.2426404210797637*x37 + 0.39000000000000001*x6 + 8.3144626181532395*x86 + x90 + 19640.287769784169) + x92;
}
else {
   result[2] = -0.12999999999999998*x71 + x72*(9.7279212632392902*x37 + 1.1699999999999999*x6 + 24.943387854459719*x86 + x94 + 58920.863309352506) + x96;
}
if (x57) {
   result[3] = x26 + x41*(-26.762699999999999*T + 8.3144626181532395*x100 + 16.628925236306479*x75 + 2.0*x8 + 89.209000000000003) - 2.0*x97;
}
else {
   result[3] = -0.66666666666666663*x101 + x67 + x72*(24.943387854459719*x100 + 133.8135*x60 + 2.0*x62 + 49.886775708919437*x75 + 6.0*x8 - 133.8135);
}
if (x57) {
   result[4] = x41*(-5.2187264999999998*T + 8.3144626181532395*x102 + 3.2426404210797637*x75 + 0.39000000000000001*x8 + x90 + 17.395755000000001) + x92 - 0.39000000000000001*x97;
}
else {
   result[4] = -0.12999999999999998*x101 + x72*(24.943387854459719*x102 + 26.093632500000002*x60 + 0.39000000000000001*x62 + 9.7279212632392902*x75 + 1.1699999999999999*x8 + x94 - 26.093632500000002) + x96;
}
if (x57) {
   result[5] = 0.30420000000000003*x25 - 0.78000000000000003*x27*x91 + x41*(0.78000000000000003*x10 + 8.3144626181532395*x104 + 6.4852808421595274*x88);
}
else {
   result[5] = 0.10139999999999998*x66 - 0.25999999999999995*x68*x95 + x72*(2.3399999999999999*x10 + 24.943387854459719*x104 + 19.45584252647858*x88);
}
}
        
static void coder_d3gdn3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 1.0*n1;
    double x1 = 1.0*n2;
    double x2 = 0.39000000000000001*n3;
    double x3 = x0 + x1 + x2;
    double x4 = n1*n2;
    double x5 = n1*(15846.000000000002*n2 - 27300.0*n3);
    double x6 = (*endmember[0].mu0)(T, P);
    double x7 = n1*x6;
    double x8 = (*endmember[1].mu0)(T, P);
    double x9 = n2*x8;
    double x10 = (*endmember[2].mu0)(T, P);
    double x11 = n3*x10;
    double x12 = 13.381349999999999*T;
    double x13 = x12 - 44.604500000000002;
    double x14 = n2*x13;
    double x15 = n1 + n2;
    double x16 = n3 + x15;
    double x17 = 1.0/x16;
    double x18 = log(n1*x17);
    double x19 = log(n2*x17);
    double x20 = log(n3*x17);
    double x21 = x15*x17;
    double x22 = 1.0*log(x21);
    double x23 = 2.0*n3*x20 + x0*x18 + x1*x19 + x15*x22;
    double x24 = 8.3144626181532395*T;
    double x25 = x23*x24;
    double x26 = (9820.1438848920843*n1*n3 + x3*(x11 - x14 + x25 + x7 + x9) - 5700.0*x4 - 0.35971223021582727*x5)/((x3)*(x3)*(x3)*(x3));
    double x27 = -6.0*x26;
    double x28 = pow(x3, -3);
    double x29 = pow(x16, -2);
    double x30 = -x17;
    double x31 = -n1*x29 - x30;
    double x32 = 1.0*x16;
    double x33 = x31*x32;
    double x34 = x1*x17;
    double x35 = x15*x29;
    double x36 = -x30 - x35;
    double x37 = x32*x36;
    double x38 = 2.0*x17;
    double x39 = -n3*x38 + x22 + x37;
    double x40 = 1.0*x18 + x33 - x34 + x39;
    double x41 = x24*x40;
    double x42 = x0*x6 - x1*x13 + x1*x8 + 1.0*x11 + x25;
    double x43 = x28*(-11400.0*n2 + 19640.287769784169*n3 + x3*(x41 + x6) + x42);
    double x44 = pow(x3, -2);
    double x45 = T*x40;
    double x46 = x0*x29;
    double x47 = -x46;
    double x48 = -2*x29;
    double x49 = pow(x16, -3);
    double x50 = 2*x49;
    double x51 = n1*x50;
    double x52 = x32*(x48 + x51);
    double x53 = 1.0/n1;
    double x54 = x31*x53;
    double x55 = x15*x50;
    double x56 = x32*(x48 + x55);
    double x57 = 1.0/x15;
    double x58 = x36*x57;
    double x59 = n3*x29;
    double x60 = 2.0*x59;
    double x61 = 1.0*x35;
    double x62 = x60 - x61;
    double x63 = x32*x58 + x56 + x62;
    double x64 = x1*x29;
    double x65 = x38 + x64;
    double x66 = T*(x32*x54 + x47 + x52 + x63 + x65);
    double x67 = 8.3144626181532395*x66;
    double x68 = x44*(x3*x67 + 16.628925236306479*x45 + 2.0*x6);
    double x69 = 1.0/x3;
    double x70 = 24.943387854459719*x66;
    double x71 = -6*x49;
    double x72 = 6/((x16)*(x16)*(x16)*(x16));
    double x73 = n1*x72;
    double x74 = 4.0*x49;
    double x75 = 2.0*x49;
    double x76 = n2*x75;
    double x77 = n1*x74 - x76;
    double x78 = 1.0*x54 + x77;
    double x79 = 8.0*x29;
    double x80 = -n3*x74 + x15*x74;
    double x81 = 1.0*x58 + x80;
    double x82 = x15*x72;
    double x83 = x32*(-x71 - x82) + x56*x57 - x37/((x15)*(x15));
    double x84 = x81 + x83;
    double x85 = -x79 + x84;
    double x86 = x3*(x32*(-x71 - x73) + x52*x53 + x78 + x85 - x33/((n1)*(n1)));
    double x87 = T >= 5.0;
    double x88 = 0.38999999999999996*n3 + x15;
    double x89 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x90 = ((x89)*(x89)*(x89));
    double x91 = 66.906750000000002*x90;
    double x92 = (40.14405*T - 200.72024999999999)*(x89 - 1);
    double x93 = x91 + x92 - 66.906750000000002;
    double x94 = n2*x93;
    double x95 = 24.943387854459719*T;
    double x96 = x23*x95;
    double x97 = (29460.431654676253*n1*n3 + x3*(3*x11 + 3*x7 + 3*x9 + x94 + x96) - 17100.0*x4 - 1.0791366906474817*x5)/((x88)*(x88)*(x88)*(x88));
    double x98 = -2.0*x97;
    double x99 = pow(x88, -3);
    double x100 = 24.943387854459719*x45;
    double x101 = x1*x93 + 3.0*x11 + 3.0*x7 + 3.0*x9 + x96;
    double x102 = x99*(-34200.0*n2 + 58920.863309352506*n3 + x101 + x3*(x100 + 3*x6));
    double x103 = pow(x88, -2);
    double x104 = x103*(x3*x70 + 49.886775708919437*x45 + 6.0*x6);
    double x105 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x106 = -x29;
    double x107 = x32*(x106 + x51);
    double x108 = x107 + x47 + x64;
    double x109 = x108 + x63;
    double x110 = T*x109;
    double x111 = 16.628925236306479*x110;
    double x112 = -4*x49;
    double x113 = x107*x53 + x32*(-x112 - x73) + x78;
    double x114 = x113 - 6.0*x29 + x84;
    double x115 = x24*x3;
    double x116 = -n2*x29 - x30;
    double x117 = x116*x32;
    double x118 = x0*x17;
    double x119 = x117 - x118 + 1.0*x19 + x39;
    double x120 = x119*x24 - x12;
    double x121 = -11400.0*n1 + x3*(x120 + x8 + 44.604500000000002) + x42;
    double x122 = 2.0*x28;
    double x123 = x109*x115 + x120 + x41 + 1.0*x6 + 1.0*x8 - 11355.395500000001;
    double x124 = 2.0*x44;
    double x125 = -x123*x124 + x27;
    double x126 = 49.886775708919437*x110;
    double x127 = x3*x95;
    double x128 = x119*x95;
    double x129 = -34200.0*n1 + x101 + x3*(x128 + 3*x8 + x93);
    double x130 = 0.66666666666666663*x99;
    double x131 = x100 + x109*x127 + x128 + 3.0*x6 + 3.0*x8 + x91 + 1.0*x92 - 34266.906750000002;
    double x132 = 0.66666666666666663*x103;
    double x133 = -x131*x132 + x98;
    double x134 = x32*(x106 + x55);
    double x135 = x134 - x38 + x62;
    double x136 = x108 + x135;
    double x137 = T*x136;
    double x138 = x134*x57 + x32*(-x112 - x82);
    double x139 = x138 - 4.0*x29 + x81;
    double x140 = x113 + x139;
    double x141 = x136*x24;
    double x142 = -x30 - x59;
    double x143 = -x118 + 2.0*x142*x16 + 2.0*x20 - 1.0*x21 - x34;
    double x144 = x143*x24;
    double x145 = 1.0*x10 + x144;
    double x146 = x141*x3 + x145 + 3.2426404210797637*x45 + 0.39000000000000001*x6 + 19640.287769784169;
    double x147 = T*x23;
    double x148 = 19640.287769784169*n1 + x10*x2 - 0.39000000000000001*x14 + 3.2426404210797637*x147 + x3*(x10 + x144) + 0.39000000000000001*x7 + 0.39000000000000001*x9;
    double x149 = x122*x148 - 2.3399999999999999*x26;
    double x150 = x136*x95;
    double x151 = x143*x95;
    double x152 = 3.0*x10 + x151;
    double x153 = x150*x3 + x152 + 9.7279212632392902*x45 + 1.1699999999999999*x6 + 58920.863309352506;
    double x154 = 58920.863309352506*n1 + 1.1699999999999999*x11 + 9.7279212632392902*x147 + x3*(3*x10 + x151) + 1.1699999999999999*x7 + 1.1699999999999999*x9 + 0.39000000000000001*x94;
    double x155 = x130*x154 - 0.77999999999999992*x97;
    double x156 = n2*x50;
    double x157 = x32*(x156 + x48);
    double x158 = 1.0/n2;
    double x159 = x46 - x64;
    double x160 = x117*x158 + x157 + x159 + x38 + x63;
    double x161 = x160*x24;
    double x162 = -2*x49;
    double x163 = x32*(-x162 - x73) + x77;
    double x164 = x163 + x81;
    double x165 = x164 - 3.0*x29 + x83;
    double x166 = x121*x28;
    double x167 = T*x119;
    double x168 = -26.762699999999999*T + x161*x3 + 16.628925236306479*x167 + 2.0*x8 + 89.209000000000003;
    double x169 = 1.0*x44;
    double x170 = x160*x95;
    double x171 = x129*x99;
    double x172 = 49.886775708919437*x167 + x170*x3 + 6.0*x8 + 133.8135*x90 + 2.0*x92 - 133.8135;
    double x173 = 0.33333333333333331*x103;
    double x174 = x32*(x106 + x156);
    double x175 = x135 + x159 + x174;
    double x176 = x175*x24;
    double x177 = x138 + x164 - 1.0*x29;
    double x178 = -5.2187264999999998*T + x145 + 3.2426404210797637*x167 + x176*x3 + 0.39000000000000001*x8 + 17.395755000000001;
    double x179 = 0.39000000000000001*x44;
    double x180 = x175*x95;
    double x181 = 0.12999999999999998*x103;
    double x182 = x152 + 9.7279212632392902*x167 + x180*x3 + 1.1699999999999999*x8 + 26.093632500000002*x90 + 0.39000000000000001*x92 - 26.093632500000002;
    double x183 = n3*x50 + x48;
    double x184 = 2.0*x16;
    double x185 = 1.0/n3;
    double x186 = x142*x184;
    double x187 = x183*x184 + x185*x186 + x46 - x60 + x61 + x65;
    double x188 = x187*x24;
    double x189 = 2.0*x29 + x32*(-x162 - x82) + x80;
    double x190 = x163 + x189;
    double x191 = 0.78000000000000003*x44;
    double x192 = x148*x28;
    double x193 = T*x143;
    double x194 = 0.78000000000000003*x10 + x188*x3 + 6.4852808421595274*x193;
    double x195 = -x169*x194 + 1.5600000000000001*x192 - 0.91259999999999997*x26;
    double x196 = x187*x95;
    double x197 = 0.25999999999999995*x103;
    double x198 = x154*x99;
    double x199 = 2.3399999999999999*x10 + 19.45584252647858*x193 + x196*x3;
    double x200 = -x173*x199 + 0.51999999999999991*x198 - 0.30419999999999991*x97;
    double x201 = n2*x72;
    double x202 = n1*x75;
    double x203 = n2*x74 - x202;
    double x204 = 1.0*x116*x158 + x203;
    double x205 = x157*x158 + x204 + x32*(-x201 - x71) + x85 - x117/((n2)*(n2));
    double x206 = T*x160;
    double x207 = T*x175;
    double x208 = x139 + x158*x174 + x204 + x32*(-x112 - x201);
    double x209 = x189 + x203 + x32*(-x162 - x201);
    double x210 = T*x187;
    double x211 = 8.0*n3*x49 + 2.0*x142*x185 - x15*x75 + 2.0*x16*x183*x185 + 2.0*x16*(-n3*x72 - x71) - x202 - x76 - x79 - x186/((n3)*(n3));

if (x87) {
   result[0] = x27 + 6.0*x43 - 3.0*x68 + x69*(x24*x86 + x70);
}
else {
   result[0] = 2.0*x102 - 1.0*x104 + x105*(74.830163563379159*x66 + x86*x95) + x98;
}
if (x87) {
   result[1] = x121*x122 + x125 + 4.0*x43 - 1.0*x68 + x69*(x111 + x114*x115 + x67);
}
else {
   result[1] = 1.3333333333333333*x102 - 0.33333333333333331*x104 + x105*(x114*x127 + x126 + x70) + x129*x130 + x133;
}
if (x87) {
   result[2] = -x124*x146 + x149 + 1.5600000000000001*x43 - 0.39000000000000001*x68 + x69*(x115*x140 + 16.628925236306479*x137 + 3.2426404210797637*x66);
}
else {
   result[2] = 0.51999999999999991*x102 - 0.12999999999999998*x104 + x105*(x127*x140 + 49.886775708919437*x137 + 9.7279212632392902*x66) - x132*x153 + x155;
}
if (x87) {
   result[3] = x125 + 4.0*x166 - x168*x169 + 2.0*x43 + x69*(x111 + x115*x165 + x161);
}
else {
   result[3] = 0.66666666666666663*x102 + x105*(x126 + x127*x165 + x170) + x133 + 1.3333333333333333*x171 - x172*x173;
}
if (x87) {
   result[4] = -x123*x179 - x146*x169 + x149 + 0.78000000000000003*x166 - x169*x178 + 0.78000000000000003*x43 + x69*(3.2426404210797637*x110 + x115*x177 + x141 + x176);
}
else {
   result[4] = 0.25999999999999995*x102 + x105*(9.7279212632392902*x110 + x127*x177 + x150 + x180) - x131*x181 - x153*x173 + x155 + 0.25999999999999995*x171 - x173*x182;
}
if (x87) {
   result[5] = -x146*x191 + x195 + 0.30420000000000003*x43 + x69*(x115*x190 + 6.4852808421595274*x137 + x188);
}
else {
   result[5] = 0.10139999999999998*x102 + x105*(x127*x190 + 19.45584252647858*x137 + x196) - x153*x197 + x200;
}
if (x87) {
   result[6] = 6.0*x166 - 3.0*x168*x44 + x27 + x69*(x115*x205 + x170);
}
else {
   result[6] = -1.0*x103*x172 + x105*(x127*x205 + 74.830163563379159*x206) + 2.0*x171 + x98;
}
if (x87) {
   result[7] = -x124*x178 + x149 + 1.5600000000000001*x166 - x168*x179 + x69*(x115*x208 + 3.2426404210797637*x206 + 16.628925236306479*x207);
}
else {
   result[7] = x105*(x127*x208 + 9.7279212632392902*x206 + 49.886775708919437*x207) - x132*x182 + x155 + 0.51999999999999991*x171 - x172*x181;
}
if (x87) {
   result[8] = 0.30420000000000003*x166 - x178*x191 + x195 + x69*(x115*x209 + x188 + 6.4852808421595274*x207);
}
else {
   result[8] = x105*(x127*x209 + x196 + 19.45584252647858*x207) + 0.10139999999999998*x171 - x182*x197 + x200;
}
if (x87) {
   result[9] = 0.91260000000000008*x192 - 1.1699999999999999*x194*x44 - 0.35591400000000001*x26 + x69*(x115*x211 + 9.727921263239292*x210);
}
else {
   result[9] = -0.3899999999999999*x103*x199 + x105*(x127*x211 + 29.183763789717872*x210) + 0.30419999999999991*x198 - 0.11863799999999997*x97;
}
}
        
static double coder_dgdt(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].dmu0dT)(T, P);
    double x1 = n2*(*endmember[1].dmu0dT)(T, P);
    double x2 = n3*(*endmember[2].dmu0dT)(T, P);
    double x3 = n1 + n2;
    double x4 = 1.0/(n3 + x3);
    double x5 = n1*log(n1*x4);
    double x6 = n2*log(n2*x4);
    double x7 = n3*log(n3*x4);
    double x8 = x3*log(x3*x4);
    double x9 = sqrt(1 - 0.19999999999999998*T);
    double x10 = 1.0*x9;
    double x11 = fmin(4, x10);
    double x12 = (4 - x10 >= 0. ? 1. : 0.)/x9;

if (T >= 5.0) {
   result = -13.381349999999999*n2 + x0 + x1 + x2 + 8.3144626181532395*x5 + 8.3144626181532395*x6 + 16.628925236306479*x7 + 8.3144626181532395*x8;
}
else {
   result = (1.0*n1 + 1.0*n2 + 0.39000000000000001*n3)*(n2*(-20.072025*((x11)*(x11))*x12 + 40.14405*x11 - 0.099999999999999992*x12*(40.14405*T - 200.72024999999999) - 40.14405) + 3*x0 + 3*x1 + 3*x2 + 24.943387854459719*x5 + 24.943387854459719*x6 + 49.886775708919437*x7 + 24.943387854459719*x8)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = 1.0/x1;
    double x3 = n1*x2;
    double x4 = log(x3);
    double x5 = pow(x1, -2);
    double x6 = -x2;
    double x7 = -n1*x5 - x6;
    double x8 = 8.3144626181532395*x1;
    double x9 = n2*x2;
    double x10 = 8.3144626181532395*x9;
    double x11 = (*endmember[0].dmu0dT)(T, P);
    double x12 = x0*x2;
    double x13 = log(x12);
    double x14 = -x0*x5 - x6;
    double x15 = n3*x2;
    double x16 = 8.3144626181532395*x13 + x14*x8 - 16.628925236306479*x15;
    double x17 = T >= 5.0;
    double x18 = 3*x11;
    double x19 = 24.943387854459719*x4;
    double x20 = 24.943387854459719*x1;
    double x21 = 24.943387854459719*x9;
    double x22 = 24.943387854459719*x13;
    double x23 = x14*x20 - 49.886775708919437*x15 + x22;
    double x24 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x25 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x26 = x24*x25;
    double x27 = (*endmember[1].dmu0dT)(T, P);
    double x28 = 3*x27;
    double x29 = (*endmember[2].dmu0dT)(T, P);
    double x30 = log(x9);
    double x31 = 24.943387854459719*x30;
    double x32 = log(x15);
    double x33 = sqrt(1 - 0.19999999999999998*T);
    double x34 = 1.0*x33;
    double x35 = fmin(4, x34);
    double x36 = (4 - x34 >= 0. ? 1. : 0.)/x33;
    double x37 = 0.099999999999999992*x36*(40.14405*T - 200.72024999999999);
    double x38 = 20.072025*((x35)*(x35))*x36;
    double x39 = n1*x18 + n1*x19 + n2*x28 + n2*x31 + n2*(40.14405*x35 - x37 - x38 - 40.14405) + 3*n3*x29 + 49.886775708919437*n3*x32 + x0*x22;
    double x40 = x24*x39;
    double x41 = x25*x39/((0.38999999999999996*n3 + x0)*(0.38999999999999996*n3 + x0));
    double x42 = 1.0*x40 - 0.33333333333333331*x41;
    double x43 = -n2*x5 - x6;
    double x44 = 8.3144626181532395*x3;
    double x45 = 24.943387854459719*x3;
    double x46 = -n3*x5 - x6;

if (x17) {
   result[0] = -x10 + x11 + x16 + 8.3144626181532395*x4 + x7*x8;
}
else {
   result[0] = x26*(x18 + x19 + x20*x7 - x21 + x23) + x42;
}
if (x17) {
   result[1] = x16 + x27 + 8.3144626181532395*x30 + x43*x8 - x44 - 13.381349999999999;
}
else {
   result[1] = x26*(x20*x43 + x23 + x28 + x31 + 40.14405*x35 - x37 - x38 - x45 - 40.14405) + x42;
}
if (x17) {
   result[2] = 16.628925236306479*x1*x46 - x10 - 8.3144626181532395*x12 + x29 + 16.628925236306479*x32 - x44;
}
else {
   result[2] = x26*(49.886775708919437*x1*x46 - 24.943387854459719*x12 - x21 + 3*x29 + 49.886775708919437*x32 - x45) + 0.39000000000000001*x40 - 0.12999999999999998*x41;
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = pow(x1, -2);
    double x3 = n1*x2;
    double x4 = 8.3144626181532395*x3;
    double x5 = -x4;
    double x6 = -2*x2;
    double x7 = 2/((x1)*(x1)*(x1));
    double x8 = n1*x7;
    double x9 = x6 + x8;
    double x10 = 8.3144626181532395*x1;
    double x11 = 1.0/x1;
    double x12 = -x11;
    double x13 = -x12 - x3;
    double x14 = 1.0/n1;
    double x15 = x0*x7;
    double x16 = x15 + x6;
    double x17 = x0*x2;
    double x18 = -x12 - x17;
    double x19 = 1.0/x0;
    double x20 = n3*x2;
    double x21 = 16.628925236306479*x20;
    double x22 = 8.3144626181532395*x17;
    double x23 = x21 - x22;
    double x24 = x10*x16 + x10*x18*x19 + x23;
    double x25 = n2*x2;
    double x26 = 8.3144626181532395*x25;
    double x27 = 16.628925236306479*x11;
    double x28 = x26 + x27;
    double x29 = T >= 5.0;
    double x30 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x31 = 3*(*endmember[0].dmu0dT)(T, P);
    double x32 = n1*x11;
    double x33 = 24.943387854459719*log(x32);
    double x34 = 24.943387854459719*x1;
    double x35 = x13*x34;
    double x36 = n2*x11;
    double x37 = 24.943387854459719*x36;
    double x38 = x0*x11;
    double x39 = 24.943387854459719*log(x38);
    double x40 = x18*x34;
    double x41 = n3*x11;
    double x42 = x39 + x40 - 49.886775708919437*x41;
    double x43 = x31 + x33 + x35 - x37 + x42;
    double x44 = x30*x43;
    double x45 = 24.943387854459719*x3;
    double x46 = -x45;
    double x47 = 49.886775708919437*x20;
    double x48 = 24.943387854459719*x17;
    double x49 = x47 - x48;
    double x50 = x16*x34 + x19*x40 + x49;
    double x51 = 24.943387854459719*x25;
    double x52 = 49.886775708919437*x11;
    double x53 = x51 + x52;
    double x54 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x55 = x30*x54;
    double x56 = 0.66666666666666663*x54;
    double x57 = 0.38999999999999996*n3 + x0;
    double x58 = pow(x57, -2);
    double x59 = x43*x58;
    double x60 = 3*(*endmember[1].dmu0dT)(T, P);
    double x61 = (*endmember[2].dmu0dT)(T, P);
    double x62 = 24.943387854459719*log(x36);
    double x63 = log(x41);
    double x64 = sqrt(1 - 0.19999999999999998*T);
    double x65 = 1.0*x64;
    double x66 = fmin(4, x65);
    double x67 = (4 - x65 >= 0. ? 1. : 0.)/x64;
    double x68 = 0.099999999999999992*x67*(40.14405*T - 200.72024999999999);
    double x69 = 20.072025*((x66)*(x66))*x67;
    double x70 = n1*x31 + n1*x33 + n2*x60 + n2*x62 + n2*(40.14405*x66 - x68 - x69 - 40.14405) + 3*n3*x61 + 49.886775708919437*n3*x63 + x0*x39;
    double x71 = x58*x70;
    double x72 = x70/((x57)*(x57)*(x57));
    double x73 = x56*x72 - 0.66666666666666663*x71;
    double x74 = -x2;
    double x75 = x74 + x8;
    double x76 = x10*x75 + x26 + x5;
    double x77 = -x12 - x25;
    double x78 = x34*x77;
    double x79 = 24.943387854459719*x32;
    double x80 = x42 + x60 + x62 + 40.14405*x66 - x68 - x69 + x78 - x79 - 40.14405;
    double x81 = 1.0*x30;
    double x82 = x34*x75 + x46 + x51;
    double x83 = 0.33333333333333331*x54;
    double x84 = x58*x83;
    double x85 = x15 + x74;
    double x86 = x10*x85 + x23 - x27;
    double x87 = x34*x85 + x49 - x52;
    double x88 = 0.12999999999999998*x54;
    double x89 = -x12 - x20;
    double x90 = 49.886775708919437*x1*x89 - x37 - 24.943387854459719*x38 + 3*x61 + 49.886775708919437*x63 - x79;
    double x91 = x54*x72;
    double x92 = -0.26000000000000001*x71 + x81*x90 - x84*x90 + 0.25999999999999995*x91;
    double x93 = n2*x7;
    double x94 = x6 + x93;
    double x95 = 1.0/n2;
    double x96 = -x26 + x4;
    double x97 = x30*x80;
    double x98 = x45 - x51;
    double x99 = x58*x80;
    double x100 = x74 + x93;
    double x101 = n3*x7 + x6;
    double x102 = 16.628925236306479*x1;
    double x103 = 1.0/n3;
    double x104 = 49.886775708919437*x1;

if (x29) {
   result[0] = x10*x13*x14 + x10*x9 + x24 + x28 + x5;
}
else {
   result[0] = 2.0*x44 + x55*(x14*x35 + x34*x9 + x46 + x50 + x53) - x56*x59 + x73;
}
if (x29) {
   result[1] = x24 + x76;
}
else {
   result[1] = 1.0*x44 + x55*(x50 + x82) - x59*x83 + x73 + x80*x81 - x80*x84;
}
if (x29) {
   result[2] = x76 + x86;
}
else {
   result[2] = 0.39000000000000001*x44 + x55*(x82 + x87) - x59*x88 + x92;
}
if (x29) {
   result[3] = x10*x77*x95 + x10*x94 + x24 + x27 + x96;
}
else {
   result[3] = x55*(x34*x94 + x50 + x52 + x78*x95 + x98) - x56*x99 + x73 + 2.0*x97;
}
if (x29) {
   result[4] = x10*x100 + x86 + x96;
}
else {
   result[4] = x55*(x100*x34 + x87 + x98) - x88*x99 + x92 + 0.39000000000000001*x97;
}
if (x29) {
   result[5] = x101*x102 + x102*x103*x89 - x21 + x22 + x28 + x4;
}
else {
   result[5] = 0.78000000000000003*x30*x90 - 0.25999999999999995*x54*x58*x90 + x55*(x101*x104 + x103*x104*x89 + x45 - x47 + x48 + x53) - 0.10139999999999999*x71 + 0.10139999999999998*x91;
}
}
        
static void coder_d4gdn3dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = pow(x1, -3);
    double x3 = -6*x2;
    double x4 = 6/((x1)*(x1)*(x1)*(x1));
    double x5 = n1*x4;
    double x6 = -x3 - x5;
    double x7 = 8.3144626181532395*x1;
    double x8 = pow(x1, -2);
    double x9 = -2*x8;
    double x10 = 2*x2;
    double x11 = n1*x10;
    double x12 = x11 + x9;
    double x13 = 1.0/n1;
    double x14 = x13*x7;
    double x15 = n1*x8;
    double x16 = 1.0/x1;
    double x17 = -x16;
    double x18 = -x15 - x17;
    double x19 = pow(n1, -2);
    double x20 = x13*x18;
    double x21 = 33.257850472612958*x2;
    double x22 = n2*x2;
    double x23 = 16.628925236306479*x22;
    double x24 = n1*x21 - x23;
    double x25 = 8.3144626181532395*x20 + x24;
    double x26 = 66.515700945225916*x8;
    double x27 = 1.0/x0;
    double x28 = x0*x8;
    double x29 = -x17 - x28;
    double x30 = x27*x29;
    double x31 = -n3*x21 + x0*x21;
    double x32 = 8.3144626181532395*x30 + x31;
    double x33 = x0*x4;
    double x34 = -x3 - x33;
    double x35 = x0*x10;
    double x36 = x35 + x9;
    double x37 = x27*x7;
    double x38 = pow(x0, -2);
    double x39 = -x29*x38*x7 + x34*x7 + x36*x37;
    double x40 = x32 + x39;
    double x41 = -x26 + x40;
    double x42 = T >= 5.0;
    double x43 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x44 = 24.943387854459719*x15;
    double x45 = -x44;
    double x46 = 24.943387854459719*x1;
    double x47 = x12*x46;
    double x48 = x36*x46;
    double x49 = n3*x8;
    double x50 = 49.886775708919437*x49;
    double x51 = 24.943387854459719*x28;
    double x52 = x50 - x51;
    double x53 = x30*x46 + x48 + x52;
    double x54 = n2*x8;
    double x55 = 24.943387854459719*x54;
    double x56 = 49.886775708919437*x16;
    double x57 = x55 + x56;
    double x58 = x20*x46 + x45 + x47 + x53 + x57;
    double x59 = x43*x58;
    double x60 = 0.38999999999999996*n3 + x0;
    double x61 = pow(x60, -2);
    double x62 = 3*(*endmember[0].dmu0dT)(T, P);
    double x63 = n1*x16;
    double x64 = 24.943387854459719*log(x63);
    double x65 = x18*x46;
    double x66 = n2*x16;
    double x67 = 24.943387854459719*x66;
    double x68 = x0*x16;
    double x69 = 24.943387854459719*log(x68);
    double x70 = x29*x46;
    double x71 = n3*x16;
    double x72 = x69 + x70 - 49.886775708919437*x71;
    double x73 = x62 + x64 + x65 - x67 + x72;
    double x74 = x61*x73;
    double x75 = 99.773551417838874*x2;
    double x76 = 49.886775708919437*x22;
    double x77 = n1*x75 - x76;
    double x78 = 24.943387854459719*x20 + x77;
    double x79 = -n3*x75 + x0*x75;
    double x80 = 24.943387854459719*x30 + x79;
    double x81 = x27*x48 + x34*x46 - x38*x70;
    double x82 = x80 + x81;
    double x83 = -199.54710283567778*x8 + x82;
    double x84 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x85 = x43*x84;
    double x86 = 2.0*x84;
    double x87 = pow(x60, -3);
    double x88 = x73*x87;
    double x89 = x61*x84;
    double x90 = x58*x89;
    double x91 = 3*(*endmember[1].dmu0dT)(T, P);
    double x92 = (*endmember[2].dmu0dT)(T, P);
    double x93 = 24.943387854459719*log(x66);
    double x94 = log(x71);
    double x95 = sqrt(1 - 0.19999999999999998*T);
    double x96 = 1.0*x95;
    double x97 = fmin(4, x96);
    double x98 = (4 - x96 >= 0. ? 1. : 0.)/x95;
    double x99 = 0.099999999999999992*x98*(40.14405*T - 200.72024999999999);
    double x100 = 20.072025*((x97)*(x97))*x98;
    double x101 = n1*x62 + n1*x64 + n2*x91 + n2*x93 + n2*(-x100 + 40.14405*x97 - x99 - 40.14405) + 3*n3*x92 + 49.886775708919437*n3*x94 + x0*x69;
    double x102 = x101*x87;
    double x103 = x101/((x60)*(x60)*(x60)*(x60));
    double x104 = 2.0*x102 - x103*x86;
    double x105 = -4*x2;
    double x106 = -x105 - x5;
    double x107 = -x8;
    double x108 = x107 + x11;
    double x109 = x106*x7 + x108*x14 + x25;
    double x110 = -x17 - x54;
    double x111 = x110*x46;
    double x112 = 24.943387854459719*x63;
    double x113 = -x100 + x111 - x112 + x72 + x91 + x93 + 40.14405*x97 - x99 - 40.14405;
    double x114 = 0.66666666666666663*x61;
    double x115 = x108*x46;
    double x116 = x106*x46 + x115*x13 + x78;
    double x117 = 0.66666666666666663*x84;
    double x118 = x113*x87;
    double x119 = x84*x88;
    double x120 = x115 + x45 + x55;
    double x121 = x120 + x53;
    double x122 = 2.0*x43;
    double x123 = x114*x84;
    double x124 = x104 + x121*x122 - x121*x123;
    double x125 = -x105 - x33;
    double x126 = x107 + x35;
    double x127 = x125*x7 + x126*x37;
    double x128 = x127 + x32 - 33.257850472612958*x8;
    double x129 = x126*x46;
    double x130 = x129 + x52 - x56;
    double x131 = x120 + x130;
    double x132 = x125*x46 + x129*x27;
    double x133 = x132 - 99.773551417838888*x8 + x80;
    double x134 = -x17 - x49;
    double x135 = 49.886775708919437*x1*x134 - x112 - x67 - 24.943387854459719*x68 + 3*x92 + 49.886775708919437*x94;
    double x136 = x135*x87;
    double x137 = x103*x84;
    double x138 = 0.77999999999999992*x102 - x114*x135 + x117*x136 - 0.77999999999999992*x137;
    double x139 = -2*x2;
    double x140 = -x139 - x5;
    double x141 = x140*x7 + x24;
    double x142 = x141 + x32;
    double x143 = n2*x10;
    double x144 = x143 + x9;
    double x145 = x144*x46;
    double x146 = 1.0/n2;
    double x147 = x44 - x55;
    double x148 = x111*x146 + x145 + x147 + x53 + x56;
    double x149 = 1.0*x43;
    double x150 = x113*x61;
    double x151 = x140*x46 + x77;
    double x152 = x151 + x80;
    double x153 = x118*x84;
    double x154 = 0.33333333333333331*x89;
    double x155 = x107 + x143;
    double x156 = x155*x46;
    double x157 = x130 + x147 + x156;
    double x158 = 0.39000000000000001*x43;
    double x159 = 0.12999999999999998*x89;
    double x160 = -x139 - x33;
    double x161 = x160*x7 + x31 + 16.628925236306479*x8;
    double x162 = 0.78000000000000003*x43;
    double x163 = x160*x46 + x79 + 49.886775708919437*x8;
    double x164 = 0.25999999999999995*x89;
    double x165 = n3*x10 + x9;
    double x166 = 49.886775708919437*x1;
    double x167 = 1.0/n3;
    double x168 = x134*x166;
    double x169 = x165*x166 + x167*x168 + x44 - x50 + x51 + x57;
    double x170 = x135*x61;
    double x171 = x136*x84;
    double x172 = 0.30419999999999997*x102 - 0.30419999999999991*x137 + x149*x169 - x154*x169 - 0.52000000000000002*x170 + 0.51999999999999991*x171;
    double x173 = n2*x4;
    double x174 = -x173 - x3;
    double x175 = x146*x7;
    double x176 = pow(n2, -2);
    double x177 = x110*x146;
    double x178 = n1*x2;
    double x179 = 16.628925236306479*x178;
    double x180 = n2*x21 - x179;
    double x181 = 8.3144626181532395*x177 + x180;
    double x182 = 49.886775708919437*x178;
    double x183 = -x182 + 99.773551417838874*x22;
    double x184 = 24.943387854459719*x177 + x183;
    double x185 = -x105 - x173;
    double x186 = -x139 - x173;
    double x187 = x0*x2;
    double x188 = -n3*x4 - x3;
    double x189 = pow(n3, -2);

if (x42) {
   result[0] = x12*x14 - x18*x19*x7 + x25 + x41 + x6*x7;
}
else {
   result[0] = x104 + 3.0*x59 - 2.0*x74 + x85*(x13*x47 - x19*x65 + x46*x6 + x78 + x83) + x86*x88 - 1.0*x90;
}
if (x42) {
   result[1] = x109 + x40 - 49.886775708919444*x8;
}
else {
   result[1] = -x113*x114 + x117*x118 + 1.3333333333333333*x119 + x124 + 1.0*x59 - 1.3333333333333333*x74 + x85*(x116 - 149.66032712675832*x8 + x82) - 0.33333333333333331*x90;
}
if (x42) {
   result[2] = x109 + x128;
}
else {
   result[2] = 0.51999999999999991*x119 + x122*x131 - x123*x131 + x138 + 0.39000000000000001*x59 - 0.52000000000000002*x74 + x85*(x116 + x133) - 0.12999999999999998*x90;
}
if (x42) {
   result[3] = x142 + x39 - 24.943387854459719*x8;
}
else {
   result[3] = x117*x88 + x124 + x148*x149 - x148*x154 - 1.3333333333333333*x150 + 1.3333333333333333*x153 - 0.66666666666666663*x74 + x85*(x152 - 74.830163563379159*x8 + x81);
}
if (x42) {
   result[4] = x127 + x142 - 8.3144626181532395*x8;
}
else {
   result[4] = 0.25999999999999995*x119 + x121*x158 - x121*x159 + x131*x149 - x131*x154 + x138 + x149*x157 - 0.26000000000000001*x150 + 0.25999999999999995*x153 - x154*x157 - 0.26000000000000001*x74 + x85*(x132 + x152 - 24.943387854459722*x8);
}
if (x42) {
   result[5] = x141 + x161;
}
else {
   result[5] = 0.10139999999999998*x119 + x131*x162 - x131*x164 + x172 - 0.10139999999999999*x74 + x85*(x151 + x163);
}
if (x42) {
   result[6] = -x110*x176*x7 + x144*x175 + x174*x7 + x181 + x41;
}
else {
   result[6] = x104 + x118*x86 + 3.0*x148*x43 - 1.0*x148*x89 - 2.0*x150 + x85*(-x111*x176 + x145*x146 + x174*x46 + x184 + x83);
}
if (x42) {
   result[7] = x128 + x155*x175 + x181 + x185*x7;
}
else {
   result[7] = x122*x157 - x123*x157 + x138 + x148*x158 - x148*x159 - 0.52000000000000002*x150 + 0.51999999999999991*x153 + x85*(x133 + x146*x156 + x184 + x185*x46);
}
if (x42) {
   result[8] = x161 + x180 + x186*x7;
}
else {
   result[8] = -0.10139999999999999*x150 + 0.10139999999999998*x153 + x157*x162 - x157*x164 + x172 + x85*(x163 + x183 + x186*x46);
}
if (x42) {
   result[9] = 66.515700945225916*n3*x2 - 16.628925236306479*x1*x134*x189 + 16.628925236306479*x1*x165*x167 + 16.628925236306479*x1*x188 + 16.628925236306479*x134*x167 - x179 - 16.628925236306479*x187 - x23 - x26;
}
else {
   result[9] = 0.11863799999999997*x102 - 0.11863799999999997*x137 + 1.1699999999999999*x169*x43 - 0.3899999999999999*x169*x89 - 0.30419999999999997*x170 + 0.30419999999999991*x171 + x85*(199.54710283567775*n3*x2 + 49.886775708919437*x1*x165*x167 + 49.886775708919437*x1*x188 + 49.886775708919437*x134*x167 - x168*x189 - x182 - 49.886775708919437*x187 - x76 - 199.54710283567775*x8);
}
}
        
static double coder_dgdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].dmu0dP)(T, P);
    double x1 = n2*(*endmember[1].dmu0dP)(T, P);
    double x2 = n3*(*endmember[2].dmu0dP)(T, P);

if (T >= 5.0) {
   result = x0 + x1 + x2;
}
else {
   result = (1.0*n1 + 1.0*n2 + 0.39000000000000001*n3)*(3*x0 + 3*x1 + 3*x2)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = T >= 5.0;
    double x2 = 3*x0;
    double x3 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x4 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x5 = x3*x4;
    double x6 = (*endmember[1].dmu0dP)(T, P);
    double x7 = 3*x6;
    double x8 = (*endmember[2].dmu0dP)(T, P);
    double x9 = 3*x8;
    double x10 = n1*x2 + n2*x7 + n3*x9;
    double x11 = x10*x3;
    double x12 = x10*x4/((n1 + n2 + 0.38999999999999996*n3)*(n1 + n2 + 0.38999999999999996*n3));
    double x13 = 1.0*x11 - 0.33333333333333331*x12;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x13 + x2*x5;
}
if (x1) {
   result[1] = x6;
}
else {
   result[1] = x13 + x5*x7;
}
if (x1) {
   result[2] = x8;
}
else {
   result[2] = 0.39000000000000001*x11 - 0.12999999999999998*x12 + x5*x9;
}
}
        
static void coder_d3gdn2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x2 = (*endmember[0].dmu0dP)(T, P);
    double x3 = x1*x2;
    double x4 = n1 + n2 + 0.38999999999999996*n3;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x7 = x5*x6;
    double x8 = x2*x7;
    double x9 = (*endmember[1].dmu0dP)(T, P);
    double x10 = (*endmember[2].dmu0dP)(T, P);
    double x11 = 3*n1*x2 + 3*n2*x9 + 3*n3*x10;
    double x12 = x11*x5;
    double x13 = x11*x6/((x4)*(x4)*(x4));
    double x14 = -0.66666666666666663*x12 + 0.66666666666666663*x13;
    double x15 = 3.0*x1;
    double x16 = 1.0*x7;
    double x17 = x10*x15 - x10*x16 - 0.26000000000000001*x12 + 0.25999999999999995*x13;
    double x18 = x1*x9;
    double x19 = x7*x9;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x14 + 6.0*x3 - 2.0*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x14 + x15*x9 - x16*x9 + 3.0*x3 - 1.0*x8;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = x17 + 1.1699999999999999*x3 - 0.38999999999999996*x8;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x14 + 6.0*x18 - 2.0*x19;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = x17 + 1.1699999999999999*x18 - 0.38999999999999996*x19;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 2.3399999999999999*x1*x10 - 0.7799999999999998*x10*x7 - 0.10139999999999999*x12 + 0.10139999999999998*x13;
}
}
        
static void coder_d4gdn3dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].dmu0dP)(T, P);
    double x2 = n1 + n2 + 0.38999999999999996*n3;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = pow(x2, -3);
    double x6 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x7 = (*endmember[1].dmu0dP)(T, P);
    double x8 = (*endmember[2].dmu0dP)(T, P);
    double x9 = 3*n1*x1 + 3*n2*x7 + 3*n3*x8;
    double x10 = x6*x9/((x2)*(x2)*(x2)*(x2));
    double x11 = 2.0*x10 - 2.0*x5*x9;
    double x12 = 2.0*x3;
    double x13 = 0.77999999999999992*x10 + x12*x8 - 2.0*x5*x6*x8 - 0.77999999999999992*x5*x9;
    double x14 = x3*x7;
    double x15 = x3*x8;
    double x16 = 0.30419999999999991*x10 + 1.5600000000000001*x15 - 1.5599999999999996*x5*x6*x8 - 0.30419999999999997*x5*x9;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 6.0*x1*x5*x6 - x11 - 6.0*x4;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = 4.0*x1*x5*x6 - x11 - x12*x7 - 4.0*x4 + 2.0*x5*x6*x7;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = 1.5599999999999998*x1*x5*x6 - x13 - 1.5600000000000001*x4;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 2.0*x1*x5*x6 - x11 - 4.0*x14 - 2.0*x4 + 4.0*x5*x6*x7;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = 0.77999999999999992*x1*x5*x6 - x13 - 0.78000000000000003*x14 - 0.78000000000000003*x4 + 0.77999999999999992*x5*x6*x7;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 0.30419999999999991*x1*x5*x6 - x16 - 0.30419999999999991*x4;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = -x11 - 6.0*x14 + 6.0*x5*x6*x7;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = -x13 - 1.5600000000000001*x14 + 1.5599999999999998*x5*x6*x7;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -0.30419999999999991*x14 - x16 + 0.30419999999999991*x5*x6*x7;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = -0.11863799999999997*x10 - 0.91259999999999974*x15 + 0.91259999999999974*x5*x6*x8 + 0.11863799999999997*x5*x9;
}
}
        
static double coder_d2gdt2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dT2)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dT2)(T, P);
    double x3 = 0.19999999999999998*T - 1;
    double x4 = -x3;
    double x5 = sqrt(x4);
    double x6 = 1.0*x5;
    double x7 = x6 - 4;
    double x8 = (-x7 >= 0. ? 1. : 0.);
    double x9 = 0.40144049999999992*T - 2.0072024999999996;
    double x10 = 1.0/x3;
    double x11 = x10*0;
    double x12 = x8/pow(x4, 3.0/2.0);
    double x13 = fmin(4, x6);
    double x14 = 2.0072025*((x13)*(x13));

if (T >= 5.0) {
   result = x0 + x1 + x2;
}
else {
   result = (1.0*n1 + 1.0*n2 + 0.39000000000000001*n3)*(-n2*(4.014405*x10*x13*((x8)*(x8)) - x11*x14 - x11*x9 + x12*x14 + x12*x9 + 8.02881*x8/x5) + 3*x0 + 3*x1 + 3*x2)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = T >= 5.0;
    double x2 = 3*x0;
    double x3 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x4 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x5 = x3*x4;
    double x6 = (*endmember[1].d2mu0dT2)(T, P);
    double x7 = (*endmember[2].d2mu0dT2)(T, P);
    double x8 = 3*x7;
    double x9 = 0.19999999999999998*T - 1;
    double x10 = -x9;
    double x11 = sqrt(x10);
    double x12 = 1.0*x11;
    double x13 = x12 - 4;
    double x14 = (-x13 >= 0. ? 1. : 0.);
    double x15 = 0.40144049999999992*T - 2.0072024999999996;
    double x16 = 1.0/x9;
    double x17 = x16*0;
    double x18 = x14/pow(x10, 3.0/2.0);
    double x19 = fmin(4, x12);
    double x20 = 2.0072025*((x19)*(x19));
    double x21 = 4.014405*((x14)*(x14))*x16*x19 - x15*x17 + x15*x18 - x17*x20 + x18*x20 + 8.02881*x14/x11;
    double x22 = n1*x2 - n2*x21 + 3*n2*x6 + n3*x8;
    double x23 = x22*x3;
    double x24 = x22*x4/((n1 + n2 + 0.38999999999999996*n3)*(n1 + n2 + 0.38999999999999996*n3));
    double x25 = 1.0*x23 - 0.33333333333333331*x24;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x2*x5 + x25;
}
if (x1) {
   result[1] = x6;
}
else {
   result[1] = x25 + x5*(-x21 + 3*x6);
}
if (x1) {
   result[2] = x7;
}
else {
   result[2] = 0.39000000000000001*x23 - 0.12999999999999998*x24 + x5*x8;
}
}
        
static void coder_d4gdn2dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x2 = (*endmember[0].d2mu0dT2)(T, P);
    double x3 = x1*x2;
    double x4 = n1 + n2 + 0.38999999999999996*n3;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x7 = x5*x6;
    double x8 = x2*x7;
    double x9 = (*endmember[1].d2mu0dT2)(T, P);
    double x10 = (*endmember[2].d2mu0dT2)(T, P);
    double x11 = 0.19999999999999998*T - 1;
    double x12 = -x11;
    double x13 = sqrt(x12);
    double x14 = 1.0*x13;
    double x15 = x14 - 4;
    double x16 = (-x15 >= 0. ? 1. : 0.);
    double x17 = 0.40144049999999992*T - 2.0072024999999996;
    double x18 = 1.0/x11;
    double x19 = x18*0;
    double x20 = x16/pow(x12, 3.0/2.0);
    double x21 = fmin(4, x14);
    double x22 = 2.0072025*((x21)*(x21));
    double x23 = 4.014405*((x16)*(x16))*x18*x21 - x17*x19 + x17*x20 - x19*x22 + x20*x22 + 8.02881*x16/x13;
    double x24 = 3*n1*x2 - n2*x23 + 3*n2*x9 + 3*n3*x10;
    double x25 = x24*x5;
    double x26 = 0.66666666666666663*x6;
    double x27 = x24/((x4)*(x4)*(x4));
    double x28 = -0.66666666666666663*x25 + x26*x27;
    double x29 = -x23 + 3*x9;
    double x30 = x1*x29;
    double x31 = x29*x7;
    double x32 = x1*x10;
    double x33 = x27*x6;
    double x34 = x10*x7;
    double x35 = -0.26000000000000001*x25 + 3.0*x32 + 0.25999999999999995*x33 - 1.0*x34;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x28 + 6.0*x3 - 2.0*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x28 + 3.0*x3 + 1.0*x30 - 0.33333333333333331*x31 - 1.0*x8;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = 1.1699999999999999*x3 + x35 - 0.38999999999999996*x8;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = -x26*x29*x5 + x28 + 2.0*x30;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = 0.39000000000000001*x30 - 0.12999999999999998*x31 + x35;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = -0.10139999999999999*x25 + 2.3399999999999999*x32 + 0.10139999999999998*x33 - 0.7799999999999998*x34;
}
}
        
static void coder_d5gdn3dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dT2)(T, P);
    double x2 = n1 + n2 + 0.38999999999999996*n3;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = pow(x2, -3);
    double x6 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x7 = (*endmember[1].d2mu0dT2)(T, P);
    double x8 = (*endmember[2].d2mu0dT2)(T, P);
    double x9 = 0.19999999999999998*T - 1;
    double x10 = -x9;
    double x11 = sqrt(x10);
    double x12 = 1.0*x11;
    double x13 = x12 - 4;
    double x14 = (-x13 >= 0. ? 1. : 0.);
    double x15 = 0.40144049999999992*T - 2.0072024999999996;
    double x16 = 1.0/x9;
    double x17 = x16*0;
    double x18 = x14/pow(x10, 3.0/2.0);
    double x19 = fmin(4, x12);
    double x20 = 2.0072025*((x19)*(x19));
    double x21 = 4.014405*((x14)*(x14))*x16*x19 - x15*x17 + x15*x18 - x17*x20 + x18*x20 + 8.02881*x14/x11;
    double x22 = 3*n1*x1 - n2*x21 + 3*n2*x7 + 3*n3*x8;
    double x23 = x22*x6/((x2)*(x2)*(x2)*(x2));
    double x24 = -2.0*x22*x5 + 2.0*x23;
    double x25 = -x21 + 3*x7;
    double x26 = x25*x3;
    double x27 = x3*x8;
    double x28 = -0.77999999999999992*x22*x5 + 0.77999999999999992*x23 + 2.0*x27 - 2.0*x5*x6*x8;
    double x29 = -0.30419999999999997*x22*x5 + 0.30419999999999991*x23 + 1.5600000000000001*x27 - 1.5599999999999996*x5*x6*x8;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 6.0*x1*x5*x6 - x24 - 6.0*x4;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = 4.0*x1*x5*x6 - x24 + 0.66666666666666663*x25*x5*x6 - 0.66666666666666663*x26 - 4.0*x4;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = 1.5599999999999998*x1*x5*x6 - x28 - 1.5600000000000001*x4;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 2.0*x1*x5*x6 - x24 + 1.3333333333333333*x25*x5*x6 - 1.3333333333333333*x26 - 2.0*x4;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = 0.77999999999999992*x1*x5*x6 + 0.25999999999999995*x25*x5*x6 - 0.26000000000000001*x26 - x28 - 0.78000000000000003*x4;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 0.30419999999999991*x1*x5*x6 - x29 - 0.30419999999999991*x4;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = -x24 + 2.0*x25*x5*x6 - 2.0*x26;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = 0.51999999999999991*x25*x5*x6 - 0.52000000000000002*x26 - x28;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = 0.10139999999999998*x25*x5*x6 - 0.10139999999999999*x26 - x29;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = 0.11863799999999997*x22*x5 - 0.11863799999999997*x23 - 0.91259999999999974*x27 + 0.91259999999999974*x5*x6*x8;
}
}
        
static double coder_d2gdtdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P) + n3*(*endmember[2].d2mu0dTdP)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 0.39000000000000001*n3)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].d2mu0dTdP)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d2mu0dTdP)(T, P);
    double x6 = (*endmember[2].d2mu0dTdP)(T, P);
    double x7 = n1*x0 + n2*x5 + n3*x6;
    double x8 = x2*x7;
    double x9 = x3*x7/((n1 + n2 + 0.38999999999999996*n3)*(n1 + n2 + 0.38999999999999996*n3));
    double x10 = 3.0*x8 - 1.0*x9;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x10;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x10 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x4*x6 + 1.1699999999999999*x8 - 0.38999999999999996*x9;
}
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dTdP)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = x1*x2;
    double x4 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x5 = 2.0*x4;
    double x6 = n1 + n2 + 0.38999999999999996*n3;
    double x7 = pow(x6, -2);
    double x8 = x1*x7;
    double x9 = (*endmember[1].d2mu0dTdP)(T, P);
    double x10 = (*endmember[2].d2mu0dTdP)(T, P);
    double x11 = n1*x1 + n2*x9 + n3*x10;
    double x12 = x11*x7;
    double x13 = x11/((x6)*(x6)*(x6));
    double x14 = -2.0*x12 + x13*x5;
    double x15 = 3.0*x2;
    double x16 = 1.0*x4;
    double x17 = x16*x7;
    double x18 = 0.38999999999999996*x4;
    double x19 = x13*x4;
    double x20 = x10*x15 - x10*x17 - 0.78000000000000003*x12 + 0.77999999999999992*x19;
    double x21 = x2*x9;
    double x22 = x7*x9;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x14 + 6.0*x3 - x5*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x14 + x15*x9 - x16*x8 - x17*x9 + 3.0*x3;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = -x18*x8 + x20 + 1.1699999999999999*x3;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x14 + 6.0*x21 - x22*x5;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -x18*x22 + x20 + 1.1699999999999999*x21;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 2.3399999999999999*x10*x2 - 0.77999999999999992*x10*x4*x7 - 0.30419999999999991*x12 + 0.30419999999999991*x19;
}
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dTdP)(T, P);
    double x2 = n1 + n2 + 0.38999999999999996*n3;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = pow(x2, -3);
    double x6 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x7 = (*endmember[1].d2mu0dTdP)(T, P);
    double x8 = (*endmember[2].d2mu0dTdP)(T, P);
    double x9 = n1*x1 + n2*x7 + n3*x8;
    double x10 = x9/((x2)*(x2)*(x2)*(x2));
    double x11 = 6.0*x10*x6 - 6.0*x5*x9;
    double x12 = 2.0*x3;
    double x13 = x10*x6;
    double x14 = x12*x8 + 2.3399999999999999*x13 - 2.0*x5*x6*x8 - 2.3399999999999999*x5*x9;
    double x15 = x3*x7;
    double x16 = x3*x8;
    double x17 = 0.91259999999999986*x13 + 1.5600000000000001*x16 - 1.5599999999999998*x5*x6*x8 - 0.91259999999999986*x5*x9;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 6.0*x1*x5*x6 - x11 - 6.0*x4;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = 4.0*x1*x5*x6 - x11 - x12*x7 - 4.0*x4 + 2.0*x5*x6*x7;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = 1.5599999999999998*x1*x5*x6 - x14 - 1.5600000000000001*x4;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 2.0*x1*x5*x6 - x11 - 4.0*x15 - 2.0*x4 + 4.0*x5*x6*x7;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = 0.77999999999999992*x1*x5*x6 - x14 - 0.78000000000000003*x15 - 0.78000000000000003*x4 + 0.77999999999999992*x5*x6*x7;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 0.30419999999999991*x1*x5*x6 - x17 - 0.30419999999999991*x4;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = -x11 - 6.0*x15 + 6.0*x5*x6*x7;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = -x14 - 1.5600000000000001*x15 + 1.5599999999999998*x5*x6*x7;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -0.30419999999999991*x15 - x17 + 0.30419999999999991*x5*x6*x7;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = -0.3559139999999999*x13 - 0.91259999999999986*x16 + 0.91259999999999974*x5*x6*x8 + 0.35591399999999984*x5*x9;
}
}
        
static double coder_d2gdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P) + n3*(*endmember[2].d2mu0dP2)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 0.39000000000000001*n3)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].d2mu0dP2)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d2mu0dP2)(T, P);
    double x6 = (*endmember[2].d2mu0dP2)(T, P);
    double x7 = n1*x0 + n2*x5 + n3*x6;
    double x8 = x2*x7;
    double x9 = x3*x7/((n1 + n2 + 0.38999999999999996*n3)*(n1 + n2 + 0.38999999999999996*n3));
    double x10 = 3.0*x8 - 1.0*x9;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x10;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x10 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x4*x6 + 1.1699999999999999*x8 - 0.38999999999999996*x9;
}
}
        
static void coder_d4gdn2dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dP2)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = x1*x2;
    double x4 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x5 = 2.0*x4;
    double x6 = n1 + n2 + 0.38999999999999996*n3;
    double x7 = pow(x6, -2);
    double x8 = x1*x7;
    double x9 = (*endmember[1].d2mu0dP2)(T, P);
    double x10 = (*endmember[2].d2mu0dP2)(T, P);
    double x11 = n1*x1 + n2*x9 + n3*x10;
    double x12 = x11*x7;
    double x13 = x11/((x6)*(x6)*(x6));
    double x14 = -2.0*x12 + x13*x5;
    double x15 = 3.0*x2;
    double x16 = 1.0*x4;
    double x17 = x16*x7;
    double x18 = 0.38999999999999996*x4;
    double x19 = x13*x4;
    double x20 = x10*x15 - x10*x17 - 0.78000000000000003*x12 + 0.77999999999999992*x19;
    double x21 = x2*x9;
    double x22 = x7*x9;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x14 + 6.0*x3 - x5*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x14 + x15*x9 - x16*x8 - x17*x9 + 3.0*x3;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = -x18*x8 + x20 + 1.1699999999999999*x3;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x14 + 6.0*x21 - x22*x5;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -x18*x22 + x20 + 1.1699999999999999*x21;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 2.3399999999999999*x10*x2 - 0.77999999999999992*x10*x4*x7 - 0.30419999999999991*x12 + 0.30419999999999991*x19;
}
}
        
static void coder_d5gdn3dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d2mu0dP2)(T, P);
    double x2 = n1 + n2 + 0.38999999999999996*n3;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = pow(x2, -3);
    double x6 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x7 = (*endmember[1].d2mu0dP2)(T, P);
    double x8 = (*endmember[2].d2mu0dP2)(T, P);
    double x9 = n1*x1 + n2*x7 + n3*x8;
    double x10 = x9/((x2)*(x2)*(x2)*(x2));
    double x11 = 6.0*x10*x6 - 6.0*x5*x9;
    double x12 = 2.0*x3;
    double x13 = x10*x6;
    double x14 = x12*x8 + 2.3399999999999999*x13 - 2.0*x5*x6*x8 - 2.3399999999999999*x5*x9;
    double x15 = x3*x7;
    double x16 = x3*x8;
    double x17 = 0.91259999999999986*x13 + 1.5600000000000001*x16 - 1.5599999999999998*x5*x6*x8 - 0.91259999999999986*x5*x9;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 6.0*x1*x5*x6 - x11 - 6.0*x4;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = 4.0*x1*x5*x6 - x11 - x12*x7 - 4.0*x4 + 2.0*x5*x6*x7;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = 1.5599999999999998*x1*x5*x6 - x14 - 1.5600000000000001*x4;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 2.0*x1*x5*x6 - x11 - 4.0*x15 - 2.0*x4 + 4.0*x5*x6*x7;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = 0.77999999999999992*x1*x5*x6 - x14 - 0.78000000000000003*x15 - 0.78000000000000003*x4 + 0.77999999999999992*x5*x6*x7;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 0.30419999999999991*x1*x5*x6 - x17 - 0.30419999999999991*x4;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = -x11 - 6.0*x15 + 6.0*x5*x6*x7;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = -x14 - 1.5600000000000001*x15 + 1.5599999999999998*x5*x6*x7;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -0.30419999999999991*x15 - x17 + 0.30419999999999991*x5*x6*x7;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = -0.3559139999999999*x13 - 0.91259999999999986*x16 + 0.91259999999999974*x5*x6*x8 + 0.35591399999999984*x5*x9;
}
}
        
static double coder_d3gdt3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT3)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dT3)(T, P);
    double x3 = 0.19999999999999998*T - 1;
    double x4 = -x3;
    double x5 = 1.0*sqrt(x4);
    double x6 = x5 - 4;
    double x7 = 0;
    double x8 = pow(x4, -3.0/2.0);
    double x9 = (-x6 >= 0. ? 1. : 0.);
    double x10 = 1.2043214999999998*x8*x9;
    double x11 = 40.14405*T - 200.72024999999999;
    double x12 = pow(x3, -2);
    double x13 = x12*x7;
    double x14 = x9/pow(x4, 5.0/2.0);
    double x15 = x8*0;
    double x16 = fmin(4, x5);
    double x17 = ((x16)*(x16));

if (T >= 5.0) {
   result = x0 + x1 + x2;
}
else {
   result = (1.0*n1 + 1.0*n2 + 0.39000000000000001*n3)*(-n2*(-x10*x16*x7 + x10 + 0.0029999999999999992*x11*x13 + 0.0029999999999999996*x11*x14 - 0.0009999999999999998*x11*x15 - 1.2043214999999998*x12*x16*((x9)*(x9)) + 0.60216074999999991*x13*x17 + 0.60216075000000002*x14*x17 - 0.20072024999999999*x15*x17 + 0.40144049999999998*x8*((x9)*(x9)*(x9)) - 1.2043214999999998*x7/x3) + 3*x0 + 3*x1 + 3*x2)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = T >= 5.0;
    double x2 = 3*x0;
    double x3 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x4 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x5 = x3*x4;
    double x6 = (*endmember[1].d3mu0dT3)(T, P);
    double x7 = 3*x6;
    double x8 = (*endmember[2].d3mu0dT3)(T, P);
    double x9 = 3*x8;
    double x10 = 0.19999999999999998*T - 1;
    double x11 = -x10;
    double x12 = 1.0*sqrt(x11);
    double x13 = x12 - 4;
    double x14 = 0;
    double x15 = 1.2043214999999998*x14/x10;
    double x16 = pow(x11, -3.0/2.0);
    double x17 = (-x13 >= 0. ? 1. : 0.);
    double x18 = 1.2043214999999998*x16*x17;
    double x19 = 0.40144049999999998*x16*((x17)*(x17)*(x17));
    double x20 = 40.14405*T - 200.72024999999999;
    double x21 = pow(x10, -2);
    double x22 = x14*x21;
    double x23 = 0.0029999999999999992*x20*x22;
    double x24 = x17/pow(x11, 5.0/2.0);
    double x25 = 0.0029999999999999996*x20*x24;
    double x26 = x16*0;
    double x27 = 0.0009999999999999998*x20*x26;
    double x28 = fmin(4, x12);
    double x29 = ((x28)*(x28));
    double x30 = 0.60216074999999991*x22*x29;
    double x31 = 0.60216075000000002*x24*x29;
    double x32 = 0.20072024999999999*x26*x29;
    double x33 = 1.2043214999999998*((x17)*(x17))*x21*x28;
    double x34 = x14*x18*x28;
    double x35 = n1*x2 + n2*x7 - n2*(-x15 + x18 + x19 + x23 + x25 - x27 + x30 + x31 - x32 - x33 - x34) + n3*x9;
    double x36 = x3*x35;
    double x37 = x35*x4/((n1 + n2 + 0.38999999999999996*n3)*(n1 + n2 + 0.38999999999999996*n3));
    double x38 = 1.0*x36 - 0.33333333333333331*x37;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x2*x5 + x38;
}
if (x1) {
   result[1] = x6;
}
else {
   result[1] = x38 + x5*(x15 - x18 - x19 - x23 - x25 + x27 - x30 - x31 + x32 + x33 + x34 + x7);
}
if (x1) {
   result[2] = x8;
}
else {
   result[2] = 0.39000000000000001*x36 - 0.12999999999999998*x37 + x5*x9;
}
}
        
static void coder_d5gdn2dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x2 = (*endmember[0].d3mu0dT3)(T, P);
    double x3 = x1*x2;
    double x4 = n1 + n2 + 0.38999999999999996*n3;
    double x5 = pow(x4, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x7 = x5*x6;
    double x8 = x2*x7;
    double x9 = 3*(*endmember[1].d3mu0dT3)(T, P);
    double x10 = (*endmember[2].d3mu0dT3)(T, P);
    double x11 = 0.19999999999999998*T - 1;
    double x12 = -x11;
    double x13 = 1.0*sqrt(x12);
    double x14 = x13 - 4;
    double x15 = 0;
    double x16 = 1.2043214999999998*x15/x11;
    double x17 = pow(x12, -3.0/2.0);
    double x18 = (-x14 >= 0. ? 1. : 0.);
    double x19 = 1.2043214999999998*x17*x18;
    double x20 = 0.40144049999999998*x17*((x18)*(x18)*(x18));
    double x21 = 40.14405*T - 200.72024999999999;
    double x22 = pow(x11, -2);
    double x23 = x15*x22;
    double x24 = 0.0029999999999999992*x21*x23;
    double x25 = x18/pow(x12, 5.0/2.0);
    double x26 = 0.0029999999999999996*x21*x25;
    double x27 = x17*0;
    double x28 = 0.0009999999999999998*x21*x27;
    double x29 = fmin(4, x13);
    double x30 = ((x29)*(x29));
    double x31 = 0.60216074999999991*x23*x30;
    double x32 = 0.60216075000000002*x25*x30;
    double x33 = 0.20072024999999999*x27*x30;
    double x34 = 1.2043214999999998*((x18)*(x18))*x22*x29;
    double x35 = x15*x19*x29;
    double x36 = 3*n1*x2 + n2*x9 - n2*(-x16 + x19 + x20 + x24 + x26 - x28 + x31 + x32 - x33 - x34 - x35) + 3*n3*x10;
    double x37 = x36*x5;
    double x38 = 0.66666666666666663*x6;
    double x39 = x36/((x4)*(x4)*(x4));
    double x40 = -0.66666666666666663*x37 + x38*x39;
    double x41 = x16 - x19 - x20 - x24 - x26 + x28 - x31 - x32 + x33 + x34 + x35 + x9;
    double x42 = x1*x41;
    double x43 = x41*x7;
    double x44 = x1*x10;
    double x45 = x39*x6;
    double x46 = x10*x7;
    double x47 = -0.26000000000000001*x37 + 3.0*x44 + 0.25999999999999995*x45 - 1.0*x46;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 6.0*x3 + x40 - 2.0*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = 3.0*x3 + x40 + 1.0*x42 - 0.33333333333333331*x43 - 1.0*x8;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = 1.1699999999999999*x3 + x47 - 0.38999999999999996*x8;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = -x38*x41*x5 + x40 + 2.0*x42;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = 0.39000000000000001*x42 - 0.12999999999999998*x43 + x47;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = -0.10139999999999999*x37 + 2.3399999999999999*x44 + 0.10139999999999998*x45 - 0.7799999999999998*x46;
}
}
        
static void coder_d6gdn3dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dT3)(T, P);
    double x2 = n1 + n2 + 0.38999999999999996*n3;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = pow(x2, -3);
    double x6 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x7 = 3*(*endmember[1].d3mu0dT3)(T, P);
    double x8 = (*endmember[2].d3mu0dT3)(T, P);
    double x9 = 0.19999999999999998*T - 1;
    double x10 = -x9;
    double x11 = 1.0*sqrt(x10);
    double x12 = x11 - 4;
    double x13 = 0;
    double x14 = 1.2043214999999998*x13/x9;
    double x15 = pow(x10, -3.0/2.0);
    double x16 = (-x12 >= 0. ? 1. : 0.);
    double x17 = 1.2043214999999998*x15*x16;
    double x18 = 0.40144049999999998*x15*((x16)*(x16)*(x16));
    double x19 = 40.14405*T - 200.72024999999999;
    double x20 = pow(x9, -2);
    double x21 = x13*x20;
    double x22 = 0.0029999999999999992*x19*x21;
    double x23 = x16/pow(x10, 5.0/2.0);
    double x24 = 0.0029999999999999996*x19*x23;
    double x25 = x15*0;
    double x26 = 0.0009999999999999998*x19*x25;
    double x27 = fmin(4, x11);
    double x28 = ((x27)*(x27));
    double x29 = 0.60216074999999991*x21*x28;
    double x30 = 0.60216075000000002*x23*x28;
    double x31 = 0.20072024999999999*x25*x28;
    double x32 = 1.2043214999999998*((x16)*(x16))*x20*x27;
    double x33 = x13*x17*x27;
    double x34 = 3*n1*x1 + n2*x7 - n2*(-x14 + x17 + x18 + x22 + x24 - x26 + x29 + x30 - x31 - x32 - x33) + 3*n3*x8;
    double x35 = x34*x6/((x2)*(x2)*(x2)*(x2));
    double x36 = -2.0*x34*x5 + 2.0*x35;
    double x37 = x14 - x17 - x18 - x22 - x24 + x26 - x29 - x30 + x31 + x32 + x33 + x7;
    double x38 = x3*x37;
    double x39 = x3*x8;
    double x40 = -0.77999999999999992*x34*x5 + 0.77999999999999992*x35 + 2.0*x39 - 2.0*x5*x6*x8;
    double x41 = -0.30419999999999997*x34*x5 + 0.30419999999999991*x35 + 1.5600000000000001*x39 - 1.5599999999999996*x5*x6*x8;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 6.0*x1*x5*x6 - x36 - 6.0*x4;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = 4.0*x1*x5*x6 - x36 + 0.66666666666666663*x37*x5*x6 - 0.66666666666666663*x38 - 4.0*x4;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = 1.5599999999999998*x1*x5*x6 - 1.5600000000000001*x4 - x40;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 2.0*x1*x5*x6 - x36 + 1.3333333333333333*x37*x5*x6 - 1.3333333333333333*x38 - 2.0*x4;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = 0.77999999999999992*x1*x5*x6 + 0.25999999999999995*x37*x5*x6 - 0.26000000000000001*x38 - 0.78000000000000003*x4 - x40;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 0.30419999999999991*x1*x5*x6 - 0.30419999999999991*x4 - x41;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = -x36 + 2.0*x37*x5*x6 - 2.0*x38;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = 0.51999999999999991*x37*x5*x6 - 0.52000000000000002*x38 - x40;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = 0.10139999999999998*x37*x5*x6 - 0.10139999999999999*x38 - x41;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = 0.11863799999999997*x34*x5 - 0.11863799999999997*x35 - 0.91259999999999974*x39 + 0.91259999999999974*x5*x6*x8;
}
}
        
static double coder_d3gdt2dp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P) + n3*(*endmember[2].d3mu0dT2dP)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 0.39000000000000001*n3)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d3mu0dT2dP)(T, P);
    double x6 = (*endmember[2].d3mu0dT2dP)(T, P);
    double x7 = n1*x0 + n2*x5 + n3*x6;
    double x8 = x2*x7;
    double x9 = x3*x7/((n1 + n2 + 0.38999999999999996*n3)*(n1 + n2 + 0.38999999999999996*n3));
    double x10 = 3.0*x8 - 1.0*x9;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x10;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x10 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x4*x6 + 1.1699999999999999*x8 - 0.38999999999999996*x9;
}
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = x1*x2;
    double x4 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x5 = 2.0*x4;
    double x6 = n1 + n2 + 0.38999999999999996*n3;
    double x7 = pow(x6, -2);
    double x8 = x1*x7;
    double x9 = (*endmember[1].d3mu0dT2dP)(T, P);
    double x10 = (*endmember[2].d3mu0dT2dP)(T, P);
    double x11 = n1*x1 + n2*x9 + n3*x10;
    double x12 = x11*x7;
    double x13 = x11/((x6)*(x6)*(x6));
    double x14 = -2.0*x12 + x13*x5;
    double x15 = 3.0*x2;
    double x16 = 1.0*x4;
    double x17 = x16*x7;
    double x18 = 0.38999999999999996*x4;
    double x19 = x13*x4;
    double x20 = x10*x15 - x10*x17 - 0.78000000000000003*x12 + 0.77999999999999992*x19;
    double x21 = x2*x9;
    double x22 = x7*x9;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x14 + 6.0*x3 - x5*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x14 + x15*x9 - x16*x8 - x17*x9 + 3.0*x3;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = -x18*x8 + x20 + 1.1699999999999999*x3;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x14 + 6.0*x21 - x22*x5;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -x18*x22 + x20 + 1.1699999999999999*x21;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 2.3399999999999999*x10*x2 - 0.77999999999999992*x10*x4*x7 - 0.30419999999999991*x12 + 0.30419999999999991*x19;
}
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x2 = n1 + n2 + 0.38999999999999996*n3;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = pow(x2, -3);
    double x6 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x7 = (*endmember[1].d3mu0dT2dP)(T, P);
    double x8 = (*endmember[2].d3mu0dT2dP)(T, P);
    double x9 = n1*x1 + n2*x7 + n3*x8;
    double x10 = x9/((x2)*(x2)*(x2)*(x2));
    double x11 = 6.0*x10*x6 - 6.0*x5*x9;
    double x12 = 2.0*x3;
    double x13 = x10*x6;
    double x14 = x12*x8 + 2.3399999999999999*x13 - 2.0*x5*x6*x8 - 2.3399999999999999*x5*x9;
    double x15 = x3*x7;
    double x16 = x3*x8;
    double x17 = 0.91259999999999986*x13 + 1.5600000000000001*x16 - 1.5599999999999998*x5*x6*x8 - 0.91259999999999986*x5*x9;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 6.0*x1*x5*x6 - x11 - 6.0*x4;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = 4.0*x1*x5*x6 - x11 - x12*x7 - 4.0*x4 + 2.0*x5*x6*x7;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = 1.5599999999999998*x1*x5*x6 - x14 - 1.5600000000000001*x4;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 2.0*x1*x5*x6 - x11 - 4.0*x15 - 2.0*x4 + 4.0*x5*x6*x7;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = 0.77999999999999992*x1*x5*x6 - x14 - 0.78000000000000003*x15 - 0.78000000000000003*x4 + 0.77999999999999992*x5*x6*x7;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 0.30419999999999991*x1*x5*x6 - x17 - 0.30419999999999991*x4;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = -x11 - 6.0*x15 + 6.0*x5*x6*x7;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = -x14 - 1.5600000000000001*x15 + 1.5599999999999998*x5*x6*x7;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -0.30419999999999991*x15 - x17 + 0.30419999999999991*x5*x6*x7;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = -0.3559139999999999*x13 - 0.91259999999999986*x16 + 0.91259999999999974*x5*x6*x8 + 0.35591399999999984*x5*x9;
}
}
        
static double coder_d3gdtdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P) + n3*(*endmember[2].d3mu0dTdP2)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 0.39000000000000001*n3)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d3mu0dTdP2)(T, P);
    double x6 = (*endmember[2].d3mu0dTdP2)(T, P);
    double x7 = n1*x0 + n2*x5 + n3*x6;
    double x8 = x2*x7;
    double x9 = x3*x7/((n1 + n2 + 0.38999999999999996*n3)*(n1 + n2 + 0.38999999999999996*n3));
    double x10 = 3.0*x8 - 1.0*x9;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x10;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x10 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x4*x6 + 1.1699999999999999*x8 - 0.38999999999999996*x9;
}
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = x1*x2;
    double x4 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x5 = 2.0*x4;
    double x6 = n1 + n2 + 0.38999999999999996*n3;
    double x7 = pow(x6, -2);
    double x8 = x1*x7;
    double x9 = (*endmember[1].d3mu0dTdP2)(T, P);
    double x10 = (*endmember[2].d3mu0dTdP2)(T, P);
    double x11 = n1*x1 + n2*x9 + n3*x10;
    double x12 = x11*x7;
    double x13 = x11/((x6)*(x6)*(x6));
    double x14 = -2.0*x12 + x13*x5;
    double x15 = 3.0*x2;
    double x16 = 1.0*x4;
    double x17 = x16*x7;
    double x18 = 0.38999999999999996*x4;
    double x19 = x13*x4;
    double x20 = x10*x15 - x10*x17 - 0.78000000000000003*x12 + 0.77999999999999992*x19;
    double x21 = x2*x9;
    double x22 = x7*x9;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x14 + 6.0*x3 - x5*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x14 + x15*x9 - x16*x8 - x17*x9 + 3.0*x3;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = -x18*x8 + x20 + 1.1699999999999999*x3;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x14 + 6.0*x21 - x22*x5;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -x18*x22 + x20 + 1.1699999999999999*x21;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 2.3399999999999999*x10*x2 - 0.77999999999999992*x10*x4*x7 - 0.30419999999999991*x12 + 0.30419999999999991*x19;
}
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x2 = n1 + n2 + 0.38999999999999996*n3;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = pow(x2, -3);
    double x6 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x7 = (*endmember[1].d3mu0dTdP2)(T, P);
    double x8 = (*endmember[2].d3mu0dTdP2)(T, P);
    double x9 = n1*x1 + n2*x7 + n3*x8;
    double x10 = x9/((x2)*(x2)*(x2)*(x2));
    double x11 = 6.0*x10*x6 - 6.0*x5*x9;
    double x12 = 2.0*x3;
    double x13 = x10*x6;
    double x14 = x12*x8 + 2.3399999999999999*x13 - 2.0*x5*x6*x8 - 2.3399999999999999*x5*x9;
    double x15 = x3*x7;
    double x16 = x3*x8;
    double x17 = 0.91259999999999986*x13 + 1.5600000000000001*x16 - 1.5599999999999998*x5*x6*x8 - 0.91259999999999986*x5*x9;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 6.0*x1*x5*x6 - x11 - 6.0*x4;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = 4.0*x1*x5*x6 - x11 - x12*x7 - 4.0*x4 + 2.0*x5*x6*x7;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = 1.5599999999999998*x1*x5*x6 - x14 - 1.5600000000000001*x4;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 2.0*x1*x5*x6 - x11 - 4.0*x15 - 2.0*x4 + 4.0*x5*x6*x7;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = 0.77999999999999992*x1*x5*x6 - x14 - 0.78000000000000003*x15 - 0.78000000000000003*x4 + 0.77999999999999992*x5*x6*x7;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 0.30419999999999991*x1*x5*x6 - x17 - 0.30419999999999991*x4;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = -x11 - 6.0*x15 + 6.0*x5*x6*x7;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = -x14 - 1.5600000000000001*x15 + 1.5599999999999998*x5*x6*x7;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -0.30419999999999991*x15 - x17 + 0.30419999999999991*x5*x6*x7;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = -0.3559139999999999*x13 - 0.91259999999999986*x16 + 0.91259999999999974*x5*x6*x8 + 0.35591399999999984*x5*x9;
}
}
        
static double coder_d3gdp3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P) + n3*(*endmember[2].d3mu0dP3)(T, P);

if (T >= 5.0) {
   result = x0;
}
else {
   result = 3*x0*(1.0*n1 + 1.0*n2 + 0.39000000000000001*n3)/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
}
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].d3mu0dP3)(T, P);
    double x1 = T >= 5.0;
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x4 = 3*x2*x3;
    double x5 = (*endmember[1].d3mu0dP3)(T, P);
    double x6 = (*endmember[2].d3mu0dP3)(T, P);
    double x7 = n1*x0 + n2*x5 + n3*x6;
    double x8 = x2*x7;
    double x9 = x3*x7/((n1 + n2 + 0.38999999999999996*n3)*(n1 + n2 + 0.38999999999999996*n3));
    double x10 = 3.0*x8 - 1.0*x9;

if (x1) {
   result[0] = x0;
}
else {
   result[0] = x0*x4 + x10;
}
if (x1) {
   result[1] = x5;
}
else {
   result[1] = x10 + x4*x5;
}
if (x1) {
   result[2] = x6;
}
else {
   result[2] = x4*x6 + 1.1699999999999999*x8 - 0.38999999999999996*x9;
}
}
        
static void coder_d5gdn2dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dP3)(T, P);
    double x2 = 1.0/(3.0*n1 + 3.0*n2 + 1.1699999999999999*n3);
    double x3 = x1*x2;
    double x4 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x5 = 2.0*x4;
    double x6 = n1 + n2 + 0.38999999999999996*n3;
    double x7 = pow(x6, -2);
    double x8 = x1*x7;
    double x9 = (*endmember[1].d3mu0dP3)(T, P);
    double x10 = (*endmember[2].d3mu0dP3)(T, P);
    double x11 = n1*x1 + n2*x9 + n3*x10;
    double x12 = x11*x7;
    double x13 = x11/((x6)*(x6)*(x6));
    double x14 = -2.0*x12 + x13*x5;
    double x15 = 3.0*x2;
    double x16 = 1.0*x4;
    double x17 = x16*x7;
    double x18 = 0.38999999999999996*x4;
    double x19 = x13*x4;
    double x20 = x10*x15 - x10*x17 - 0.78000000000000003*x12 + 0.77999999999999992*x19;
    double x21 = x2*x9;
    double x22 = x7*x9;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = x14 + 6.0*x3 - x5*x8;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = x14 + x15*x9 - x16*x8 - x17*x9 + 3.0*x3;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = -x18*x8 + x20 + 1.1699999999999999*x3;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = x14 + 6.0*x21 - x22*x5;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = -x18*x22 + x20 + 1.1699999999999999*x21;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 2.3399999999999999*x10*x2 - 0.77999999999999992*x10*x4*x7 - 0.30419999999999991*x12 + 0.30419999999999991*x19;
}
}
        
static void coder_d6gdn3dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = T >= 5.0;
    double x1 = (*endmember[0].d3mu0dP3)(T, P);
    double x2 = n1 + n2 + 0.38999999999999996*n3;
    double x3 = pow(x2, -2);
    double x4 = x1*x3;
    double x5 = pow(x2, -3);
    double x6 = 1.0*n1 + 1.0*n2 + 0.39000000000000001*n3;
    double x7 = (*endmember[1].d3mu0dP3)(T, P);
    double x8 = (*endmember[2].d3mu0dP3)(T, P);
    double x9 = n1*x1 + n2*x7 + n3*x8;
    double x10 = x9/((x2)*(x2)*(x2)*(x2));
    double x11 = 6.0*x10*x6 - 6.0*x5*x9;
    double x12 = 2.0*x3;
    double x13 = x10*x6;
    double x14 = x12*x8 + 2.3399999999999999*x13 - 2.0*x5*x6*x8 - 2.3399999999999999*x5*x9;
    double x15 = x3*x7;
    double x16 = x3*x8;
    double x17 = 0.91259999999999986*x13 + 1.5600000000000001*x16 - 1.5599999999999998*x5*x6*x8 - 0.91259999999999986*x5*x9;

if (x0) {
   result[0] = 0;
}
else {
   result[0] = 6.0*x1*x5*x6 - x11 - 6.0*x4;
}
if (x0) {
   result[1] = 0;
}
else {
   result[1] = 4.0*x1*x5*x6 - x11 - x12*x7 - 4.0*x4 + 2.0*x5*x6*x7;
}
if (x0) {
   result[2] = 0;
}
else {
   result[2] = 1.5599999999999998*x1*x5*x6 - x14 - 1.5600000000000001*x4;
}
if (x0) {
   result[3] = 0;
}
else {
   result[3] = 2.0*x1*x5*x6 - x11 - 4.0*x15 - 2.0*x4 + 4.0*x5*x6*x7;
}
if (x0) {
   result[4] = 0;
}
else {
   result[4] = 0.77999999999999992*x1*x5*x6 - x14 - 0.78000000000000003*x15 - 0.78000000000000003*x4 + 0.77999999999999992*x5*x6*x7;
}
if (x0) {
   result[5] = 0;
}
else {
   result[5] = 0.30419999999999991*x1*x5*x6 - x17 - 0.30419999999999991*x4;
}
if (x0) {
   result[6] = 0;
}
else {
   result[6] = -x11 - 6.0*x15 + 6.0*x5*x6*x7;
}
if (x0) {
   result[7] = 0;
}
else {
   result[7] = -x14 - 1.5600000000000001*x15 + 1.5599999999999998*x5*x6*x7;
}
if (x0) {
   result[8] = 0;
}
else {
   result[8] = -0.30419999999999991*x15 - x17 + 0.30419999999999991*x5*x6*x7;
}
if (x0) {
   result[9] = 0;
}
else {
   result[9] = -0.3559139999999999*x13 - 0.91259999999999986*x16 + 0.91259999999999974*x5*x6*x8 + 0.35591399999999984*x5*x9;
}
}
        
static double coder_s(double T, double P, double n[3]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[3]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[3]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[3]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[3]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[3]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

