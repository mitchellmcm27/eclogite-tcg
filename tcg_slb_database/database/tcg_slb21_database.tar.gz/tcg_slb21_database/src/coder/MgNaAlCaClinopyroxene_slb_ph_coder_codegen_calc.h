#include <math.h>


static double coder_g(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = 1.0*n1;
    double x1 = 1.0*n2;
    double x2 = 1.0*n3 + x0 + x1;
    double x3 = 3.5*n4 + x2;
    double x4 = n1 + n3;
    double x5 = n2 + n4;
    double x6 = 1.0/(x4 + x5);
    double x7 = 1.0*n4;
    double x8 = n3 + n4;

result = (0.055555555555555552*n1*(222300.0*n3 + 364000.0*n4) + 7777.7777777777774*n2*n4 + 0.055555555555555552*n3*(222300.0*n1 + 345800.0*n4) + 0.038408779149519887*n4*(526500.0*n1 + 202500.0*n2 + 500175.0*n3) + x3*(8.3144626181532395*T*(x0*log(n1*x6) + x1*log(n2*x6) + 1.0*x4*log(x4*x6) + 1.0*x5*log(x5*x6) + x7*(log(n4*x6) - 0.69314718055994495) + 1.0*x8*log(x6*x8) + (2.0*n1 + 2.0*n2 + 2.0*n3 + x7)*log(x6*(0.5*n4 + x2))) + n1*(*endmember[0].mu0)(T, P) + n2*(*endmember[1].mu0)(T, P) + n3*(*endmember[2].mu0)(T, P) + n4*(*endmember[3].mu0)(T, P)))/x3;
    return result;
}
        
static void coder_dgdn(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = 3.5*n4;
    double x1 = 1.0*n1;
    double x2 = 1.0*n2;
    double x3 = 1.0*n3;
    double x4 = x1 + x2 + x3;
    double x5 = x0 + x4;
    double x6 = (*endmember[0].mu0)(T, P);
    double x7 = n1*x6;
    double x8 = (*endmember[1].mu0)(T, P);
    double x9 = n2*x8;
    double x10 = (*endmember[2].mu0)(T, P);
    double x11 = n3*x10;
    double x12 = (*endmember[3].mu0)(T, P);
    double x13 = n1 + n3;
    double x14 = n2 + n4;
    double x15 = x13 + x14;
    double x16 = 1.0/x15;
    double x17 = log(n1*x16);
    double x18 = log(n2*x16);
    double x19 = log(n4*x16);
    double x20 = 1.0*n4;
    double x21 = x13*x16;
    double x22 = 1.0*log(x21);
    double x23 = 1.0*log(x14*x16);
    double x24 = n3 + n4;
    double x25 = 1.0*log(x16*x24);
    double x26 = 2.0*n1 + 2.0*n2 + 2.0*n3 + x20;
    double x27 = 0.5*n4 + x4;
    double x28 = log(x16*x27);
    double x29 = x1*x17 + x13*x22 + x14*x23 + x18*x2 + x20*(x19 - 0.69314718055994495) + x24*x25 + x26*x28;
    double x30 = 8.3144626181532395*T;
    double x31 = x29*x30;
    double x32 = (0.055555555555555552*n1*(222300.0*n3 + 364000.0*n4) + 7777.7777777777774*n2*n4 + 0.055555555555555552*n3*(222300.0*n1 + 345800.0*n4) + 0.038408779149519887*n4*(526500.0*n1 + 202500.0*n2 + 500175.0*n3) + x5*(n4*x12 + x11 + x31 + x7 + x9))/((0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4)*(0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4));
    double x33 = -0.081632653061224483*x32;
    double x34 = 1.0/x5;
    double x35 = pow(x15, -2);
    double x36 = -x16;
    double x37 = 1.0*x15;
    double x38 = 2.0*x28;
    double x39 = 1.0*x16;
    double x40 = -n4*x39;
    double x41 = x27*x35;
    double x42 = x15*x26/x27;
    double x43 = x42*(1.0*x16 - x41);
    double x44 = -x24*x39 + x38 + x40 + x43;
    double x45 = -x16*x2;
    double x46 = -x14*x39 + x22 + x37*(-x13*x35 - x36) + x45;
    double x47 = x1*x6 + x10*x3 + x12*x20 + x2*x8 + x31;
    double x48 = -x1*x16;
    double x49 = -1.0*x21 + x23 + x37*(-x14*x35 - x36) + x48;
    double x50 = x25 + x37*(-x24*x35 - x36);

result[0] = x33 + x34*(24700.0*n3 + 40444.444444444438*n4 + x47 + x5*(x30*(1.0*x17 + x37*(-n1*x35 - x36) + x44 + x46) + x6));
result[1] = x33 + x34*(15555.555555555555*n4 + x47 + x5*(x30*(1.0*x18 + x37*(-n2*x35 - x36) + x44 + x49) + x8));
result[2] = x33 + x34*(24700.0*n1 + 38422.222222222219*n4 + x47 + x5*(x10 + x30*(x38 + x40 + x43 + x46 + x48 + x50)));
result[3] = -0.2857142857142857*x32 + x34*(29.100619163536336*T*x29 + 40444.444444444438*n1 + 15555.555555555555*n2 + 38422.222222222219*n3 + x0*x12 + 3.5*x11 + x5*(x12 + x30*(1.0*x19 + 1.0*x28 + x37*(-n4*x35 - x36) + x42*(0.5*x16 - x41) + x45 + x49 + x50 - 0.69314718055994495)) + 3.5*x7 + 3.5*x9);
}
        
static void coder_d2gdn2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4;
    double x1 = 3.5*n4;
    double x2 = 1.0*n1;
    double x3 = 1.0*n2;
    double x4 = 1.0*n3;
    double x5 = x2 + x3 + x4;
    double x6 = x1 + x5;
    double x7 = (*endmember[0].mu0)(T, P);
    double x8 = n1*x7;
    double x9 = (*endmember[1].mu0)(T, P);
    double x10 = n2*x9;
    double x11 = (*endmember[2].mu0)(T, P);
    double x12 = n3*x11;
    double x13 = (*endmember[3].mu0)(T, P);
    double x14 = n1 + n3;
    double x15 = n2 + n4;
    double x16 = x14 + x15;
    double x17 = 1.0/x16;
    double x18 = log(n1*x17);
    double x19 = log(n2*x17);
    double x20 = log(n4*x17);
    double x21 = 1.0*n4;
    double x22 = x14*x17;
    double x23 = 1.0*log(x22);
    double x24 = 1.0*log(x15*x17);
    double x25 = n3 + n4;
    double x26 = 1.0*log(x17*x25);
    double x27 = 2.0*n1 + 2.0*n2 + 2.0*n3 + x21;
    double x28 = 0.5*n4 + x5;
    double x29 = log(x17*x28);
    double x30 = x14*x23 + x15*x24 + x18*x2 + x19*x3 + x21*(x20 - 0.69314718055994495) + x25*x26 + x27*x29;
    double x31 = 8.3144626181532395*T;
    double x32 = x30*x31;
    double x33 = (0.055555555555555552*n1*(222300.0*n3 + 364000.0*n4) + 7777.7777777777774*n2*n4 + 0.055555555555555552*n3*(222300.0*n1 + 345800.0*n4) + 0.038408779149519887*n4*(526500.0*n1 + 202500.0*n2 + 500175.0*n3) + x6*(n4*x13 + x10 + x12 + x32 + x8))/((x0)*(x0)*(x0));
    double x34 = 0.046647230320699701*x33;
    double x35 = pow(x0, -2);
    double x36 = pow(x16, -2);
    double x37 = -x17;
    double x38 = 1.0*x16;
    double x39 = x38*(-n1*x36 - x37);
    double x40 = 2.0*x29;
    double x41 = 1.0*x17;
    double x42 = -n4*x41;
    double x43 = -x41;
    double x44 = x28*x36;
    double x45 = -x43 - x44;
    double x46 = 1.0/x28;
    double x47 = x27*x46;
    double x48 = x45*x47;
    double x49 = x16*x48;
    double x50 = -x25*x41 + x40 + x42 + x49;
    double x51 = x14*x36;
    double x52 = x38*(-x37 - x51);
    double x53 = -x17*x3;
    double x54 = -x15*x41 + x23 + x52 + x53;
    double x55 = T*(1.0*x18 + x39 + x50 + x54);
    double x56 = 8.3144626181532395*x55;
    double x57 = x11*x4 + x13*x21 + x2*x7 + x3*x9 + x32;
    double x58 = x35*(24700.0*n3 + 40444.444444444438*n4 + x57 + x6*(x56 + x7));
    double x59 = 1.0/x6;
    double x60 = 2.0*x17;
    double x61 = -2*x36;
    double x62 = 2/((x16)*(x16)*(x16));
    double x63 = n1*x62;
    double x64 = x2*x36;
    double x65 = -x64;
    double x66 = x45*x46;
    double x67 = 4.0*x16*x66;
    double x68 = x28*x62;
    double x69 = x16*x47;
    double x70 = x69*(-2.0*x36 + x68);
    double x71 = x27/((x28)*(x28));
    double x72 = x45*x71;
    double x73 = -x38*x72;
    double x74 = x21*x36;
    double x75 = x25*x36;
    double x76 = 1.0*x75;
    double x77 = x48 + x74 + x76;
    double x78 = x67 + x70 + x73 + x77;
    double x79 = x3*x36;
    double x80 = x15*x36;
    double x81 = 1.0*x80;
    double x82 = 1.0*x51;
    double x83 = -x82;
    double x84 = x14*x62;
    double x85 = x38*(x61 + x84) + x79 + x81 + x83 + x52/x14;
    double x86 = x65 + x78 + x85;
    double x87 = x31*x6;
    double x88 = -x60 + x78;
    double x89 = -x36;
    double x90 = x38*(x63 + x89);
    double x91 = x38*(x84 + x89) + x79 + x81 + x83;
    double x92 = x65 + x90 + x91;
    double x93 = x38*(-n2*x36 - x37);
    double x94 = x38*(-x37 - x80);
    double x95 = -x17*x2;
    double x96 = -1.0*x22 + x24 + x94 + x95;
    double x97 = 1.0*x19 + x50 + x93 + x96;
    double x98 = x31*x97;
    double x99 = 1.0*x9 + x98;
    double x100 = x56 + 1.0*x7;
    double x101 = 15555.555555555555*n4 + x57 + x6*(x9 + x98);
    double x102 = 0.081632653061224483*x35;
    double x103 = -x101*x102;
    double x104 = x34 - 0.081632653061224483*x58;
    double x105 = x38*(-x37 - x75);
    double x106 = x105 + x26;
    double x107 = x106 + x40 + x42 + x49 + x54 + x95;
    double x108 = x107*x31;
    double x109 = x108 + 1.0*x11;
    double x110 = 24700.0*n1 + 38422.222222222219*n4 + x57 + x6*(x108 + x11);
    double x111 = -x102*x110;
    double x112 = 3.0*x17;
    double x113 = 0.5*x17 - x44;
    double x114 = x113*x16;
    double x115 = 2.0*x114*x46;
    double x116 = x115 - 0.5*x16*x72 + x38*x66 + x69*(-1.5*x36 + x68);
    double x117 = x116 + x77;
    double x118 = x38*(-n4*x36 - x37);
    double x119 = x113*x47;
    double x120 = x106 + x118 + x119*x16 + 1.0*x20 + 1.0*x29 + x53 + x96 - 0.69314718055994495;
    double x121 = x120*x31;
    double x122 = x121 + 1.0*x13;
    double x123 = 29.100619163536336*T;
    double x124 = 40444.444444444438*n1 + 15555.555555555555*n2 + 38422.222222222219*n3 + x1*x13 + 3.5*x10 + 3.5*x12 + x123*x30 + x6*(x121 + x13) + 3.5*x8;
    double x125 = -x102*x124 + 0.16326530612244897*x33;
    double x126 = x101*x35;
    double x127 = 16.628925236306479*T;
    double x128 = n2*x62;
    double x129 = x64 - x81 + x82;
    double x130 = x129 - x79;
    double x131 = x15*x62;
    double x132 = x38*(x131 + x61) + x94/x15;
    double x133 = x130 + x38*(x128 + x89);
    double x134 = x110*x35;
    double x135 = x105/x25 + x38*(x25*x62 + x61) - x76;
    double x136 = x135 + x48 + x64 + x74;

result[0] = x34 - 0.16326530612244897*x58 + x59*(16.628925236306479*x55 + 2.0*x7 + x87*(x38*(x61 + x63) + x60 + x86 + x39/n1));
result[1] = x103 + x104 + x59*(x100 + x87*(x88 + x92) + x99);
result[2] = x104 + x111 + x59*(x100 + x109 + x87*(x86 + x90) + 24700.0);
result[3] = x125 - 0.2857142857142857*x58 + x59*(x122 + 29.100619163536336*x55 + 3.5*x7 + x87*(-x112 + x117 + x92) + 40444.444444444438);
result[4] = -0.16326530612244897*x126 + x34 + x59*(x127*x97 + x87*(x130 + x132 + x38*(x128 + x61) + x60 + x78 + x93/n2) + 2.0*x9);
result[5] = x103 + x111 + x34 + x59*(x109 + x87*(x133 + x38*(x131 + x89) + x88) + x99);
result[6] = x125 - 0.2857142857142857*x126 + x59*(x122 + x123*x97 + x87*(x117 + x132 + x133 + x43) + 3.5*x9 + 15555.555555555555);
result[7] = -0.16326530612244897*x134 + x34 + x59*(x107*x127 + 2.0*x11 + x87*(x136 + x60 + x67 + x70 + x73 + x85));
result[8] = x125 - 0.2857142857142857*x134 + x59*(x107*x123 + 3.5*x11 + x122 + x87*(x116 + x136 + x43 + x91) + 38422.222222222219);
result[9] = -0.5714285714285714*x124*x35 + 0.5714285714285714*x33 + x59*(58.201238327072673*T*x120 + 7.0*x13 + x87*(x112 - 0.5*x114*x71 + x115 + x119 + x129 + x132 + x135 + x38*(n4*x62 + x61) + x69*(-1.0*x36 + x68) - x74 + x79 + x118/n4));
}
        
static void coder_d3gdn3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = 0.2857142857142857*n1 + 0.2857142857142857*n2 + 0.2857142857142857*n3 + n4;
    double x1 = 3.5*n4;
    double x2 = 1.0*n1;
    double x3 = 1.0*n2;
    double x4 = 1.0*n3;
    double x5 = x2 + x3 + x4;
    double x6 = x1 + x5;
    double x7 = (*endmember[0].mu0)(T, P);
    double x8 = n1*x7;
    double x9 = (*endmember[1].mu0)(T, P);
    double x10 = n2*x9;
    double x11 = (*endmember[2].mu0)(T, P);
    double x12 = n3*x11;
    double x13 = (*endmember[3].mu0)(T, P);
    double x14 = n2 + n4;
    double x15 = n1 + n3;
    double x16 = x14 + x15;
    double x17 = 1.0/x16;
    double x18 = log(n1*x17);
    double x19 = log(n2*x17);
    double x20 = log(n4*x17);
    double x21 = 1.0*n4;
    double x22 = 1.0*log(x15*x17);
    double x23 = 1.0*log(x14*x17);
    double x24 = n3 + n4;
    double x25 = 1.0*log(x17*x24);
    double x26 = 2.0*n1;
    double x27 = 2.0*n2;
    double x28 = 2.0*n3 + x21 + x26 + x27;
    double x29 = 0.5*n4 + x5;
    double x30 = log(x17*x29);
    double x31 = x14*x23 + x15*x22 + x18*x2 + x19*x3 + x21*(x20 - 0.69314718055994495) + x24*x25 + x28*x30;
    double x32 = 8.3144626181532395*T;
    double x33 = x31*x32;
    double x34 = (0.055555555555555552*n1*(222300.0*n3 + 364000.0*n4) + 7777.7777777777774*n2*n4 + 0.055555555555555552*n3*(222300.0*n1 + 345800.0*n4) + 0.038408779149519887*n4*(526500.0*n1 + 202500.0*n2 + 500175.0*n3) + x6*(n4*x13 + x10 + x12 + x33 + x8))/((x0)*(x0)*(x0)*(x0));
    double x35 = 0.039983340274885454*x34;
    double x36 = -x35;
    double x37 = pow(x0, -3);
    double x38 = pow(x16, -2);
    double x39 = -x17;
    double x40 = -n1*x38 - x39;
    double x41 = 1.0*x16;
    double x42 = x40*x41;
    double x43 = 2.0*x30;
    double x44 = 1.0*x17;
    double x45 = -n4*x44;
    double x46 = 1.0/x29;
    double x47 = -x44;
    double x48 = x29*x38;
    double x49 = -x47 - x48;
    double x50 = x46*x49;
    double x51 = x28*x50;
    double x52 = x16*x51;
    double x53 = -x24*x44 + x43 + x45 + x52;
    double x54 = x15*x38;
    double x55 = -x39 - x54;
    double x56 = x41*x55;
    double x57 = -x17*x3;
    double x58 = -x14*x44 + x22 + x56 + x57;
    double x59 = 1.0*x18 + x42 + x53 + x58;
    double x60 = x32*x59;
    double x61 = x11*x4 + x13*x21 + x2*x7 + x3*x9 + x33;
    double x62 = 24700.0*n3 + 40444.444444444438*n4 + x6*(x60 + x7) + x61;
    double x63 = x37*x62;
    double x64 = pow(x0, -2);
    double x65 = 16.628925236306479*T;
    double x66 = 2.0*x17;
    double x67 = -2*x38;
    double x68 = pow(x16, -3);
    double x69 = 2*x68;
    double x70 = n1*x69;
    double x71 = x41*(x67 + x70);
    double x72 = 1.0/n1;
    double x73 = x40*x72;
    double x74 = x2*x38;
    double x75 = -x74;
    double x76 = 4.0*x16;
    double x77 = x50*x76;
    double x78 = 2.0*x38;
    double x79 = x29*x69;
    double x80 = -x78 + x79;
    double x81 = x28*x46;
    double x82 = x80*x81;
    double x83 = x16*x82;
    double x84 = pow(x29, -2);
    double x85 = x49*x84;
    double x86 = x28*x85;
    double x87 = -x41*x86;
    double x88 = x21*x38;
    double x89 = x24*x38;
    double x90 = 1.0*x89;
    double x91 = x51 + x88 + x90;
    double x92 = x77 + x83 + x87 + x91;
    double x93 = x3*x38;
    double x94 = x14*x38;
    double x95 = 1.0*x94;
    double x96 = 1.0*x54;
    double x97 = -x96;
    double x98 = x15*x69;
    double x99 = x41*(x67 + x98);
    double x100 = 1.0/x15;
    double x101 = x100*x55;
    double x102 = x101*x41 + x93 + x95 + x97 + x99;
    double x103 = x102 + x75 + x92;
    double x104 = T*(x103 + x41*x73 + x66 + x71);
    double x105 = 8.3144626181532395*x104;
    double x106 = x64*(x105*x6 + x59*x65 + 2.0*x7);
    double x107 = 1.0/x6;
    double x108 = -6*x68;
    double x109 = 6/((x16)*(x16)*(x16)*(x16));
    double x110 = n1*x109;
    double x111 = 4.0*x68;
    double x112 = n1*x111;
    double x113 = 2.0*x68;
    double x114 = -n4*x113;
    double x115 = -x113*x24 + x114;
    double x116 = x112 + x115 + 1.0*x73;
    double x117 = -8.0*x38;
    double x118 = x109*x15;
    double x119 = -x27*x68;
    double x120 = x111*x15 - x113*x14 + x119;
    double x121 = 1.0*x101;
    double x122 = 6.0*x16;
    double x123 = x46*x80;
    double x124 = x109*x29;
    double x125 = x16*x81;
    double x126 = 2.0*x16;
    double x127 = x126*x28;
    double x128 = pow(x29, -3);
    double x129 = x128*x49;
    double x130 = x80*x84;
    double x131 = x122*x123 - x122*x85 + x125*(-x124 + 6.0*x68) + x127*x129 - x127*x130 + 6.0*x50 + 2*x82 - 2.0*x86;
    double x132 = x121 + x131;
    double x133 = x100*x99 + x120 + x132 + x41*(-x108 - x118) - x56/((x15)*(x15));
    double x134 = x117 + x133;
    double x135 = x32*x6;
    double x136 = -x66 + x92;
    double x137 = -x38;
    double x138 = x41*(x137 + x70);
    double x139 = x41*(x137 + x98);
    double x140 = x139 + x93 + x95 + x97;
    double x141 = x138 + x140 + x75;
    double x142 = x136 + x141;
    double x143 = x142*x65;
    double x144 = 4.0*x38;
    double x145 = -x144;
    double x146 = x100*x139;
    double x147 = -4*x68;
    double x148 = x120 + x41*(-x118 - x147);
    double x149 = x146 + x148;
    double x150 = x116 + x138*x72 + x41*(-x110 - x147);
    double x151 = x149 + x150;
    double x152 = -n2*x38 - x39;
    double x153 = x152*x41;
    double x154 = -x39 - x94;
    double x155 = x154*x41;
    double x156 = -x17*x2;
    double x157 = -x15*x44 + x155 + x156 + x23;
    double x158 = x153 + x157 + 1.0*x19 + x53;
    double x159 = x158*x32;
    double x160 = 15555.555555555555*n4 + x6*(x159 + x9) + x61;
    double x161 = -0.046647230320699701*x160*x37;
    double x162 = x142*x32;
    double x163 = x159 + 1.0*x9;
    double x164 = x60 + 1.0*x7;
    double x165 = x162*x6 + x163 + x164;
    double x166 = 0.16326530612244897*x64;
    double x167 = x165*x166 + x35;
    double x168 = 0.081632653061224483*x106 - 0.093294460641399402*x37*x62;
    double x169 = x103 + x138;
    double x170 = x169*x65;
    double x171 = -x39 - x89;
    double x172 = x171*x41;
    double x173 = x172 + x25;
    double x174 = x156 + x173 + x43 + x45 + x52 + x58;
    double x175 = x174*x32;
    double x176 = 24700.0*n1 + 38422.222222222219*n4 + x6*(x11 + x175) + x61;
    double x177 = -0.046647230320699701*x176*x37;
    double x178 = x169*x32;
    double x179 = 1.0*x11 + x175;
    double x180 = x164 + x178*x6 + x179 + 24700.0;
    double x181 = x166*x180 + x35;
    double x182 = 3.0*x17;
    double x183 = 0.5*x17 - x48;
    double x184 = x183*x46;
    double x185 = 2.0*x184;
    double x186 = x16*x185;
    double x187 = -1.5*x38 + x79;
    double x188 = x187*x81;
    double x189 = 0.5*x16;
    double x190 = x16*x188 + x186 - x189*x86 + x41*x50;
    double x191 = x190 + x91;
    double x192 = x141 - x182 + x191;
    double x193 = 3.0*x38;
    double x194 = -x193;
    double x195 = x28*x41;
    double x196 = x195*x84;
    double x197 = -x187*x196;
    double x198 = x187*x46;
    double x199 = 3.0*x16;
    double x200 = x189*x28;
    double x201 = x123*x41 + x125*(-x124 + 5.0*x68) + x129*x195 - x130*x200 + x188 + x198*x76 - x199*x85 + 5.0*x50 + x82 - 1.5*x86;
    double x202 = x197 + x201;
    double x203 = x121 + x202;
    double x204 = 29.100619163536336*T;
    double x205 = x192*x32;
    double x206 = -n4*x38 - x39;
    double x207 = x206*x41;
    double x208 = x183*x81;
    double x209 = x157 + x16*x208 + x173 + 1.0*x20 + x207 + 1.0*x30 + x57 - 0.69314718055994495;
    double x210 = x209*x32;
    double x211 = 1.0*x13 + x210;
    double x212 = x204*x59 + x205*x6 + x211 + 3.5*x7 + 40444.444444444438;
    double x213 = 0.1399416909620991*x34;
    double x214 = 40444.444444444438*n1 + 15555.555555555555*n2 + 38422.222222222219*n3 + x1*x13 + 3.5*x10 + 3.5*x12 + x204*x31 + x6*(x13 + x210) + 3.5*x8;
    double x215 = x213 - 0.046647230320699701*x214*x37;
    double x216 = n2*x69;
    double x217 = x41*(x216 + x67);
    double x218 = 1.0/n2;
    double x219 = x74 - x95 + x96;
    double x220 = x219 - x93;
    double x221 = x14*x69;
    double x222 = x41*(x221 + x67);
    double x223 = 1.0/x14;
    double x224 = x155*x223 + x222;
    double x225 = x153*x218 + x217 + x220 + x224 + x66 + x92;
    double x226 = x225*x32;
    double x227 = x131 + x78;
    double x228 = -2*x68;
    double x229 = x112 + x115 + x41*(-x110 - x228);
    double x230 = x120 + x41*(-x118 - x228);
    double x231 = x229 + x230;
    double x232 = -0.046647230320699701*x37*x62;
    double x233 = x158*x65 + x226*x6 + 2.0*x9;
    double x234 = 0.081632653061224483*x64;
    double x235 = -0.093294460641399402*x160*x37 + x233*x234;
    double x236 = 0.046647230320699701*x37;
    double x237 = x41*(x137 + x221);
    double x238 = x41*(x137 + x216);
    double x239 = x220 + x238;
    double x240 = x136 + x237 + x239;
    double x241 = x240*x32;
    double x242 = x163 + x179 + x241*x6;
    double x243 = x148 + x229;
    double x244 = x191 + x224 + x239 + x47;
    double x245 = x244*x32;
    double x246 = x197 + x231;
    double x247 = 0.2857142857142857*x64;
    double x248 = x214*x236;
    double x249 = -x213;
    double x250 = -x212*x234 + x248 + x249 + 0.16326530612244897*x63;
    double x251 = x160*x37;
    double x252 = x158*x204 + x211 + x245*x6 + 3.5*x9 + 15555.555555555555;
    double x253 = -x234*x252 + 0.16326530612244897*x251;
    double x254 = x41*(x24*x69 + x67);
    double x255 = 1.0/x24;
    double x256 = x172*x255 + x254 - x90;
    double x257 = x256 + x51 + x74 + x88;
    double x258 = x102 + x257 + x66 + x77 + x83 + x87;
    double x259 = x258*x32;
    double x260 = 2.0*x11 + x174*x65 + x259*x6;
    double x261 = -0.093294460641399402*x176*x37 + x234*x260;
    double x262 = x140 + x190 + x257 + x47;
    double x263 = x262*x32;
    double x264 = x176*x37;
    double x265 = 3.5*x11 + x174*x204 + x211 + x263*x6 + 38422.222222222219;
    double x266 = -x234*x265 + 0.16326530612244897*x264;
    double x267 = 58.201238327072673*T;
    double x268 = x41*(n4*x69 + x67);
    double x269 = 1.0/n4;
    double x270 = 1.0*x38;
    double x271 = -x270;
    double x272 = x271 + x79;
    double x273 = x183*x84;
    double x274 = x273*x28;
    double x275 = x125*x272 + x182 + x186 - x189*x274 + x207*x269 + x208 + x219 + x224 + x256 + x268 - x88 + x93;
    double x276 = x275*x32;
    double x277 = x272*x46;
    double x278 = x125*(-x124 + 4.0*x68) + x126*x198 + x126*x277 + x129*x200 + x185 + 2*x188 - x273*x41 - x41*x85 + 2.0*x50 - 1.0*x86;
    double x279 = 0.5714285714285714*x64;
    double x280 = 7.0*x13 + x209*x267 + x276*x6;
    double x281 = -0.32653061224489793*x214*x37 + x234*x280 + 0.48979591836734693*x34;
    double x282 = 0.24489795918367346*x64;
    double x283 = 24.943387854459719*T;
    double x284 = n2*x109;
    double x285 = 1.0*x152*x218;
    double x286 = 1.0*x154*x223;
    double x287 = -x26*x68;
    double x288 = x111*x14 - x113*x15 + x287;
    double x289 = n2*x111 + x115 + x288;
    double x290 = x131 + x285 + x286 + x289;
    double x291 = x109*x14;
    double x292 = x222*x223 + x41*(-x108 - x291) - x155/((x14)*(x14));
    double x293 = x240*x65;
    double x294 = x41*(-x147 - x291);
    double x295 = x218*x238 + x41*(-x147 - x284);
    double x296 = x166*x242 + x35;
    double x297 = -5.0*x38;
    double x298 = x286 + x292;
    double x299 = x289 + x41*(-x228 - x284);
    double x300 = x197 + x271 + x278;
    double x301 = x111*x24 + 1.0*x171*x255 - x172/((x24)*(x24)) + x254*x255 + x41*(-x108 - x109*x24);
    double x302 = x114 + x287 + x301;

result[0] = -0.24489795918367346*x106 + x107*(24.943387854459719*x104 + x135*(x116 + x134 + x41*(-x108 - x110) + x71*x72 - x42/((n1)*(n1)))) + x36 + 0.1399416909620991*x63;
result[1] = x107*(x105 + x135*(x132 + x145 + x151) + x143) - x161 - x167 - x168;
result[2] = x107*(x105 + x135*(x133 + x150 - 6.0*x38) + x170) - x168 - x177 - x181;
result[3] = -0.2857142857142857*x106 + x107*(29.100619163536336*x104 + x135*(x151 + x194 + x203) + x192*x65) - x166*x212 - x215 + 0.32653061224489793*x37*x62;
result[4] = x107*(x135*(x227 + x231) + x143 + x226) - x167 - x232 - x235;
result[5] = x107*(x135*(x131 + x243) + x162 + x178 + x241) + x160*x236 - x165*x234 + x176*x236 - x180*x234 - x234*x242 + x36 + 0.046647230320699701*x63;
result[6] = x107*(x135*(x193 + x201 + x246) + x142*x204 + x205 + x245) - x165*x247 + x250 + x253;
result[7] = x107*(x135*(x133 + x194 + x229) + x170 + x259) - x181 - x232 - x261;
result[8] = x107*(x135*(x146 + x203 + x243) + x169*x204 + x205 + x263) - x180*x247 + x250 + x266;
result[9] = x107*(x135*(x144 + x246 + x278) + x192*x267 + x276) - x212*x279 - x281 + 0.5714285714285714*x37*x62;
result[10] = x107*(x135*(x117 + x217*x218 + x290 + x292 + x41*(-x108 - x284) - x153/((n2)*(n2))) + x225*x283) - x233*x282 + 0.1399416909620991*x251 + x36;
result[11] = x107*(x135*(x145 + x223*x237 + x290 + x294 + x295) + x226 + x293) - x177 - x235 - x296;
result[12] = x107*(x135*(x202 + x285 + x289 + x295 + x297 + x298) + x204*x225 + x244*x65) + 0.32653061224489793*x160*x37 - x166*x252 - x215 - x233*x247;
result[13] = x107*(x135*(x227 + x299 + x41*(-x228 - x291)) + x259 + x293) - x161 - x261 - x296;
result[14] = x107*(x135*(x202 + x270 + x294 + x299) + x204*x240 + x245 + x263) - x242*x247 + x248 + x249 + x253 + x266;
result[15] = x107*(x135*(x298 + x299 + x300) + x244*x267 + x276) + 0.5714285714285714*x160*x37 - x252*x279 - x281;
result[16] = x107*(x135*(x134 + x302) + x258*x283) - x260*x282 + 0.1399416909620991*x264 + x36;
result[17] = x107*(x135*(x149 + x203 + x297 + x302) + x204*x258 + x262*x65) - x166*x265 + 0.32653061224489793*x176*x37 - x215 - x247*x260;
result[18] = x107*(x135*(x230 + x300 + x302) + x262*x267 + x276) + 0.5714285714285714*x176*x37 - x265*x279 - x281;
result[19] = x107*(87.301857490609009*T*x275 + x135*(n4*x111 + x119 + x125*(-x124 + 3.0*x68) + x128*x183*x200 - 1.5*x16*x273 + 3.0*x184 - x196*x272 + x199*x277 + 1.0*x206*x269 + x268*x269 + 2*x272*x81 - 1.0*x274 + x288 + x298 + x301 - 12.0*x38 + x41*(-n4*x109 - x108) - x207/((n4)*(n4)))) + 1.7142857142857142*x214*x37 - 0.8571428571428571*x280*x64 - 1.7142857142857142*x34;
}
        
static double coder_dgdt(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = n1 + n3;
    double x1 = n2 + n4;
    double x2 = 1.0/(x0 + x1);
    double x3 = n3 + n4;

result = 8.3144626181532395*n1*log(n1*x2) + n1*(*endmember[0].dmu0dT)(T, P) + 8.3144626181532395*n2*log(n2*x2) + n2*(*endmember[1].dmu0dT)(T, P) + n3*(*endmember[2].dmu0dT)(T, P) + 8.3144626181532395*n4*(log(n4*x2) - 0.69314718055994495) + n4*(*endmember[3].dmu0dT)(T, P) + 8.3144626181532395*x0*log(x0*x2) + 8.3144626181532395*x1*log(x1*x2) + 8.3144626181532395*x3*log(x2*x3) + 8.3144626181532395*(2.0*n1 + 2.0*n2 + 2.0*n3 + 1.0*n4)*log(x2*(1.0*n1 + 1.0*n2 + 1.0*n3 + 0.5*n4));
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = n1 + n3;
    double x1 = n2 + n4;
    double x2 = x0 + x1;
    double x3 = 1.0/x2;
    double x4 = n1*x3;
    double x5 = pow(x2, -2);
    double x6 = -x3;
    double x7 = 8.3144626181532395*x2;
    double x8 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 0.5*n4;
    double x9 = log(x3*x8);
    double x10 = 16.628925236306479*x9;
    double x11 = n4*x3;
    double x12 = -8.3144626181532395*x11;
    double x13 = n3 + n4;
    double x14 = x13*x3;
    double x15 = x5*x8;
    double x16 = x7*(2.0*n1 + 2.0*n2 + 2.0*n3 + 1.0*n4)/x8;
    double x17 = x16*(-x15 + 1.0*x3);
    double x18 = x10 + x12 - 8.3144626181532395*x14 + x17;
    double x19 = x0*x3;
    double x20 = n2*x3;
    double x21 = -8.3144626181532395*x20;
    double x22 = x1*x3;
    double x23 = x21 - 8.3144626181532395*x22 + x7*(-x0*x5 - x6) + 8.3144626181532395*log(x19);
    double x24 = -8.3144626181532395*x4;
    double x25 = -8.3144626181532395*x19 + x24 + x7*(-x1*x5 - x6) + 8.3144626181532395*log(x22);
    double x26 = x7*(-x13*x5 - x6) + 8.3144626181532395*log(x14);

result[0] = x18 + x23 + x7*(-n1*x5 - x6) + 8.3144626181532395*log(x4) + (*endmember[0].dmu0dT)(T, P);
result[1] = x18 + x25 + x7*(-n2*x5 - x6) + 8.3144626181532395*log(x20) + (*endmember[1].dmu0dT)(T, P);
result[2] = x10 + x12 + x17 + x23 + x24 + x26 + (*endmember[2].dmu0dT)(T, P);
result[3] = x16*(-x15 + 0.5*x3) + x21 + x25 + x26 + x7*(-n4*x5 - x6) + 8.3144626181532395*x9 + 8.3144626181532395*log(x11) + (*endmember[3].dmu0dT)(T, P) - 5.7631463216439762;
}
        
static void coder_d3gdn2dt(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = n2 + n4;
    double x1 = n1 + n3;
    double x2 = x0 + x1;
    double x3 = 1.0/x2;
    double x4 = 16.628925236306479*x3;
    double x5 = pow(x2, -2);
    double x6 = -2*x5;
    double x7 = 2/((x2)*(x2)*(x2));
    double x8 = n1*x7;
    double x9 = 8.3144626181532395*x2;
    double x10 = n1*x5;
    double x11 = -x3;
    double x12 = 8.3144626181532395*x10;
    double x13 = -x12;
    double x14 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 0.5*n4;
    double x15 = 1.0/x14;
    double x16 = x14*x5;
    double x17 = -x16 + 1.0*x3;
    double x18 = x15*x17;
    double x19 = 33.257850472612958*x18*x2;
    double x20 = x14*x7;
    double x21 = 2.0*n1 + 2.0*n2 + 2.0*n3 + 1.0*n4;
    double x22 = x21*x9;
    double x23 = x15*x22;
    double x24 = x23*(x20 - 2.0*x5);
    double x25 = pow(x14, -2);
    double x26 = x17*x25;
    double x27 = -x22*x26;
    double x28 = n4*x5;
    double x29 = 8.3144626181532395*x28;
    double x30 = n3 + n4;
    double x31 = x30*x5;
    double x32 = 8.3144626181532395*x31;
    double x33 = 8.3144626181532395*x21;
    double x34 = x18*x33;
    double x35 = x29 + x32 + x34;
    double x36 = x19 + x24 + x27 + x35;
    double x37 = n2*x5;
    double x38 = 8.3144626181532395*x37;
    double x39 = x0*x5;
    double x40 = 8.3144626181532395*x39;
    double x41 = x1*x5;
    double x42 = 8.3144626181532395*x41;
    double x43 = -x42;
    double x44 = x1*x7;
    double x45 = x38 + x40 + x43 + x9*(x44 + x6) + x9*(-x11 - x41)/x1;
    double x46 = x13 + x36 + x45;
    double x47 = x36 - x4;
    double x48 = -x5;
    double x49 = x9*(x48 + x8);
    double x50 = x38 + x40 + x43 + x9*(x44 + x48);
    double x51 = x13 + x49 + x50;
    double x52 = 24.943387854459719*x3;
    double x53 = -x16 + 0.5*x3;
    double x54 = x15*x53;
    double x55 = 16.628925236306479*x2*x54;
    double x56 = 4.1572313090766198*x2*x21;
    double x57 = x18*x9 + x23*(x20 - 1.5*x5) - x26*x56 + x55;
    double x58 = x35 + x57;
    double x59 = n2*x7;
    double x60 = x12 - x40 + x42;
    double x61 = -x38 + x60;
    double x62 = x0*x7;
    double x63 = x9*(x6 + x62) + x9*(-x11 - x39)/x0;
    double x64 = x61 + x9*(x48 + x59);
    double x65 = -8.3144626181532395*x3;
    double x66 = -x32 + x9*(x30*x7 + x6) + x9*(-x11 - x31)/x30;
    double x67 = x12 + x29 + x34 + x66;

result[0] = x4 + x46 + x9*(x6 + x8) + x9*(-x10 - x11)/n1;
result[1] = x47 + x51;
result[2] = x46 + x49;
result[3] = x51 - x52 + x58;
result[4] = x36 + x4 + x61 + x63 + x9*(x59 + x6) + x9*(-x11 - x37)/n2;
result[5] = x47 + x64 + x9*(x48 + x62);
result[6] = x58 + x63 + x64 + x65;
result[7] = x19 + x24 + x27 + x4 + x45 + x67;
result[8] = x50 + x57 + x65 + x67;
result[9] = x23*(x20 - 1.0*x5) - x25*x53*x56 - x29 + x33*x54 + x38 + x52 + x55 + x60 + x63 + x66 + x9*(n4*x7 + x6) + x9*(-x11 - x28)/n4;
}
        
static void coder_d4gdn3dt(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = n1 + n3;
    double x1 = n2 + n4;
    double x2 = x0 + x1;
    double x3 = pow(x2, -3);
    double x4 = -6*x3;
    double x5 = 6/((x2)*(x2)*(x2)*(x2));
    double x6 = n1*x5;
    double x7 = 8.3144626181532395*x2;
    double x8 = pow(x2, -2);
    double x9 = -2*x8;
    double x10 = 2*x3;
    double x11 = n1*x10;
    double x12 = 8.3144626181532395/n1;
    double x13 = x12*x2;
    double x14 = 1.0/x2;
    double x15 = -x14;
    double x16 = -n1*x8 - x15;
    double x17 = 33.257850472612958*x3;
    double x18 = n1*x17;
    double x19 = 16.628925236306479*x3;
    double x20 = -n4*x19;
    double x21 = n3 + n4;
    double x22 = -x19*x21 + x20;
    double x23 = x12*x16 + x18 + x22;
    double x24 = -66.515700945225916*x8;
    double x25 = x0*x5;
    double x26 = x0*x10;
    double x27 = 8.3144626181532395/x0;
    double x28 = x2*x27;
    double x29 = -x0*x8 - x15;
    double x30 = -n2*x19;
    double x31 = x0*x17 - x1*x19 + x30;
    double x32 = x27*x29;
    double x33 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 0.5*n4;
    double x34 = 1.0/x33;
    double x35 = x33*x8;
    double x36 = 1.0*x14 - x35;
    double x37 = x34*x36;
    double x38 = x10*x33;
    double x39 = x38 - 2.0*x8;
    double x40 = x34*x39;
    double x41 = 2.0*n1 + 2.0*n2 + 2.0*n3 + 1.0*n4;
    double x42 = 16.628925236306479*x41;
    double x43 = 49.886775708919437*x2;
    double x44 = pow(x33, -2);
    double x45 = x36*x44;
    double x46 = x33*x5;
    double x47 = x41*x7;
    double x48 = x34*x47;
    double x49 = x2*x42;
    double x50 = pow(x33, -3);
    double x51 = x36*x50;
    double x52 = x39*x44;
    double x53 = 49.886775708919437*x37 + x40*x42 + x40*x43 - x42*x45 - x43*x45 + x48*(6.0*x3 - x46) + x49*x51 - x49*x52;
    double x54 = x32 + x53;
    double x55 = x28*(x26 + x9) + x31 + x54 + x7*(-x25 - x4) - x29*x7/((x0)*(x0));
    double x56 = x24 + x55;
    double x57 = 33.257850472612958*x8;
    double x58 = -x57;
    double x59 = -x8;
    double x60 = x28*(x26 + x59);
    double x61 = -4*x3;
    double x62 = x31 + x7*(-x25 - x61);
    double x63 = x60 + x62;
    double x64 = x13*(x11 + x59) + x23 + x7*(-x6 - x61);
    double x65 = x63 + x64;
    double x66 = 24.943387854459719*x8;
    double x67 = -x66;
    double x68 = x38 - 1.5*x8;
    double x69 = x44*x47;
    double x70 = -x68*x69;
    double x71 = 8.3144626181532395*x41;
    double x72 = x34*x68;
    double x73 = x2*x72;
    double x74 = 24.943387854459719*x2;
    double x75 = 4.1572313090766198*x2*x41;
    double x76 = 41.572313090766201*x37 + x40*x7 + x40*x71 - 12.471693927229859*x41*x45 - x45*x74 + x47*x51 + x48*(5.0*x3 - x46) - x52*x75 + x71*x72 + 33.257850472612958*x73;
    double x77 = x70 + x76;
    double x78 = x32 + x77;
    double x79 = x53 + 16.628925236306479*x8;
    double x80 = -2*x3;
    double x81 = x18 + x22 + x7*(-x6 - x80);
    double x82 = x31 + x7*(-x25 - x80);
    double x83 = x81 + x82;
    double x84 = x62 + x81;
    double x85 = x70 + x83;
    double x86 = 0.5*x14 - x35;
    double x87 = x34*x86;
    double x88 = x38 - 1.0*x8;
    double x89 = x34*x88;
    double x90 = x44*x86;
    double x91 = 16.628925236306479*x2*x89 + 16.628925236306479*x37 + x42*x72 - x45*x7 - x45*x71 + x48*(4.0*x3 - x46) + x51*x75 - x7*x90 + 16.628925236306479*x73 + 16.628925236306479*x87;
    double x92 = n2*x5;
    double x93 = n2*x10;
    double x94 = 1.0/n2;
    double x95 = x7*x94;
    double x96 = -n2*x8 - x15;
    double x97 = 8.3144626181532395*x94*x96;
    double x98 = 1.0/x1;
    double x99 = -x1*x8 - x15;
    double x100 = 8.3144626181532395*x98*x99;
    double x101 = -n1*x19;
    double x102 = -x0*x19 + x1*x17 + x101;
    double x103 = n2*x17 + x102 + x22;
    double x104 = x100 + x103 + x53 + x97;
    double x105 = x1*x5;
    double x106 = x1*x10;
    double x107 = x7*x98;
    double x108 = x107*(x106 + x9) + x7*(-x105 - x4) - x7*x99/((x1)*(x1));
    double x109 = x7*(-x105 - x61);
    double x110 = x7*(-x61 - x92) + x95*(x59 + x93);
    double x111 = -41.572313090766201*x8;
    double x112 = x100 + x108;
    double x113 = x103 + x7*(-x80 - x92);
    double x114 = 8.3144626181532395*x8;
    double x115 = -x114 + x70 + x91;
    double x116 = 1.0/x21;
    double x117 = -x15 - x21*x8;
    double x118 = 8.3144626181532395*x116*x117 + x116*x7*(x10*x21 + x9) - x117*x7/((x21)*(x21)) + x17*x21 + x7*(-x21*x5 - x4);
    double x119 = x101 + x118 + x20;
    double x120 = 1.0/n4;
    double x121 = -n4*x8 - x15;

result[0] = x13*(x11 + x9) + x23 + x56 + x7*(-x4 - x6) - x16*x7/((n1)*(n1));
result[1] = x54 + x58 + x65;
result[2] = x55 + x64 - 49.886775708919444*x8;
result[3] = x65 + x67 + x78;
result[4] = x79 + x83;
result[5] = x53 + x84;
result[6] = x66 + x76 + x85;
result[7] = x55 + x67 + x81;
result[8] = x60 + x78 + x84;
result[9] = x57 + x85 + x91;
result[10] = x104 + x108 + x24 + x7*(-x4 - x92) + x95*(x9 + x93) - x7*x96/((n2)*(n2));
result[11] = x104 + x107*(x106 + x59) + x109 + x110 + x58;
result[12] = x103 + x110 + x111 + x112 + x77 + x97;
result[13] = x113 + x7*(-x105 - x80) + x79;
result[14] = x109 + x113 + x114 + x77;
result[15] = x112 + x113 + x115;
result[16] = x119 + x56;
result[17] = x111 + x119 + x63 + x78;
result[18] = x115 + x119 + x82;
result[19] = n4*x17 + x102 + x112 + x118 + 8.3144626181532395*x120*x121 + x120*x7*(n4*x10 + x9) - 12.471693927229859*x2*x90 + x30 + x42*x89 + x48*(3.0*x3 - x46) + x50*x75*x86 - x69*x88 + x7*(-n4*x5 - x4) - x71*x90 + x74*x89 - 99.773551417838888*x8 + 24.943387854459719*x87 - x121*x7/((n4)*(n4));
}
        
static double coder_dgdp(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].dmu0dP)(T, P) + n2*(*endmember[1].dmu0dP)(T, P) + n3*(*endmember[2].dmu0dP)(T, P) + n4*(*endmember[3].dmu0dP)(T, P);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].dmu0dP)(T, P);
result[1] = (*endmember[1].dmu0dP)(T, P);
result[2] = (*endmember[2].dmu0dP)(T, P);
result[3] = (*endmember[3].dmu0dP)(T, P);
}
        
static void coder_d3gdn2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d2mu0dT2)(T, P) + n2*(*endmember[1].d2mu0dT2)(T, P) + n3*(*endmember[2].d2mu0dT2)(T, P) + n4*(*endmember[3].d2mu0dT2)(T, P);
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d2mu0dT2)(T, P);
result[1] = (*endmember[1].d2mu0dT2)(T, P);
result[2] = (*endmember[2].d2mu0dT2)(T, P);
result[3] = (*endmember[3].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P) + n3*(*endmember[2].d2mu0dTdP)(T, P) + n4*(*endmember[3].d2mu0dTdP)(T, P);
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d2mu0dTdP)(T, P);
result[1] = (*endmember[1].d2mu0dTdP)(T, P);
result[2] = (*endmember[2].d2mu0dTdP)(T, P);
result[3] = (*endmember[3].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P) + n3*(*endmember[2].d2mu0dP2)(T, P) + n4*(*endmember[3].d2mu0dP2)(T, P);
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d2mu0dP2)(T, P);
result[1] = (*endmember[1].d2mu0dP2)(T, P);
result[2] = (*endmember[2].d2mu0dP2)(T, P);
result[3] = (*endmember[3].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d3mu0dT3)(T, P) + n2*(*endmember[1].d3mu0dT3)(T, P) + n3*(*endmember[2].d3mu0dT3)(T, P) + n4*(*endmember[3].d3mu0dT3)(T, P);
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d3mu0dT3)(T, P);
result[1] = (*endmember[1].d3mu0dT3)(T, P);
result[2] = (*endmember[2].d3mu0dT3)(T, P);
result[3] = (*endmember[3].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P) + n3*(*endmember[2].d3mu0dT2dP)(T, P) + n4*(*endmember[3].d3mu0dT2dP)(T, P);
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d3mu0dT2dP)(T, P);
result[1] = (*endmember[1].d3mu0dT2dP)(T, P);
result[2] = (*endmember[2].d3mu0dT2dP)(T, P);
result[3] = (*endmember[3].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P) + n3*(*endmember[2].d3mu0dTdP2)(T, P) + n4*(*endmember[3].d3mu0dTdP2)(T, P);
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d3mu0dTdP2)(T, P);
result[1] = (*endmember[1].d3mu0dTdP2)(T, P);
result[2] = (*endmember[2].d3mu0dTdP2)(T, P);
result[3] = (*endmember[3].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P) + n3*(*endmember[2].d3mu0dP3)(T, P) + n4*(*endmember[3].d3mu0dP3)(T, P);
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = (*endmember[0].d3mu0dP3)(T, P);
result[1] = (*endmember[1].d3mu0dP3)(T, P);
result[2] = (*endmember[2].d3mu0dP3)(T, P);
result[3] = (*endmember[3].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_s(double T, double P, double n[4]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[4]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[4]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[4]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[4]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[4]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[4]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[4]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[4]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[4]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[4]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[4]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[4]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[4]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

