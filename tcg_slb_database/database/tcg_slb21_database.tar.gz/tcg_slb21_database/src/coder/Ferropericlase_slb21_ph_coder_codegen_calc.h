#include <math.h>


static double coder_g(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = 1.0/x1;
    double x3 = n1*(*endmember[0].mu0)(T, P);
    double x4 = n2*(*endmember[1].mu0)(T, P);
    double x5 = n3*(*endmember[2].mu0)(T, P);
    double x6 = T*(n1*log(n1*x2) + n2*log(n2*x2) + n3*log(n3*x2));
    double x7 = 240000.0*n3;
    double x8 = 0.087999999999999995*P + 88000.0;
    double x9 = 0.25*n1*(n2*x8 + x7) + 0.25*n2*(n1*x8 + x7) + 60000.0*n3*x0;
    double x10 = fmin(4, 1.0*sqrt(1 - 0.005235602094240838*T));

if (T >= 191.0) {
   result = x2*(1.0*x1*(-n2*(53.525399999999998*T - 6815.5675999999994) + x3 + x4 + x5 + 33.257850472612958*x6) + x9);
}
else {
   result = x2*(0.33333333333333331*x1*(n2*(10223.3514*((x10)*(x10)*(x10)) + (160.5762*T - 30670.054199999999)*(x10 - 1) - 10223.3514) + 3*x3 + 3*x4 + 3*x5 + 99.773551417838874*x6) + x9);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = pow(x1, -2);
    double x3 = (*endmember[0].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = n2*x5;
    double x7 = (*endmember[2].mu0)(T, P);
    double x8 = n3*x7;
    double x9 = 53.525399999999998*T;
    double x10 = x9 - 6815.5675999999994;
    double x11 = 1.0/x1;
    double x12 = n1*x11;
    double x13 = log(x12);
    double x14 = n2*x11;
    double x15 = log(x14);
    double x16 = n3*x11;
    double x17 = log(x16);
    double x18 = n1*x13 + n2*x15 + n3*x17;
    double x19 = 33.257850472612958*T;
    double x20 = x18*x19;
    double x21 = 240000.0*n3;
    double x22 = 0.043999999999999997*P + 44000.0;
    double x23 = n2*x22;
    double x24 = 0.25*n1;
    double x25 = n1*x22;
    double x26 = 0.25*n2;
    double x27 = 60000.0*n3*x0 + x24*(x21 + 2.0*x23) + x26*(x21 + 2.0*x25);
    double x28 = -x2*(1.0*x1*(-n2*x10 + x20 + x4 + x6 + x8) + x27);
    double x29 = 1.0*n1;
    double x30 = 1.0*n2;
    double x31 = 1.0*n3;
    double x32 = x29 + x30 + x31;
    double x33 = -x14;
    double x34 = -x16;
    double x35 = x1*(-n1*x2 + x11) + x13 + x33 + x34;
    double x36 = 120000.0*n3;
    double x37 = x20 + x29*x3 + x30*x5 + x31*x7;
    double x38 = -x10*x30 + x37;
    double x39 = x36 + x38;
    double x40 = 0.087999999999999995*P + 88000.0;
    double x41 = 0.5*x23 + x26*x40;
    double x42 = T >= 191.0;
    double x43 = 99.773551417838874*T;
    double x44 = fmin(4, 1.0*sqrt(1 - 0.005235602094240838*T));
    double x45 = 10223.3514*((x44)*(x44)*(x44)) + (160.5762*T - 30670.054199999999)*(x44 - 1) - 10223.3514;
    double x46 = -x2*(0.33333333333333331*x1*(n2*x45 + x18*x43 + 3*x4 + 3*x6 + 3*x8) + x27);
    double x47 = 0.33333333333333331*n2;
    double x48 = 0.33333333333333331*n1 + 0.33333333333333331*n3 + x47;
    double x49 = x37 + x45*x47;
    double x50 = x36 + x49;
    double x51 = -x12;
    double x52 = x1*(-n2*x2 + x11) + x15 + x34 + x51;
    double x53 = x24*x40 + 0.5*x25;
    double x54 = x1*(-n3*x2 + x11) + x17 + x33 + x51;
    double x55 = 120000.0*n1 + 120000.0*n2;

if (x42) {
   result[0] = x11*(x32*(x19*x35 + x3) + x39 + x41) + x28;
}
else {
   result[0] = x11*(x41 + x48*(3*x3 + x35*x43) + x50) + x46;
}
if (x42) {
   result[1] = x11*(x32*(x19*x52 + x5 - x9 + 6815.5675999999994) + x39 + x53) + x28;
}
else {
   result[1] = x11*(x48*(x43*x52 + x45 + 3*x5) + x50 + x53) + x46;
}
if (x42) {
   result[2] = x11*(x32*(x19*x54 + x7) + x38 + x55) + x28;
}
else {
   result[2] = x11*(x48*(x43*x54 + 3*x7) + x49 + x55) + x46;
}
}
        
static void coder_d2gdn2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = (*endmember[0].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[1].mu0)(T, P);
    double x5 = n2*x4;
    double x6 = (*endmember[2].mu0)(T, P);
    double x7 = n3*x6;
    double x8 = 53.525399999999998*T;
    double x9 = x8 - 6815.5675999999994;
    double x10 = 1.0/x1;
    double x11 = n1*x10;
    double x12 = log(x11);
    double x13 = n2*x10;
    double x14 = log(x13);
    double x15 = n3*x10;
    double x16 = log(x15);
    double x17 = T*(n1*x12 + n2*x14 + n3*x16);
    double x18 = 33.257850472612958*x17;
    double x19 = 240000.0*n3;
    double x20 = 0.043999999999999997*P;
    double x21 = x20 + 44000.0;
    double x22 = n2*x21;
    double x23 = 0.25*n1;
    double x24 = n1*x21;
    double x25 = 0.25*n2;
    double x26 = 60000.0*n3*x0 + x23*(x19 + 2.0*x22) + x25*(x19 + 2.0*x24);
    double x27 = 2/((x1)*(x1)*(x1));
    double x28 = x27*(1.0*x1*(-n2*x9 + x18 + x3 + x5 + x7) + x26);
    double x29 = pow(x1, -2);
    double x30 = n2*x29;
    double x31 = n3*x29;
    double x32 = 2*x29;
    double x33 = -x32;
    double x34 = n1*x27;
    double x35 = n1*x29;
    double x36 = -x35;
    double x37 = x10 + x36;
    double x38 = x1*x37;
    double x39 = T*(x1*(x33 + x34) + x30 + x31 + x37 + x38/n1);
    double x40 = 1.0*n1;
    double x41 = 1.0*n2;
    double x42 = 1.0*n3;
    double x43 = x40 + x41 + x42;
    double x44 = 33.257850472612958*x43;
    double x45 = -x13;
    double x46 = -x15;
    double x47 = T*(x12 + x38 + x45 + x46);
    double x48 = 2.0*x2 + 66.515700945225916*x47;
    double x49 = 33.257850472612958*x47;
    double x50 = 120000.0*n3;
    double x51 = x18 + x2*x40 + x4*x41 + x42*x6;
    double x52 = -x41*x9 + x51;
    double x53 = x50 + x52;
    double x54 = 0.087999999999999995*P + 88000.0;
    double x55 = 0.5*x22 + x25*x54;
    double x56 = x43*(x2 + x49) + x53 + x55;
    double x57 = T >= 191.0;
    double x58 = fmin(4, 1.0*sqrt(1 - 0.005235602094240838*T));
    double x59 = ((x58)*(x58)*(x58));
    double x60 = (160.5762*T - 30670.054199999999)*(x58 - 1);
    double x61 = 10223.3514*x59 + x60 - 10223.3514;
    double x62 = x27*(0.33333333333333331*x1*(n2*x61 + 99.773551417838874*x17 + 3*x3 + 3*x5 + 3*x7) + x26);
    double x63 = 0.33333333333333331*n2;
    double x64 = 0.33333333333333331*n1 + 0.33333333333333331*n3 + x63;
    double x65 = 99.773551417838874*x64;
    double x66 = x51 + x61*x63;
    double x67 = x50 + x66;
    double x68 = x55 + x64*(3*x2 + 99.773551417838874*x47) + x67;
    double x69 = -x29;
    double x70 = -x10 + x31;
    double x71 = T*(x1*(x34 + x69) + x30 + x36 + x70);
    double x72 = 1.0*x2 + x49;
    double x73 = x44*x71 + x72;
    double x74 = 1.0*x4;
    double x75 = -x11;
    double x76 = -x30;
    double x77 = x10 + x76;
    double x78 = x1*x77;
    double x79 = T*(x14 + x46 + x75 + x78);
    double x80 = 33.257850472612958*x79;
    double x81 = -x8 + x80;
    double x82 = x74 + x81;
    double x83 = x23*x54 + 0.5*x24;
    double x84 = x43*(x4 + x81 + 6815.5675999999994) + x53 + x83;
    double x85 = -x29*x84;
    double x86 = x28 - x29*x56;
    double x87 = x65*x71 + x72;
    double x88 = 3407.7837999999997*x59 + 0.33333333333333331*x60 + x74 + x80;
    double x89 = x64*(3*x4 + x61 + 99.773551417838874*x79) + x67 + x83;
    double x90 = -x29*x89;
    double x91 = -x29*x68 + x62;
    double x92 = x10 - x31;
    double x93 = x1*x92;
    double x94 = T*(x16 + x45 + x75 + x93);
    double x95 = 33.257850472612958*x94;
    double x96 = 1.0*x6 + x95;
    double x97 = x96 + 120000.0;
    double x98 = 120000.0*n1 + 120000.0*n2;
    double x99 = x43*(x6 + x95) + x52 + x98;
    double x100 = -x29*x99;
    double x101 = x64*(3*x6 + 99.773551417838874*x94) + x66 + x98;
    double x102 = -x101*x29;
    double x103 = n2*x27;
    double x104 = T*(x1*(x103 + x33) + x31 + x35 + x77 + x78/n2);
    double x105 = 2.0*x4 + 66.515700945225916*x79;
    double x106 = T*(x1*(x103 + x69) + x35 + x70 + x76);
    double x107 = T*(x1*(n3*x27 + x33) + x30 + x35 + x92 + x93/n3);
    double x108 = 2.0*x6 + 66.515700945225916*x94;

if (x57) {
   result[0] = x10*(x39*x44 + x48) + x28 - x32*x56;
}
else {
   result[0] = x10*(x39*x65 + x48) - x32*x68 + x62;
}
if (x57) {
   result[1] = x10*(x20 + x73 + x82 + 50815.567600000002) + x85 + x86;
}
else {
   result[1] = x10*(x20 + x87 + x88 + 40592.216200000003) + x90 + x91;
}
if (x57) {
   result[2] = x10*(x73 + x97) + x100 + x86;
}
else {
   result[2] = x10*(x87 + x97) + x102 + x91;
}
if (x57) {
   result[3] = x10*(-107.0508*T + x104*x44 + x105 + 13631.135199999999) + x28 - x32*x84;
}
else {
   result[3] = x10*(x104*x65 + x105 + 6815.5675999999994*x59 + 0.66666666666666663*x60 - 6815.5675999999994) - x32*x89 + x62;
}
if (x57) {
   result[4] = x10*(x106*x44 + x82 + x96 + 126815.56759999999) + x100 + x28 + x85;
}
else {
   result[4] = x10*(x106*x65 + x88 + x96 + 116592.2162) + x102 + x62 + x90;
}
if (x57) {
   result[5] = x10*(x107*x44 + x108) + x28 - x32*x99;
}
else {
   result[5] = x10*(x107*x65 + x108) - x101*x32 + x62;
}
}
        
static void coder_d3gdn3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = (*endmember[0].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[1].mu0)(T, P);
    double x5 = n2*x4;
    double x6 = (*endmember[2].mu0)(T, P);
    double x7 = n3*x6;
    double x8 = 53.525399999999998*T;
    double x9 = x8 - 6815.5675999999994;
    double x10 = 1.0/x1;
    double x11 = n1*x10;
    double x12 = log(x11);
    double x13 = n2*x10;
    double x14 = log(x13);
    double x15 = n3*x10;
    double x16 = log(x15);
    double x17 = n1*x12 + n2*x14 + n3*x16;
    double x18 = 33.257850472612958*T;
    double x19 = x17*x18;
    double x20 = 240000.0*n3;
    double x21 = 0.043999999999999997*P;
    double x22 = x21 + 44000.0;
    double x23 = 2.0*x22;
    double x24 = 0.25*n1;
    double x25 = 0.25*n2;
    double x26 = 60000.0*n3*x0 + x24*(n2*x23 + x20) + x25*(n1*x23 + x20);
    double x27 = 6/((x1)*(x1)*(x1)*(x1));
    double x28 = -x27*(1.0*x1*(-n2*x9 + x19 + x3 + x5 + x7) + x26);
    double x29 = 1.0*n1;
    double x30 = 1.0*n2;
    double x31 = 1.0*n3;
    double x32 = x29 + x30 + x31;
    double x33 = -x13;
    double x34 = -x15;
    double x35 = pow(x1, -2);
    double x36 = n1*x35;
    double x37 = -x36;
    double x38 = x10 + x37;
    double x39 = x1*x38;
    double x40 = x12 + x33 + x34 + x39;
    double x41 = x18*x40;
    double x42 = 120000.0*n3;
    double x43 = x19 + x2*x29 + x30*x4 + x31*x6;
    double x44 = -x30*x9 + x43;
    double x45 = x42 + x44;
    double x46 = 0.087999999999999995*P + 88000.0;
    double x47 = 0.5*x22;
    double x48 = n2*x47 + x25*x46;
    double x49 = x32*(x2 + x41) + x45 + x48;
    double x50 = pow(x1, -3);
    double x51 = 6*x50;
    double x52 = n2*x35;
    double x53 = n3*x35;
    double x54 = 2*x35;
    double x55 = -x54;
    double x56 = 2*x50;
    double x57 = n1*x56;
    double x58 = x1*(x55 + x57);
    double x59 = 1.0/n1;
    double x60 = x38*x59;
    double x61 = x1*x60 + x38 + x52 + x53 + x58;
    double x62 = x18*x61;
    double x63 = 66.515700945225916*T;
    double x64 = 2.0*x2 + x40*x63;
    double x65 = x35*(x32*x62 + x64);
    double x66 = 99.773551417838874*T;
    double x67 = x61*x66;
    double x68 = -n1*x27;
    double x69 = n2*x56;
    double x70 = -x69;
    double x71 = 4*x50;
    double x72 = n1*x71 + x70;
    double x73 = x60 + x72;
    double x74 = n3*x56;
    double x75 = -x74;
    double x76 = -4*x35;
    double x77 = x75 + x76;
    double x78 = x1*(x51 + x68) + x58*x59 + x73 + x77 - x39/((n1)*(n1));
    double x79 = x18*x32;
    double x80 = T >= 191.0;
    double x81 = fmin(4, 1.0*sqrt(1 - 0.005235602094240838*T));
    double x82 = ((x81)*(x81)*(x81));
    double x83 = (160.5762*T - 30670.054199999999)*(x81 - 1);
    double x84 = 10223.3514*x82 + x83 - 10223.3514;
    double x85 = -x27*(0.33333333333333331*x1*(n2*x84 + x17*x66 + 3*x3 + 3*x5 + 3*x7) + x26);
    double x86 = 0.33333333333333331*n2;
    double x87 = 0.33333333333333331*n1 + 0.33333333333333331*n3 + x86;
    double x88 = x35*(x64 + x67*x87);
    double x89 = x43 + x84*x86;
    double x90 = x42 + x89;
    double x91 = x48 + x87*(3*x2 + x40*x66) + x90;
    double x92 = x66*x87;
    double x93 = -x11;
    double x94 = -x52;
    double x95 = x10 + x94;
    double x96 = x1*x95;
    double x97 = x14 + x34 + x93 + x96;
    double x98 = x18*x97;
    double x99 = -x8 + x98;
    double x100 = n1*x47 + x24*x46;
    double x101 = x100 + x32*(x4 + x99 + 6815.5675999999994) + x45;
    double x102 = x101*x56;
    double x103 = -x35;
    double x104 = x1*(x103 + x57);
    double x105 = -x10 + x53;
    double x106 = x104 + x105 + x37 + x52;
    double x107 = 1.0*x2 + x41;
    double x108 = x106*x79 + x107;
    double x109 = 1.0*x4;
    double x110 = x109 + x99;
    double x111 = x108 + x110 + x21 + 50815.567600000002;
    double x112 = -x111*x54 + x28;
    double x113 = x55 + x75;
    double x114 = x1*(x68 + x71) + x104*x59 + x113 + x73;
    double x115 = x106*x63;
    double x116 = x115 + x62;
    double x117 = x10*(x114*x79 + x116) + x49*x71 - x65;
    double x118 = x100 + x87*(3*x4 + x66*x97 + x84) + x90;
    double x119 = x118*x56;
    double x120 = x106*x92 + x107;
    double x121 = x109 + 3407.7837999999997*x82 + 0.33333333333333331*x83 + x98;
    double x122 = x120 + x121 + x21 + 40592.216200000003;
    double x123 = -x122*x54 + x85;
    double x124 = x10*(x114*x92 + x116) + x71*x91 - x88;
    double x125 = x10 - x53;
    double x126 = x1*x125;
    double x127 = x126 + x16 + x33 + x93;
    double x128 = x127*x18;
    double x129 = 120000.0*n1 + 120000.0*n2;
    double x130 = x129 + x32*(x128 + x6) + x44;
    double x131 = x130*x56;
    double x132 = x128 + 1.0*x6;
    double x133 = x132 + 120000.0;
    double x134 = x108 + x133;
    double x135 = -x134*x54 + x28;
    double x136 = x129 + x87*(x127*x66 + 3*x6) + x89;
    double x137 = x136*x56;
    double x138 = x120 + x133;
    double x139 = -x138*x54 + x85;
    double x140 = x35 + x75;
    double x141 = x1*(x56 + x68) + x140 + x72;
    double x142 = x141*x79;
    double x143 = x1*(x55 + x69);
    double x144 = 1.0/n2;
    double x145 = x143 + x144*x96 + x36 + x53 + x95;
    double x146 = x145*x18;
    double x147 = x115 + x146;
    double x148 = x49*x56;
    double x149 = 2.0*x4 + x63*x97;
    double x150 = x35*(-107.0508*T + x146*x32 + x149 + 13631.135199999999);
    double x151 = x101*x71 - x150;
    double x152 = x141*x92;
    double x153 = x56*x91;
    double x154 = x145*x66;
    double x155 = x35*(x149 + x154*x87 + 6815.5675999999994*x82 + 0.66666666666666663*x83 - 6815.5675999999994);
    double x156 = x118*x71 - x155;
    double x157 = x1*(x103 + x69);
    double x158 = x105 + x157 + x36 + x94;
    double x159 = x158*x18;
    double x160 = x110 + x132 + x159*x32 + 126815.56759999999;
    double x161 = x115 + x159;
    double x162 = x121 + x132 + x158*x92 + 116592.2162;
    double x163 = x1*(x55 + x74);
    double x164 = 1.0/n3;
    double x165 = x125 + x126*x164 + x163 + x36 + x52;
    double x166 = x165*x18;
    double x167 = x115 + x166;
    double x168 = x127*x63 + 2.0*x6;
    double x169 = x35*(x166*x32 + x168);
    double x170 = x130*x71 - x169;
    double x171 = x165*x66;
    double x172 = x35*(x168 + x171*x87);
    double x173 = x136*x71 - x172;
    double x174 = -n2*x27;
    double x175 = -x57;
    double x176 = n2*x71 + x175;
    double x177 = x144*x95 + x176;
    double x178 = x1*(x174 + x51) + x143*x144 + x177 + x77 - x96/((n2)*(n2));
    double x179 = x1*(x174 + x71) + x113 + x144*x157 + x177;
    double x180 = x158*x63;
    double x181 = x146 + x180;
    double x182 = -x160*x54 + x28;
    double x183 = -x162*x54 + x85;
    double x184 = x1*(x174 + x56) + x140 + x176;
    double x185 = x166 + x180;
    double x186 = n3*x71 + x1*(-n3*x27 + x51) + x125*x164 + x163*x164 + x175 + x70 + x76 - x126/((n3)*(n3));

if (x80) {
   result[0] = x10*(x67 + x78*x79) + x28 + x49*x51 - 3*x65;
}
else {
   result[0] = x10*(x67 + x78*x92) + x51*x91 + x85 - 3*x88;
}
if (x80) {
   result[1] = x102 + x112 + x117;
}
else {
   result[1] = x119 + x123 + x124;
}
if (x80) {
   result[2] = x117 + x131 + x135;
}
else {
   result[2] = x124 + x137 + x139;
}
if (x80) {
   result[3] = x10*(x142 + x147) + x112 + x148 + x151;
}
else {
   result[3] = x10*(x147 + x152) + x123 + x153 + x156;
}
if (x80) {
   result[4] = x10*(x142 + x161) + x102 - x111*x35 + x131 - x134*x35 + x148 - x160*x35 + x28;
}
else {
   result[4] = x10*(x152 + x161) + x119 - x122*x35 + x137 - x138*x35 + x153 - x162*x35 + x85;
}
if (x80) {
   result[5] = x10*(x142 + x167) + x135 + x148 + x170;
}
else {
   result[5] = x10*(x152 + x167) + x139 + x153 + x173;
}
if (x80) {
   result[6] = x10*(x154 + x178*x79) + x101*x51 - 3*x150 + x28;
}
else {
   result[6] = x10*(x154 + x178*x92) + x118*x51 - 3*x155 + x85;
}
if (x80) {
   result[7] = x10*(x179*x79 + x181) + x131 + x151 + x182;
}
else {
   result[7] = x10*(x179*x92 + x181) + x137 + x156 + x183;
}
if (x80) {
   result[8] = x10*(x184*x79 + x185) + x102 + x170 + x182;
}
else {
   result[8] = x10*(x184*x92 + x185) + x119 + x173 + x183;
}
if (x80) {
   result[9] = x10*(x171 + x186*x79) + x130*x51 - 3*x169 + x28;
}
else {
   result[9] = x10*(x171 + x186*x92) + x136*x51 - 3*x172 + x85;
}
}
        
static double coder_dgdt(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = 1.0/(n1 + n2 + n3);
    double x1 = n1*(*endmember[0].dmu0dT)(T, P);
    double x2 = n2*(*endmember[1].dmu0dT)(T, P);
    double x3 = n3*(*endmember[2].dmu0dT)(T, P);
    double x4 = n1*log(n1*x0);
    double x5 = n2*log(n2*x0);
    double x6 = n3*log(n3*x0);
    double x7 = sqrt(1 - 0.005235602094240838*T);
    double x8 = 1.0*x7;
    double x9 = fmin(4, x8);
    double x10 = (4 - x8 >= 0. ? 1. : 0.)/x7;

if (T >= 191.0) {
   result = x0*(1.0*n1 + 1.0*n2 + 1.0*n3)*(-53.525399999999998*n2 + x1 + x2 + x3 + 33.257850472612958*x4 + 33.257850472612958*x5 + 33.257850472612958*x6);
}
else {
   result = x0*(0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3)*(n2*(-80.288100000000014*x10*((x9)*(x9)) - 0.002617801047120419*x10*(160.5762*T - 30670.054199999999) + 160.5762*x9 - 160.5762) + 3*x1 + 3*x2 + 3*x3 + 99.773551417838874*x4 + 99.773551417838874*x5 + 99.773551417838874*x6);
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = n1 + n2 + n3;
    double x2 = 1.0/x1;
    double x3 = n2*x2;
    double x4 = -33.257850472612958*x3;
    double x5 = n3*x2;
    double x6 = -33.257850472612958*x5;
    double x7 = n1*x2;
    double x8 = log(x7);
    double x9 = 33.257850472612958*x8;
    double x10 = pow(x1, -2);
    double x11 = x1*(-n1*x10 + x2);
    double x12 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x13 = x12*x2;
    double x14 = n1*x0;
    double x15 = (*endmember[1].dmu0dT)(T, P);
    double x16 = n2*x15;
    double x17 = (*endmember[2].dmu0dT)(T, P);
    double x18 = n3*x17;
    double x19 = log(x3);
    double x20 = 33.257850472612958*x19;
    double x21 = log(x5);
    double x22 = 33.257850472612958*x21;
    double x23 = n1*x9 + n2*x20 - 53.525399999999998*n2 + n3*x22 + x14 + x16 + x18;
    double x24 = -x10*x12*x23 + 1.0*x2*x23;
    double x25 = T >= 191.0;
    double x26 = -99.773551417838874*x3;
    double x27 = -99.773551417838874*x5;
    double x28 = 99.773551417838874*x8;
    double x29 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3;
    double x30 = x2*x29;
    double x31 = 99.773551417838874*x19;
    double x32 = 99.773551417838874*x21;
    double x33 = sqrt(1 - 0.005235602094240838*T);
    double x34 = 1.0*x33;
    double x35 = fmin(4, x34);
    double x36 = (4 - x34 >= 0. ? 1. : 0.)/x33;
    double x37 = -80.288100000000014*((x35)*(x35))*x36 + 160.5762*x35 - 0.002617801047120419*x36*(160.5762*T - 30670.054199999999) - 160.5762;
    double x38 = n1*x28 + n2*x31 + n2*x37 + n3*x32 + 3*x14 + 3*x16 + 3*x18;
    double x39 = -x10*x29*x38 + 0.33333333333333331*x2*x38;
    double x40 = -33.257850472612958*x7;
    double x41 = x1*(-n2*x10 + x2);
    double x42 = -99.773551417838874*x7;
    double x43 = x1*(-n3*x10 + x2);

if (x25) {
   result[0] = x13*(x0 + 33.257850472612958*x11 + x4 + x6 + x9) + x24;
}
else {
   result[0] = x30*(3*x0 + 99.773551417838874*x11 + x26 + x27 + x28) + x39;
}
if (x25) {
   result[1] = x13*(x15 + x20 + x40 + 33.257850472612958*x41 + x6 - 53.525399999999998) + x24;
}
else {
   result[1] = x30*(3*x15 + x27 + x31 + x37 + 99.773551417838874*x41 + x42) + x39;
}
if (x25) {
   result[2] = x13*(x17 + x22 + x4 + x40 + 33.257850472612958*x43) + x24;
}
else {
   result[2] = x30*(3*x17 + x26 + x32 + x42 + 99.773551417838874*x43) + x39;
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = 1.0/x0;
    double x2 = (*endmember[0].dmu0dT)(T, P);
    double x3 = n2*x1;
    double x4 = -33.257850472612958*x3;
    double x5 = n3*x1;
    double x6 = -33.257850472612958*x5;
    double x7 = n1*x1;
    double x8 = log(x7);
    double x9 = 33.257850472612958*x8;
    double x10 = pow(x0, -2);
    double x11 = n1*x10;
    double x12 = x0*(x1 - x11);
    double x13 = 33.257850472612958*x12;
    double x14 = x13 + x2 + x4 + x6 + x9;
    double x15 = x1*x14;
    double x16 = -66.515700945225916*x10;
    double x17 = pow(x0, -3);
    double x18 = n1*x17;
    double x19 = 66.515700945225916*x18;
    double x20 = 1.0/n1;
    double x21 = n2*x10;
    double x22 = 33.257850472612958*x21;
    double x23 = 33.257850472612958*x11;
    double x24 = x22 - x23;
    double x25 = 33.257850472612958*x10;
    double x26 = n3*x25;
    double x27 = 33.257850472612958*x1;
    double x28 = x26 + x27;
    double x29 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x30 = x1*x29;
    double x31 = x10*x29;
    double x32 = x14*x31;
    double x33 = n1*x2;
    double x34 = (*endmember[1].dmu0dT)(T, P);
    double x35 = n2*x34;
    double x36 = (*endmember[2].dmu0dT)(T, P);
    double x37 = n3*x36;
    double x38 = log(x3);
    double x39 = 33.257850472612958*x38;
    double x40 = log(x5);
    double x41 = 33.257850472612958*x40;
    double x42 = n1*x9 + n2*x39 - 53.525399999999998*n2 + n3*x41 + x33 + x35 + x37;
    double x43 = 2*x17;
    double x44 = -2.0*x10*x42 + x29*x42*x43;
    double x45 = T >= 191.0;
    double x46 = -99.773551417838874*x3;
    double x47 = -99.773551417838874*x5;
    double x48 = 99.773551417838874*x8;
    double x49 = 99.773551417838874*x12;
    double x50 = 3*x2 + x46 + x47 + x48 + x49;
    double x51 = x1*x50;
    double x52 = -199.54710283567775*x10;
    double x53 = 199.54710283567775*x18;
    double x54 = 99.773551417838874*x21;
    double x55 = 99.773551417838874*x11;
    double x56 = x54 - x55;
    double x57 = 99.773551417838874*x10;
    double x58 = n3*x57;
    double x59 = 99.773551417838874*x1;
    double x60 = x58 + x59;
    double x61 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3;
    double x62 = x1*x61;
    double x63 = x10*x61;
    double x64 = x50*x63;
    double x65 = 99.773551417838874*x38;
    double x66 = 99.773551417838874*x40;
    double x67 = sqrt(1 - 0.005235602094240838*T);
    double x68 = 1.0*x67;
    double x69 = fmin(4, x68);
    double x70 = (4 - x68 >= 0. ? 1. : 0.)/x67;
    double x71 = -80.288100000000014*((x69)*(x69))*x70 + 160.5762*x69 - 0.002617801047120419*x70*(160.5762*T - 30670.054199999999) - 160.5762;
    double x72 = n1*x48 + n2*x65 + n2*x71 + n3*x66 + 3*x33 + 3*x35 + 3*x37;
    double x73 = -0.66666666666666663*x10*x72 + x43*x61*x72;
    double x74 = -33.257850472612958*x7;
    double x75 = x0*(x1 - x21);
    double x76 = 33.257850472612958*x75;
    double x77 = x34 + x39 + x6 + x74 + x76 - 53.525399999999998;
    double x78 = 1.0*x1;
    double x79 = x31*x77;
    double x80 = x44 + x77*x78 - x79;
    double x81 = -x25;
    double x82 = x26 - x27;
    double x83 = 1.0*x15 + x30*(x0*(x19 + x81) + x24 + x82) - x32;
    double x84 = -99.773551417838874*x7;
    double x85 = 99.773551417838874*x75;
    double x86 = 3*x34 + x47 + x65 + x71 + x84 + x85;
    double x87 = 0.33333333333333331*x1;
    double x88 = x63*x86;
    double x89 = x73 + x86*x87 - x88;
    double x90 = -x57;
    double x91 = x58 - x59;
    double x92 = 0.33333333333333331*x51 + x62*(x0*(x53 + x90) + x56 + x91) - x64;
    double x93 = x0*(-n3*x10 + x1);
    double x94 = 33.257850472612958*x93;
    double x95 = x36 + x4 + x41 + x74 + x94;
    double x96 = x31*x95;
    double x97 = x78*x95 - x96;
    double x98 = 99.773551417838874*x93;
    double x99 = 3*x36 + x46 + x66 + x84 + x98;
    double x100 = x63*x99;
    double x101 = -x100 + x87*x99;
    double x102 = 2.0*x1;
    double x103 = n2*x17;
    double x104 = 66.515700945225916*x103;
    double x105 = 1.0/n2;
    double x106 = -x22 + x23;
    double x107 = 0.66666666666666663*x1;
    double x108 = 199.54710283567775*x103;
    double x109 = -x54 + x55;
    double x110 = n3*x17;
    double x111 = 1.0/n3;

if (x45) {
   result[0] = 2.0*x15 + x30*(x0*(x16 + x19) + x13*x20 + x24 + x28) - 2*x32 + x44;
}
else {
   result[0] = 0.66666666666666663*x51 + x62*(x0*(x52 + x53) + x20*x49 + x56 + x60) - 2*x64 + x73;
}
if (x45) {
   result[1] = x80 + x83;
}
else {
   result[1] = x89 + x92;
}
if (x45) {
   result[2] = x44 + x83 + x97;
}
else {
   result[2] = x101 + x73 + x92;
}
if (x45) {
   result[3] = x102*x77 + x30*(x0*(x104 + x16) + x105*x76 + x106 + x28) + x44 - 2*x79;
}
else {
   result[3] = x107*x86 + x62*(x0*(x108 + x52) + x105*x85 + x109 + x60) + x73 - 2*x88;
}
if (x45) {
   result[4] = x30*(x0*(x104 + x81) + x106 + x82) + x80 + x97;
}
else {
   result[4] = x101 + x62*(x0*(x108 + x90) + x109 + x91) + x89;
}
if (x45) {
   result[5] = x102*x95 + x30*(x0*(66.515700945225916*x110 + x16) + x111*x94 + x22 + x23 - x26 + x27) + x44 - 2*x96;
}
else {
   result[5] = -2*x100 + x107*x99 + x62*(x0*(199.54710283567775*x110 + x52) + x111*x98 + x54 + x55 - x58 + x59) + x73;
}
}
        
static void coder_d4gdn3dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = 1.0/x0;
    double x2 = pow(x0, -2);
    double x3 = -66.515700945225916*x2;
    double x4 = pow(x0, -3);
    double x5 = 66.515700945225916*x4;
    double x6 = n1*x5;
    double x7 = 1.0/n1;
    double x8 = n1*x2;
    double x9 = x1 - x8;
    double x10 = 33.257850472612958*x9;
    double x11 = x0*x10;
    double x12 = 33.257850472612958*x2;
    double x13 = n2*x12;
    double x14 = 33.257850472612958*x8;
    double x15 = x13 - x14;
    double x16 = n3*x12;
    double x17 = 33.257850472612958*x1;
    double x18 = x16 + x17;
    double x19 = x0*(x3 + x6) + x11*x7 + x15 + x18;
    double x20 = x1*x19;
    double x21 = (*endmember[0].dmu0dT)(T, P);
    double x22 = -n2*x17;
    double x23 = -n3*x17;
    double x24 = n1*x1;
    double x25 = log(x24);
    double x26 = 33.257850472612958*x25;
    double x27 = x11 + x21 + x22 + x23 + x26;
    double x28 = x2*x27;
    double x29 = 199.54710283567775*x4;
    double x30 = pow(x0, -4);
    double x31 = n1*x30;
    double x32 = -199.54710283567775*x31;
    double x33 = 2*x2;
    double x34 = -x33;
    double x35 = 2*x4;
    double x36 = n1*x35;
    double x37 = x0*x7;
    double x38 = x37*(x34 + x36);
    double x39 = pow(n1, -2);
    double x40 = 133.03140189045183*x4;
    double x41 = n2*x5;
    double x42 = -x41;
    double x43 = n1*x40 + x42;
    double x44 = x10*x7 + x43;
    double x45 = n3*x5;
    double x46 = -x45;
    double x47 = -133.03140189045183*x2;
    double x48 = x46 + x47;
    double x49 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x50 = x1*x49;
    double x51 = x2*x49;
    double x52 = x19*x51;
    double x53 = 6*x49;
    double x54 = x27*x4;
    double x55 = n1*x21;
    double x56 = (*endmember[1].dmu0dT)(T, P);
    double x57 = n2*x56;
    double x58 = (*endmember[2].dmu0dT)(T, P);
    double x59 = n3*x58;
    double x60 = n2*x1;
    double x61 = log(x60);
    double x62 = 33.257850472612958*x61;
    double x63 = n3*x1;
    double x64 = log(x63);
    double x65 = 33.257850472612958*x64;
    double x66 = n1*x26 + n2*x62 - 53.525399999999998*n2 + n3*x65 + x55 + x57 + x59;
    double x67 = -x30*x53*x66 + 6.0*x4*x66;
    double x68 = T >= 191.0;
    double x69 = -199.54710283567775*x2;
    double x70 = n1*x29;
    double x71 = 99.773551417838874*x9;
    double x72 = x0*x71;
    double x73 = n2*x2;
    double x74 = 99.773551417838874*x73;
    double x75 = 99.773551417838874*x8;
    double x76 = x74 - x75;
    double x77 = 99.773551417838874*x2;
    double x78 = n3*x77;
    double x79 = 99.773551417838874*x1;
    double x80 = x78 + x79;
    double x81 = x0*(x69 + x70) + x7*x72 + x76 + x80;
    double x82 = x1*x81;
    double x83 = -99.773551417838874*x60;
    double x84 = -99.773551417838874*x63;
    double x85 = 99.773551417838874*x25;
    double x86 = 3*x21 + x72 + x83 + x84 + x85;
    double x87 = 2.0*x2;
    double x88 = 598.64130850703327*x4;
    double x89 = -598.64130850703327*x31;
    double x90 = 399.0942056713555*x4;
    double x91 = n2*x29;
    double x92 = -x91;
    double x93 = n1*x90 + x92;
    double x94 = x7*x71 + x93;
    double x95 = n3*x29;
    double x96 = -x95;
    double x97 = -399.0942056713555*x2;
    double x98 = x96 + x97;
    double x99 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3;
    double x100 = x1*x99;
    double x101 = x2*x99;
    double x102 = x101*x81;
    double x103 = 6*x99;
    double x104 = x4*x86;
    double x105 = 99.773551417838874*x61;
    double x106 = 99.773551417838874*x64;
    double x107 = sqrt(1 - 0.005235602094240838*T);
    double x108 = 1.0*x107;
    double x109 = fmin(4, x108);
    double x110 = (4 - x108 >= 0. ? 1. : 0.)/x107;
    double x111 = -80.288100000000014*((x109)*(x109))*x110 + 160.5762*x109 - 0.002617801047120419*x110*(160.5762*T - 30670.054199999999) - 160.5762;
    double x112 = n1*x85 + n2*x105 + n2*x111 + n3*x106 + 3*x55 + 3*x57 + 3*x59;
    double x113 = -x103*x112*x30 + 2.0*x112*x4;
    double x114 = -x12;
    double x115 = x16 - x17;
    double x116 = x0*(x114 + x6) + x115 + x15;
    double x117 = 2.0*x1;
    double x118 = x33*x49;
    double x119 = x116*x117 - x116*x118 + x67;
    double x120 = -n1*x17;
    double x121 = x1 - x73;
    double x122 = x0*x121;
    double x123 = 33.257850472612958*x122;
    double x124 = x120 + x123 + x23 + x56 + x62 - 53.525399999999998;
    double x125 = x35*x49;
    double x126 = x124*x125 - x124*x87;
    double x127 = x119 + x126;
    double x128 = -x2;
    double x129 = x37*(x128 + x36);
    double x130 = x3 + x46;
    double x131 = 4*x49;
    double x132 = x131*x54 + 1.0*x20 - 4.0*x28 + x50*(x0*(x32 + x40) + 33.257850472612958*x129 + x130 + x44) - x52;
    double x133 = -x77;
    double x134 = x78 - x79;
    double x135 = x0*(x133 + x70) + x134 + x76;
    double x136 = 0.66666666666666663*x1;
    double x137 = x33*x99;
    double x138 = x113 + x135*x136 - x135*x137;
    double x139 = -99.773551417838874*x24;
    double x140 = 99.773551417838874*x122;
    double x141 = x105 + x111 + x139 + x140 + 3*x56 + x84;
    double x142 = 0.66666666666666663*x2;
    double x143 = x35*x99;
    double x144 = -x141*x142 + x141*x143;
    double x145 = x138 + x144;
    double x146 = 1.3333333333333333*x2;
    double x147 = -199.54710283567778*x2 + x96;
    double x148 = 4*x99;
    double x149 = x100*(x0*(x89 + x90) + 99.773551417838874*x129 + x147 + x94) - x102 + x104*x148 - x146*x86 + 0.33333333333333331*x82;
    double x150 = -n3*x2 + x1;
    double x151 = x0*x150;
    double x152 = 33.257850472612958*x151;
    double x153 = x120 + x152 + x22 + x58 + x65;
    double x154 = x125*x153 - x153*x87;
    double x155 = 99.773551417838874*x151;
    double x156 = x106 + x139 + x155 + 3*x58 + x83;
    double x157 = -x142*x156 + x143*x156;
    double x158 = x12 + x46;
    double x159 = x125*x27 - 2.0*x28 + x50*(x0*(x32 + x5) + x158 + x43);
    double x160 = x119 + x159;
    double x161 = 1.0/n2;
    double x162 = -x13 + x14;
    double x163 = x0*(x3 + x41) + x123*x161 + x162 + x18;
    double x164 = 1.0*x1;
    double x165 = 4.0*x2;
    double x166 = x163*x51;
    double x167 = x131*x4;
    double x168 = -x124*x165 + x124*x167 + x163*x164 - x166;
    double x169 = x77 + x96;
    double x170 = x100*(x0*(x29 + x89) + x169 + x93) - x142*x86 + x143*x86;
    double x171 = x138 + x170;
    double x172 = -x74 + x75;
    double x173 = x0*(x69 + x91) + x140*x161 + x172 + x80;
    double x174 = 0.33333333333333331*x1;
    double x175 = x101*x173;
    double x176 = x148*x4;
    double x177 = -x141*x146 + x141*x176 + x173*x174 - x175;
    double x178 = x0*(x114 + x41) + x115 + x162;
    double x179 = x0*(x133 + x91) + x134 + x172;
    double x180 = 1.0/n3;
    double x181 = x0*(x3 + x45) + x13 + x14 + x152*x180 - x16 + x17;
    double x182 = x181*x51;
    double x183 = -x153*x165 + x153*x167 + x164*x181 - x182;
    double x184 = x0*(x69 + x95) + x155*x180 + x74 + x75 - x78 + x79;
    double x185 = x101*x184;
    double x186 = -x146*x156 + x156*x176 + x174*x184 - x185;
    double x187 = 3.0*x1;
    double x188 = 6.0*x2;
    double x189 = n2*x30;
    double x190 = -199.54710283567775*x189;
    double x191 = n2*x35;
    double x192 = x0*x161;
    double x193 = x192*(x191 + x34);
    double x194 = pow(n2, -2);
    double x195 = x121*x161;
    double x196 = -x6;
    double x197 = n2*x40 + x196;
    double x198 = 33.257850472612958*x195 + x197;
    double x199 = x4*x53;
    double x200 = -598.64130850703327*x189;
    double x201 = -x70;
    double x202 = n2*x90 + x201;
    double x203 = 99.773551417838874*x195 + x202;
    double x204 = x103*x4;
    double x205 = x192*(x128 + x191);
    double x206 = x117*x178 - x118*x178 + x67;
    double x207 = x113 + x136*x179 - x137*x179;
    double x208 = x150*x180;
    double x209 = n3*x30;
    double x210 = pow(n3, -2);
    double x211 = x0*x180*(n3*x35 + x34);

if (x68) {
   result[0] = 3.0*x20 - 6.0*x28 + x50*(x0*(x29 + x32) - x11*x39 + 33.257850472612958*x38 + x44 + x48) - 3*x52 + x53*x54 + x67;
}
else {
   result[0] = x100*(x0*(x88 + x89) + 99.773551417838874*x38 - x39*x72 + x94 + x98) - 3*x102 + x103*x104 + x113 + 1.0*x82 - x86*x87;
}
if (x68) {
   result[1] = x127 + x132;
}
else {
   result[1] = x145 + x149;
}
if (x68) {
   result[2] = x119 + x132 + x154;
}
else {
   result[2] = x138 + x149 + x157;
}
if (x68) {
   result[3] = x160 + x168;
}
else {
   result[3] = x171 + x177;
}
if (x68) {
   result[4] = x127 + x154 + x159 + x164*x178 - x178*x51;
}
else {
   result[4] = -x101*x179 + x145 + x157 + x170 + x174*x179;
}
if (x68) {
   result[5] = x160 + x183;
}
else {
   result[5] = x171 + x186;
}
if (x68) {
   result[6] = -x124*x188 + x124*x199 + x163*x187 - 3*x166 + x50*(x0*(x190 + x29) - x123*x194 + 33.257850472612958*x193 + x198 + x48) + x67;
}
else {
   result[6] = x100*(x0*(x200 + x88) - x140*x194 + 99.773551417838874*x193 + x203 + x98) + x113 + x141*x204 - x141*x87 + x164*x173 - 3*x175;
}
if (x68) {
   result[7] = x154 + x168 + x206 + x50*(x0*(x190 + x40) + x130 + x198 + 33.257850472612958*x205);
}
else {
   result[7] = x100*(x0*(x200 + x90) + x147 + x203 + 99.773551417838874*x205) + x157 + x177 + x207;
}
if (x68) {
   result[8] = x126 + x183 + x206 + x50*(x0*(x190 + x5) + x158 + x197);
}
else {
   result[8] = x100*(x0*(x200 + x29) + x169 + x202) + x144 + x186 + x207;
}
if (x68) {
   result[9] = -x153*x188 + x153*x199 + x181*x187 - 3*x182 + x50*(n3*x40 + x0*(-199.54710283567775*x209 + x29) - x152*x210 + x196 + 33.257850472612958*x208 + 33.257850472612958*x211 + x42 + x47) + x67;
}
else {
   result[9] = x100*(n3*x90 + x0*(-598.64130850703327*x209 + x88) - x155*x210 + x201 + 99.773551417838874*x208 + 99.773551417838874*x211 + x92 + x97) + x113 + x156*x204 - x156*x87 + x164*x184 - 3*x185;
}
}
        
static double coder_dgdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = 1.0/(n1 + n2 + n3);
    double x1 = 0.043999999999999997*n1*n2;
    double x2 = n1*(*endmember[0].dmu0dP)(T, P);
    double x3 = n2*(*endmember[1].dmu0dP)(T, P);
    double x4 = n3*(*endmember[2].dmu0dP)(T, P);

if (T >= 191.0) {
   result = x0*(x1 + (1.0*n1 + 1.0*n2 + 1.0*n3)*(x2 + x3 + x4));
}
else {
   result = x0*(x1 + (0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3)*(3*x2 + 3*x3 + 3*x4));
}
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = pow(x0, -2);
    double x2 = 0.043999999999999997*n2;
    double x3 = n1*x2;
    double x4 = 1.0*n1;
    double x5 = 1.0*n2;
    double x6 = 1.0*n3;
    double x7 = x4 + x5 + x6;
    double x8 = (*endmember[0].dmu0dP)(T, P);
    double x9 = n1*x8;
    double x10 = (*endmember[1].dmu0dP)(T, P);
    double x11 = n2*x10;
    double x12 = (*endmember[2].dmu0dP)(T, P);
    double x13 = n3*x12;
    double x14 = -x1*(x3 + x7*(x11 + x13 + x9));
    double x15 = 1.0/x0;
    double x16 = x10*x5 + x12*x6 + x4*x8;
    double x17 = x16 + x2;
    double x18 = T >= 191.0;
    double x19 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3;
    double x20 = -x1*(x19*(3*x11 + 3*x13 + 3*x9) + x3);
    double x21 = 3*x19;
    double x22 = 0.043999999999999997*n1 + x16;

if (x18) {
   result[0] = x14 + x15*(x17 + x7*x8);
}
else {
   result[0] = x15*(x17 + x21*x8) + x20;
}
if (x18) {
   result[1] = x14 + x15*(x10*x7 + x22);
}
else {
   result[1] = x15*(x10*x21 + x22) + x20;
}
if (x18) {
   result[2] = x14 + x15*(x12*x7 + x16);
}
else {
   result[2] = x15*(x12*x21 + x16) + x20;
}
}
        
static void coder_d3gdn2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2 + n3;
    double x2 = 1.0/x1;
    double x3 = 2.0*x2;
    double x4 = x0*x3;
    double x5 = 0.043999999999999997*n2;
    double x6 = n1*x5;
    double x7 = 1.0*n1;
    double x8 = 1.0*n2;
    double x9 = 1.0*n3;
    double x10 = x7 + x8 + x9;
    double x11 = n1*x0;
    double x12 = (*endmember[1].dmu0dP)(T, P);
    double x13 = n2*x12;
    double x14 = (*endmember[2].dmu0dP)(T, P);
    double x15 = n3*x14;
    double x16 = 2/((x1)*(x1)*(x1));
    double x17 = x16*(x10*(x11 + x13 + x15) + x6);
    double x18 = pow(x1, -2);
    double x19 = x0*x7 + x12*x8 + x14*x9;
    double x20 = x19 + x5;
    double x21 = x18*(x0*x10 + x20);
    double x22 = T >= 191.0;
    double x23 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3;
    double x24 = x16*(x23*(3*x11 + 3*x13 + 3*x15) + x6);
    double x25 = 3*x23;
    double x26 = x18*(x0*x25 + x20);
    double x27 = 1.0*x0;
    double x28 = 1.0*x12;
    double x29 = x2*(x27 + x28 + 0.043999999999999997);
    double x30 = 0.043999999999999997*n1 + x19;
    double x31 = x18*(x10*x12 + x30);
    double x32 = -x31;
    double x33 = x17 - x21;
    double x34 = x18*(x12*x25 + x30);
    double x35 = -x34;
    double x36 = x24 - x26;
    double x37 = 1.0*x14;
    double x38 = x2*(x27 + x37);
    double x39 = x18*(x10*x14 + x19);
    double x40 = -x39;
    double x41 = x18*(x14*x25 + x19);
    double x42 = -x41;
    double x43 = x12*x3;
    double x44 = x2*(x28 + x37);
    double x45 = x14*x3;

if (x22) {
   result[0] = x17 - 2*x21 + x4;
}
else {
   result[0] = x24 - 2*x26 + x4;
}
if (x22) {
   result[1] = x29 + x32 + x33;
}
else {
   result[1] = x29 + x35 + x36;
}
if (x22) {
   result[2] = x33 + x38 + x40;
}
else {
   result[2] = x36 + x38 + x42;
}
if (x22) {
   result[3] = x17 - 2*x31 + x43;
}
else {
   result[3] = x24 - 2*x34 + x43;
}
if (x22) {
   result[4] = x17 + x32 + x40 + x44;
}
else {
   result[4] = x24 + x35 + x42 + x44;
}
if (x22) {
   result[5] = x17 - 2*x39 + x45;
}
else {
   result[5] = x24 - 2*x41 + x45;
}
}
        
static void coder_d4gdn3dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2 + n3;
    double x2 = pow(x1, -2);
    double x3 = x0*x2;
    double x4 = -6.0*x3;
    double x5 = 0.043999999999999997*n2;
    double x6 = n1*x5;
    double x7 = 1.0*n1;
    double x8 = 1.0*n2;
    double x9 = 1.0*n3;
    double x10 = x7 + x8 + x9;
    double x11 = n1*x0;
    double x12 = (*endmember[1].dmu0dP)(T, P);
    double x13 = n2*x12;
    double x14 = (*endmember[2].dmu0dP)(T, P);
    double x15 = n3*x14;
    double x16 = 6/((x1)*(x1)*(x1)*(x1));
    double x17 = -x16*(x10*(x11 + x13 + x15) + x6);
    double x18 = x0*x7 + x12*x8 + x14*x9;
    double x19 = x18 + x5;
    double x20 = x0*x10 + x19;
    double x21 = pow(x1, -3);
    double x22 = 6*x21;
    double x23 = T >= 191.0;
    double x24 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3;
    double x25 = -x16*(x24*(3*x11 + 3*x13 + 3*x15) + x6);
    double x26 = 3*x24;
    double x27 = x0*x26 + x19;
    double x28 = 4*x21;
    double x29 = x20*x28;
    double x30 = 1.0*x0;
    double x31 = 1.0*x12;
    double x32 = x2*(x30 + x31 + 0.043999999999999997);
    double x33 = -2*x32;
    double x34 = -2.0*x3;
    double x35 = x33 + x34;
    double x36 = 0.043999999999999997*n1 + x18;
    double x37 = x10*x12 + x36;
    double x38 = 2*x21;
    double x39 = x17 + x37*x38;
    double x40 = x12*x26 + x36;
    double x41 = x38*x40;
    double x42 = x25 + x27*x28;
    double x43 = 1.0*x14;
    double x44 = x2*(x30 + x43);
    double x45 = -2*x44;
    double x46 = x34 + x45;
    double x47 = x10*x14 + x18;
    double x48 = x38*x47;
    double x49 = x17 + x48;
    double x50 = x14*x26 + x18;
    double x51 = x38*x50;
    double x52 = x28*x37;
    double x53 = 2.0*x2;
    double x54 = -x12*x53;
    double x55 = x33 + x54;
    double x56 = x20*x38;
    double x57 = x17 + x56;
    double x58 = x28*x40;
    double x59 = x25 + x27*x38;
    double x60 = x2*(x31 + x43);
    double x61 = -x32 - x44 - x60;
    double x62 = x28*x47;
    double x63 = -x14*x53;
    double x64 = x45 + x63;
    double x65 = x28*x50;
    double x66 = 6.0*x2;
    double x67 = -x12*x66;
    double x68 = -2*x60;
    double x69 = x54 + x68;
    double x70 = x63 + x68;
    double x71 = -x14*x66;

if (x23) {
   result[0] = x17 + x20*x22 + x4;
}
else {
   result[0] = x22*x27 + x25 + x4;
}
if (x23) {
   result[1] = x29 + x35 + x39;
}
else {
   result[1] = x35 + x41 + x42;
}
if (x23) {
   result[2] = x29 + x46 + x49;
}
else {
   result[2] = x42 + x46 + x51;
}
if (x23) {
   result[3] = x52 + x55 + x57;
}
else {
   result[3] = x55 + x58 + x59;
}
if (x23) {
   result[4] = x39 + x48 + x56 + x61;
}
else {
   result[4] = x41 + x51 + x59 + x61;
}
if (x23) {
   result[5] = x57 + x62 + x64;
}
else {
   result[5] = x59 + x64 + x65;
}
if (x23) {
   result[6] = x17 + x22*x37 + x67;
}
else {
   result[6] = x22*x40 + x25 + x67;
}
if (x23) {
   result[7] = x49 + x52 + x69;
}
else {
   result[7] = x25 + x51 + x58 + x69;
}
if (x23) {
   result[8] = x39 + x62 + x70;
}
else {
   result[8] = x25 + x41 + x65 + x70;
}
if (x23) {
   result[9] = x17 + x22*x47 + x71;
}
else {
   result[9] = x22*x50 + x25 + x71;
}
}
        
static double coder_d2gdt2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = 1.0*n1*(*endmember[0].d2mu0dT2)(T, P) + 1.0*n2*(*endmember[1].d2mu0dT2)(T, P) + 1.0*n3*(*endmember[2].d2mu0dT2)(T, P);
    double x1 = 0.005235602094240838*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 0.001100409802362874*T - 0.21017827225130892;
    double x7 = 1.0/(x1 - 1);
    double x8 = x7*0;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = 0.21017827225130895*((x10)*(x10));

if (T >= 191.0) {
   result = x0;
}
else {
   result = -0.33333333333333331*n2*(0.42035654450261789*x10*((x5)*(x5))*x7 - x11*x8 + x11*x9 - x6*x8 + x6*x9 + 0.84071308900523567*x5/x3) + x0;
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 1.0*(*endmember[1].d2mu0dT2)(T, P);
    double x1 = 0.005235602094240838*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 1.0/(x1 - 1);
    double x7 = x6*0;
    double x8 = 0.00036680326745429132*T - 0.070059424083769639;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = 0.070059424083769639*((x10)*(x10));

result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
if (T >= 191.0) {
   result[1] = x0;
}
else {
   result[1] = x0 - 0.14011884816753928*x10*((x5)*(x5))*x6 + x11*x7 - x11*x9 + x7*x8 - x8*x9 - 0.28023769633507856*x5/x3;
}
result[2] = 1.0*(*endmember[2].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dTdP)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dTdP)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dTdP)(T, P);

if (T >= 191.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = x0 + x1 + x2;
}
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dP2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dP2)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dP2)(T, P);

if (T >= 191.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = x0 + x1 + x2;
}
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = 1.0*n1*(*endmember[0].d3mu0dT3)(T, P) + 1.0*n2*(*endmember[1].d3mu0dT3)(T, P) + 1.0*n3*(*endmember[2].d3mu0dT3)(T, P);
    double x1 = 0.005235602094240838*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = pow(x3, -3.0/2.0);
    double x8 = (4 - x4 >= 0. ? 1. : 0.);
    double x9 = x7*x8;
    double x10 = 160.5762*T - 30670.054199999999;
    double x11 = pow(x2, -2);
    double x12 = x11*x6;
    double x13 = x8/pow(x3, 5.0/2.0);
    double x14 = x7*0;
    double x15 = fmin(4, x4);
    double x16 = ((x15)*(x15));
    double x17 = 0.0033012294070886225*x15;

if (T >= 191.0) {
   result = x0;
}
else {
   result = -0.33333333333333331*n2*(5.3818447557367247e-8*x10*x12 + 5.3818447557367253e-8*x10*x13 - 1.7939482519122417e-8*x10*x14 - x11*x17*((x8)*(x8)) + 0.0016506147035443113*x12*x16 + 0.0016506147035443115*x13*x16 - 0.00055020490118143708*x14*x16 - x17*x6*x9 + 0.0011004098023628742*x7*((x8)*(x8)*(x8)) + 0.0033012294070886216*x9 - 0.0033012294070886216*x6/x2) + x0;
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 1.0*(*endmember[1].d3mu0dT3)(T, P);
    double x1 = 0.005235602094240838*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = pow(x3, -3.0/2.0);
    double x8 = (4 - x4 >= 0. ? 1. : 0.);
    double x9 = x7*x8;
    double x10 = 160.5762*T - 30670.054199999999;
    double x11 = pow(x2, -2);
    double x12 = x11*x6;
    double x13 = x8/pow(x3, 5.0/2.0);
    double x14 = x7*0;
    double x15 = fmin(4, x4);
    double x16 = ((x15)*(x15));
    double x17 = 0.00055020490118143708*x16;
    double x18 = 0.0011004098023628742*x15;

result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
if (T >= 191.0) {
   result[1] = x0;
}
else {
   result[1] = x0 - 1.7939482519122413e-8*x10*x12 - 1.7939482519122417e-8*x10*x13 + 5.9798275063741389e-9*x10*x14 + x11*x18*((x8)*(x8)) - x12*x17 - x13*x17 + 0.00018340163372714569*x14*x16 + x18*x6*x9 - 0.00036680326745429137*x7*((x8)*(x8)*(x8)) - 0.0011004098023628737*x9 + 0.0011004098023628737*x6/x2;
}
result[2] = 1.0*(*endmember[2].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT2dP)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT2dP)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dT2dP)(T, P);

if (T >= 191.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = x0 + x1 + x2;
}
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dTdP2)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dTdP2)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dTdP2)(T, P);

if (T >= 191.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = x0 + x1 + x2;
}
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dP3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dP3)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dP3)(T, P);

if (T >= 191.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = x0 + x1 + x2;
}
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_s(double T, double P, double n[3]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[3]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[3]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[3]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[3]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[3]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

