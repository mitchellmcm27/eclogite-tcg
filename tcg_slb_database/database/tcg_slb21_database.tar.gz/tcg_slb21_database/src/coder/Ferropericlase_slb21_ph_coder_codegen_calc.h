#include <math.h>


static double coder_g(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = 1.0/x1;
    double x3 = n1*(*endmember[0].mu0)(T, P);
    double x4 = n2*(*endmember[1].mu0)(T, P);
    double x5 = n3*(*endmember[2].mu0)(T, P);
    double x6 = T*(n1*log(n1*x2) + n2*log(n2*x2) + n3*log(n3*x2));
    double x7 = 240000.0*n3;
    double x8 = 0.087999999999999995*P + 88000.0;
    double x9 = 0.25*n1*(n2*x8 + x7) + 0.25*n2*(n1*x8 + x7) + 60000.0*n3*x0;
    double x10 = fmin(4, 1.0*sqrt(1 - 0.005235602094240838*T));

if (T >= 191.0) {
   result = x2*(1.0*x1*(-n2*(53.525399999999998*T - 6815.5675999999994) + x3 + x4 + x5 + 33.257850472612958*x6) + x9);
}
else {
   result = x2*(0.33333333333333331*x1*(n2*(10223.3514*((x10)*(x10)*(x10)) + (160.5762*T - 30670.054199999999)*(x10 - 1) - 10223.3514) + 3*x3 + 3*x4 + 3*x5 + 99.773551417838874*x6) + x9);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = pow(x1, -2);
    double x3 = (*endmember[0].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = n2*x5;
    double x7 = (*endmember[2].mu0)(T, P);
    double x8 = n3*x7;
    double x9 = 53.525399999999998*T;
    double x10 = n2*(x9 - 6815.5675999999994);
    double x11 = 1.0/x1;
    double x12 = n1*x11;
    double x13 = log(x12);
    double x14 = n2*x11;
    double x15 = log(x14);
    double x16 = n3*x11;
    double x17 = log(x16);
    double x18 = n1*x13 + n2*x15 + n3*x17;
    double x19 = 33.257850472612958*T;
    double x20 = x18*x19;
    double x21 = 1.0*x1;
    double x22 = 240000.0*n3;
    double x23 = 0.043999999999999997*P + 44000.0;
    double x24 = n2*x23;
    double x25 = 0.25*n1;
    double x26 = n1*x23;
    double x27 = 0.25*n2;
    double x28 = 60000.0*n3*x0 + x25*(x22 + 2.0*x24) + x27*(x22 + 2.0*x26);
    double x29 = -x2*(x21*(-x10 + x20 + x4 + x6 + x8) + x28);
    double x30 = -x11;
    double x31 = x1*(-n1*x2 - x30) + x13 - x14 - x16;
    double x32 = 120000.0*n3;
    double x33 = x20 + 1.0*x4 + 1.0*x6 + 1.0*x8;
    double x34 = -1.0*x10 + x33;
    double x35 = x32 + x34;
    double x36 = 0.087999999999999995*P + 88000.0;
    double x37 = 0.5*x24 + x27*x36;
    double x38 = T >= 191.0;
    double x39 = fmin(4, 1.0*sqrt(1 - 0.005235602094240838*T));
    double x40 = 10223.3514*((x39)*(x39)*(x39)) + (160.5762*T - 30670.054199999999)*(x39 - 1) - 10223.3514;
    double x41 = n2*x40;
    double x42 = 99.773551417838874*T;
    double x43 = 0.33333333333333331*x1;
    double x44 = -x2*(x28 + x43*(x18*x42 + 3*x4 + x41 + 3*x6 + 3*x8));
    double x45 = x33 + 0.33333333333333331*x41;
    double x46 = x32 + x45;
    double x47 = x1*(-n2*x2 - x30) - x12 + x15 - x16;
    double x48 = x25*x36 + 0.5*x26;
    double x49 = x1*(-n3*x2 - x30) - x12 - x14 + x17;
    double x50 = 120000.0*n1 + 120000.0*n2;

if (x38) {
   result[0] = x11*(x21*(x19*x31 + x3) + x35 + x37) + x29;
}
else {
   result[0] = x11*(x37 + x43*(3*x3 + x31*x42) + x46) + x44;
}
if (x38) {
   result[1] = x11*(x21*(x19*x47 + x5 - x9 + 6815.5675999999994) + x35 + x48) + x29;
}
else {
   result[1] = x11*(x43*(x40 + x42*x47 + 3*x5) + x46 + x48) + x44;
}
if (x38) {
   result[2] = x11*(x21*(x19*x49 + x7) + x34 + x50) + x29;
}
else {
   result[2] = x11*(x43*(x42*x49 + 3*x7) + x45 + x50) + x44;
}
}
        
static void coder_d2gdn2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n3*x4;
    double x6 = 53.525399999999998*T;
    double x7 = n2*(x6 - 6815.5675999999994);
    double x8 = n1 + n2;
    double x9 = n3 + x8;
    double x10 = 1.0/x9;
    double x11 = n1*x10;
    double x12 = log(x11);
    double x13 = n2*x10;
    double x14 = log(x13);
    double x15 = n3*x10;
    double x16 = log(x15);
    double x17 = T*(n1*x12 + n2*x14 + n3*x16);
    double x18 = 33.257850472612958*x17;
    double x19 = 1.0*x9;
    double x20 = 240000.0*n3;
    double x21 = 0.043999999999999997*P;
    double x22 = x21 + 44000.0;
    double x23 = n2*x22;
    double x24 = 0.25*n1;
    double x25 = n1*x22;
    double x26 = 0.25*n2;
    double x27 = 60000.0*n3*x8 + x24*(x20 + 2.0*x23) + x26*(x20 + 2.0*x25);
    double x28 = 2/((x9)*(x9)*(x9));
    double x29 = x28*(x19*(x1 + x18 + x3 + x5 - x7) + x27);
    double x30 = pow(x9, -2);
    double x31 = n1*x30;
    double x32 = -x10;
    double x33 = x31 + x32;
    double x34 = -x33;
    double x35 = T*(x12 - x13 - x15 + x34*x9);
    double x36 = 33.257850472612958*x35;
    double x37 = 120000.0*n3;
    double x38 = 1.0*x1 + x18 + 1.0*x3 + 1.0*x5;
    double x39 = x38 - 1.0*x7;
    double x40 = x37 + x39;
    double x41 = 0.087999999999999995*P + 88000.0;
    double x42 = 0.5*x23 + x26*x41;
    double x43 = x19*(x0 + x36) + x40 + x42;
    double x44 = 2*x30;
    double x45 = -x44;
    double x46 = n1*x28;
    double x47 = n3*x30;
    double x48 = -x31 + x47;
    double x49 = n2*x30;
    double x50 = x10 + x49;
    double x51 = 33.257850472612958*T*x9;
    double x52 = x10*(2.0*x0 + 66.515700945225916*x35 + x51*(x48 + x50 + x9*(x45 + x46) + x34*x9/n1));
    double x53 = T >= 191.0;
    double x54 = fmin(4, 1.0*sqrt(1 - 0.005235602094240838*T));
    double x55 = ((x54)*(x54)*(x54));
    double x56 = (160.5762*T - 30670.054199999999)*(x54 - 1);
    double x57 = 10223.3514*x55 + x56 - 10223.3514;
    double x58 = n2*x57;
    double x59 = 0.33333333333333331*x9;
    double x60 = x28*(x27 + x59*(3*x1 + 99.773551417838874*x17 + 3*x3 + 3*x5 + x58));
    double x61 = x38 + 0.33333333333333331*x58;
    double x62 = x37 + x61;
    double x63 = x42 + x59*(3*x0 + 99.773551417838874*x35) + x62;
    double x64 = 1.0*x2;
    double x65 = x32 + x49;
    double x66 = -x65;
    double x67 = T*(-x11 + x14 - x15 + x66*x9);
    double x68 = 33.257850472612958*x67;
    double x69 = -x6 + x68;
    double x70 = x64 + x69;
    double x71 = -x30;
    double x72 = 1.0*x0 + x36 + x51*(x48 + x65 + x9*(x46 + x71));
    double x73 = x21 + x72;
    double x74 = x24*x41 + 0.5*x25;
    double x75 = x19*(x2 + x69 + 6815.5675999999994) + x40 + x74;
    double x76 = -x30*x75;
    double x77 = x29 - x30*x43;
    double x78 = 3407.7837999999997*x55 + 0.33333333333333331*x56 + x64 + x68;
    double x79 = x59*(3*x2 + x57 + 99.773551417838874*x67) + x62 + x74;
    double x80 = -x30*x79;
    double x81 = -x30*x63 + x60;
    double x82 = -x32 - x47;
    double x83 = T*(-x11 - x13 + x16 + x82*x9);
    double x84 = 33.257850472612958*x83;
    double x85 = 1.0*x4 + x84;
    double x86 = x10*(x72 + x85 + 120000.0);
    double x87 = 120000.0*n1 + 120000.0*n2;
    double x88 = x19*(x4 + x84) + x39 + x87;
    double x89 = -x30*x88;
    double x90 = x59*(3*x4 + 99.773551417838874*x83) + x61 + x87;
    double x91 = -x30*x90;
    double x92 = n2*x28;
    double x93 = x47 - x49;
    double x94 = 2.0*x2 + x51*(x10 + x31 + x9*(x45 + x92) + x93 + x66*x9/n2) + 66.515700945225916*x67;
    double x95 = x51*(x33 + x9*(x71 + x92) + x93) + x85;
    double x96 = x10*(2.0*x4 + x51*(x31 - x47 + x50 + x9*(n3*x28 + x45) + x82*x9/n3) + 66.515700945225916*x83);

if (x53) {
   result[0] = x29 - x43*x44 + x52;
}
else {
   result[0] = -x44*x63 + x52 + x60;
}
if (x53) {
   result[1] = x10*(x70 + x73 + 50815.567600000002) + x76 + x77;
}
else {
   result[1] = x10*(x73 + x78 + 40592.216200000003) + x80 + x81;
}
if (x53) {
   result[2] = x77 + x86 + x89;
}
else {
   result[2] = x81 + x86 + x91;
}
if (x53) {
   result[3] = x10*(-107.0508*T + x94 + 13631.135199999999) + x29 - x44*x75;
}
else {
   result[3] = x10*(6815.5675999999994*x55 + 0.66666666666666663*x56 + x94 - 6815.5675999999994) - x44*x79 + x60;
}
if (x53) {
   result[4] = x10*(x70 + x95 + 126815.56759999999) + x29 + x76 + x89;
}
else {
   result[4] = x10*(x78 + x95 + 116592.2162) + x60 + x80 + x91;
}
if (x53) {
   result[5] = x29 - x44*x88 + x96;
}
else {
   result[5] = -x44*x90 + x60 + x96;
}
}
        
static void coder_d3gdn3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n3*x4;
    double x6 = 53.525399999999998*T;
    double x7 = n2*(x6 - 6815.5675999999994);
    double x8 = n1 + n2;
    double x9 = n3 + x8;
    double x10 = 1.0/x9;
    double x11 = n1*x10;
    double x12 = log(x11);
    double x13 = n2*x10;
    double x14 = log(x13);
    double x15 = n3*x10;
    double x16 = log(x15);
    double x17 = n1*x12 + n2*x14 + n3*x16;
    double x18 = 33.257850472612958*T;
    double x19 = x17*x18;
    double x20 = 1.0*x9;
    double x21 = 240000.0*n3;
    double x22 = 0.043999999999999997*P;
    double x23 = x22 + 44000.0;
    double x24 = 2.0*x23;
    double x25 = 0.25*n1;
    double x26 = 0.25*n2;
    double x27 = 60000.0*n3*x8 + x25*(n2*x24 + x21) + x26*(n1*x24 + x21);
    double x28 = 6/((x9)*(x9)*(x9)*(x9));
    double x29 = -x28*(x20*(x1 + x19 + x3 + x5 - x7) + x27);
    double x30 = pow(x9, -2);
    double x31 = n1*x30;
    double x32 = -x10;
    double x33 = x31 + x32;
    double x34 = -x33;
    double x35 = x12 - x13 - x15 + x34*x9;
    double x36 = x18*x35;
    double x37 = 120000.0*n3;
    double x38 = 1.0*x1 + x19 + 1.0*x3 + 1.0*x5;
    double x39 = x38 - 1.0*x7;
    double x40 = x37 + x39;
    double x41 = 0.087999999999999995*P + 88000.0;
    double x42 = 0.5*x23;
    double x43 = n2*x42 + x26*x41;
    double x44 = x20*(x0 + x36) + x40 + x43;
    double x45 = pow(x9, -3);
    double x46 = 6*x45;
    double x47 = 2*x30;
    double x48 = -x47;
    double x49 = 2*x45;
    double x50 = n1*x49;
    double x51 = x9*(x48 + x50);
    double x52 = 1.0/n1;
    double x53 = x34*x52;
    double x54 = n3*x30;
    double x55 = -x31 + x54;
    double x56 = n2*x30;
    double x57 = x10 + x56;
    double x58 = x51 + x53*x9 + x55 + x57;
    double x59 = 99.773551417838874*T;
    double x60 = n3*x49;
    double x61 = -x60;
    double x62 = 4*x30;
    double x63 = -6*x45;
    double x64 = n1*x28;
    double x65 = n2*x49;
    double x66 = 4*x45;
    double x67 = n1*x66 - x65;
    double x68 = x53 + x67;
    double x69 = x18*x9;
    double x70 = 66.515700945225916*T;
    double x71 = x18*x58;
    double x72 = x30*(2.0*x0 + x35*x70 + x71*x9);
    double x73 = x10*(x58*x59 + x69*(x51*x52 + x61 - x62 + x68 + x9*(-x63 - x64) - x34*x9/((n1)*(n1)))) - 3*x72;
    double x74 = T >= 191.0;
    double x75 = fmin(4, 1.0*sqrt(1 - 0.005235602094240838*T));
    double x76 = ((x75)*(x75)*(x75));
    double x77 = (160.5762*T - 30670.054199999999)*(x75 - 1);
    double x78 = 10223.3514*x76 + x77 - 10223.3514;
    double x79 = n2*x78;
    double x80 = 0.33333333333333331*x9;
    double x81 = -x28*(x27 + x80*(3*x1 + x17*x59 + 3*x3 + 3*x5 + x79));
    double x82 = x38 + 0.33333333333333331*x79;
    double x83 = x37 + x82;
    double x84 = x43 + x80*(3*x0 + x35*x59) + x83;
    double x85 = x32 + x56;
    double x86 = -x85;
    double x87 = -x11 + x14 - x15 + x86*x9;
    double x88 = x18*x87;
    double x89 = -x6 + x88;
    double x90 = n1*x42 + x25*x41;
    double x91 = x20*(x2 + x89 + 6815.5675999999994) + x40 + x90;
    double x92 = x49*x91;
    double x93 = 1.0*x2;
    double x94 = x89 + x93;
    double x95 = -x30;
    double x96 = x9*(x50 + x95);
    double x97 = x55 + x85 + x96;
    double x98 = 1.0*x0 + x36 + x69*x97;
    double x99 = x22 + x98;
    double x100 = x94 + x99 + 50815.567600000002;
    double x101 = -x100*x47 + x29;
    double x102 = x70*x97;
    double x103 = -4*x45;
    double x104 = x48 + x61;
    double x105 = x10*(x102 + x69*(x104 + x52*x96 + x68 + x9*(-x103 - x64)) + x71) - x72;
    double x106 = x105 + x44*x66;
    double x107 = x80*(3*x2 + x59*x87 + x78) + x83 + x90;
    double x108 = x107*x49;
    double x109 = 3407.7837999999997*x76 + 0.33333333333333331*x77 + x88 + x93;
    double x110 = x109 + x99 + 40592.216200000003;
    double x111 = -x110*x47 + x81;
    double x112 = x105 + x66*x84;
    double x113 = -x32 - x54;
    double x114 = -x11 + x113*x9 - x13 + x16;
    double x115 = x114*x18;
    double x116 = 120000.0*n1 + 120000.0*n2;
    double x117 = x116 + x20*(x115 + x4) + x39;
    double x118 = x117*x49;
    double x119 = x115 + 1.0*x4;
    double x120 = x119 + x98 + 120000.0;
    double x121 = -x120*x47;
    double x122 = x121 + x29;
    double x123 = x116 + x80*(x114*x59 + 3*x4) + x82;
    double x124 = x123*x49;
    double x125 = x121 + x81;
    double x126 = x48 + x65;
    double x127 = 1.0/n2;
    double x128 = x86*x9;
    double x129 = x54 - x56;
    double x130 = x10 + x126*x9 + x127*x128 + x129 + x31;
    double x131 = x130*x18;
    double x132 = -2*x45;
    double x133 = x30 + x61;
    double x134 = x102 + x69*(x133 + x67 + x9*(-x132 - x64));
    double x135 = x10*(x131 + x134);
    double x136 = x44*x49;
    double x137 = x131*x9 + 2.0*x2 + x70*x87;
    double x138 = x30*(-107.0508*T + x137 + 13631.135199999999);
    double x139 = -x138 + x66*x91;
    double x140 = x49*x84;
    double x141 = x30*(x137 + 6815.5675999999994*x76 + 0.66666666666666663*x77 - 6815.5675999999994);
    double x142 = x107*x66 - x141;
    double x143 = x9*(x65 + x95);
    double x144 = x129 + x143 + x33;
    double x145 = x144*x18;
    double x146 = x119 + x145*x9;
    double x147 = x146 + x94 + 126815.56759999999;
    double x148 = x10*(x134 + x145) - x120*x30;
    double x149 = x109 + x146 + 116592.2162;
    double x150 = x117*x66;
    double x151 = x48 + x60;
    double x152 = 1.0/n3;
    double x153 = x113*x9;
    double x154 = x151*x9 + x152*x153 + x31 - x54 + x57;
    double x155 = x154*x18;
    double x156 = x30*(x114*x70 + x155*x9 + 2.0*x4);
    double x157 = -x156;
    double x158 = x10*(x134 + x155) + x157;
    double x159 = x123*x66;
    double x160 = n2*x28;
    double x161 = x50 + x62;
    double x162 = x10*(x130*x59 + x69*(4*n2*x45 + x126*x127*x9 + x127*x86 - x161 - x60 + x9*(-x160 - x63) - x128/((n2)*(n2))));
    double x163 = x144*x70;
    double x164 = n2*x66 - x50;
    double x165 = x10*(x131 + x163 + x69*(x104 + x127*x143 + x127*x86 + x164 + x9*(-x103 - x160)));
    double x166 = -x147*x47 + x29;
    double x167 = -x149*x47 + x81;
    double x168 = x10*(x155 + x163 + x69*(x133 + x164 + x9*(-x132 - x160))) + x157;
    double x169 = x10*(x154*x59 + x69*(4*n3*x45 + x113*x152 + x151*x152*x9 - x161 - x65 + x9*(-n3*x28 - x63) - x153/((n3)*(n3)))) - 3*x156;

if (x74) {
   result[0] = x29 + x44*x46 + x73;
}
else {
   result[0] = x46*x84 + x73 + x81;
}
if (x74) {
   result[1] = x101 + x106 + x92;
}
else {
   result[1] = x108 + x111 + x112;
}
if (x74) {
   result[2] = x106 + x118 + x122;
}
else {
   result[2] = x112 + x124 + x125;
}
if (x74) {
   result[3] = x101 + x135 + x136 + x139;
}
else {
   result[3] = x111 + x135 + x140 + x142;
}
if (x74) {
   result[4] = -x100*x30 + x118 + x136 - x147*x30 + x148 + x29 + x92;
}
else {
   result[4] = x108 - x110*x30 + x124 + x140 + x148 - x149*x30 + x81;
}
if (x74) {
   result[5] = x122 + x136 + x150 + x158;
}
else {
   result[5] = x125 + x140 + x158 + x159;
}
if (x74) {
   result[6] = -3*x138 + x162 + x29 + x46*x91;
}
else {
   result[6] = x107*x46 - 3*x141 + x162 + x81;
}
if (x74) {
   result[7] = x118 + x139 + x165 + x166;
}
else {
   result[7] = x124 + x142 + x165 + x167;
}
if (x74) {
   result[8] = x150 + x166 + x168 + x92;
}
else {
   result[8] = x108 + x159 + x167 + x168;
}
if (x74) {
   result[9] = x117*x46 + x169 + x29;
}
else {
   result[9] = x123*x46 + x169 + x81;
}
}
        
static double coder_dgdt(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = 1.0/(n1 + n2 + n3);
    double x1 = 33.257850472612958*n1*log(n1*x0) + 1.0*n1*(*endmember[0].dmu0dT)(T, P) + 33.257850472612958*n2*log(n2*x0) + 1.0*n2*(*endmember[1].dmu0dT)(T, P) + 33.257850472612958*n3*log(n3*x0) + 1.0*n3*(*endmember[2].dmu0dT)(T, P);
    double x2 = sqrt(1 - 0.005235602094240838*T);
    double x3 = 1.0*x2;
    double x4 = fmin(4, x3);
    double x5 = (4 - x3 >= 0. ? 1. : 0.)/x2;

if (T >= 191.0) {
   result = -53.525399999999998*n2 + x1;
}
else {
   result = 0.33333333333333331*n2*(-80.288100000000014*((x4)*(x4))*x5 + 160.5762*x4 - 0.002617801047120419*x5*(160.5762*T - 30670.054199999999) - 160.5762) + x1;
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = 1.0/x0;
    double x2 = n2*x1;
    double x3 = -33.257850472612958*x2;
    double x4 = n3*x1;
    double x5 = 33.257850472612958*x4;
    double x6 = n1*x1;
    double x7 = pow(x0, -2);
    double x8 = -x1;
    double x9 = 33.257850472612958*x0;
    double x10 = 33.257850472612958*x6;
    double x11 = -33.257850472612958*x0*(-n2*x7 - x8) + x10 + x5 - 33.257850472612958*log(x2) - 1.0*(*endmember[1].dmu0dT)(T, P) + 53.525399999999998;
    double x12 = sqrt(1 - 0.005235602094240838*T);
    double x13 = 1.0*x12;
    double x14 = fmin(4, x13);
    double x15 = (4 - x13 >= 0. ? 1. : 0.)/x12;

result[0] = x3 - x5 + x9*(-n1*x7 - x8) + 33.257850472612958*log(x6) + 1.0*(*endmember[0].dmu0dT)(T, P);
if (T >= 191.0) {
   result[1] = -x11;
}
else {
   result[1] = -x11 - 26.762700000000002*((x14)*(x14))*x15 + 53.525399999999998*x14 - 0.00087260034904013963*x15*(160.5762*T - 30670.054199999999);
}
result[2] = -x10 + x3 + x9*(-n3*x7 - x8) + 33.257850472612958*log(x4) + 1.0*(*endmember[2].dmu0dT)(T, P);
}
        
static void coder_d3gdn2dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = pow(x0, -2);
    double x2 = -2*x1;
    double x3 = 2/((x0)*(x0)*(x0));
    double x4 = n1*x3;
    double x5 = 33.257850472612958*x0;
    double x6 = n1*x1;
    double x7 = 1.0/x0;
    double x8 = -x7;
    double x9 = n2*x1;
    double x10 = 33.257850472612958*x9;
    double x11 = 33.257850472612958*x6;
    double x12 = x10 - x11;
    double x13 = n3*x1;
    double x14 = 33.257850472612958*x13;
    double x15 = 33.257850472612958*x7;
    double x16 = x14 + x15;
    double x17 = -x1;
    double x18 = x14 - x15;
    double x19 = x12 + x18 + x5*(x17 + x4);
    double x20 = n2*x3;
    double x21 = -x10 + x11;

result[0] = x12 + x16 + x5*(x2 + x4) + x5*(-x6 - x8)/n1;
result[1] = x19;
result[2] = x19;
result[3] = x16 + x21 + x5*(x2 + x20) + x5*(-x8 - x9)/n2;
result[4] = x18 + x21 + x5*(x17 + x20);
result[5] = x10 + x11 - x14 + x15 + x5*(n3*x3 + x2) + x5*(-x13 - x8)/n3;
}
        
static void coder_d4gdn3dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = pow(x0, -3);
    double x2 = 66.515700945225916*x1;
    double x3 = n3*x2;
    double x4 = -x3;
    double x5 = pow(x0, -2);
    double x6 = 133.03140189045183*x5;
    double x7 = -6*x1;
    double x8 = 6/((x0)*(x0)*(x0)*(x0));
    double x9 = n1*x8;
    double x10 = 33.257850472612958*x0;
    double x11 = -2*x5;
    double x12 = 2*x1;
    double x13 = n1*x12;
    double x14 = 33.257850472612958/n1;
    double x15 = x0*x14;
    double x16 = -1/x0;
    double x17 = -n1*x5 - x16;
    double x18 = 133.03140189045183*x1;
    double x19 = n2*x2;
    double x20 = n1*x18 - x19;
    double x21 = x14*x17 + x20;
    double x22 = -4*x1;
    double x23 = -x5;
    double x24 = x4 - 66.515700945225916*x5;
    double x25 = x10*(-x22 - x9) + x15*(x13 + x23) + x21 + x24;
    double x26 = -2*x1;
    double x27 = x4 + 33.257850472612958*x5;
    double x28 = x10*(-x26 - x9) + x20 + x27;
    double x29 = 1.0/n2;
    double x30 = -n2*x5 - x16;
    double x31 = n2*x8;
    double x32 = n2*x12;
    double x33 = n1*x2;
    double x34 = x33 + x6;
    double x35 = n2*x18 - x33;
    double x36 = 1.0/n3;
    double x37 = -n3*x5 - x16;

result[0] = x10*(-x7 - x9) + x15*(x11 + x13) + x21 + x4 - x6 - x10*x17/((n1)*(n1));
result[1] = x25;
result[2] = x25;
result[3] = x28;
result[4] = x28;
result[5] = x28;
result[6] = 133.03140189045183*n2*x1 + 33.257850472612958*x0*x29*(x11 + x32) + 33.257850472612958*x0*(-x31 - x7) + 33.257850472612958*x29*x30 - x3 - x34 - x10*x30/((n2)*(n2));
result[7] = x10*x29*(x23 + x32) + x10*(-x22 - x31) + x24 + 33.257850472612958*x29*x30 + x35;
result[8] = x10*(-x26 - x31) + x27 + x35;
result[9] = 133.03140189045183*n3*x1 + 33.257850472612958*x0*x36*(n3*x12 + x11) + 33.257850472612958*x0*(-n3*x8 - x7) - x19 - x34 + 33.257850472612958*x36*x37 - x10*x37/((n3)*(n3));
}
        
static double coder_dgdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1 + n2 + n3;
    double x1 = 1.0/x0;
    double x2 = 0.043999999999999997*n1*n2;
    double x3 = n1*(*endmember[0].dmu0dP)(T, P);
    double x4 = n2*(*endmember[1].dmu0dP)(T, P);
    double x5 = n3*(*endmember[2].dmu0dP)(T, P);

if (T >= 191.0) {
   result = x1*(1.0*x0*(x3 + x4 + x5) + x2);
}
else {
   result = x1*(0.33333333333333331*x0*(3*x3 + 3*x4 + 3*x5) + x2);
}
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2 + n3;
    double x1 = pow(x0, -2);
    double x2 = 0.043999999999999997*n2;
    double x3 = n1*x2;
    double x4 = (*endmember[0].dmu0dP)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[1].dmu0dP)(T, P);
    double x7 = n2*x6;
    double x8 = (*endmember[2].dmu0dP)(T, P);
    double x9 = n3*x8;
    double x10 = 1.0*x0;
    double x11 = x1*(x10*(x5 + x7 + x9) + x3);
    double x12 = 1.0/x0;
    double x13 = 1.0*x5 + 1.0*x7 + 1.0*x9;
    double x14 = -x12*(x10*x4 + x13 + x2);
    double x15 = T >= 191.0;
    double x16 = x1*(0.33333333333333331*x0*(3*x5 + 3*x7 + 3*x9) + x3);
    double x17 = -x12*(0.043999999999999997*n1 + x10*x6 + x13);
    double x18 = -x12*(x10*x8 + x13);

if (x15) {
   result[0] = -x11 - x14;
}
else {
   result[0] = -x14 - x16;
}
if (x15) {
   result[1] = -x11 - x17;
}
else {
   result[1] = -x16 - x17;
}
if (x15) {
   result[2] = -x11 - x18;
}
else {
   result[2] = -x16 - x18;
}
}
        
static void coder_d3gdn2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 0.043999999999999997*n2;
    double x1 = n1*x0;
    double x2 = n1 + n2 + n3;
    double x3 = (*endmember[0].dmu0dP)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].dmu0dP)(T, P);
    double x6 = n2*x5;
    double x7 = (*endmember[2].dmu0dP)(T, P);
    double x8 = n3*x7;
    double x9 = 2/((x2)*(x2)*(x2));
    double x10 = x9*(x1 + 1.0*x2*(x4 + x6 + x8));
    double x11 = pow(x2, -2);
    double x12 = 1.0*x3;
    double x13 = 1.0*x4 + 1.0*x6 + 1.0*x8;
    double x14 = x11*(x0 + x12*x2 + x13);
    double x15 = 1.0/x2;
    double x16 = 2.0*x15;
    double x17 = -2*x14 + x16*x3;
    double x18 = T >= 191.0;
    double x19 = x9*(x1 + 0.33333333333333331*x2*(3*x4 + 3*x6 + 3*x8));
    double x20 = -x14;
    double x21 = x10 + x20;
    double x22 = 1.0*x5;
    double x23 = x11*(0.043999999999999997*n1 + x13 + x2*x22);
    double x24 = -x23;
    double x25 = x15*(x12 + x22 + 0.043999999999999997) + x24;
    double x26 = x19 + x20;
    double x27 = 1.0*x7;
    double x28 = x11*(x13 + x2*x27);
    double x29 = -x28;
    double x30 = x15*(x12 + x27) + x29;
    double x31 = x16*x5 - 2*x23;
    double x32 = x15*(x22 + x27) + x24 + x29;
    double x33 = x16*x7 - 2*x28;

if (x18) {
   result[0] = x10 + x17;
}
else {
   result[0] = x17 + x19;
}
if (x18) {
   result[1] = x21 + x25;
}
else {
   result[1] = x25 + x26;
}
if (x18) {
   result[2] = x21 + x30;
}
else {
   result[2] = x26 + x30;
}
if (x18) {
   result[3] = x10 + x31;
}
else {
   result[3] = x19 + x31;
}
if (x18) {
   result[4] = x10 + x32;
}
else {
   result[4] = x19 + x32;
}
if (x18) {
   result[5] = x10 + x33;
}
else {
   result[5] = x19 + x33;
}
}
        
static void coder_d4gdn3dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 0.043999999999999997*n2;
    double x1 = n1*x0;
    double x2 = n1 + n2 + n3;
    double x3 = (*endmember[0].dmu0dP)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].dmu0dP)(T, P);
    double x6 = n2*x5;
    double x7 = (*endmember[2].dmu0dP)(T, P);
    double x8 = n3*x7;
    double x9 = 6/((x2)*(x2)*(x2)*(x2));
    double x10 = x9*(x1 + 1.0*x2*(x4 + x6 + x8));
    double x11 = pow(x2, -3);
    double x12 = 1.0*x3;
    double x13 = 1.0*x4 + 1.0*x6 + 1.0*x8;
    double x14 = x0 + x12*x2 + x13;
    double x15 = pow(x2, -2);
    double x16 = x15*x3;
    double x17 = -6*x11*x14 + 6.0*x16;
    double x18 = T >= 191.0;
    double x19 = x9*(x1 + 0.33333333333333331*x2*(3*x4 + 3*x6 + 3*x8));
    double x20 = 1.0*x5;
    double x21 = x15*(x12 + x20 + 0.043999999999999997);
    double x22 = 2*x21;
    double x23 = x10 + x22;
    double x24 = 0.043999999999999997*n1 + x13 + x2*x20;
    double x25 = -2*x11*x24;
    double x26 = -4*x11*x14 + 2.0*x16;
    double x27 = x25 + x26;
    double x28 = x19 + x22;
    double x29 = 1.0*x7;
    double x30 = x15*(x12 + x29);
    double x31 = 2*x30;
    double x32 = x10 + x31;
    double x33 = x13 + x2*x29;
    double x34 = -2*x11*x33;
    double x35 = x26 + x34;
    double x36 = x19 + x31;
    double x37 = -2*x11*x14;
    double x38 = 2.0*x15;
    double x39 = -4*x11*x24 + x38*x5;
    double x40 = x37 + x39;
    double x41 = x15*(x20 + x29);
    double x42 = x21 + x25 + x30 + x34 + x37 + x41;
    double x43 = -4*x11*x33 + x38*x7;
    double x44 = x37 + x43;
    double x45 = 6.0*x15;
    double x46 = -6*x11*x24 + x45*x5;
    double x47 = 2*x41;
    double x48 = x10 + x47;
    double x49 = x34 + x39;
    double x50 = x19 + x47;
    double x51 = x25 + x43;
    double x52 = -6*x11*x33 + x45*x7;

if (x18) {
   result[0] = -x10 - x17;
}
else {
   result[0] = -x17 - x19;
}
if (x18) {
   result[1] = -x23 - x27;
}
else {
   result[1] = -x27 - x28;
}
if (x18) {
   result[2] = -x32 - x35;
}
else {
   result[2] = -x35 - x36;
}
if (x18) {
   result[3] = -x23 - x40;
}
else {
   result[3] = -x28 - x40;
}
if (x18) {
   result[4] = -x10 - x42;
}
else {
   result[4] = -x19 - x42;
}
if (x18) {
   result[5] = -x32 - x44;
}
else {
   result[5] = -x36 - x44;
}
if (x18) {
   result[6] = -x10 - x46;
}
else {
   result[6] = -x19 - x46;
}
if (x18) {
   result[7] = -x48 - x49;
}
else {
   result[7] = -x49 - x50;
}
if (x18) {
   result[8] = -x48 - x51;
}
else {
   result[8] = -x50 - x51;
}
if (x18) {
   result[9] = -x10 - x52;
}
else {
   result[9] = -x19 - x52;
}
}
        
static double coder_d2gdt2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dT2)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dT2)(T, P);
    double x3 = 0.005235602094240838*T - 1;
    double x4 = -x3;
    double x5 = sqrt(x4);
    double x6 = 1.0*x5;
    double x7 = x6 - 4;
    double x8 = (-x7 >= 0. ? 1. : 0.);
    double x9 = 0.001100409802362874*T - 0.21017827225130892;
    double x10 = 1.0/x3;
    double x11 = x10*0;
    double x12 = x8/pow(x4, 3.0/2.0);
    double x13 = fmin(4, x6);
    double x14 = 0.21017827225130895*((x13)*(x13));

if (T >= 191.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = -0.33333333333333331*n2*(0.42035654450261789*x10*x13*((x8)*(x8)) - x11*x14 - x11*x9 + x12*x14 + x12*x9 + 0.84071308900523567*x8/x5) + 1.0*x0 + 1.0*x1 + 1.0*x2;
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[1].d2mu0dT2)(T, P);
    double x1 = 0.005235602094240838*T - 1;
    double x2 = -x1;
    double x3 = sqrt(x2);
    double x4 = 1.0*x3;
    double x5 = x4 - 4;
    double x6 = (-x5 >= 0. ? 1. : 0.);
    double x7 = 160.5762*T - 30670.054199999999;
    double x8 = 1.0/x1;
    double x9 = 0;
    double x10 = x6/pow(x2, 3.0/2.0);
    double x11 = fmin(4, x4);
    double x12 = ((x11)*(x11));

result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
if (T >= 191.0) {
   result[1] = 1.0*x0;
}
else {
   result[1] = 1.0*x0 - 0.070059424083769639*x10*x12 - 2.2842941074349207e-6*x10*x7 - 0.14011884816753928*x11*((x6)*(x6))*x8 + 0.070059424083769639*x12*x8*x9 + 2.2842941074349207e-6*x7*x8*x9 - 0.28023769633507856*x6/x3;
}
result[2] = 1.0*(*endmember[2].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P) + n3*(*endmember[2].d2mu0dTdP)(T, P));
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P) + n3*(*endmember[2].d2mu0dP2)(T, P));
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT3)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dT3)(T, P);
    double x3 = 0.005235602094240838*T - 1;
    double x4 = -x3;
    double x5 = 1.0*sqrt(x4);
    double x6 = x5 - 4;
    double x7 = 0;
    double x8 = pow(x4, -3.0/2.0);
    double x9 = (-x6 >= 0. ? 1. : 0.);
    double x10 = x8*x9;
    double x11 = 160.5762*T - 30670.054199999999;
    double x12 = pow(x3, -2);
    double x13 = x12*x7;
    double x14 = x9/pow(x4, 5.0/2.0);
    double x15 = x8*0;
    double x16 = fmin(4, x5);
    double x17 = ((x16)*(x16));
    double x18 = 0.0033012294070886225*x16;

if (T >= 191.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = -0.33333333333333331*n2*(-x10*x18*x7 + 0.0033012294070886216*x10 + 5.3818447557367247e-8*x11*x13 + 5.3818447557367253e-8*x11*x14 - 1.7939482519122417e-8*x11*x15 - x12*x18*((x9)*(x9)) + 0.0016506147035443113*x13*x17 + 0.0016506147035443115*x14*x17 - 0.00055020490118143708*x15*x17 + 0.0011004098023628742*x8*((x9)*(x9)*(x9)) - 0.0033012294070886216*x7/x3) + 1.0*x0 + 1.0*x1 + 1.0*x2;
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 1.0*(*endmember[1].d3mu0dT3)(T, P);
    double x1 = 0.005235602094240838*T - 1;
    double x2 = -x1;
    double x3 = 1.0*sqrt(x2);
    double x4 = x3 - 4;
    double x5 = 0;
    double x6 = pow(x2, -3.0/2.0);
    double x7 = (-x4 >= 0. ? 1. : 0.);
    double x8 = x6*x7;
    double x9 = 160.5762*T - 30670.054199999999;
    double x10 = pow(x1, -2);
    double x11 = x10*x5;
    double x12 = x7/pow(x2, 5.0/2.0);
    double x13 = x6*0;
    double x14 = fmin(4, x3);
    double x15 = ((x14)*(x14));
    double x16 = 0.00055020490118143708*x15;
    double x17 = 0.0011004098023628742*x14;

result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
if (T >= 191.0) {
   result[1] = x0;
}
else {
   result[1] = x0 + x10*x17*((x7)*(x7)) - x11*x16 - 1.7939482519122413e-8*x11*x9 - x12*x16 - 1.7939482519122417e-8*x12*x9 + 0.00018340163372714569*x13*x15 + 5.9798275063741389e-9*x13*x9 + x17*x5*x8 - 0.00036680326745429137*x6*((x7)*(x7)*(x7)) - 0.0011004098023628737*x8 + 0.0011004098023628737*x5/x1;
}
result[2] = 1.0*(*endmember[2].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P) + n3*(*endmember[2].d3mu0dT2dP)(T, P));
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P) + n3*(*endmember[2].d3mu0dTdP2)(T, P));
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P) + n3*(*endmember[2].d3mu0dP3)(T, P));
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_s(double T, double P, double n[3]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[3]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[3]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[3]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[3]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[3]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

