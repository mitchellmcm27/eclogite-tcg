#include <math.h>


static double coder_g(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = 1.0/x1;
    double x3 = n1*(*endmember[0].mu0)(T, P);
    double x4 = n2*(*endmember[1].mu0)(T, P);
    double x5 = n3*(*endmember[2].mu0)(T, P);
    double x6 = T*(1.0*n1*log(n1*x2) + 1.0*n2*log(n2*x2) + 2.0*n3*log(n3*x2) + 1.0*x0*log(x0*x2));
    double x7 = -70000.0*n3;
    double x8 = -0.25*n1*(22000.0*n2 + x7) - 0.25*n2*(22000.0*n1 + x7) + 17500.0*n3*x0;
    double x9 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));

if (T >= 5.0) {
   result = x2*(1.0*x1*(-n2*(13.381349999999999*T - 44.604500000000002) + x3 + x4 + x5 + 8.3144626181532395*x6) + x8);
}
else {
   result = x2*(0.33333333333333331*x1*(n2*(66.906750000000002*((x9)*(x9)*(x9)) + (40.14405*T - 200.72024999999999)*(x9 - 1) - 66.906750000000002) + 3*x3 + 3*x4 + 3*x5 + 24.943387854459719*x6) + x8);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = pow(x1, -2);
    double x3 = (*endmember[0].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = n2*x5;
    double x7 = (*endmember[2].mu0)(T, P);
    double x8 = n3*x7;
    double x9 = 13.381349999999999*T;
    double x10 = x9 - 44.604500000000002;
    double x11 = 1.0/x1;
    double x12 = n1*x11;
    double x13 = 1.0*log(x12);
    double x14 = log(n2*x11);
    double x15 = 1.0*n2;
    double x16 = n3*x11;
    double x17 = 2.0*log(x16);
    double x18 = 1.0*log(x0*x11);
    double x19 = n1*x13 + n3*x17 + x0*x18 + x14*x15;
    double x20 = 8.3144626181532395*T;
    double x21 = x19*x20;
    double x22 = 1.0*x1;
    double x23 = -70000.0*n3;
    double x24 = -0.25*n1*(22000.0*n2 + x23) - 0.25*n2*(22000.0*n1 + x23) + 17500.0*n3*x0;
    double x25 = -x2*(x22*(-n2*x10 + x21 + x4 + x6 + x8) + x24);
    double x26 = 1.0*n3;
    double x27 = 1.0*n1;
    double x28 = x15 + x27;
    double x29 = x26 + x28;
    double x30 = -x11*x15;
    double x31 = -2.0*x16 + x18 + x1*x28*(-x0*x2 + x11)/x0;
    double x32 = x13 + x22*(-n1*x2 + x11) + x30 + x31;
    double x33 = -x10*x15;
    double x34 = x15*x5 + x21 + x26*x7 + x27*x3;
    double x35 = 35000.0*n3 + x34;
    double x36 = -11000.0*n2 + x35;
    double x37 = T >= 5.0;
    double x38 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x39 = 66.906750000000002*((x38)*(x38)*(x38)) + (40.14405*T - 200.72024999999999)*(x38 - 1) - 66.906750000000002;
    double x40 = 24.943387854459719*T;
    double x41 = -x2*(0.33333333333333331*x1*(n2*x39 + x19*x40 + 3*x4 + 3*x6 + 3*x8) + x24);
    double x42 = 0.33333333333333331*n2;
    double x43 = 0.33333333333333331*n1 + 0.33333333333333331*n3 + x42;
    double x44 = x39*x42;
    double x45 = -1.0*x12;
    double x46 = 1.0*x14 + x22*(-n2*x2 + x11) + x31 + x45;
    double x47 = -11000.0*n1 + x35;
    double x48 = 2.0*x1*(-n3*x2 + x11) - x11*x28 + x17 + x30 + x45;
    double x49 = 35000.0*n1 + 35000.0*n2 + x34;

if (x37) {
   result[0] = x11*(x29*(x20*x32 + x3) + x33 + x36) + x25;
}
else {
   result[0] = x11*(x36 + x43*(3*x3 + x32*x40) + x44) + x41;
}
if (x37) {
   result[1] = x11*(x29*(x20*x46 + x5 - x9 + 44.604500000000002) + x33 + x47) + x25;
}
else {
   result[1] = x11*(x43*(x39 + x40*x46 + 3*x5) + x44 + x47) + x41;
}
if (x37) {
   result[2] = x11*(x29*(x20*x48 + x7) + x33 + x49) + x25;
}
else {
   result[2] = x11*(x43*(x40*x48 + 3*x7) + x44 + x49) + x41;
}
}
        
static void coder_d2gdn2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n3*x4;
    double x6 = 13.381349999999999*T;
    double x7 = x6 - 44.604500000000002;
    double x8 = n1 + n2;
    double x9 = n3 + x8;
    double x10 = 1.0/x9;
    double x11 = n1*x10;
    double x12 = 1.0*log(x11);
    double x13 = log(n2*x10);
    double x14 = 1.0*n2;
    double x15 = n3*x10;
    double x16 = 2.0*log(x15);
    double x17 = 1.0*log(x10*x8);
    double x18 = T*(n1*x12 + n3*x16 + x13*x14 + x17*x8);
    double x19 = 8.3144626181532395*x18;
    double x20 = 1.0*x9;
    double x21 = -70000.0*n3;
    double x22 = -0.25*n1*(22000.0*n2 + x21) - 0.25*n2*(22000.0*n1 + x21) + 17500.0*n3*x8;
    double x23 = pow(x9, -3);
    double x24 = 2*x23;
    double x25 = x24*(x20*(-n2*x7 + x1 + x19 + x3 + x5) + x22);
    double x26 = 1.0*n3;
    double x27 = 1.0*n1;
    double x28 = x14 + x27;
    double x29 = x26 + x28;
    double x30 = -x10*x14;
    double x31 = pow(x9, -2);
    double x32 = n1*x31;
    double x33 = x20*(x10 - x32);
    double x34 = 1.0/x8;
    double x35 = x10 - x31*x8;
    double x36 = x34*x35;
    double x37 = x28*x36;
    double x38 = -2.0*x15 + x17 + x37*x9;
    double x39 = T*(x12 + x30 + x33 + x38);
    double x40 = 8.3144626181532395*x39;
    double x41 = -x14*x7;
    double x42 = x0*x27 + x14*x2 + x19 + x26*x4;
    double x43 = 35000.0*n3 + x42;
    double x44 = -11000.0*n2 + x43;
    double x45 = x29*(x0 + x40) + x41 + x44;
    double x46 = 2*x31;
    double x47 = 2.0*x31;
    double x48 = -x47;
    double x49 = 2.0*x23;
    double x50 = n1*x49;
    double x51 = x14*x31;
    double x52 = 1.0*x32;
    double x53 = x51 - x52;
    double x54 = 1.0*x10;
    double x55 = 2.0*x9;
    double x56 = x24*x8;
    double x57 = x28*x9;
    double x58 = x34*x57;
    double x59 = n3*x47;
    double x60 = x37 + x59;
    double x61 = -x35*x57/((x8)*(x8)) + x36*x55 + x58*(-x46 + x56) + x60;
    double x62 = x54 + x61;
    double x63 = T*(x53 + x62 + x9*(x48 + x50) + x33/n1);
    double x64 = 8.3144626181532395*x29;
    double x65 = 2.0*x0 + 16.628925236306479*x39;
    double x66 = T >= 5.0;
    double x67 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x68 = ((x67)*(x67)*(x67));
    double x69 = (40.14405*T - 200.72024999999999)*(x67 - 1);
    double x70 = 66.906750000000002*x68 + x69 - 66.906750000000002;
    double x71 = x24*(x22 + 0.33333333333333331*x9*(n2*x70 + 3*x1 + 24.943387854459719*x18 + 3*x3 + 3*x5));
    double x72 = 0.33333333333333331*n2;
    double x73 = 0.33333333333333331*n1 + 0.33333333333333331*n3 + x72;
    double x74 = x70*x72;
    double x75 = x44 + x73*(3*x0 + 24.943387854459719*x39) + x74;
    double x76 = 24.943387854459719*x73;
    double x77 = -1.0*x31;
    double x78 = x53 + x9*(x50 + x77);
    double x79 = T*(-x54 + x61 + x78);
    double x80 = 1.0*x0 + x40;
    double x81 = 1.0*x2;
    double x82 = -1.0*x11;
    double x83 = x20*(-n2*x31 + x10);
    double x84 = T*(1.0*x13 + x38 + x82 + x83);
    double x85 = 8.3144626181532395*x84;
    double x86 = -x6 + x85;
    double x87 = x81 + x86;
    double x88 = -11000.0*n1 + x43;
    double x89 = x29*(x2 + x86 + 44.604500000000002) + x41 + x88;
    double x90 = -x31*x89;
    double x91 = x25 - x31*x45;
    double x92 = 22.302250000000001*x68 + 0.33333333333333331*x69 + x81 + x85;
    double x93 = x73*(3*x2 + x70 + 24.943387854459719*x84) + x74 + x88;
    double x94 = -x31*x93;
    double x95 = -x31*x75 + x71;
    double x96 = -3.0*x10 + x58*(-x31 + x56) + x60;
    double x97 = T*(x78 + x96);
    double x98 = x55*(-n3*x31 + x10);
    double x99 = T*(-x10*x28 + x16 + x30 + x82 + x98);
    double x100 = 8.3144626181532395*x99;
    double x101 = x100 + 1.0*x4;
    double x102 = x101 + x80 + 35000.0;
    double x103 = 35000.0*n1 + 35000.0*n2 + x42;
    double x104 = x103 + x29*(x100 + x4) + x41;
    double x105 = -x104*x31;
    double x106 = x103 + x73*(3*x4 + 24.943387854459719*x99) + x74;
    double x107 = -x106*x31;
    double x108 = n2*x49;
    double x109 = -x51 + x52;
    double x110 = T*(x109 + x62 + x9*(x108 + x48) + x83/n2);
    double x111 = 2.0*x2 + 16.628925236306479*x84;
    double x112 = T*(x109 + x9*(x108 + x77) + x96);
    double x113 = T*(2.0*x10 + x28*x31 + x51 + x52 - x59 + x9*(4.0*n3*x23 - 4.0*x31) + x98/n3);
    double x114 = 2.0*x4 + 16.628925236306479*x99;

if (x66) {
   result[0] = x10*(x63*x64 + x65) + x25 - x45*x46;
}
else {
   result[0] = x10*(x63*x76 + x65) - x46*x75 + x71;
}
if (x66) {
   result[1] = x10*(x64*x79 + x80 + x87 - 10955.395500000001) + x90 + x91;
}
else {
   result[1] = x10*(x76*x79 + x80 + x92 - 11022.302250000001) + x94 + x95;
}
if (x66) {
   result[2] = x10*(x102 + x64*x97) + x105 + x91;
}
else {
   result[2] = x10*(x102 + x76*x97) + x107 + x95;
}
if (x66) {
   result[3] = x10*(-26.762699999999999*T + x110*x64 + x111 + 89.209000000000003) + x25 - x46*x89;
}
else {
   result[3] = x10*(x110*x76 + x111 + 44.604500000000002*x68 + 0.66666666666666663*x69 - 44.604500000000002) - x46*x93 + x71;
}
if (x66) {
   result[4] = x10*(x101 + x112*x64 + x87 + 35044.604500000001) + x105 + x25 + x90;
}
else {
   result[4] = x10*(x101 + x112*x76 + x92 + 34977.697749999999) + x107 + x71 + x94;
}
if (x66) {
   result[5] = x10*(x113*x64 + x114) - x104*x46 + x25;
}
else {
   result[5] = x10*(x113*x76 + x114) - x106*x46 + x71;
}
}
        
static void coder_d3gdn3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n3*x4;
    double x6 = 13.381349999999999*T;
    double x7 = x6 - 44.604500000000002;
    double x8 = n1 + n2;
    double x9 = n3 + x8;
    double x10 = 1.0/x9;
    double x11 = log(n1*x10);
    double x12 = 1.0*n1;
    double x13 = log(n2*x10);
    double x14 = 1.0*n2;
    double x15 = n3*x10;
    double x16 = 2.0*log(x15);
    double x17 = 1.0*log(x10*x8);
    double x18 = n3*x16 + x11*x12 + x13*x14 + x17*x8;
    double x19 = 8.3144626181532395*T;
    double x20 = x18*x19;
    double x21 = 1.0*x9;
    double x22 = -70000.0*n3;
    double x23 = -0.25*n1*(22000.0*n2 + x22) - 0.25*n2*(22000.0*n1 + x22) + 17500.0*n3*x8;
    double x24 = pow(x9, -4);
    double x25 = 6*x24;
    double x26 = -x25*(x21*(-n2*x7 + x1 + x20 + x3 + x5) + x23);
    double x27 = 1.0*n3;
    double x28 = x12 + x14;
    double x29 = x27 + x28;
    double x30 = 1.0*x10;
    double x31 = -n2*x30;
    double x32 = pow(x9, -2);
    double x33 = -1.0*n1*x32 + 1.0*x10;
    double x34 = x33*x9;
    double x35 = 1.0/x8;
    double x36 = x10 - x32*x8;
    double x37 = x35*x36;
    double x38 = x28*x37;
    double x39 = -2.0*x15 + x17 + x38*x9;
    double x40 = 1.0*x11 + x31 + x34 + x39;
    double x41 = x19*x40;
    double x42 = -x14*x7;
    double x43 = x0*x12 + x14*x2 + x20 + x27*x4;
    double x44 = 35000.0*n3 + x43;
    double x45 = -11000.0*n2 + x44;
    double x46 = x29*(x0 + x41) + x42 + x45;
    double x47 = pow(x9, -3);
    double x48 = 6*x47;
    double x49 = 2.0*x32;
    double x50 = -x49;
    double x51 = 2.0*x47;
    double x52 = n1*x51;
    double x53 = 1.0/n1;
    double x54 = x33*x53;
    double x55 = x14*x32;
    double x56 = x12*x32;
    double x57 = x55 - x56;
    double x58 = 2.0*x37;
    double x59 = 2*x32;
    double x60 = -x59;
    double x61 = 2*x47;
    double x62 = x61*x8;
    double x63 = x60 + x62;
    double x64 = x28*x35;
    double x65 = x63*x64;
    double x66 = pow(x8, -2);
    double x67 = x36*x66;
    double x68 = x28*x67;
    double x69 = n3*x49;
    double x70 = x38 + x69;
    double x71 = x58*x9 + x65*x9 - x68*x9 + x70;
    double x72 = x30 + x71;
    double x73 = x54*x9 + x57 + x72 + x9*(x50 + x52);
    double x74 = x19*x73;
    double x75 = 16.628925236306479*T;
    double x76 = 2.0*x0 + x40*x75;
    double x77 = x32*(x29*x74 + x76);
    double x78 = 24.943387854459719*T;
    double x79 = x73*x78;
    double x80 = 6.0*x47;
    double x81 = 6.0*x24;
    double x82 = -n1*x81;
    double x83 = n1*x61;
    double x84 = x21*x53;
    double x85 = 4.0*x47;
    double x86 = n2*x51;
    double x87 = -x86;
    double x88 = n3*x85;
    double x89 = -x88;
    double x90 = n1*x85 + x87 + x89;
    double x91 = x54 + x90;
    double x92 = 4.0*x32;
    double x93 = -x92;
    double x94 = 3.0*x9;
    double x95 = -x25*x8;
    double x96 = x64*x9;
    double x97 = x28*x66;
    double x98 = 2*x9;
    double x99 = x28*x36*x98/((x8)*(x8)*(x8)) + x35*x63*x94 + 3.0*x37 - x63*x97*x98 + 2*x65 - x67*x94 - 2*x68 + x96*(x48 + x95);
    double x100 = x93 + x99;
    double x101 = x100 + x84*(x60 + x83) + x9*(x80 + x82) + x91 - x34/((n1)*(n1));
    double x102 = x19*x29;
    double x103 = T >= 5.0;
    double x104 = fmin(4, 1.0*sqrt(1 - 0.19999999999999998*T));
    double x105 = ((x104)*(x104)*(x104));
    double x106 = (40.14405*T - 200.72024999999999)*(x104 - 1);
    double x107 = 66.906750000000002*x105 + x106 - 66.906750000000002;
    double x108 = -x25*(x23 + 0.33333333333333331*x9*(n2*x107 + 3*x1 + x18*x78 + 3*x3 + 3*x5));
    double x109 = 0.33333333333333331*n2;
    double x110 = 0.33333333333333331*n1 + 0.33333333333333331*n3 + x109;
    double x111 = x107*x109;
    double x112 = x110*(3*x0 + x40*x78) + x111 + x45;
    double x113 = x32*(x110*x79 + x76);
    double x114 = x110*x78;
    double x115 = -x32;
    double x116 = x84*(x115 + x83) + x9*(x82 + x85) + x91;
    double x117 = x116 + x50 + x99;
    double x118 = 1.0*x32;
    double x119 = -x118;
    double x120 = x57 + x9*(x119 + x52);
    double x121 = x120 - x30 + x71;
    double x122 = x121*x75;
    double x123 = x122 + x74;
    double x124 = -n1*x30;
    double x125 = -n2*x32 + x10;
    double x126 = x125*x21;
    double x127 = x124 + x126 + 1.0*x13 + x39;
    double x128 = x127*x19;
    double x129 = x128 - x6;
    double x130 = -11000.0*n1 + x44;
    double x131 = x130 + x29*(x129 + x2 + 44.604500000000002) + x42;
    double x132 = x131*x61;
    double x133 = x121*x19;
    double x134 = 1.0*x0 + x41;
    double x135 = 1.0*x2;
    double x136 = x129 + x135;
    double x137 = x133*x29 + x134 + x136 - 10955.395500000001;
    double x138 = -x137*x59 + x26;
    double x139 = 4*x47;
    double x140 = x139*x46 - x77;
    double x141 = x110*(x107 + x127*x78 + 3*x2) + x111 + x130;
    double x142 = x141*x61;
    double x143 = 22.302250000000001*x105 + 0.33333333333333331*x106 + x128 + x135;
    double x144 = x114*x121 + x134 + x143 - 11022.302250000001;
    double x145 = x108 - x144*x59;
    double x146 = x112*x139 - x113;
    double x147 = x115 + x62;
    double x148 = x147*x64;
    double x149 = x147*x9;
    double x150 = x148 + 2.0*x149*x35 - x149*x97 + x58 + x65 - x68 + x96*(x139 + x95);
    double x151 = x119 + x150;
    double x152 = x116 + x151;
    double x153 = -3.0*x10 + x148*x9 + x70;
    double x154 = x120 + x153;
    double x155 = x154*x75;
    double x156 = x155 + x74;
    double x157 = -2.0*n3*x32 + 2.0*x10;
    double x158 = x157*x9;
    double x159 = -x10*x28 + x124 + x158 + x16 + x31;
    double x160 = x159*x19;
    double x161 = 35000.0*n1 + 35000.0*n2 + x43;
    double x162 = x161 + x29*(x160 + x4) + x42;
    double x163 = x162*x61;
    double x164 = x154*x19;
    double x165 = x160 + 1.0*x4;
    double x166 = x134 + x165 + 35000.0;
    double x167 = x164*x29 + x166;
    double x168 = -x167*x59 + x26;
    double x169 = x110*(x159*x78 + 3*x4) + x111 + x161;
    double x170 = x169*x61;
    double x171 = x114*x154 + x166;
    double x172 = x108 - x171*x59;
    double x173 = x9*(x51 + x82) + x90;
    double x174 = x118 + x173 + x99;
    double x175 = 1.0/n2;
    double x176 = -x55 + x56;
    double x177 = x126*x175 + x176 + x72 + x9*(x50 + x86);
    double x178 = x177*x19;
    double x179 = x122 + x178;
    double x180 = x46*x61;
    double x181 = x127*x75 + 2.0*x2;
    double x182 = x32*(-26.762699999999999*T + x178*x29 + x181 + 89.209000000000003);
    double x183 = x131*x139 - x182;
    double x184 = x112*x61;
    double x185 = x177*x78;
    double x186 = x32*(44.604500000000002*x105 + 0.66666666666666663*x106 + x110*x185 + x181 - 44.604500000000002);
    double x187 = x139*x141 - x186;
    double x188 = x153 + x176 + x9*(x119 + x86);
    double x189 = x188*x19;
    double x190 = x136 + x165 + x189*x29 + 35044.604500000001;
    double x191 = x150 + x173 + x49;
    double x192 = x133 + x164 + x189;
    double x193 = x114*x188 + x143 + x165 + 34977.697749999999;
    double x194 = 2*x148 + x92 + x96*(x61 + x95);
    double x195 = x173 + x194;
    double x196 = 1.0/n3;
    double x197 = 2.0*x10 + x158*x196 + x28*x32 + x55 + x56 - x69 + x9*(x88 + x93);
    double x198 = x19*x197;
    double x199 = x155 + x198;
    double x200 = x159*x75 + 2.0*x4;
    double x201 = x32*(x198*x29 + x200);
    double x202 = x139*x162 - x201;
    double x203 = x197*x78;
    double x204 = x32*(x110*x203 + x200);
    double x205 = x139*x169 - x204;
    double x206 = -n2*x81;
    double x207 = n2*x61;
    double x208 = x175*x21;
    double x209 = -x52;
    double x210 = n2*x85 + x209 + x89;
    double x211 = 1.0*x125*x175 + x210;
    double x212 = x100 + x208*(x207 + x60) + x211 + x9*(x206 + x80) - x126/((n2)*(n2));
    double x213 = x151 + x208*(x115 + x207) + x211 + x9*(x206 + x85);
    double x214 = x188*x75;
    double x215 = x178 + x214;
    double x216 = -x190*x59 + x26;
    double x217 = x108 - x193*x59;
    double x218 = x194 + x210 + x9*(x206 + x51);
    double x219 = x198 + x214;
    double x220 = 8.0*n3*x47 + x157*x196 + 2.0*x196*x9*(n3*x61 + x60) + x209 - x28*x61 - 8.0*x32 + x87 + x9*(-12.0*n3*x24 + 12.0*x47) - x158/((n3)*(n3));

if (x103) {
   result[0] = x10*(x101*x102 + x79) + x26 + x46*x48 - 3*x77;
}
else {
   result[0] = x10*(x101*x114 + x79) + x108 + x112*x48 - 3*x113;
}
if (x103) {
   result[1] = x10*(x102*x117 + x123) + x132 + x138 + x140;
}
else {
   result[1] = x10*(x114*x117 + x123) + x142 + x145 + x146;
}
if (x103) {
   result[2] = x10*(x102*x152 + x156) + x140 + x163 + x168;
}
else {
   result[2] = x10*(x114*x152 + x156) + x146 + x170 + x172;
}
if (x103) {
   result[3] = x10*(x102*x174 + x179) + x138 + x180 + x183;
}
else {
   result[3] = x10*(x114*x174 + x179) + x145 + x184 + x187;
}
if (x103) {
   result[4] = x10*(x102*x191 + x192) + x132 - x137*x32 + x163 - x167*x32 + x180 - x190*x32 + x26;
}
else {
   result[4] = x10*(x114*x191 + x192) + x108 + x142 - x144*x32 + x170 - x171*x32 + x184 - x193*x32;
}
if (x103) {
   result[5] = x10*(x102*x195 + x199) + x168 + x180 + x202;
}
else {
   result[5] = x10*(x114*x195 + x199) + x172 + x184 + x205;
}
if (x103) {
   result[6] = x10*(x102*x212 + x185) + x131*x48 - 3*x182 + x26;
}
else {
   result[6] = x10*(x114*x212 + x185) + x108 + x141*x48 - 3*x186;
}
if (x103) {
   result[7] = x10*(x102*x213 + x215) + x163 + x183 + x216;
}
else {
   result[7] = x10*(x114*x213 + x215) + x170 + x187 + x217;
}
if (x103) {
   result[8] = x10*(x102*x218 + x219) + x132 + x202 + x216;
}
else {
   result[8] = x10*(x114*x218 + x219) + x142 + x205 + x217;
}
if (x103) {
   result[9] = x10*(x102*x220 + x203) + x162*x48 - 3*x201 + x26;
}
else {
   result[9] = x10*(x114*x220 + x203) + x108 + x169*x48 - 3*x204;
}
}
        
static double coder_dgdt(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1 + n2;
    double x1 = 1.0/(n3 + x0);
    double x2 = n1*(*endmember[0].dmu0dT)(T, P);
    double x3 = n2*(*endmember[1].dmu0dT)(T, P);
    double x4 = n3*(*endmember[2].dmu0dT)(T, P);
    double x5 = n1*log(n1*x1);
    double x6 = n2*log(n2*x1);
    double x7 = n3*log(n3*x1);
    double x8 = x0*log(x0*x1);
    double x9 = sqrt(1 - 0.19999999999999998*T);
    double x10 = 1.0*x9;
    double x11 = fmin(4, x10);
    double x12 = (4 - x10 >= 0. ? 1. : 0.)/x9;

if (T >= 5.0) {
   result = x1*(1.0*n1 + 1.0*n2 + 1.0*n3)*(-13.381349999999999*n2 + x2 + x3 + x4 + 8.3144626181532395*x5 + 8.3144626181532395*x6 + 16.628925236306479*x7 + 8.3144626181532395*x8);
}
else {
   result = x1*(0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3)*(n2*(-20.072025*((x11)*(x11))*x12 + 40.14405*x11 - 0.099999999999999992*x12*(40.14405*T - 200.72024999999999) - 40.14405) + 3*x2 + 3*x3 + 3*x4 + 24.943387854459719*x5 + 24.943387854459719*x6 + 49.886775708919437*x7 + 24.943387854459719*x8);
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = 1.0/x1;
    double x3 = n2*x2;
    double x4 = -8.3144626181532395*x3;
    double x5 = n1*x2;
    double x6 = log(x5);
    double x7 = 8.3144626181532395*x6;
    double x8 = pow(x1, -2);
    double x9 = x1*(-n1*x8 + x2);
    double x10 = (*endmember[0].dmu0dT)(T, P);
    double x11 = log(x0*x2);
    double x12 = 8.3144626181532395*x11;
    double x13 = n3*x2;
    double x14 = 8.3144626181532395*n2;
    double x15 = 8.3144626181532395*n1 + x14;
    double x16 = x1*(-x0*x8 + x2)/x0;
    double x17 = x12 - 16.628925236306479*x13 + x15*x16;
    double x18 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x19 = x18*x2;
    double x20 = n1*x10;
    double x21 = (*endmember[1].dmu0dT)(T, P);
    double x22 = n2*x21;
    double x23 = (*endmember[2].dmu0dT)(T, P);
    double x24 = n3*x23;
    double x25 = log(x3);
    double x26 = log(x13);
    double x27 = 16.628925236306479*x26;
    double x28 = n1*x7 - 13.381349999999999*n2 + n3*x27 + x0*x12 + x14*x25 + x20 + x22 + x24;
    double x29 = -x18*x28*x8 + 1.0*x2*x28;
    double x30 = T >= 5.0;
    double x31 = -24.943387854459719*x3;
    double x32 = 24.943387854459719*x6;
    double x33 = 24.943387854459719*x11;
    double x34 = 24.943387854459719*n2;
    double x35 = 24.943387854459719*n1 + x34;
    double x36 = -49.886775708919437*x13 + x16*x35 + x33;
    double x37 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3;
    double x38 = x2*x37;
    double x39 = 49.886775708919437*x26;
    double x40 = sqrt(1 - 0.19999999999999998*T);
    double x41 = 1.0*x40;
    double x42 = fmin(4, x41);
    double x43 = (4 - x41 >= 0. ? 1. : 0.)/x40;
    double x44 = -20.072025*((x42)*(x42))*x43 + 40.14405*x42 - 0.099999999999999992*x43*(40.14405*T - 200.72024999999999) - 40.14405;
    double x45 = n1*x32 + n2*x44 + n3*x39 + x0*x33 + 3*x20 + 3*x22 + 3*x24 + x25*x34;
    double x46 = 0.33333333333333331*x2*x45 - x37*x45*x8;
    double x47 = -8.3144626181532395*x5;
    double x48 = x1*(-n2*x8 + x2);
    double x49 = -24.943387854459719*x5;
    double x50 = x1*(-n3*x8 + x2);

if (x30) {
   result[0] = x19*(x10 + x17 + x4 + x7 + 8.3144626181532395*x9) + x29;
}
else {
   result[0] = x38*(3*x10 + x31 + x32 + x36 + 24.943387854459719*x9) + x46;
}
if (x30) {
   result[1] = x19*(x17 + x21 + 8.3144626181532395*x25 + x47 + 8.3144626181532395*x48 - 13.381349999999999) + x29;
}
else {
   result[1] = x38*(3*x21 + 24.943387854459719*x25 + x36 + x44 + 24.943387854459719*x48 + x49) + x46;
}
if (x30) {
   result[2] = x19*(-x15*x2 + x23 + x27 + x4 + x47 + 16.628925236306479*x50) + x29;
}
else {
   result[2] = x38*(-x2*x35 + 3*x23 + x31 + x39 + x49 + 49.886775708919437*x50) + x46;
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = 1.0/x1;
    double x3 = 8.3144626181532395*n2;
    double x4 = -x2*x3;
    double x5 = n1*x2;
    double x6 = log(x5);
    double x7 = 8.3144626181532395*x6;
    double x8 = pow(x1, -2);
    double x9 = n1*x8;
    double x10 = x1*(x2 - x9);
    double x11 = 8.3144626181532395*x10;
    double x12 = (*endmember[0].dmu0dT)(T, P);
    double x13 = log(x0*x2);
    double x14 = 8.3144626181532395*x13;
    double x15 = n3*x2;
    double x16 = 8.3144626181532395*n1 + x3;
    double x17 = 1.0/x0;
    double x18 = -x0*x8 + x2;
    double x19 = x17*x18;
    double x20 = x16*x19;
    double x21 = x1*x20 + x14 - 16.628925236306479*x15;
    double x22 = x11 + x12 + x21 + x4 + x7;
    double x23 = x2*x22;
    double x24 = 16.628925236306479*x8;
    double x25 = -x24;
    double x26 = pow(x1, -3);
    double x27 = n1*x26;
    double x28 = 16.628925236306479*x27;
    double x29 = 1.0/n1;
    double x30 = x3*x8;
    double x31 = 8.3144626181532395*x9;
    double x32 = x30 - x31;
    double x33 = 8.3144626181532395*x2;
    double x34 = x1*x19;
    double x35 = x1*x16;
    double x36 = 2*x8;
    double x37 = 2*x26;
    double x38 = x0*x37;
    double x39 = x17*(-x36 + x38);
    double x40 = x18/((x0)*(x0));
    double x41 = n3*x24;
    double x42 = x20 + x41;
    double x43 = 16.628925236306479*x34 + x35*x39 - x35*x40 + x42;
    double x44 = x33 + x43;
    double x45 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x46 = x2*x45;
    double x47 = x36*x45;
    double x48 = n1*x12;
    double x49 = (*endmember[1].dmu0dT)(T, P);
    double x50 = n2*x49;
    double x51 = (*endmember[2].dmu0dT)(T, P);
    double x52 = n3*x51;
    double x53 = n2*x2;
    double x54 = log(x53);
    double x55 = log(x15);
    double x56 = 16.628925236306479*x55;
    double x57 = n1*x7 - 13.381349999999999*n2 + n3*x56 + x0*x14 + x3*x54 + x48 + x50 + x52;
    double x58 = x37*x45*x57 - 2.0*x57*x8;
    double x59 = T >= 5.0;
    double x60 = -24.943387854459719*x53;
    double x61 = 24.943387854459719*x6;
    double x62 = 24.943387854459719*x10;
    double x63 = 24.943387854459719*x13;
    double x64 = 24.943387854459719*n2;
    double x65 = 24.943387854459719*n1 + x64;
    double x66 = x19*x65;
    double x67 = x1*x66 - 49.886775708919437*x15 + x63;
    double x68 = 3*x12 + x60 + x61 + x62 + x67;
    double x69 = x2*x68;
    double x70 = 49.886775708919437*x8;
    double x71 = -x70;
    double x72 = 49.886775708919437*x27;
    double x73 = x64*x8;
    double x74 = 24.943387854459719*x9;
    double x75 = x73 - x74;
    double x76 = 24.943387854459719*x2;
    double x77 = x1*x65;
    double x78 = n3*x70;
    double x79 = x66 + x78;
    double x80 = 49.886775708919437*x34 + x39*x77 - x40*x77 + x79;
    double x81 = x76 + x80;
    double x82 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3;
    double x83 = x2*x82;
    double x84 = x36*x82;
    double x85 = 49.886775708919437*x55;
    double x86 = sqrt(1 - 0.19999999999999998*T);
    double x87 = 1.0*x86;
    double x88 = fmin(4, x87);
    double x89 = (4 - x87 >= 0. ? 1. : 0.)/x86;
    double x90 = -20.072025*((x88)*(x88))*x89 + 40.14405*x88 - 0.099999999999999992*x89*(40.14405*T - 200.72024999999999) - 40.14405;
    double x91 = n1*x61 + n2*x90 + n3*x85 + x0*x63 + 3*x48 + 3*x50 + 3*x52 + x54*x64;
    double x92 = x37*x82*x91 - 0.66666666666666663*x8*x91;
    double x93 = -8.3144626181532395*x8;
    double x94 = x1*(x28 + x93) + x32;
    double x95 = x45*x8;
    double x96 = -x22*x95 + 1.0*x23 + x58;
    double x97 = -8.3144626181532395*x5;
    double x98 = x1*(-n2*x8 + x2);
    double x99 = 8.3144626181532395*x98;
    double x100 = x21 + x49 + 8.3144626181532395*x54 + x97 + x99 - 13.381349999999999;
    double x101 = 1.0*x2;
    double x102 = x100*x101 - x100*x95;
    double x103 = -x76;
    double x104 = -24.943387854459719*x8;
    double x105 = x1*(x104 + x72) + x75;
    double x106 = x8*x82;
    double x107 = -x106*x68 + 0.33333333333333331*x69 + x92;
    double x108 = -24.943387854459719*x5;
    double x109 = 24.943387854459719*x98;
    double x110 = x108 + x109 + 3*x49 + 24.943387854459719*x54 + x67 + x90;
    double x111 = 0.33333333333333331*x2;
    double x112 = -x106*x110 + x110*x111;
    double x113 = x17*(x38 - x8);
    double x114 = x103 + x113*x35 + x42;
    double x115 = x1*(-n3*x8 + x2);
    double x116 = 16.628925236306479*x115;
    double x117 = x116 - x16*x2 + x4 + x51 + x56 + x97;
    double x118 = x101*x117 - x117*x95;
    double x119 = x113*x77 - 74.830163563379159*x2 + x79;
    double x120 = 49.886775708919437*x115;
    double x121 = x108 + x120 - x2*x65 + 3*x51 + x60 + x85;
    double x122 = -x106*x121 + x111*x121;
    double x123 = 2.0*x2;
    double x124 = n2*x26;
    double x125 = 16.628925236306479*x124;
    double x126 = 1.0/n2;
    double x127 = -x30 + x31;
    double x128 = 0.66666666666666663*x2;
    double x129 = 49.886775708919437*x124;
    double x130 = -x73 + x74;
    double x131 = n3*x26;
    double x132 = 1.0/n3;

if (x59) {
   result[0] = -x22*x47 + 2.0*x23 + x46*(x1*(x25 + x28) + x11*x29 + x32 + x44) + x58;
}
else {
   result[0] = -x68*x84 + 0.66666666666666663*x69 + x83*(x1*(x71 + x72) + x29*x62 + x75 + x81) + x92;
}
if (x59) {
   result[1] = x102 + x46*(-x33 + x43 + x94) + x96;
}
else {
   result[1] = x107 + x112 + x83*(x103 + x105 + x80);
}
if (x59) {
   result[2] = x118 + x46*(x114 + x94) + x96;
}
else {
   result[2] = x107 + x122 + x83*(x105 + x119);
}
if (x59) {
   result[3] = x100*x123 - x100*x47 + x46*(x1*(x125 + x25) + x126*x99 + x127 + x44) + x58;
}
else {
   result[3] = x110*x128 - x110*x84 + x83*(x1*(x129 + x71) + x109*x126 + x130 + x81) + x92;
}
if (x59) {
   result[4] = x102 + x118 + x46*(x1*(x125 + x93) + x114 + x127) + x58;
}
else {
   result[4] = x112 + x122 + x83*(x1*(x104 + x129) + x119 + x130) + x92;
}
if (x59) {
   result[5] = x117*x123 - x117*x47 + x46*(x1*(33.257850472612958*x131 - 33.257850472612958*x8) + x116*x132 + x16*x8 + 16.628925236306479*x2 + x30 + x31 - x41) + x58;
}
else {
   result[5] = x121*x128 - x121*x84 + x83*(x1*(99.773551417838874*x131 - 99.773551417838874*x8) + x120*x132 + 49.886775708919437*x2 + x65*x8 + x73 + x74 - x78) + x92;
}
}
        
static void coder_d4gdn3dt(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = n1 + n2;
    double x1 = n3 + x0;
    double x2 = 1.0/x1;
    double x3 = pow(x1, -2);
    double x4 = 16.628925236306479*x3;
    double x5 = -x4;
    double x6 = pow(x1, -3);
    double x7 = 16.628925236306479*x6;
    double x8 = n1*x7;
    double x9 = 1.0/n1;
    double x10 = n1*x3;
    double x11 = -x10 + x2;
    double x12 = 8.3144626181532395*x11;
    double x13 = x1*x12;
    double x14 = 8.3144626181532395*n2;
    double x15 = x14*x3;
    double x16 = 8.3144626181532395*n1;
    double x17 = x16*x3;
    double x18 = x15 - x17;
    double x19 = 8.3144626181532395*x2;
    double x20 = 1.0/x0;
    double x21 = -x0*x3 + x2;
    double x22 = x20*x21;
    double x23 = 16.628925236306479*x22;
    double x24 = 2*x3;
    double x25 = -x24;
    double x26 = 2*x6;
    double x27 = x0*x26;
    double x28 = x25 + x27;
    double x29 = x14 + x16;
    double x30 = x20*x29;
    double x31 = x28*x30;
    double x32 = pow(x0, -2);
    double x33 = x21*x32;
    double x34 = x29*x33;
    double x35 = n3*x4;
    double x36 = x22*x29;
    double x37 = x35 + x36;
    double x38 = x1*x23 + x1*x31 - x1*x34 + x37;
    double x39 = x19 + x38;
    double x40 = x1*(x5 + x8) + x13*x9 + x18 + x39;
    double x41 = x2*x40;
    double x42 = -n2*x19;
    double x43 = n1*x2;
    double x44 = log(x43);
    double x45 = (*endmember[0].dmu0dT)(T, P);
    double x46 = log(x0*x2);
    double x47 = 8.3144626181532395*x46;
    double x48 = n3*x2;
    double x49 = x1*x36 + x47 - 16.628925236306479*x48;
    double x50 = x13 + x42 + 8.3144626181532395*x44 + x45 + x49;
    double x51 = x3*x50;
    double x52 = 49.886775708919437*x6;
    double x53 = pow(x1, -4);
    double x54 = n1*x53;
    double x55 = -49.886775708919437*x54;
    double x56 = n1*x26;
    double x57 = x1*x9;
    double x58 = x57*(x25 + x56);
    double x59 = pow(n1, -2);
    double x60 = 33.257850472612958*x6;
    double x61 = n2*x7;
    double x62 = -x61;
    double x63 = n3*x60;
    double x64 = -x63;
    double x65 = n1*x60 + x62 + x64;
    double x66 = x12*x9 + x65;
    double x67 = 33.257850472612958*x3;
    double x68 = -x67;
    double x69 = 24.943387854459719*x1;
    double x70 = x20*x28;
    double x71 = 6*x6;
    double x72 = 6*x53;
    double x73 = -x0*x72;
    double x74 = x1*(x71 + x73);
    double x75 = 2*x1;
    double x76 = x29*x75;
    double x77 = x28*x32;
    double x78 = x21/((x0)*(x0)*(x0));
    double x79 = 24.943387854459719*x22 + x30*x74 + 2*x31 - x33*x69 - 2*x34 + x69*x70 - x76*x77 + x76*x78;
    double x80 = x68 + x79;
    double x81 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x82 = x2*x81;
    double x83 = x3*x81;
    double x84 = x40*x83;
    double x85 = x50*x81;
    double x86 = n1*x45;
    double x87 = (*endmember[1].dmu0dT)(T, P);
    double x88 = n2*x87;
    double x89 = (*endmember[2].dmu0dT)(T, P);
    double x90 = n3*x89;
    double x91 = n2*x2;
    double x92 = log(x91);
    double x93 = log(x48);
    double x94 = 16.628925236306479*x93;
    double x95 = -13.381349999999999*n2 + n3*x94 + x0*x47 + x14*x92 + x16*x44 + x86 + x88 + x90;
    double x96 = 6.0*x6*x95 - x72*x81*x95;
    double x97 = T >= 5.0;
    double x98 = 49.886775708919437*x3;
    double x99 = -x98;
    double x100 = n1*x52;
    double x101 = 24.943387854459719*x11;
    double x102 = x1*x101;
    double x103 = 24.943387854459719*n2;
    double x104 = x103*x3;
    double x105 = 24.943387854459719*x10;
    double x106 = x104 - x105;
    double x107 = 24.943387854459719*x2;
    double x108 = 49.886775708919437*x22;
    double x109 = 24.943387854459719*n1;
    double x110 = x103 + x109;
    double x111 = x110*x20;
    double x112 = x111*x28;
    double x113 = x110*x33;
    double x114 = n3*x98;
    double x115 = x110*x22;
    double x116 = x114 + x115;
    double x117 = x1*x108 + x1*x112 - x1*x113 + x116;
    double x118 = x107 + x117;
    double x119 = x1*(x100 + x99) + x102*x9 + x106 + x118;
    double x120 = x119*x2;
    double x121 = -24.943387854459719*x91;
    double x122 = 24.943387854459719*x46;
    double x123 = x1*x115 + x122 - 49.886775708919437*x48;
    double x124 = x102 + x121 + x123 + 24.943387854459719*x44 + 3*x45;
    double x125 = 2.0*x3;
    double x126 = 149.66032712675832*x6;
    double x127 = -149.66032712675832*x54;
    double x128 = 99.773551417838874*x6;
    double x129 = n2*x52;
    double x130 = -x129;
    double x131 = n3*x128;
    double x132 = -x131;
    double x133 = n1*x128 + x130 + x132;
    double x134 = x101*x9 + x133;
    double x135 = -99.773551417838874*x3;
    double x136 = 74.830163563379159*x1;
    double x137 = x110*x75;
    double x138 = x111*x74 + 2*x112 - 2*x113 - x136*x33 + x136*x70 - x137*x77 + x137*x78 + 74.830163563379159*x22;
    double x139 = x135 + x138;
    double x140 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3;
    double x141 = x140*x2;
    double x142 = x140*x3;
    double x143 = x119*x142;
    double x144 = x124*x140;
    double x145 = 49.886775708919437*x93;
    double x146 = sqrt(1 - 0.19999999999999998*T);
    double x147 = 1.0*x146;
    double x148 = fmin(4, x147);
    double x149 = (4 - x147 >= 0. ? 1. : 0.)/x146;
    double x150 = -20.072025*((x148)*(x148))*x149 + 40.14405*x148 - 0.099999999999999992*x149*(40.14405*T - 200.72024999999999) - 40.14405;
    double x151 = n2*x150 + n3*x145 + x0*x122 + x103*x92 + x109*x44 + 3*x86 + 3*x88 + 3*x90;
    double x152 = -x140*x151*x72 + 2.0*x151*x6;
    double x153 = -x3;
    double x154 = x57*(x153 + x56);
    double x155 = x1*(x55 + x60) + 8.3144626181532395*x154 + x66;
    double x156 = 8.3144626181532395*x3;
    double x157 = -x156;
    double x158 = x1*(x157 + x8) + x18;
    double x159 = x158 - x19 + x38;
    double x160 = 2.0*x2;
    double x161 = x24*x81;
    double x162 = x159*x160 - x159*x161 + x96;
    double x163 = -n1*x19;
    double x164 = -n2*x3 + x2;
    double x165 = x1*x164;
    double x166 = 8.3144626181532395*x165;
    double x167 = x163 + x166 + x49 + x87 + 8.3144626181532395*x92 - 13.381349999999999;
    double x168 = x26*x81;
    double x169 = -x125*x167 + x167*x168;
    double x170 = 4*x6;
    double x171 = x170*x85 + 1.0*x41 - 4.0*x51 - x84;
    double x172 = x1*(x127 + x128) + x134 + 24.943387854459719*x154;
    double x173 = -x107;
    double x174 = 24.943387854459719*x3;
    double x175 = -x174;
    double x176 = x1*(x100 + x175) + x106;
    double x177 = x117 + x173 + x176;
    double x178 = 0.66666666666666663*x2;
    double x179 = x140*x24;
    double x180 = x152 + x177*x178 - x177*x179;
    double x181 = -24.943387854459719*x43;
    double x182 = 24.943387854459719*x165;
    double x183 = x123 + x150 + x181 + x182 + 3*x87 + 24.943387854459719*x92;
    double x184 = 0.66666666666666663*x3;
    double x185 = x140*x26;
    double x186 = -x183*x184 + x183*x185;
    double x187 = 1.3333333333333333*x3;
    double x188 = 0.33333333333333331*x120 - x124*x187 - x143 + x144*x170;
    double x189 = x153 + x27;
    double x190 = x189*x30;
    double x191 = x1*x189;
    double x192 = x191*x20;
    double x193 = x1*(x170 + x73);
    double x194 = x191*x32;
    double x195 = x190 + 16.628925236306479*x192 + x193*x30 - x194*x29 + x23 + x31 - x34;
    double x196 = x157 + x195;
    double x197 = x1*x190 + x173 + x37;
    double x198 = x158 + x197;
    double x199 = x160*x198 - x161*x198 + x96;
    double x200 = -n3*x3 + x2;
    double x201 = x1*x200;
    double x202 = 16.628925236306479*x201;
    double x203 = x163 - x2*x29 + x202 + x42 + x89 + x94;
    double x204 = -x125*x203 + x168*x203;
    double x205 = x111*x189;
    double x206 = x108 - x110*x194 + x111*x193 + x112 - x113 + 49.886775708919437*x192 + x205;
    double x207 = x206 - 24.943387854459722*x3;
    double x208 = x1*x205 + x116 - 74.830163563379159*x2;
    double x209 = x176 + x208;
    double x210 = x152 + x178*x209 - x179*x209;
    double x211 = 49.886775708919437*x201;
    double x212 = -x110*x2 + x121 + x145 + x181 + x211 + 3*x89;
    double x213 = -x184*x212 + x185*x212;
    double x214 = x1*(x55 + x7) + x65;
    double x215 = x26*x85 - 2.0*x51;
    double x216 = 1.0/n2;
    double x217 = -x15 + x17;
    double x218 = x1*(x5 + x61) + x166*x216 + x217 + x39;
    double x219 = 1.0*x2;
    double x220 = 4.0*x3;
    double x221 = x218*x83;
    double x222 = x170*x81;
    double x223 = -x167*x220 + x167*x222 + x218*x219 - x221;
    double x224 = x1*(x127 + x52) + x133;
    double x225 = -x124*x184 + x144*x26;
    double x226 = -x104 + x105;
    double x227 = x1*(x129 + x99) + x118 + x182*x216 + x226;
    double x228 = 0.33333333333333331*x2;
    double x229 = x142*x227;
    double x230 = x140*x170;
    double x231 = -x183*x187 + x183*x230 + x227*x228 - x229;
    double x232 = x1*(x157 + x61) + x197 + x217;
    double x233 = x204 + x96;
    double x234 = x1*(x129 + x175) + x208 + x226;
    double x235 = x152 + x213;
    double x236 = x1*(x26 + x73);
    double x237 = 2*x190 + x236*x30 + x67;
    double x238 = 1.0/n3;
    double x239 = x1*(x63 + x68) + x15 + x17 + 16.628925236306479*x2 + x202*x238 + x29*x3 - x35;
    double x240 = x239*x83;
    double x241 = -x203*x220 + x203*x222 + x219*x239 - x240;
    double x242 = x111*x236 + 2*x205 + 99.773551417838888*x3;
    double x243 = x1*(x131 + x135) + x104 + x105 + x110*x3 - x114 + 49.886775708919437*x2 + x211*x238;
    double x244 = x142*x243;
    double x245 = -x187*x212 + x212*x230 + x228*x243 - x244;
    double x246 = 3.0*x2;
    double x247 = 6.0*x3;
    double x248 = n2*x53;
    double x249 = -49.886775708919437*x248;
    double x250 = n2*x26;
    double x251 = x216*(x25 + x250);
    double x252 = 8.3144626181532395*x1;
    double x253 = pow(n2, -2);
    double x254 = x164*x216;
    double x255 = -x8;
    double x256 = n2*x60 + x255 + x64;
    double x257 = 8.3144626181532395*x254 + x256;
    double x258 = x71*x81;
    double x259 = -149.66032712675832*x248;
    double x260 = -x100;
    double x261 = n2*x128 + x132 + x260;
    double x262 = 24.943387854459719*x254 + x261;
    double x263 = x140*x71;
    double x264 = x216*(x153 + x250);
    double x265 = x160*x232 - x161*x232;
    double x266 = x178*x234 - x179*x234;
    double x267 = n3*x6;
    double x268 = x200*x238;
    double x269 = n3*x53;
    double x270 = pow(n3, -2);
    double x271 = x1*x238*(n3*x26 + x25);

if (x97) {
   result[0] = 3.0*x41 - 6.0*x51 + x71*x85 + x82*(x1*(x52 + x55) - x13*x59 + 8.3144626181532395*x58 + x66 + x80) - 3*x84 + x96;
}
else {
   result[0] = 1.0*x120 - x124*x125 + x141*(x1*(x126 + x127) - x102*x59 + x134 + x139 + 24.943387854459719*x58) - 3*x143 + x144*x71 + x152;
}
if (x97) {
   result[1] = x162 + x169 + x171 + x82*(x155 + x5 + x79);
}
else {
   result[1] = x141*(x138 + x172 - 49.886775708919444*x3) + x180 + x186 + x188;
}
if (x97) {
   result[2] = x171 + x199 + x204 + x82*(x155 + x196);
}
else {
   result[2] = x141*(x172 + x207) + x188 + x210 + x213;
}
if (x97) {
   result[3] = x162 + x215 + x223 + x82*(x156 + x214 + x79);
}
else {
   result[3] = x141*(x138 + x174 + x224) + x180 + x225 + x231;
}
if (x97) {
   result[4] = x159*x219 - x159*x83 + x169 + x198*x219 - x198*x83 + x215 + x219*x232 - x232*x83 + x233 + x82*(x195 + x214 + x4);
}
else {
   result[4] = x141*(x206 + x224 + x98) - x142*x177 - x142*x209 - x142*x234 + x177*x228 + x186 + x209*x228 + x225 + x228*x234 + x235;
}
if (x97) {
   result[5] = x199 + x215 + x241 + x82*(x214 + x237);
}
else {
   result[5] = x141*(x224 + x242) + x210 + x225 + x245;
}
if (x97) {
   result[6] = -x167*x247 + x167*x258 + x218*x246 - 3*x221 + x82*(x1*(x249 + x52) - x166*x253 + x251*x252 + x257 + x80) + x96;
}
else {
   result[6] = -x125*x183 + x141*(x1*(x126 + x259) + x139 - x182*x253 + x251*x69 + x262) + x152 + x183*x263 + x219*x227 - 3*x229;
}
if (x97) {
   result[7] = x223 + x233 + x265 + x82*(x1*(x249 + x60) + x196 + x252*x264 + x257);
}
else {
   result[7] = x141*(x1*(x128 + x259) + x207 + x262 + x264*x69) + x231 + x235 + x266;
}
if (x97) {
   result[8] = x169 + x241 + x265 + x82*(x1*(x249 + x7) + x237 + x256) + x96;
}
else {
   result[8] = x141*(x1*(x259 + x52) + x242 + x261) + x152 + x186 + x245 + x266;
}
if (x97) {
   result[9] = -x203*x247 + x203*x258 + x239*x246 - 3*x240 + x82*(x1*(x128 - 99.773551417838874*x269) - x202*x270 + x255 - x26*x29 + 66.515700945225916*x267 + 16.628925236306479*x268 + 16.628925236306479*x271 - 66.515700945225916*x3 + x62) + x96;
}
else {
   result[9] = -x125*x212 + x141*(x1*(-299.32065425351664*x269 + 299.32065425351664*x6) - x110*x26 + x130 - x211*x270 + x260 + 199.54710283567775*x267 + 49.886775708919437*x268 + 49.886775708919437*x271 - 199.54710283567775*x3) + x152 + x212*x263 + x219*x243 - 3*x244;
}
}
        
static double coder_dgdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = 1.0/(n1 + n2 + n3);
    double x1 = n1*(*endmember[0].dmu0dP)(T, P);
    double x2 = n2*(*endmember[1].dmu0dP)(T, P);
    double x3 = n3*(*endmember[2].dmu0dP)(T, P);

if (T >= 5.0) {
   result = x0*(1.0*n1 + 1.0*n2 + 1.0*n3)*(x1 + x2 + x3);
}
else {
   result = x0*(0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3)*(3*x1 + 3*x2 + 3*x3);
}
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2 + n3;
    double x2 = 1.0/x1;
    double x3 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x4 = x2*x3;
    double x5 = n1*x0;
    double x6 = (*endmember[1].dmu0dP)(T, P);
    double x7 = n2*x6;
    double x8 = (*endmember[2].dmu0dP)(T, P);
    double x9 = n3*x8;
    double x10 = x5 + x7 + x9;
    double x11 = pow(x1, -2);
    double x12 = -x10*x11*x3 + 1.0*x10*x2;
    double x13 = T >= 5.0;
    double x14 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3;
    double x15 = 3*x14*x2;
    double x16 = 3*x5 + 3*x7 + 3*x9;
    double x17 = -x11*x14*x16 + 0.33333333333333331*x16*x2;

if (x13) {
   result[0] = x0*x4 + x12;
}
else {
   result[0] = x0*x15 + x17;
}
if (x13) {
   result[1] = x12 + x4*x6;
}
else {
   result[1] = x15*x6 + x17;
}
if (x13) {
   result[2] = x12 + x4*x8;
}
else {
   result[2] = x15*x8 + x17;
}
}
        
static void coder_d3gdn2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2 + n3;
    double x2 = 1.0/x1;
    double x3 = x0*x2;
    double x4 = 2.0*x3;
    double x5 = pow(x1, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x7 = x5*x6;
    double x8 = x0*x7;
    double x9 = n1*x0;
    double x10 = (*endmember[1].dmu0dP)(T, P);
    double x11 = n2*x10;
    double x12 = (*endmember[2].dmu0dP)(T, P);
    double x13 = n3*x12;
    double x14 = x11 + x13 + x9;
    double x15 = 2/((x1)*(x1)*(x1));
    double x16 = x14*x15*x6 - 2.0*x14*x5;
    double x17 = T >= 5.0;
    double x18 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3;
    double x19 = x18*x5;
    double x20 = x0*x19;
    double x21 = 3*x11 + 3*x13 + 3*x9;
    double x22 = x15*x18*x21 - 0.66666666666666663*x21*x5;
    double x23 = x10*x7;
    double x24 = -x23;
    double x25 = 1.0*x3;
    double x26 = 1.0*x2;
    double x27 = x10*x26;
    double x28 = x25 + x27;
    double x29 = x16 - x8;
    double x30 = 3*x19;
    double x31 = -x10*x30;
    double x32 = -3*x20 + x22;
    double x33 = x12*x7;
    double x34 = -x33;
    double x35 = x12*x26;
    double x36 = x25 + x35;
    double x37 = -x12*x30;
    double x38 = 2.0*x2;
    double x39 = x10*x38;
    double x40 = 6*x19;
    double x41 = x27 + x35;
    double x42 = x12*x38;

if (x17) {
   result[0] = x16 + x4 - 2*x8;
}
else {
   result[0] = -6*x20 + x22 + x4;
}
if (x17) {
   result[1] = x24 + x28 + x29;
}
else {
   result[1] = x28 + x31 + x32;
}
if (x17) {
   result[2] = x29 + x34 + x36;
}
else {
   result[2] = x32 + x36 + x37;
}
if (x17) {
   result[3] = x16 - 2*x23 + x39;
}
else {
   result[3] = -x10*x40 + x22 + x39;
}
if (x17) {
   result[4] = x16 + x24 + x34 + x41;
}
else {
   result[4] = x22 + x31 + x37 + x41;
}
if (x17) {
   result[5] = x16 - 2*x33 + x42;
}
else {
   result[5] = -x12*x40 + x22 + x42;
}
}
        
static void coder_d4gdn3dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2 + n3;
    double x2 = pow(x1, -2);
    double x3 = x0*x2;
    double x4 = -6.0*x3;
    double x5 = 1.0*n1 + 1.0*n2 + 1.0*n3;
    double x6 = 6*x5;
    double x7 = pow(x1, -3);
    double x8 = x0*x7;
    double x9 = n1*x0;
    double x10 = (*endmember[1].dmu0dP)(T, P);
    double x11 = n2*x10;
    double x12 = (*endmember[2].dmu0dP)(T, P);
    double x13 = n3*x12;
    double x14 = x11 + x13 + x9;
    double x15 = pow(x1, -4);
    double x16 = -x14*x15*x6 + 6.0*x14*x7;
    double x17 = T >= 5.0;
    double x18 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3;
    double x19 = x18*x8;
    double x20 = 3*x11 + 3*x13 + 3*x9;
    double x21 = 6*x18;
    double x22 = -x15*x20*x21 + 2.0*x20*x7;
    double x23 = x10*x7;
    double x24 = 2*x5;
    double x25 = x23*x24;
    double x26 = 2.0*x2;
    double x27 = -x10*x26;
    double x28 = -4.0*x3;
    double x29 = x27 + x28;
    double x30 = 4*x5;
    double x31 = x16 + x30*x8;
    double x32 = x21*x23;
    double x33 = 12*x19 + x22;
    double x34 = x12*x7;
    double x35 = x24*x34;
    double x36 = -x12*x26;
    double x37 = x28 + x36;
    double x38 = x21*x34;
    double x39 = x23*x30;
    double x40 = -2.0*x3;
    double x41 = 4.0*x2;
    double x42 = -x10*x41;
    double x43 = x40 + x42;
    double x44 = x16 + x24*x8;
    double x45 = 12*x18;
    double x46 = x23*x45;
    double x47 = x21*x8 + x22;
    double x48 = x27 + x36 + x40;
    double x49 = x30*x34;
    double x50 = -x12*x41;
    double x51 = x40 + x50;
    double x52 = x34*x45;
    double x53 = 6.0*x2;
    double x54 = -x10*x53;
    double x55 = 18*x18;
    double x56 = x36 + x42;
    double x57 = x27 + x50;
    double x58 = -x12*x53;

if (x17) {
   result[0] = x16 + x4 + x6*x8;
}
else {
   result[0] = 18*x19 + x22 + x4;
}
if (x17) {
   result[1] = x25 + x29 + x31;
}
else {
   result[1] = x29 + x32 + x33;
}
if (x17) {
   result[2] = x31 + x35 + x37;
}
else {
   result[2] = x33 + x37 + x38;
}
if (x17) {
   result[3] = x39 + x43 + x44;
}
else {
   result[3] = x43 + x46 + x47;
}
if (x17) {
   result[4] = x25 + x35 + x44 + x48;
}
else {
   result[4] = x32 + x38 + x47 + x48;
}
if (x17) {
   result[5] = x44 + x49 + x51;
}
else {
   result[5] = x47 + x51 + x52;
}
if (x17) {
   result[6] = x16 + x23*x6 + x54;
}
else {
   result[6] = x22 + x23*x55 + x54;
}
if (x17) {
   result[7] = x16 + x35 + x39 + x56;
}
else {
   result[7] = x22 + x38 + x46 + x56;
}
if (x17) {
   result[8] = x16 + x25 + x49 + x57;
}
else {
   result[8] = x22 + x32 + x52 + x57;
}
if (x17) {
   result[9] = x16 + x34*x6 + x58;
}
else {
   result[9] = x22 + x34*x55 + x58;
}
}
        
static double coder_d2gdt2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = 1.0*n1*(*endmember[0].d2mu0dT2)(T, P) + 1.0*n2*(*endmember[1].d2mu0dT2)(T, P) + 1.0*n3*(*endmember[2].d2mu0dT2)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 0.40144049999999992*T - 2.0072024999999996;
    double x7 = 1.0/(x1 - 1);
    double x8 = x7*0;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = 2.0072025*((x10)*(x10));

if (T >= 5.0) {
   result = x0;
}
else {
   result = -0.33333333333333331*n2*(4.014405*x10*((x5)*(x5))*x7 - x11*x8 + x11*x9 - x6*x8 + x6*x9 + 8.02881*x5/x3) + x0;
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 1.0*(*endmember[1].d2mu0dT2)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 1.0/(x1 - 1);
    double x7 = x6*0;
    double x8 = 0.13381349999999997*T - 0.66906749999999982;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = 0.66906749999999993*((x10)*(x10));

result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
if (T >= 5.0) {
   result[1] = x0;
}
else {
   result[1] = x0 - 1.3381349999999999*x10*((x5)*(x5))*x6 + x11*x7 - x11*x9 + x7*x8 - x8*x9 - 2.6762699999999997*x5/x3;
}
result[2] = 1.0*(*endmember[2].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dTdP)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dTdP)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dTdP)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = x0 + x1 + x2;
}
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dP2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dP2)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dP2)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = x0 + x1 + x2;
}
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = 1.0*n1*(*endmember[0].d3mu0dT3)(T, P) + 1.0*n2*(*endmember[1].d3mu0dT3)(T, P) + 1.0*n3*(*endmember[2].d3mu0dT3)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = pow(x3, -3.0/2.0);
    double x8 = (4 - x4 >= 0. ? 1. : 0.);
    double x9 = 1.2043214999999998*x7*x8;
    double x10 = 40.14405*T - 200.72024999999999;
    double x11 = pow(x2, -2);
    double x12 = x11*x6;
    double x13 = x8/pow(x3, 5.0/2.0);
    double x14 = x7*0;
    double x15 = fmin(4, x4);
    double x16 = ((x15)*(x15));

if (T >= 5.0) {
   result = x0;
}
else {
   result = -0.33333333333333331*n2*(0.0029999999999999992*x10*x12 + 0.0029999999999999996*x10*x13 - 0.0009999999999999998*x10*x14 - 1.2043214999999998*x11*x15*((x8)*(x8)) + 0.60216074999999991*x12*x16 + 0.60216075000000002*x13*x16 - 0.20072024999999999*x14*x16 - x15*x6*x9 + 0.40144049999999998*x7*((x8)*(x8)*(x8)) + x9 - 1.2043214999999998*x6/x2) + x0;
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];

    double x0 = 1.0*(*endmember[1].d3mu0dT3)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = 0.40144049999999992*x6;
    double x8 = pow(x3, -3.0/2.0);
    double x9 = (4 - x4 >= 0. ? 1. : 0.);
    double x10 = x8*x9;
    double x11 = 40.14405*T - 200.72024999999999;
    double x12 = pow(x2, -2);
    double x13 = x12*x6;
    double x14 = x9/pow(x3, 5.0/2.0);
    double x15 = x8*0;
    double x16 = fmin(4, x4);
    double x17 = ((x16)*(x16));

result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
if (T >= 5.0) {
   result[1] = x0;
}
else {
   result[1] = x0 + x10*x16*x7 - 0.40144049999999992*x10 - 0.00099999999999999959*x11*x13 - 0.0009999999999999998*x11*x14 + 0.00033333333333333327*x11*x15 + 0.40144049999999992*x12*x16*((x9)*(x9)) - 0.20072024999999996*x13*x17 - 0.20072024999999999*x14*x17 + 0.066906749999999987*x15*x17 - 0.13381349999999997*x8*((x9)*(x9)*(x9)) + x7/x2;
}
result[2] = 1.0*(*endmember[2].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT2dP)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT2dP)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dT2dP)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = x0 + x1 + x2;
}
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dTdP2)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dTdP2)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dTdP2)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = x0 + x1 + x2;
}
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dP3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dP3)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dP3)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2;
}
else {
   result = x0 + x1 + x2;
}
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[3], double result[3]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static double coder_s(double T, double P, double n[3]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[3]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[3]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[3]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[3]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[3]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[3]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[3]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[3]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[3]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

