#include <math.h>


static double coder_g(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = fmin(4, 1.0*sqrt(1 - 0.005235602094240838*T));

if (T >= 191.0) {
   result = n1*(-53.525399999999998*T + x0 + 6815.5675999999994);
}
else {
   result = (1.0/3.0)*n1*(3*x0 + 10223.3514*((x1)*(x1)*(x1)) + (160.5762*T - 30670.054199999999)*(x1 - 1) - 10223.3514);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = fmin(4, 1.0*sqrt(1 - 0.005235602094240838*T));

if (T >= 191.0) {
   result[0] = -53.525399999999998*T + x0 + 6815.5675999999994;
}
else {
   result[0] = x0 + 3407.7837999999997*((x1)*(x1)*(x1)) + (1.0/3.0)*(160.5762*T - 30670.054199999999)*(x1 - 1) - 3407.7837999999997;
}
}
        
static void coder_d2gdn2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d3gdn3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_dgdt(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = sqrt(1 - 0.005235602094240838*T);
    double x2 = 1.0*x1;
    double x3 = fmin(4, x2);
    double x4 = (4 - x2 >= 0. ? 1. : 0.)/x1;

if (T >= 191.0) {
   result = n1*(x0 - 53.525399999999998);
}
else {
   result = (1.0/3.0)*n1*(3*x0 - 80.288100000000014*((x3)*(x3))*x4 + 160.5762*x3 - 0.002617801047120419*x4*(160.5762*T - 30670.054199999999) - 160.5762);
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].dmu0dT)(T, P) - 53.525399999999998;
    double x1 = sqrt(1 - 0.005235602094240838*T);
    double x2 = 1.0*x1;
    double x3 = fmin(4, x2);
    double x4 = (4 - x2 >= 0. ? 1. : 0.)/x1;

if (T >= 191.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - 26.762700000000002*((x3)*(x3))*x4 + 53.525399999999998*x3 - 0.00087260034904013963*x4*(160.5762*T - 30670.054199999999);
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d4gdn3dt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_dgdp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].dmu0dP)(T, P);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].dmu0dP)(T, P);
}
        
static void coder_d3gdn2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = 0.005235602094240838*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 0.001100409802362874*T - 0.21017827225130892;
    double x7 = 1.0/(x1 - 1);
    double x8 = x7*0;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = 0.21017827225130895*((x10)*(x10));

if (T >= 191.0) {
   result = n1*x0;
}
else {
   result = -1.0/3.0*n1*(-3*x0 + 0.42035654450261789*x10*((x5)*(x5))*x7 - x11*x8 + x11*x9 - x6*x8 + x6*x9 + 0.84071308900523567*x5/x3);
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = 0.005235602094240838*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 1.0/(x1 - 1);
    double x7 = x6*0;
    double x8 = 0.00036680326745429132*T - 0.070059424083769639;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = 0.070059424083769639*((x10)*(x10));

if (T >= 191.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - 0.14011884816753928*x10*((x5)*(x5))*x6 + x11*x7 - x11*x9 + x7*x8 - x8*x9 - 0.28023769633507856*x5/x3;
}
}
        
static void coder_d4gdn2dt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d2mu0dTdP)(T, P);
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d2mu0dP2)(T, P);
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = 0.005235602094240838*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = pow(x3, -3.0/2.0);
    double x8 = (4 - x4 >= 0. ? 1. : 0.);
    double x9 = x7*x8;
    double x10 = 160.5762*T - 30670.054199999999;
    double x11 = pow(x2, -2);
    double x12 = x11*x6;
    double x13 = x8/pow(x3, 5.0/2.0);
    double x14 = x7*0;
    double x15 = fmin(4, x4);
    double x16 = ((x15)*(x15));
    double x17 = 0.0033012294070886225*x15;

if (T >= 191.0) {
   result = n1*x0;
}
else {
   result = -1.0/3.0*n1*(-3*x0 + 5.3818447557367247e-8*x10*x12 + 5.3818447557367253e-8*x10*x13 - 1.7939482519122417e-8*x10*x14 - x11*x17*((x8)*(x8)) + 0.0016506147035443113*x12*x16 + 0.0016506147035443115*x13*x16 - 0.00055020490118143708*x14*x16 - x17*x6*x9 + 0.0011004098023628742*x7*((x8)*(x8)*(x8)) + 0.0033012294070886216*x9 - 0.0033012294070886216*x6/x2);
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = 0.005235602094240838*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = pow(x3, -3.0/2.0);
    double x8 = (4 - x4 >= 0. ? 1. : 0.);
    double x9 = x7*x8;
    double x10 = 160.5762*T - 30670.054199999999;
    double x11 = pow(x2, -2);
    double x12 = x11*x6;
    double x13 = x8/pow(x3, 5.0/2.0);
    double x14 = x7*0;
    double x15 = fmin(4, x4);
    double x16 = ((x15)*(x15));
    double x17 = 0.00055020490118143708*x16;
    double x18 = 0.0011004098023628742*x15;

if (T >= 191.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - 1.7939482519122413e-8*x10*x12 - 1.7939482519122417e-8*x10*x13 + 5.9798275063741389e-9*x10*x14 + x11*x18*((x8)*(x8)) - x12*x17 - x13*x17 + 0.00018340163372714569*x14*x16 + x18*x6*x9 - 0.00036680326745429137*x7*((x8)*(x8)*(x8)) - 0.0011004098023628737*x9 + 0.0011004098023628737*x6/x2;
}
}
        
static void coder_d5gdn2dt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d3mu0dT2dP)(T, P);
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d3mu0dTdP2)(T, P);
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    

result = n1*(*endmember[0].d3mu0dP3)(T, P);
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = (*endmember[0].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_s(double T, double P, double n[1]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[1]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[1]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[1]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[1]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[1]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[1]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[1]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[1]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[1]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[1]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[1]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[1]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[1]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

