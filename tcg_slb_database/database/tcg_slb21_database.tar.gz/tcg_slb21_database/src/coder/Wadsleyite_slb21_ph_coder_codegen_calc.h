#include <math.h>


static double coder_g(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = n1 + n2;
    double x1 = 1.0/x0;
    double x2 = 13200.0*n1*n2;
    double x3 = n1*(*endmember[0].mu0)(T, P);
    double x4 = n2*(*endmember[1].mu0)(T, P);
    double x5 = T*(n1*log(n1*x1) + n2*log(n2*x1));
    double x6 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));

if (T >= 5.0) {
   result = x1*(1.0*x0*(-n2*(26.762699999999999*T - 89.209000000000003) + x3 + x4 + 16.628925236306479*x5) + x2);
}
else {
   result = x1*(0.33333333333333331*x0*(n2*(133.8135*((x6)*(x6)*(x6)) + (80.2881*T - 401.44049999999999)*(x6 - 1) - 133.8135) + 3*x3 + 3*x4 + 49.886775708919437*x5) + x2);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = pow(x0, -2);
    double x2 = 13200.0*n2;
    double x3 = n1*x2;
    double x4 = (*endmember[0].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[1].mu0)(T, P);
    double x7 = n2*x6;
    double x8 = 26.762699999999999*T;
    double x9 = n2*(x8 - 89.209000000000003);
    double x10 = 1.0/x0;
    double x11 = n1*x10;
    double x12 = log(x11);
    double x13 = n2*x10;
    double x14 = log(x13);
    double x15 = n1*x12 + n2*x14;
    double x16 = 16.628925236306479*T;
    double x17 = x15*x16;
    double x18 = 1.0*x0;
    double x19 = -x1*(x18*(x17 + x5 + x7 - x9) + x3);
    double x20 = -x10;
    double x21 = x0*(-n1*x1 - x20) + x12 - x13;
    double x22 = -1.0*x9;
    double x23 = x17 + 1.0*x5 + 1.0*x7;
    double x24 = x2 + x23;
    double x25 = T >= 5.0;
    double x26 = 49.886775708919437*T;
    double x27 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));
    double x28 = 133.8135*((x27)*(x27)*(x27)) + (80.2881*T - 401.44049999999999)*(x27 - 1) - 133.8135;
    double x29 = n2*x28;
    double x30 = 0.33333333333333331*x0;
    double x31 = -x1*(x3 + x30*(x15*x26 + x29 + 3*x5 + 3*x7));
    double x32 = 0.33333333333333331*x29;
    double x33 = x0*(-n2*x1 - x20) - x11 + x14;
    double x34 = 13200.0*n1 + x23;

if (x25) {
   result[0] = x10*(x18*(x16*x21 + x4) + x22 + x24) + x19;
}
else {
   result[0] = x10*(x24 + x30*(x21*x26 + 3*x4) + x32) + x31;
}
if (x25) {
   result[1] = x10*(x18*(x16*x33 + x6 - x8 + 89.209000000000003) + x22 + x34) + x19;
}
else {
   result[1] = x10*(x30*(x26*x33 + x28 + 3*x6) + x32 + x34) + x31;
}
}
        
static void coder_d2gdn2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = 13200.0*n2;
    double x1 = n1*x0;
    double x2 = (*endmember[0].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[1].mu0)(T, P);
    double x5 = n2*x4;
    double x6 = 26.762699999999999*T;
    double x7 = n2*(x6 - 89.209000000000003);
    double x8 = n1 + n2;
    double x9 = 1.0/x8;
    double x10 = n1*x9;
    double x11 = log(x10);
    double x12 = n2*x9;
    double x13 = log(x12);
    double x14 = T*(n1*x11 + n2*x13);
    double x15 = 16.628925236306479*x14;
    double x16 = 1.0*x8;
    double x17 = 2/((x8)*(x8)*(x8));
    double x18 = x17*(x1 + x16*(x15 + x3 + x5 - x7));
    double x19 = pow(x8, -2);
    double x20 = n1*x19;
    double x21 = -x9;
    double x22 = x8*(-x20 - x21);
    double x23 = T*(x11 - x12 + x22);
    double x24 = 16.628925236306479*x23;
    double x25 = -1.0*x7;
    double x26 = x15 + 1.0*x3 + 1.0*x5;
    double x27 = x0 + x26;
    double x28 = x16*(x2 + x24) + x25 + x27;
    double x29 = 2*x19;
    double x30 = n2*x19;
    double x31 = -x29;
    double x32 = n1*x17;
    double x33 = 16.628925236306479*T*x8;
    double x34 = x9*(2.0*x2 + 33.257850472612958*x23 + x33*(-x20 + x30 + x8*(x31 + x32) + x9 + x22/n1));
    double x35 = T >= 5.0;
    double x36 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));
    double x37 = ((x36)*(x36)*(x36));
    double x38 = (80.2881*T - 401.44049999999999)*(x36 - 1);
    double x39 = 133.8135*x37 + x38 - 133.8135;
    double x40 = n2*x39;
    double x41 = 0.33333333333333331*x8;
    double x42 = x17*(x1 + x41*(49.886775708919437*x14 + 3*x3 + x40 + 3*x5));
    double x43 = 0.33333333333333331*x40;
    double x44 = x27 + x41*(3*x2 + 49.886775708919437*x23) + x43;
    double x45 = x8*(-x21 - x30);
    double x46 = T*(-x10 + x13 + x45);
    double x47 = 16.628925236306479*x46;
    double x48 = x47 - x6;
    double x49 = 13200.0*n1 + x26;
    double x50 = x16*(x4 + x48 + 89.209000000000003) + x25 + x49;
    double x51 = x20 - x30 + x9;
    double x52 = 1.0*x2 + x24 + x33*(-x51 + x8*(-x19 + x32)) + 1.0*x4;
    double x53 = x41*(x39 + 3*x4 + 49.886775708919437*x46) + x43 + x49;
    double x54 = x33*(x51 + x8*(n2*x17 + x31) + x45/n2) + 2.0*x4 + 33.257850472612958*x46;

if (x35) {
   result[0] = x18 - x28*x29 + x34;
}
else {
   result[0] = -x29*x44 + x34 + x42;
}
if (x35) {
   result[1] = x18 - x19*x28 - x19*x50 + x9*(x48 + x52 + 13289.209000000001);
}
else {
   result[1] = -x19*x44 - x19*x53 + x42 + x9*(44.604500000000002*x37 + 0.33333333333333331*x38 + x47 + x52 + 13155.395500000001);
}
if (x35) {
   result[2] = x18 - x29*x50 + x9*(-53.525399999999998*T + x54 + 178.41800000000001);
}
else {
   result[2] = -x29*x53 + x42 + x9*(89.209000000000003*x37 + 0.66666666666666663*x38 + x54 - 89.209000000000003);
}
}
        
static void coder_d3gdn3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = 13200.0*n2;
    double x1 = n1*x0;
    double x2 = (*endmember[0].mu0)(T, P);
    double x3 = n1*x2;
    double x4 = (*endmember[1].mu0)(T, P);
    double x5 = n2*x4;
    double x6 = 26.762699999999999*T;
    double x7 = n2*(x6 - 89.209000000000003);
    double x8 = n1 + n2;
    double x9 = 1.0/x8;
    double x10 = n1*x9;
    double x11 = log(x10);
    double x12 = n2*x9;
    double x13 = log(x12);
    double x14 = n1*x11 + n2*x13;
    double x15 = 16.628925236306479*T;
    double x16 = x14*x15;
    double x17 = 1.0*x8;
    double x18 = 6/((x8)*(x8)*(x8)*(x8));
    double x19 = -x18*(x1 + x17*(x16 + x3 + x5 - x7));
    double x20 = pow(x8, -2);
    double x21 = n1*x20;
    double x22 = -x9;
    double x23 = -x21 - x22;
    double x24 = x23*x8;
    double x25 = x11 - x12 + x24;
    double x26 = x15*x25;
    double x27 = -1.0*x7;
    double x28 = x16 + 1.0*x3 + 1.0*x5;
    double x29 = x0 + x28;
    double x30 = x17*(x2 + x26) + x27 + x29;
    double x31 = pow(x8, -3);
    double x32 = 6*x31;
    double x33 = n2*x20;
    double x34 = 2*x20;
    double x35 = -x34;
    double x36 = 2*x31;
    double x37 = n1*x36;
    double x38 = x8*(x35 + x37);
    double x39 = 1.0/n1;
    double x40 = x23*x39;
    double x41 = -x21 + x33 + x38 + x40*x8 + x9;
    double x42 = 49.886775708919437*T;
    double x43 = -4*x20;
    double x44 = -6*x31;
    double x45 = n1*x18;
    double x46 = n2*x36;
    double x47 = 4*x31;
    double x48 = n1*x47 - x46;
    double x49 = x40 + x48;
    double x50 = x15*x8;
    double x51 = 33.257850472612958*T;
    double x52 = x15*x41;
    double x53 = x20*(2.0*x2 + x25*x51 + x52*x8);
    double x54 = -3*x53 + x9*(x41*x42 + x50*(x38*x39 + x43 + x49 + x8*(-x44 - x45) - x24/((n1)*(n1))));
    double x55 = T >= 5.0;
    double x56 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));
    double x57 = ((x56)*(x56)*(x56));
    double x58 = (80.2881*T - 401.44049999999999)*(x56 - 1);
    double x59 = 133.8135*x57 + x58 - 133.8135;
    double x60 = n2*x59;
    double x61 = 0.33333333333333331*x8;
    double x62 = -x18*(x1 + x61*(x14*x42 + 3*x3 + 3*x5 + x60));
    double x63 = 0.33333333333333331*x60;
    double x64 = x29 + x61*(3*x2 + x25*x42) + x63;
    double x65 = -x22 - x33;
    double x66 = x65*x8;
    double x67 = -x10 + x13 + x66;
    double x68 = x15*x67;
    double x69 = -x6 + x68;
    double x70 = 13200.0*n1 + x28;
    double x71 = x17*(x4 + x69 + 89.209000000000003) + x27 + x70;
    double x72 = -x20 + x37;
    double x73 = x21 - x33 + x9;
    double x74 = x72*x8 - x73;
    double x75 = x51*x74;
    double x76 = -x53 + x9*(x50*(x35 + x39*x72*x8 + x49 + x8*(4*x31 - x45)) + x52 + x75);
    double x77 = 1.0*x2 + x26 + 1.0*x4 + x50*x74;
    double x78 = x19 - x34*(x69 + x77 + 13289.209000000001);
    double x79 = x61*(3*x4 + x42*x67 + x59) + x63 + x70;
    double x80 = -x34*(44.604500000000002*x57 + 0.33333333333333331*x58 + x68 + x77 + 13155.395500000001) + x62;
    double x81 = x8*(x35 + x46);
    double x82 = 1.0/n2;
    double x83 = x66*x82 + x73 + x81;
    double x84 = x15*x83;
    double x85 = x9*(x50*(x20 + x48 + x8*(2*x31 - x45)) + x75 + x84);
    double x86 = 2.0*x4 + x51*x67 + x8*x84;
    double x87 = x20*(-53.525399999999998*T + x86 + 178.41800000000001);
    double x88 = x20*(89.209000000000003*x57 + 0.66666666666666663*x58 + x86 - 89.209000000000003);
    double x89 = x9*(x42*x83 + x50*(n2*x47 - x37 + x43 + x65*x82 + x8*(-n2*x18 - x44) + x81*x82 - x66/((n2)*(n2))));

if (x55) {
   result[0] = x19 + x30*x32 + x54;
}
else {
   result[0] = x32*x64 + x54 + x62;
}
if (x55) {
   result[1] = x30*x47 + x36*x71 + x76 + x78;
}
else {
   result[1] = x36*x79 + x47*x64 + x76 + x80;
}
if (x55) {
   result[2] = x30*x36 + x47*x71 + x78 + x85 - x87;
}
else {
   result[2] = x36*x64 + x47*x79 + x80 + x85 - x88;
}
if (x55) {
   result[3] = x19 + x32*x71 - 3*x87 + x89;
}
else {
   result[3] = x32*x79 + x62 - 3*x88 + x89;
}
}
        
static double coder_dgdt(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = 1.0/(n1 + n2);
    double x1 = 16.628925236306479*n1*log(n1*x0) + 1.0*n1*(*endmember[0].dmu0dT)(T, P) + 16.628925236306479*n2*log(n2*x0) + 1.0*n2*(*endmember[1].dmu0dT)(T, P);
    double x2 = sqrt(1 - 0.19999999999999998*T);
    double x3 = 1.0000000000000002*x2;
    double x4 = fmin(4, x3);
    double x5 = (4 - x3 >= 0. ? 1. : 0.)/x2;

if (T >= 5.0) {
   result = -26.762699999999999*n2 + x1;
}
else {
   result = 0.33333333333333331*n2*(-40.144050000000007*((x4)*(x4))*x5 + 80.2881*x4 - 0.10000000000000002*x5*(80.2881*T - 401.44049999999999) - 80.2881) + x1;
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = 1.0/x0;
    double x2 = n2*x1;
    double x3 = n1*x1;
    double x4 = pow(x0, -2);
    double x5 = -x1;
    double x6 = 16.628925236306479*x0;
    double x7 = 16.628925236306479*x3;
    double x8 = (*endmember[1].dmu0dT)(T, P);
    double x9 = log(x2);
    double x10 = -n2*x4 - x5;
    double x11 = sqrt(1 - 0.19999999999999998*T);
    double x12 = 1.0000000000000002*x11;
    double x13 = fmin(4, x12);
    double x14 = (4 - x12 >= 0. ? 1. : 0.)/x11;

result[0] = -16.628925236306479*x2 + x6*(-n1*x4 - x5) + 16.628925236306479*log(x3) + 1.0*(*endmember[0].dmu0dT)(T, P);
if (T >= 5.0) {
   result[1] = x10*x6 - x7 + 1.0*x8 + 16.628925236306479*x9 - 26.762699999999999;
}
else {
   result[1] = 16.628925236306479*x0*x10 - 13.381350000000001*((x13)*(x13))*x14 + 26.762699999999999*x13 - 0.03333333333333334*x14*(80.2881*T - 401.44049999999999) - x7 + 1.0*x8 + 16.628925236306479*x9 - 26.762699999999999;
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = 1.0/x0;
    double x2 = 16.628925236306479*x1;
    double x3 = pow(x0, -2);
    double x4 = n1*x3;
    double x5 = 16.628925236306479*x4;
    double x6 = n2*x3;
    double x7 = 16.628925236306479*x6;
    double x8 = -2*x3;
    double x9 = 2/((x0)*(x0)*(x0));
    double x10 = n1*x9;
    double x11 = 16.628925236306479*x0;
    double x12 = -x1;
    double x13 = x2 + x5 - x7;

result[0] = x11*(x10 + x8) + x2 - x5 + x7 + x11*(-x12 - x4)/n1;
result[1] = 16.628925236306479*x0*(x10 - x3) - x13;
result[2] = x11*(n2*x9 + x8) + x13 + x11*(-x12 - x6)/n2;
}
        
static void coder_d4gdn3dt(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = n1 + n2;
    double x1 = pow(x0, -2);
    double x2 = -66.515700945225916*x1;
    double x3 = pow(x0, -3);
    double x4 = -6*x3;
    double x5 = 6/((x0)*(x0)*(x0)*(x0));
    double x6 = n1*x5;
    double x7 = 16.628925236306479*x0;
    double x8 = -2*x1;
    double x9 = 2*x3;
    double x10 = n1*x9;
    double x11 = 16.628925236306479/n1;
    double x12 = x0*x11;
    double x13 = -1/x0;
    double x14 = -n1*x1 - x13;
    double x15 = 66.515700945225916*x3;
    double x16 = 33.257850472612958*x3;
    double x17 = n1*x15 - n2*x16;
    double x18 = x11*x14 + x17;
    double x19 = 1.0/n2;
    double x20 = -n2*x1 - x13;

result[0] = x12*(x10 + x8) + x18 + x2 + x7*(-x4 - x6) - x14*x7/((n1)*(n1));
result[1] = -33.257850472612958*x1 + x12*(-x1 + x10) + x18 + x7*(4*x3 - x6);
result[2] = 16.628925236306479*x1 + x17 + x7*(2*x3 - x6);
result[3] = -n1*x16 + n2*x15 + 16.628925236306479*x19*x20 + x19*x7*(n2*x9 + x8) + x2 + x7*(-n2*x5 - x4) - x20*x7/((n2)*(n2));
}
        
static double coder_dgdp(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*n1*(*endmember[0].dmu0dP)(T, P) + 1.0*n2*(*endmember[1].dmu0dP)(T, P);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].dmu0dP)(T, P);
result[1] = 1.0*(*endmember[1].dmu0dP)(T, P);
}
        
static void coder_d3gdn2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dT2)(T, P);
    double x2 = 0.19999999999999998*T - 1;
    double x3 = -x2;
    double x4 = sqrt(x3);
    double x5 = 1.0000000000000002*x4;
    double x6 = x5 - 4;
    double x7 = (-x6 >= 0. ? 1. : 0.);
    double x8 = 80.2881*T - 401.44049999999999;
    double x9 = 1.0/x2;
    double x10 = x9*0;
    double x11 = x7/pow(x3, 3.0/2.0);
    double x12 = fmin(4, x5);
    double x13 = ((x12)*(x12));

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1;
}
else {
   result = -0.33333333333333331*n2*(-4.0144050000000018*x10*x13 - 0.010000000000000004*x10*x8 + 4.014405*x11*x13 + 0.010000000000000002*x11*x8 + 8.0288100000000036*x12*((x7)*(x7))*x9 + 16.057620000000004*x7/x4) + 1.0*x0 + 1.0*x1;
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = (*endmember[1].d2mu0dT2)(T, P);
    double x1 = 0.19999999999999998*T - 1;
    double x2 = -x1;
    double x3 = sqrt(x2);
    double x4 = 1.0000000000000002*x3;
    double x5 = x4 - 4;
    double x6 = (-x5 >= 0. ? 1. : 0.);
    double x7 = 80.2881*T - 401.44049999999999;
    double x8 = 1.0/x1;
    double x9 = 0;
    double x10 = x6/pow(x2, 3.0/2.0);
    double x11 = fmin(4, x4);
    double x12 = ((x11)*(x11));

result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
if (T >= 5.0) {
   result[1] = 1.0*x0;
}
else {
   result[1] = 1.0*x0 - 1.3381349999999999*x10*x12 - 0.003333333333333334*x10*x7 - 2.676270000000001*x11*((x6)*(x6))*x8 + 1.3381350000000005*x12*x8*x9 + 0.0033333333333333344*x7*x8*x9 - 5.3525400000000012*x6/x3;
}
}
        
static void coder_d4gdn2dt2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P));
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P));
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT3)(T, P);
    double x2 = 0.19999999999999998*T - 1;
    double x3 = -x2;
    double x4 = 1.0000000000000002*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = pow(x3, -3.0/2.0);
    double x8 = (-x5 >= 0. ? 1. : 0.);
    double x9 = x7*x8;
    double x10 = 80.2881*T - 401.44049999999999;
    double x11 = pow(x2, -2);
    double x12 = x11*x6;
    double x13 = x8/pow(x3, 5.0/2.0);
    double x14 = x7*0;
    double x15 = fmin(4, x4);
    double x16 = ((x15)*(x15));

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1;
}
else {
   result = -0.33333333333333331*n2*(0.0030000000000000009*x10*x12 + 0.0030000000000000005*x10*x13 - 0.0010000000000000005*x10*x14 - 2.4086430000000005*x11*x15*((x8)*(x8)) + 1.2043215000000003*x12*x16 + 1.2043215*x13*x16 - 0.40144050000000026*x14*x16 - 2.4086430000000014*x15*x6*x9 + 0.80288100000000051*x7*((x8)*(x8)*(x8)) + 2.4086430000000005*x9 - 2.408643000000001*x6/x2) + 1.0*x0 + 1.0*x1;
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];

    double x0 = 1.0*(*endmember[1].d3mu0dT3)(T, P);
    double x1 = 0.19999999999999998*T - 1;
    double x2 = -x1;
    double x3 = 1.0000000000000002*sqrt(x2);
    double x4 = x3 - 4;
    double x5 = 0;
    double x6 = pow(x2, -3.0/2.0);
    double x7 = (-x4 >= 0. ? 1. : 0.);
    double x8 = x6*x7;
    double x9 = 80.2881*T - 401.44049999999999;
    double x10 = pow(x1, -2);
    double x11 = x10*x5;
    double x12 = x7/pow(x2, 5.0/2.0);
    double x13 = x6*0;
    double x14 = fmin(4, x3);
    double x15 = ((x14)*(x14));

result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
if (T >= 5.0) {
   result[1] = x0;
}
else {
   result[1] = x0 + 0.80288100000000018*x10*x14*((x7)*(x7)) - 0.40144050000000009*x11*x15 - 0.0010000000000000002*x11*x9 - 0.40144049999999998*x12*x15 - 0.001*x12*x9 + 0.13381350000000009*x13*x15 + 0.00033333333333333348*x13*x9 + 0.8028810000000004*x14*x5*x8 - 0.26762700000000017*x6*((x7)*(x7)*(x7)) - 0.80288100000000018*x8 + 0.80288100000000029*x5/x1;
}
}
        
static void coder_d5gdn2dt3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P));
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P));
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[2]) {
    double n1 = n[0];
    double n2 = n[1];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P));
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[2], double result[2]) {
    double n1 = n[0];
    double n2 = n[1];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
}
        
static double coder_s(double T, double P, double n[2]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[2]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[2]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[2]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[2]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[2]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[2]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[2]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[2]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[2]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[2]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[2]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[2]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[2]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

