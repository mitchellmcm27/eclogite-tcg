#include <math.h>


static double coder_g(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = n1 + n3;
    double x1 = n2 + n4 + x0;
    double x2 = 1.0/x1;
    double x3 = n1*(*endmember[0].mu0)(T, P);
    double x4 = n2*(*endmember[1].mu0)(T, P);
    double x5 = n3*(*endmember[2].mu0)(T, P);
    double x6 = n4*(*endmember[3].mu0)(T, P);
    double x7 = n1 + n4;
    double x8 = T*(2.0*n2*log(n2*x2) + 1.0*n3*log(n3*x2) + 1.0*n4*log(n4*x2) + 1.0*x0*log(x0*x2) + 1.0*x7*log(x2*x7));
    double x9 = 16100.0*n4;
    double x10 = n1*x9 + n2*x9 + 24000.0*n3*n4 + 0.125*n4*(128800.0*n1 + 128800.0*n2 + 192000.0*n3);
    double x11 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));

if (T >= 5.0) {
   result = x2*(1.0*x1*(-n2*(26.762699999999999*T - 89.209000000000003) + x3 + x4 + x5 + x6 + 8.3144626181532395*x8) + x10);
}
else {
   result = x2*(0.33333333333333331*x1*(n2*(133.8135*((x11)*(x11)*(x11)) + (80.2881*T - 401.44049999999999)*(x11 - 1) - 133.8135) + 3*x3 + 3*x4 + 3*x5 + 3*x6 + 24.943387854459719*x8) + x10);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = n1 + n3;
    double x1 = n2 + n4 + x0;
    double x2 = pow(x1, -2);
    double x3 = (*endmember[0].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = n2*x5;
    double x7 = (*endmember[2].mu0)(T, P);
    double x8 = n3*x7;
    double x9 = (*endmember[3].mu0)(T, P);
    double x10 = n4*x9;
    double x11 = 26.762699999999999*T;
    double x12 = x11 - 89.209000000000003;
    double x13 = 1.0/x1;
    double x14 = n2*x13;
    double x15 = 2.0*log(x14);
    double x16 = log(n3*x13);
    double x17 = 1.0*n3;
    double x18 = log(n4*x13);
    double x19 = 1.0*n4;
    double x20 = 1.0*log(x0*x13);
    double x21 = n1 + n4;
    double x22 = 1.0*log(x13*x21);
    double x23 = n2*x15 + x0*x20 + x16*x17 + x18*x19 + x21*x22;
    double x24 = 8.3144626181532395*T;
    double x25 = x23*x24;
    double x26 = 1.0*x1;
    double x27 = 16100.0*n4;
    double x28 = n1*x27 + n2*x27 + 24000.0*n3*n4 + 0.125*n4*(128800.0*n1 + 128800.0*n2 + 192000.0*n3);
    double x29 = -x2*(x26*(-n2*x12 + x10 + x25 + x4 + x6 + x8) + x28);
    double x30 = 1.0*n2;
    double x31 = 1.0*n1;
    double x32 = x17 + x31;
    double x33 = x19 + x30 + x32;
    double x34 = -x13*x17;
    double x35 = -x13*x19;
    double x36 = x34 + x35;
    double x37 = -2.0*x14;
    double x38 = x20 + x37 + x1*x32*(-x0*x2 + x13)/x0;
    double x39 = x19 + x31;
    double x40 = x1*x39*(x13 - x2*x21)/x21 + x22;
    double x41 = x36 + x38 + x40;
    double x42 = -x12*x30;
    double x43 = x17*x7 + x19*x9 + x25 + x3*x31 + x30*x5;
    double x44 = 32200.0*n4 + x43;
    double x45 = x42 + x44;
    double x46 = T >= 5.0;
    double x47 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));
    double x48 = 133.8135*((x47)*(x47)*(x47)) + (80.2881*T - 401.44049999999999)*(x47 - 1) - 133.8135;
    double x49 = 24.943387854459719*T;
    double x50 = -x2*(0.33333333333333331*x1*(n2*x48 + 3*x10 + x23*x49 + 3*x4 + 3*x6 + 3*x8) + x28);
    double x51 = 0.33333333333333331*n2;
    double x52 = 0.33333333333333331*n1 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + x51;
    double x53 = x48*x51;
    double x54 = x44 + x53;
    double x55 = -x13*x32;
    double x56 = -x13*x39;
    double x57 = 2.0*x1*(-n2*x2 + x13) + x15 + x36 + x55 + x56;
    double x58 = 1.0*x16 + x26*(-n3*x2 + x13) + x35 + x38 + x56;
    double x59 = 48000.0*n4 + x43;
    double x60 = 1.0*x18 + x26*(-n4*x2 + x13) + x34 + x37 + x40 + x55;
    double x61 = 32200.0*n1 + 32200.0*n2 + 48000.0*n3 + x43;

if (x46) {
   result[0] = x13*(x33*(x24*x41 + x3) + x45) + x29;
}
else {
   result[0] = x13*(x52*(3*x3 + x41*x49) + x54) + x50;
}
if (x46) {
   result[1] = x13*(x33*(-x11 + x24*x57 + x5 + 89.209000000000003) + x45) + x29;
}
else {
   result[1] = x13*(x52*(x48 + x49*x57 + 3*x5) + x54) + x50;
}
if (x46) {
   result[2] = x13*(x33*(x24*x58 + x7) + x42 + x59) + x29;
}
else {
   result[2] = x13*(x52*(x49*x58 + 3*x7) + x53 + x59) + x50;
}
if (x46) {
   result[3] = x13*(x33*(x24*x60 + x9) + x42 + x61) + x29;
}
else {
   result[3] = x13*(x52*(x49*x60 + 3*x9) + x53 + x61) + x50;
}
}
        
static void coder_d2gdn2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n3*x4;
    double x6 = (*endmember[3].mu0)(T, P);
    double x7 = n4*x6;
    double x8 = 26.762699999999999*T;
    double x9 = x8 - 89.209000000000003;
    double x10 = n1 + n3;
    double x11 = n2 + n4 + x10;
    double x12 = 1.0/x11;
    double x13 = n2*x12;
    double x14 = 2.0*log(x13);
    double x15 = log(n3*x12);
    double x16 = 1.0*n3;
    double x17 = log(n4*x12);
    double x18 = 1.0*n4;
    double x19 = 1.0*log(x10*x12);
    double x20 = n1 + n4;
    double x21 = 1.0*log(x12*x20);
    double x22 = T*(n2*x14 + x10*x19 + x15*x16 + x17*x18 + x20*x21);
    double x23 = 8.3144626181532395*x22;
    double x24 = 1.0*x11;
    double x25 = 16100.0*n4;
    double x26 = n1*x25 + n2*x25 + 24000.0*n3*n4 + 0.125*n4*(128800.0*n1 + 128800.0*n2 + 192000.0*n3);
    double x27 = pow(x11, -3);
    double x28 = 2*x27;
    double x29 = x28*(x24*(-n2*x9 + x1 + x23 + x3 + x5 + x7) + x26);
    double x30 = 1.0*n2;
    double x31 = 1.0*n1;
    double x32 = x16 + x31;
    double x33 = x18 + x30 + x32;
    double x34 = -x12*x16;
    double x35 = -x12*x18;
    double x36 = x34 + x35;
    double x37 = -2.0*x13;
    double x38 = 1.0/x10;
    double x39 = pow(x11, -2);
    double x40 = -x10*x39 + x12;
    double x41 = x38*x40;
    double x42 = x32*x41;
    double x43 = x11*x42 + x19 + x37;
    double x44 = x18 + x31;
    double x45 = 1.0/x20;
    double x46 = x12 - x20*x39;
    double x47 = x45*x46;
    double x48 = x44*x47;
    double x49 = x11*x48 + x21;
    double x50 = T*(x36 + x43 + x49);
    double x51 = 8.3144626181532395*x50;
    double x52 = -x30*x9;
    double x53 = x0*x31 + x16*x4 + x18*x6 + x2*x30 + x23;
    double x54 = 32200.0*n4 + x53;
    double x55 = x52 + x54;
    double x56 = x33*(x0 + x51) + x55;
    double x57 = 2*x39;
    double x58 = x16*x39;
    double x59 = x18*x39;
    double x60 = x58 + x59;
    double x61 = 2.0*x11;
    double x62 = -x57;
    double x63 = x10*x28;
    double x64 = x11*x32;
    double x65 = x38*x64;
    double x66 = n2*x39;
    double x67 = 2.0*x66;
    double x68 = x42 + x67;
    double x69 = x41*x61 + x65*(x62 + x63) + x68 - x40*x64/((x10)*(x10));
    double x70 = x20*x28;
    double x71 = x11*x44;
    double x72 = x45*x71;
    double x73 = x47*x61 + x48 + x72*(x62 + x70) - x46*x71/((x20)*(x20));
    double x74 = T*(x60 + x69 + x73);
    double x75 = 8.3144626181532395*x33;
    double x76 = 2.0*x0 + 16.628925236306479*x50;
    double x77 = T >= 5.0;
    double x78 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));
    double x79 = ((x78)*(x78)*(x78));
    double x80 = (80.2881*T - 401.44049999999999)*(x78 - 1);
    double x81 = 133.8135*x79 + x80 - 133.8135;
    double x82 = x28*(0.33333333333333331*x11*(n2*x81 + 3*x1 + 24.943387854459719*x22 + 3*x3 + 3*x5 + 3*x7) + x26);
    double x83 = 0.33333333333333331*n2;
    double x84 = 0.33333333333333331*n1 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + x83;
    double x85 = x81*x83;
    double x86 = x54 + x85;
    double x87 = x84*(3*x0 + 24.943387854459719*x50) + x86;
    double x88 = 24.943387854459719*x84;
    double x89 = -x39;
    double x90 = x65*(x63 + x89) + x68;
    double x91 = x48 + x72*(x70 + x89);
    double x92 = T*(-4.0*x12 + x60 + x90 + x91);
    double x93 = 1.0*x0 + x51;
    double x94 = 1.0*x2;
    double x95 = -x12*x32;
    double x96 = -x12*x44;
    double x97 = x61*(x12 - x66);
    double x98 = T*(x14 + x36 + x95 + x96 + x97);
    double x99 = 8.3144626181532395*x98;
    double x100 = -x8 + x99;
    double x101 = x100 + 89.209000000000003;
    double x102 = x101 + x94;
    double x103 = x33*(x101 + x2) + x55;
    double x104 = -x103*x39;
    double x105 = x29 - x39*x56;
    double x106 = 44.604500000000002*x79 + 0.33333333333333331*x80 + x99;
    double x107 = x106 + x94 - 44.604500000000002;
    double x108 = x84*(3*x2 + x81 + 24.943387854459719*x98) + x86;
    double x109 = -x108*x39;
    double x110 = -x39*x87 + x82;
    double x111 = 2.0*x12;
    double x112 = -x111 + x60;
    double x113 = T*(x112 + x69 + x91);
    double x114 = x24*(-n3*x39 + x12);
    double x115 = T*(x114 + 1.0*x15 + x35 + x43 + x96);
    double x116 = 8.3144626181532395*x115;
    double x117 = x116 + 1.0*x4;
    double x118 = x117 + x93;
    double x119 = 48000.0*n4 + x53;
    double x120 = x119 + x33*(x116 + x4) + x52;
    double x121 = -x120*x39;
    double x122 = x119 + x84*(24.943387854459719*x115 + 3*x4) + x85;
    double x123 = -x122*x39;
    double x124 = T*(x112 + x73 + x90);
    double x125 = x24*(-n4*x39 + x12);
    double x126 = T*(x125 + 1.0*x17 + x34 + x37 + x49 + x95);
    double x127 = 8.3144626181532395*x126;
    double x128 = x127 + 1.0*x6;
    double x129 = x128 + x93 + 32200.0;
    double x130 = 32200.0*n1 + 32200.0*n2 + 48000.0*n3 + x53;
    double x131 = x130 + x33*(x127 + x6) + x52;
    double x132 = -x131*x39;
    double x133 = x130 + x84*(24.943387854459719*x126 + 3*x6) + x85;
    double x134 = -x133*x39;
    double x135 = 4.0*n2*x27;
    double x136 = x32*x39;
    double x137 = x39*x44;
    double x138 = x136 + x137 - x67;
    double x139 = T*(x11*(x135 - 4.0*x39) + x111 + x138 + x60 + x97/n2);
    double x140 = 2.0*x2 + 16.628925236306479*x98;
    double x141 = -2.0*x39;
    double x142 = T*(x11*(x135 + x141) + x112 + x138);
    double x143 = x142*x75;
    double x144 = x104 + x29;
    double x145 = x142*x88;
    double x146 = x109 + x82;
    double x147 = x128 + x94;
    double x148 = 1.0*x12;
    double x149 = 2.0*x27;
    double x150 = n3*x149;
    double x151 = x137 - x58 + x59;
    double x152 = T*(x11*(x141 + x150) + x148 + x151 + x69 + x114/n3);
    double x153 = 16.628925236306479*x115 + 2.0*x4;
    double x154 = T*(x11*(x150 - 1.0*x39) - 3.0*x12 + x151 + x90);
    double x155 = x117 + x128 + 48000.0;
    double x156 = T*(x11*(n4*x149 + x141) + x136 + x148 + x58 - x59 + x67 + x73 + x125/n4);
    double x157 = 16.628925236306479*x126 + 2.0*x6;

if (x77) {
   result[0] = x12*(x74*x75 + x76) + x29 - x56*x57;
}
else {
   result[0] = x12*(x74*x88 + x76) - x57*x87 + x82;
}
if (x77) {
   result[1] = x104 + x105 + x12*(x102 + x75*x92 + x93);
}
else {
   result[1] = x109 + x110 + x12*(x107 + x88*x92 + x93);
}
if (x77) {
   result[2] = x105 + x12*(x113*x75 + x118) + x121;
}
else {
   result[2] = x110 + x12*(x113*x88 + x118) + x123;
}
if (x77) {
   result[3] = x105 + x12*(x124*x75 + x129) + x132;
}
else {
   result[3] = x110 + x12*(x124*x88 + x129) + x134;
}
if (x77) {
   result[4] = -x103*x57 + x12*(-53.525399999999998*T + x139*x75 + x140 + 178.41800000000001) + x29;
}
else {
   result[4] = -x108*x57 + x12*(x139*x88 + x140 + 89.209000000000003*x79 + 0.66666666666666663*x80 - 89.209000000000003) + x82;
}
if (x77) {
   result[5] = x12*(x102 + x117 + x143) + x121 + x144;
}
else {
   result[5] = x12*(x107 + x117 + x145) + x123 + x146;
}
if (x77) {
   result[6] = x12*(x100 + x143 + x147 + 32289.208999999999) + x132 + x144;
}
else {
   result[6] = x12*(x106 + x145 + x147 + 32155.395499999999) + x134 + x146;
}
if (x77) {
   result[7] = x12*(x152*x75 + x153) - x120*x57 + x29;
}
else {
   result[7] = x12*(x152*x88 + x153) - x122*x57 + x82;
}
if (x77) {
   result[8] = x12*(x154*x75 + x155) + x121 + x132 + x29;
}
else {
   result[8] = x12*(x154*x88 + x155) + x123 + x134 + x82;
}
if (x77) {
   result[9] = x12*(x156*x75 + x157) - x131*x57 + x29;
}
else {
   result[9] = x12*(x156*x88 + x157) - x133*x57 + x82;
}
}
        
static void coder_d3gdn3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n3*x4;
    double x6 = (*endmember[3].mu0)(T, P);
    double x7 = n4*x6;
    double x8 = 26.762699999999999*T;
    double x9 = x8 - 89.209000000000003;
    double x10 = n1 + n3;
    double x11 = n2 + n4 + x10;
    double x12 = 1.0/x11;
    double x13 = n2*x12;
    double x14 = 2.0*log(x13);
    double x15 = log(n3*x12);
    double x16 = 1.0*n3;
    double x17 = log(n4*x12);
    double x18 = 1.0*n4;
    double x19 = 1.0*log(x10*x12);
    double x20 = n1 + n4;
    double x21 = 1.0*log(x12*x20);
    double x22 = n2*x14 + x10*x19 + x15*x16 + x17*x18 + x20*x21;
    double x23 = 8.3144626181532395*T;
    double x24 = x22*x23;
    double x25 = 1.0*x11;
    double x26 = 16100.0*n4;
    double x27 = n1*x26 + n2*x26 + 24000.0*n3*n4 + 0.125*n4*(128800.0*n1 + 128800.0*n2 + 192000.0*n3);
    double x28 = pow(x11, -4);
    double x29 = 6*x28;
    double x30 = -x29*(x25*(-n2*x9 + x1 + x24 + x3 + x5 + x7) + x27);
    double x31 = 1.0*n2;
    double x32 = 1.0*n1;
    double x33 = x16 + x32;
    double x34 = x18 + x31 + x33;
    double x35 = -x12*x16;
    double x36 = -x12*x18;
    double x37 = x35 + x36;
    double x38 = -2.0*x13;
    double x39 = 1.0/x10;
    double x40 = pow(x11, -2);
    double x41 = -x10*x40 + x12;
    double x42 = x39*x41;
    double x43 = x33*x42;
    double x44 = x11*x43 + x19 + x38;
    double x45 = x18 + x32;
    double x46 = 1.0/x20;
    double x47 = x12 - x20*x40;
    double x48 = x46*x47;
    double x49 = x45*x48;
    double x50 = x11*x49 + x21;
    double x51 = x37 + x44 + x50;
    double x52 = x23*x51;
    double x53 = -x31*x9;
    double x54 = x0*x32 + x16*x4 + x18*x6 + x2*x31 + x24;
    double x55 = 32200.0*n4 + x54;
    double x56 = x53 + x55;
    double x57 = x34*(x0 + x52) + x56;
    double x58 = pow(x11, -3);
    double x59 = 6*x58;
    double x60 = x16*x40;
    double x61 = x18*x40;
    double x62 = x60 + x61;
    double x63 = 2.0*x42;
    double x64 = 2*x40;
    double x65 = -x64;
    double x66 = 2*x58;
    double x67 = x10*x66;
    double x68 = x65 + x67;
    double x69 = x33*x39;
    double x70 = x68*x69;
    double x71 = pow(x10, -2);
    double x72 = x41*x71;
    double x73 = x33*x72;
    double x74 = 2.0*x40;
    double x75 = n2*x74;
    double x76 = x43 + x75;
    double x77 = x11*x63 + x11*x70 - x11*x73 + x76;
    double x78 = 2.0*x48;
    double x79 = x20*x66;
    double x80 = x65 + x79;
    double x81 = x45*x46;
    double x82 = x80*x81;
    double x83 = pow(x20, -2);
    double x84 = x47*x83;
    double x85 = x45*x84;
    double x86 = x11*x78 + x11*x82 - x11*x85 + x49;
    double x87 = x62 + x77 + x86;
    double x88 = x23*x87;
    double x89 = 16.628925236306479*T;
    double x90 = 2.0*x0 + x51*x89;
    double x91 = x40*(x34*x88 + x90);
    double x92 = 24.943387854459719*T;
    double x93 = x87*x92;
    double x94 = 3.0*x11;
    double x95 = -x20*x29;
    double x96 = x11*x81;
    double x97 = x11*x45;
    double x98 = x83*x97;
    double x99 = x46*x80*x94 + 3.0*x48 - 2*x80*x98 + 2*x82 - x84*x94 - 2*x85 + x96*(x59 + x95) + 2*x47*x97/((x20)*(x20)*(x20));
    double x100 = 4.0*x58;
    double x101 = n2*x100;
    double x102 = -x101;
    double x103 = 2.0*x58;
    double x104 = n3*x103;
    double x105 = -x104;
    double x106 = n4*x103;
    double x107 = -x106;
    double x108 = x105 + x107;
    double x109 = x102 + x108;
    double x110 = -x10*x29;
    double x111 = x11*x69;
    double x112 = x11*x33;
    double x113 = x112*x71;
    double x114 = x111*(x110 + x59) - 2*x113*x68 + x39*x68*x94 + 3.0*x42 + 2*x70 - x72*x94 - 2*x73 + 2*x112*x41/((x10)*(x10)*(x10));
    double x115 = x109 + x114;
    double x116 = x115 + x99;
    double x117 = x23*x34;
    double x118 = T >= 5.0;
    double x119 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));
    double x120 = ((x119)*(x119)*(x119));
    double x121 = (80.2881*T - 401.44049999999999)*(x119 - 1);
    double x122 = 133.8135*x120 + x121 - 133.8135;
    double x123 = -x29*(0.33333333333333331*x11*(n2*x122 + 3*x1 + x22*x92 + 3*x3 + 3*x5 + 3*x7) + x27);
    double x124 = 0.33333333333333331*n2;
    double x125 = 0.33333333333333331*n1 + 0.33333333333333331*n3 + 0.33333333333333331*n4 + x124;
    double x126 = x122*x124;
    double x127 = x126 + x55;
    double x128 = x125*(3*x0 + x51*x92) + x127;
    double x129 = x40*(x125*x93 + x90);
    double x130 = x125*x92;
    double x131 = x108 + x74;
    double x132 = 2.0*x11;
    double x133 = -x40;
    double x134 = x133 + x67;
    double x135 = x134*x39;
    double x136 = x134*x69;
    double x137 = 4*x58;
    double x138 = x111*(x110 + x137) - x113*x134 + x136 + x70 - x73;
    double x139 = x132*x135 + x138 + x63;
    double x140 = x133 + x79;
    double x141 = x140*x46;
    double x142 = x140*x81;
    double x143 = -x140*x98 + x142 + x82 - x85 + x96*(x137 + x95);
    double x144 = x132*x141 + x143 + x78;
    double x145 = x102 + x131 + x139 + x144;
    double x146 = x11*x136 + x76;
    double x147 = x11*x142 + x49;
    double x148 = -4.0*x12 + x146 + x147 + x62;
    double x149 = x148*x89;
    double x150 = x149 + x88;
    double x151 = -x12*x33;
    double x152 = -x12*x45;
    double x153 = -2.0*n2*x40 + 2.0*x12;
    double x154 = x11*x153;
    double x155 = x14 + x151 + x152 + x154 + x37;
    double x156 = x155*x23;
    double x157 = x156 - x8;
    double x158 = x157 + 89.209000000000003;
    double x159 = x34*(x158 + x2) + x56;
    double x160 = x159*x66;
    double x161 = x148*x23;
    double x162 = 1.0*x0 + x52;
    double x163 = 1.0*x2;
    double x164 = x158 + x163;
    double x165 = x161*x34 + x162 + x164;
    double x166 = -x165*x64 + x30;
    double x167 = x137*x57 - x91;
    double x168 = x125*(x122 + x155*x92 + 3*x2) + x127;
    double x169 = x168*x66;
    double x170 = 44.604500000000002*x120 + 0.33333333333333331*x121 + x156;
    double x171 = x163 + x170 - 44.604500000000002;
    double x172 = x130*x148 + x162 + x171;
    double x173 = x123 - x172*x64;
    double x174 = x128*x137 - x129;
    double x175 = 1.0*x40;
    double x176 = x115 + x144 + x175;
    double x177 = 2.0*x12;
    double x178 = -x177 + x62;
    double x179 = x147 + x178 + x77;
    double x180 = x179*x89;
    double x181 = x180 + x88;
    double x182 = x179*x23;
    double x183 = -n3*x40 + x12;
    double x184 = x183*x25;
    double x185 = 1.0*x15 + x152 + x184 + x36 + x44;
    double x186 = x185*x23;
    double x187 = x186 + 1.0*x4;
    double x188 = x162 + x187;
    double x189 = x182*x34 + x188;
    double x190 = -x189*x64;
    double x191 = 48000.0*n4 + x54;
    double x192 = x191 + x34*(x186 + x4) + x53;
    double x193 = x192*x66;
    double x194 = x167 + x30;
    double x195 = x130*x179 + x188;
    double x196 = -x195*x64;
    double x197 = x125*(x185*x92 + 3*x4) + x126 + x191;
    double x198 = x197*x66;
    double x199 = x123 + x174;
    double x200 = x109 + x139;
    double x201 = x175 + x200 + x99;
    double x202 = x146 + x178 + x86;
    double x203 = x202*x89;
    double x204 = x203 + x88;
    double x205 = x202*x23;
    double x206 = -n4*x40 + x12;
    double x207 = x206*x25;
    double x208 = x151 + 1.0*x17 + x207 + x35 + x38 + x50;
    double x209 = x208*x23;
    double x210 = x209 + 1.0*x6;
    double x211 = x162 + x210 + 32200.0;
    double x212 = x205*x34 + x211;
    double x213 = -x212*x64;
    double x214 = 32200.0*n1 + 32200.0*n2 + 48000.0*n3 + x54;
    double x215 = x214 + x34*(x209 + x6) + x53;
    double x216 = x215*x66;
    double x217 = x130*x202 + x211;
    double x218 = -x217*x64;
    double x219 = x125*(x208*x92 + 3*x6) + x126 + x214;
    double x220 = x219*x66;
    double x221 = x111*(x110 + x66) + 2*x136;
    double x222 = x109 + 2*x142 + x96*(x66 + x95);
    double x223 = x221 + x222 + 6.0*x40;
    double x224 = 4.0*x40;
    double x225 = -x224;
    double x226 = 1.0/n2;
    double x227 = x33*x40;
    double x228 = x40*x45;
    double x229 = x227 + x228 - x75;
    double x230 = x11*(x101 + x225) + x154*x226 + x177 + x229 + x62;
    double x231 = x23*x230;
    double x232 = x149 + x231;
    double x233 = x57*x66;
    double x234 = x155*x89 + 2.0*x2;
    double x235 = x40*(-53.525399999999998*T + x231*x34 + x234 + 178.41800000000001);
    double x236 = x137*x159 - x235;
    double x237 = x128*x66;
    double x238 = x230*x92;
    double x239 = x40*(89.209000000000003*x120 + 0.66666666666666663*x121 + x125*x238 + x234 - 89.209000000000003);
    double x240 = x137*x168 - x239;
    double x241 = 5.0*x40;
    double x242 = x135*x25 + x138 + x222 + x241 + 1.0*x42;
    double x243 = -x74;
    double x244 = x11*(x101 + x243) + x178 + x229;
    double x245 = x23*x244;
    double x246 = x161 + x245;
    double x247 = x182 + x246;
    double x248 = x245*x34;
    double x249 = x164 + x187 + x248;
    double x250 = -x249*x40;
    double x251 = x233 + x30;
    double x252 = x160 - x165*x40 + x251;
    double x253 = -x189*x40 + x193;
    double x254 = x130*x244;
    double x255 = x171 + x187 + x254;
    double x256 = -x255*x40;
    double x257 = x123 + x237;
    double x258 = x169 - x172*x40 + x257;
    double x259 = -x195*x40 + x198;
    double x260 = x109 + x221;
    double x261 = x141*x25 + x143 + 1.0*x48;
    double x262 = x241 + x260 + x261;
    double x263 = x205 + x246;
    double x264 = x163 + x210;
    double x265 = x157 + x248 + x264 + 32289.208999999999;
    double x266 = -x265*x40;
    double x267 = -x212*x40 + x216;
    double x268 = x170 + x254 + x264 + 32155.395499999999;
    double x269 = -x268*x40;
    double x270 = -x217*x40 + x220;
    double x271 = 3.0*x40;
    double x272 = x114 + x222 + x271;
    double x273 = 1.0*x12;
    double x274 = 1.0/n3;
    double x275 = x228 - x60 + x61;
    double x276 = x11*(x104 + x243) + x184*x274 + x273 + x275 + x77;
    double x277 = x23*x276;
    double x278 = x180 + x277;
    double x279 = x185*x89 + 2.0*x4;
    double x280 = x40*(x277*x34 + x279);
    double x281 = x137*x192 - x280;
    double x282 = x276*x92;
    double x283 = x40*(x125*x282 + x279);
    double x284 = x137*x197 - x283;
    double x285 = x200 + x261 + x271;
    double x286 = -x175;
    double x287 = x11*(x104 + x286) - 3.0*x12 + x146 + x275;
    double x288 = x23*x287;
    double x289 = x182 + x205 + x288;
    double x290 = x187 + x210 + 48000.0;
    double x291 = x288*x34 + x290;
    double x292 = -x291*x40;
    double x293 = x130*x287 + x290;
    double x294 = -x293*x40;
    double x295 = x260 + x271 + x99;
    double x296 = 1.0/n4;
    double x297 = x11*(x106 + x243) + x207*x296 + x227 + x273 + x60 - x61 + x75 + x86;
    double x298 = x23*x297;
    double x299 = x203 + x298;
    double x300 = x208*x89 + 2.0*x6;
    double x301 = x40*(x298*x34 + x300);
    double x302 = x137*x215 - x301;
    double x303 = x297*x92;
    double x304 = x40*(x125*x303 + x300);
    double x305 = x137*x219 - x304;
    double x306 = -12.0*n2*x28;
    double x307 = n2*x66;
    double x308 = x132*x226;
    double x309 = -x33*x66;
    double x310 = -x45*x66;
    double x311 = 8.0*x58;
    double x312 = n2*x311 + x309 + x310;
    double x313 = x108 + x153*x226 + x312;
    double x314 = x11*(x306 + 12.0*x58) + x308*(x307 + x65) + x313 - 8.0*x40 - x154/((n2)*(n2));
    double x315 = -x249*x64 + x30;
    double x316 = x11*(x306 + x311) + x225 + x308*(x133 + x307) + x313;
    double x317 = x244*x89;
    double x318 = x231 + x317;
    double x319 = x12*(x117*x316 + x318) + x236;
    double x320 = x123 - x255*x64;
    double x321 = x12*(x130*x316 + x318) + x240;
    double x322 = -x265*x64 + x30;
    double x323 = x123 - x268*x64;
    double x324 = x11*(x100 + x306) + x131 + x312;
    double x325 = x117*x324;
    double x326 = x277 + x317;
    double x327 = x130*x324;
    double x328 = x288 + x317;
    double x329 = x298 + x317;
    double x330 = 6.0*x58;
    double x331 = 6.0*x28;
    double x332 = -n3*x331;
    double x333 = n3*x66;
    double x334 = x25*x274;
    double x335 = n3*x100 + x102 + x107 + x310;
    double x336 = 1.0*x183*x274 + x335;
    double x337 = x11*(x330 + x332) + x114 + x225 + x334*(x333 + x65) + x336 - x184/((n3)*(n3));
    double x338 = x11*(x100 + x332) + x139 + x286 + x334*(x133 + x333) + x336;
    double x339 = x287*x89;
    double x340 = x277 + x339;
    double x341 = -x291*x64 + x30;
    double x342 = x123 - x293*x64;
    double x343 = x11*(x103 + x332) + x221 + x224 + x335;
    double x344 = x298 + x339;
    double x345 = n4*x100 + x102 + x105 + x11*(-n4*x331 + x330) + 1.0*x206*x296 + x225 + x25*x296*(n4*x66 + x65) + x309 + x99 - x207/((n4)*(n4));

if (x118) {
   result[0] = x12*(x116*x117 + x93) + x30 + x57*x59 - 3*x91;
}
else {
   result[0] = x12*(x116*x130 + x93) + x123 + x128*x59 - 3*x129;
}
if (x118) {
   result[1] = x12*(x117*x145 + x150) + x160 + x166 + x167;
}
else {
   result[1] = x12*(x130*x145 + x150) + x169 + x173 + x174;
}
if (x118) {
   result[2] = x12*(x117*x176 + x181) + x190 + x193 + x194;
}
else {
   result[2] = x12*(x130*x176 + x181) + x196 + x198 + x199;
}
if (x118) {
   result[3] = x12*(x117*x201 + x204) + x194 + x213 + x216;
}
else {
   result[3] = x12*(x130*x201 + x204) + x199 + x218 + x220;
}
if (x118) {
   result[4] = x12*(x117*x223 + x232) + x166 + x233 + x236;
}
else {
   result[4] = x12*(x130*x223 + x232) + x173 + x237 + x240;
}
if (x118) {
   result[5] = x12*(x117*x242 + x247) + x250 + x252 + x253;
}
else {
   result[5] = x12*(x130*x242 + x247) + x256 + x258 + x259;
}
if (x118) {
   result[6] = x12*(x117*x262 + x263) + x252 + x266 + x267;
}
else {
   result[6] = x12*(x130*x262 + x263) + x258 + x269 + x270;
}
if (x118) {
   result[7] = x12*(x117*x272 + x278) + x190 + x251 + x281;
}
else {
   result[7] = x12*(x130*x272 + x278) + x196 + x257 + x284;
}
if (x118) {
   result[8] = x12*(x117*x285 + x289) + x251 + x253 + x267 + x292;
}
else {
   result[8] = x12*(x130*x285 + x289) + x257 + x259 + x270 + x294;
}
if (x118) {
   result[9] = x12*(x117*x295 + x299) + x213 + x251 + x302;
}
else {
   result[9] = x12*(x130*x295 + x299) + x218 + x257 + x305;
}
if (x118) {
   result[10] = x12*(x117*x314 + x238) + x159*x59 - 3*x235 + x30;
}
else {
   result[10] = x12*(x130*x314 + x238) + x123 + x168*x59 - 3*x239;
}
if (x118) {
   result[11] = x193 + x315 + x319;
}
else {
   result[11] = x198 + x320 + x321;
}
if (x118) {
   result[12] = x216 + x319 + x322;
}
else {
   result[12] = x220 + x321 + x323;
}
if (x118) {
   result[13] = x12*(x325 + x326) + x160 + x281 + x315;
}
else {
   result[13] = x12*(x326 + x327) + x169 + x284 + x320;
}
if (x118) {
   result[14] = x12*(x325 + x328) + x160 + x193 + x216 + x250 + x266 + x292 + x30;
}
else {
   result[14] = x12*(x327 + x328) + x123 + x169 + x198 + x220 + x256 + x269 + x294;
}
if (x118) {
   result[15] = x12*(x325 + x329) + x160 + x302 + x322;
}
else {
   result[15] = x12*(x327 + x329) + x169 + x305 + x323;
}
if (x118) {
   result[16] = x12*(x117*x337 + x282) + x192*x59 - 3*x280 + x30;
}
else {
   result[16] = x12*(x130*x337 + x282) + x123 + x197*x59 - 3*x283;
}
if (x118) {
   result[17] = x12*(x117*x338 + x340) + x216 + x281 + x341;
}
else {
   result[17] = x12*(x130*x338 + x340) + x220 + x284 + x342;
}
if (x118) {
   result[18] = x12*(x117*x343 + x344) + x193 + x302 + x341;
}
else {
   result[18] = x12*(x130*x343 + x344) + x198 + x305 + x342;
}
if (x118) {
   result[19] = x12*(x117*x345 + x303) + x215*x59 + x30 - 3*x301;
}
else {
   result[19] = x12*(x130*x345 + x303) + x123 + x219*x59 - 3*x304;
}
}
        
static double coder_dgdt(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = n1 + n3;
    double x1 = 1.0/(n2 + n4 + x0);
    double x2 = n1*(*endmember[0].dmu0dT)(T, P);
    double x3 = n2*(*endmember[1].dmu0dT)(T, P);
    double x4 = n3*(*endmember[2].dmu0dT)(T, P);
    double x5 = n4*(*endmember[3].dmu0dT)(T, P);
    double x6 = n2*log(n2*x1);
    double x7 = n3*log(n3*x1);
    double x8 = n4*log(n4*x1);
    double x9 = x0*log(x0*x1);
    double x10 = n1 + n4;
    double x11 = x10*log(x1*x10);
    double x12 = sqrt(1 - 0.19999999999999998*T);
    double x13 = 1.0000000000000002*x12;
    double x14 = fmin(4, x13);
    double x15 = (4 - x13 >= 0. ? 1. : 0.)/x12;

if (T >= 5.0) {
   result = x1*(1.0*n1 + 1.0*n2 + 1.0*n3 + 1.0*n4)*(-26.762699999999999*n2 + 8.3144626181532395*x11 + x2 + x3 + x4 + x5 + 16.628925236306479*x6 + 8.3144626181532395*x7 + 8.3144626181532395*x8 + 8.3144626181532395*x9);
}
else {
   result = x1*(0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4)*(n2*(-40.144050000000007*((x14)*(x14))*x15 + 80.2881*x14 - 0.10000000000000002*x15*(80.2881*T - 401.44049999999999) - 80.2881) + 24.943387854459719*x11 + 3*x2 + 3*x3 + 3*x4 + 3*x5 + 49.886775708919437*x6 + 24.943387854459719*x7 + 24.943387854459719*x8 + 24.943387854459719*x9);
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = n1 + n3;
    double x2 = n2 + n4 + x1;
    double x3 = 1.0/x2;
    double x4 = n3*x3;
    double x5 = -8.3144626181532395*x4;
    double x6 = n4*x3;
    double x7 = -8.3144626181532395*x6;
    double x8 = x5 + x7;
    double x9 = log(x1*x3);
    double x10 = 8.3144626181532395*x9;
    double x11 = n2*x3;
    double x12 = -16.628925236306479*x11;
    double x13 = 8.3144626181532395*n1;
    double x14 = 8.3144626181532395*n3;
    double x15 = x13 + x14;
    double x16 = pow(x2, -2);
    double x17 = x2*(-x1*x16 + x3)/x1;
    double x18 = x10 + x12 + x15*x17;
    double x19 = n1 + n4;
    double x20 = log(x19*x3);
    double x21 = 8.3144626181532395*x20;
    double x22 = 8.3144626181532395*n4;
    double x23 = x13 + x22;
    double x24 = x2*(-x16*x19 + x3)/x19;
    double x25 = x21 + x23*x24;
    double x26 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 1.0*n4;
    double x27 = x26*x3;
    double x28 = n1*x0;
    double x29 = (*endmember[1].dmu0dT)(T, P);
    double x30 = n2*x29;
    double x31 = (*endmember[2].dmu0dT)(T, P);
    double x32 = n3*x31;
    double x33 = (*endmember[3].dmu0dT)(T, P);
    double x34 = n4*x33;
    double x35 = log(x11);
    double x36 = 16.628925236306479*x35;
    double x37 = log(x4);
    double x38 = log(x6);
    double x39 = n2*x36 - 26.762699999999999*n2 + x1*x10 + x14*x37 + x19*x21 + x22*x38 + x28 + x30 + x32 + x34;
    double x40 = -x16*x26*x39 + 1.0*x3*x39;
    double x41 = T >= 5.0;
    double x42 = -24.943387854459719*x4;
    double x43 = -24.943387854459719*x6;
    double x44 = x42 + x43;
    double x45 = 24.943387854459719*x9;
    double x46 = -49.886775708919437*x11;
    double x47 = 24.943387854459719*n1;
    double x48 = 24.943387854459719*n3;
    double x49 = x47 + x48;
    double x50 = x17*x49 + x45 + x46;
    double x51 = 24.943387854459719*x20;
    double x52 = 24.943387854459719*n4;
    double x53 = x47 + x52;
    double x54 = x24*x53 + x51;
    double x55 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4;
    double x56 = x3*x55;
    double x57 = 49.886775708919437*x35;
    double x58 = sqrt(1 - 0.19999999999999998*T);
    double x59 = 1.0000000000000002*x58;
    double x60 = fmin(4, x59);
    double x61 = (4 - x59 >= 0. ? 1. : 0.)/x58;
    double x62 = -40.144050000000007*((x60)*(x60))*x61 + 80.2881*x60 - 0.10000000000000002*x61*(80.2881*T - 401.44049999999999) - 80.2881;
    double x63 = n2*x57 + n2*x62 + x1*x45 + x19*x51 + 3*x28 + 3*x30 + 3*x32 + 3*x34 + x37*x48 + x38*x52;
    double x64 = -x16*x55*x63 + 0.33333333333333331*x3*x63;
    double x65 = -x15*x3;
    double x66 = -x23*x3;
    double x67 = x2*(-n2*x16 + x3);
    double x68 = -x3*x53;
    double x69 = -x3*x49;
    double x70 = x2*(-n3*x16 + x3);
    double x71 = x2*(-n4*x16 + x3);

if (x41) {
   result[0] = x27*(x0 + x18 + x25 + x8) + x40;
}
else {
   result[0] = x56*(3*x0 + x44 + x50 + x54) + x64;
}
if (x41) {
   result[1] = x27*(x29 + x36 + x65 + x66 + 16.628925236306479*x67 + x8 - 26.762699999999999) + x40;
}
else {
   result[1] = x56*(3*x29 + x44 + x57 + x62 + 49.886775708919437*x67 + x68 + x69) + x64;
}
if (x41) {
   result[2] = x27*(x18 + x31 + 8.3144626181532395*x37 + x66 + x7 + 8.3144626181532395*x70) + x40;
}
else {
   result[2] = x56*(3*x31 + 24.943387854459719*x37 + x43 + x50 + x68 + 24.943387854459719*x70) + x64;
}
if (x41) {
   result[3] = x27*(x12 + x25 + x33 + 8.3144626181532395*x38 + x5 + x65 + 8.3144626181532395*x71) + x40;
}
else {
   result[3] = x56*(3*x33 + 24.943387854459719*x38 + x42 + x46 + x54 + x69 + 24.943387854459719*x71) + x64;
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = n1 + n3;
    double x1 = n2 + n4 + x0;
    double x2 = 1.0/x1;
    double x3 = (*endmember[0].dmu0dT)(T, P);
    double x4 = 8.3144626181532395*n3;
    double x5 = -x2*x4;
    double x6 = 8.3144626181532395*n4;
    double x7 = -x2*x6;
    double x8 = x5 + x7;
    double x9 = log(x0*x2);
    double x10 = 8.3144626181532395*x9;
    double x11 = n2*x2;
    double x12 = -16.628925236306479*x11;
    double x13 = 8.3144626181532395*n1;
    double x14 = x13 + x4;
    double x15 = 1.0/x0;
    double x16 = pow(x1, -2);
    double x17 = -x0*x16 + x2;
    double x18 = x15*x17;
    double x19 = x14*x18;
    double x20 = x1*x19 + x10 + x12;
    double x21 = n1 + n4;
    double x22 = log(x2*x21);
    double x23 = 8.3144626181532395*x22;
    double x24 = x13 + x6;
    double x25 = 1.0/x21;
    double x26 = -x16*x21 + x2;
    double x27 = x25*x26;
    double x28 = x24*x27;
    double x29 = x1*x28 + x23;
    double x30 = x20 + x29 + x3 + x8;
    double x31 = x2*x30;
    double x32 = x16*x4;
    double x33 = x16*x6;
    double x34 = x32 + x33;
    double x35 = 16.628925236306479*x1;
    double x36 = x1*x14;
    double x37 = 2*x16;
    double x38 = -x37;
    double x39 = pow(x1, -3);
    double x40 = 2*x39;
    double x41 = x0*x40;
    double x42 = x15*(x38 + x41);
    double x43 = x17/((x0)*(x0));
    double x44 = n2*x16;
    double x45 = 16.628925236306479*x44;
    double x46 = x19 + x45;
    double x47 = x18*x35 + x36*x42 - x36*x43 + x46;
    double x48 = x1*x24;
    double x49 = x21*x40;
    double x50 = x25*(x38 + x49);
    double x51 = x26/((x21)*(x21));
    double x52 = x27*x35 + x28 + x48*x50 - x48*x51;
    double x53 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 1.0*n4;
    double x54 = x2*x53;
    double x55 = x37*x53;
    double x56 = n1*x3;
    double x57 = (*endmember[1].dmu0dT)(T, P);
    double x58 = n2*x57;
    double x59 = (*endmember[2].dmu0dT)(T, P);
    double x60 = n3*x59;
    double x61 = (*endmember[3].dmu0dT)(T, P);
    double x62 = n4*x61;
    double x63 = log(x11);
    double x64 = 16.628925236306479*x63;
    double x65 = n3*x2;
    double x66 = log(x65);
    double x67 = n4*x2;
    double x68 = log(x67);
    double x69 = n2*x64 - 26.762699999999999*n2 + x0*x10 + x21*x23 + x4*x66 + x56 + x58 + x6*x68 + x60 + x62;
    double x70 = -2.0*x16*x69 + x40*x53*x69;
    double x71 = T >= 5.0;
    double x72 = -24.943387854459719*x65;
    double x73 = -24.943387854459719*x67;
    double x74 = x72 + x73;
    double x75 = 24.943387854459719*x9;
    double x76 = -49.886775708919437*x11;
    double x77 = 24.943387854459719*n1;
    double x78 = 24.943387854459719*n3;
    double x79 = x77 + x78;
    double x80 = x18*x79;
    double x81 = x1*x80 + x75 + x76;
    double x82 = 24.943387854459719*x22;
    double x83 = 24.943387854459719*n4;
    double x84 = x77 + x83;
    double x85 = x27*x84;
    double x86 = x1*x85 + x82;
    double x87 = 3*x3 + x74 + x81 + x86;
    double x88 = x2*x87;
    double x89 = 49.886775708919437*x1;
    double x90 = x1*x79;
    double x91 = 49.886775708919437*x44;
    double x92 = x80 + x91;
    double x93 = x18*x89 + x42*x90 - x43*x90 + x92;
    double x94 = x16*x78;
    double x95 = x16*x83;
    double x96 = x94 + x95;
    double x97 = x85 + x96;
    double x98 = x1*x84;
    double x99 = x27*x89 + x50*x98 - x51*x98;
    double x100 = x97 + x99;
    double x101 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4;
    double x102 = x101*x2;
    double x103 = x101*x37;
    double x104 = 49.886775708919437*x63;
    double x105 = sqrt(1 - 0.19999999999999998*T);
    double x106 = 1.0000000000000002*x105;
    double x107 = fmin(4, x106);
    double x108 = (4 - x106 >= 0. ? 1. : 0.)/x105;
    double x109 = -40.144050000000007*((x107)*(x107))*x108 + 80.2881*x107 - 0.10000000000000002*x108*(80.2881*T - 401.44049999999999) - 80.2881;
    double x110 = n2*x104 + n2*x109 + x0*x75 + x21*x82 + 3*x56 + 3*x58 + 3*x60 + 3*x62 + x66*x78 + x68*x83;
    double x111 = x101*x110*x40 - 0.66666666666666663*x110*x16;
    double x112 = -x16;
    double x113 = x15*(x112 + x41);
    double x114 = x113*x36 + x46;
    double x115 = x25*(x112 + x49);
    double x116 = x115*x48 + x28;
    double x117 = x16*x53;
    double x118 = -x117*x30 + 1.0*x31 + x70;
    double x119 = -x14*x2;
    double x120 = -x2*x24;
    double x121 = x1*(x2 - x44);
    double x122 = 16.628925236306479*x121;
    double x123 = x119 + x120 + x122 + x57 + x64 + x8 - 26.762699999999999;
    double x124 = 1.0*x2;
    double x125 = -x117*x123 + x123*x124;
    double x126 = x113*x90 + x92;
    double x127 = x115*x98 + x97;
    double x128 = x101*x16;
    double x129 = x111 - x128*x87 + 0.33333333333333331*x88;
    double x130 = -x2*x84;
    double x131 = -x2*x79;
    double x132 = 49.886775708919437*x121;
    double x133 = x104 + x109 + x130 + x131 + x132 + 3*x57 + x74;
    double x134 = 0.33333333333333331*x2;
    double x135 = -x128*x133 + x133*x134;
    double x136 = 16.628925236306479*x2;
    double x137 = -x136 + x34;
    double x138 = x1*(-n3*x16 + x2);
    double x139 = 8.3144626181532395*x138;
    double x140 = x120 + x139 + x20 + x59 + 8.3144626181532395*x66 + x7;
    double x141 = -x117*x140 + x124*x140;
    double x142 = 49.886775708919437*x2;
    double x143 = -x142;
    double x144 = 24.943387854459719*x138;
    double x145 = x130 + x144 + 3*x59 + 24.943387854459719*x66 + x73 + x81;
    double x146 = -x128*x145 + x134*x145;
    double x147 = x1*(-n4*x16 + x2);
    double x148 = 8.3144626181532395*x147;
    double x149 = x119 + x12 + x148 + x29 + x5 + x61 + 8.3144626181532395*x68;
    double x150 = -x117*x149 + x124*x149;
    double x151 = 24.943387854459719*x147;
    double x152 = x131 + x151 + 3*x61 + 24.943387854459719*x68 + x72 + x76 + x86;
    double x153 = -x128*x152 + x134*x152;
    double x154 = 2.0*x2;
    double x155 = n2*x39;
    double x156 = 33.257850472612958*x155;
    double x157 = 1.0/n2;
    double x158 = x14*x16;
    double x159 = x16*x24;
    double x160 = x158 + x159 - x45;
    double x161 = 0.66666666666666663*x2;
    double x162 = 99.773551417838874*x155;
    double x163 = x16*x79;
    double x164 = x16*x84;
    double x165 = x163 + x164 - x91 + x96;
    double x166 = x141 + x70;
    double x167 = -16.628925236306479*x16;
    double x168 = x125 + x54*(x1*(x156 + x167) + x137 + x160);
    double x169 = x111 + x146;
    double x170 = -49.886775708919437*x16;
    double x171 = x102*(x1*(x162 + x170) + x165 - 49.886775708919444*x2) + x135;
    double x172 = 8.3144626181532395*x2;
    double x173 = n3*x39;
    double x174 = 16.628925236306479*x173;
    double x175 = 1.0/n3;
    double x176 = x159 - x32 + x33;
    double x177 = 24.943387854459719*x2;
    double x178 = 49.886775708919437*x173;
    double x179 = x164 - x94 + x95;
    double x180 = n4*x39;
    double x181 = 1.0/n4;

if (x71) {
   result[0] = -x30*x55 + 2.0*x31 + x54*(x34 + x47 + x52) + x70;
}
else {
   result[0] = x102*(x100 + x93) - x103*x87 + x111 + 0.66666666666666663*x88;
}
if (x71) {
   result[1] = x118 + x125 + x54*(x114 + x116 - 33.257850472612958*x2 + x34);
}
else {
   result[1] = x102*(x126 + x127 - 99.773551417838874*x2) + x129 + x135;
}
if (x71) {
   result[2] = x118 + x141 + x54*(x116 + x137 + x47);
}
else {
   result[2] = x102*(x127 + x143 + x93) + x129 + x146;
}
if (x71) {
   result[3] = x118 + x150 + x54*(x114 + x137 + x52);
}
else {
   result[3] = x102*(x100 + x126 + x143) + x129 + x153;
}
if (x71) {
   result[4] = x123*x154 - x123*x55 + x54*(x1*(x156 - 33.257850472612958*x16) + x122*x157 + x136 + x160 + x34) + x70;
}
else {
   result[4] = x102*(x1*(-99.773551417838874*x16 + x162) + x132*x157 + x142 + x165) - x103*x133 + x111 + x133*x161;
}
if (x71) {
   result[5] = x166 + x168;
}
else {
   result[5] = x169 + x171;
}
if (x71) {
   result[6] = x150 + x168 + x70;
}
else {
   result[6] = x111 + x153 + x171;
}
if (x71) {
   result[7] = x140*x154 - x140*x55 + x54*(x1*(x167 + x174) + x139*x175 + x172 + x176 + x47) + x70;
}
else {
   result[7] = x102*(x1*(x170 + x178) + x144*x175 + x177 + x179 + x93) - x103*x145 + x111 + x145*x161;
}
if (x71) {
   result[8] = x150 + x166 + x54*(x1*(-8.3144626181532395*x16 + x174) + x114 + x176 - x177);
}
else {
   result[8] = x102*(x1*(-24.943387854459719*x16 + x178) + x126 + x179 - 74.830163563379159*x2) + x153 + x169;
}
if (x71) {
   result[9] = x149*x154 - x149*x55 + x54*(x1*(x167 + 16.628925236306479*x180) + x148*x181 + x158 + x172 + x32 - x33 + x45 + x52) + x70;
}
else {
   result[9] = x102*(x1*(x170 + 49.886775708919437*x180) + x151*x181 + x163 + x177 + x85 + x91 + x94 - x95 + x99) - x103*x152 + x111 + x152*x161;
}
}
        
static void coder_d4gdn3dt(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = n1 + n3;
    double x1 = n2 + n4 + x0;
    double x2 = 1.0/x1;
    double x3 = pow(x1, -2);
    double x4 = 8.3144626181532395*n3;
    double x5 = x3*x4;
    double x6 = 8.3144626181532395*n4;
    double x7 = x3*x6;
    double x8 = x5 + x7;
    double x9 = 1.0/x0;
    double x10 = -x0*x3 + x2;
    double x11 = x10*x9;
    double x12 = 16.628925236306479*x11;
    double x13 = 2*x3;
    double x14 = -x13;
    double x15 = pow(x1, -3);
    double x16 = 2*x15;
    double x17 = x0*x16;
    double x18 = x14 + x17;
    double x19 = 8.3144626181532395*n1;
    double x20 = x19 + x4;
    double x21 = x20*x9;
    double x22 = x18*x21;
    double x23 = pow(x0, -2);
    double x24 = x10*x23;
    double x25 = x20*x24;
    double x26 = n2*x3;
    double x27 = 16.628925236306479*x26;
    double x28 = x11*x20;
    double x29 = x27 + x28;
    double x30 = x1*x12 + x1*x22 - x1*x25 + x29;
    double x31 = x19 + x6;
    double x32 = n1 + n4;
    double x33 = 1.0/x32;
    double x34 = x2 - x3*x32;
    double x35 = x33*x34;
    double x36 = x31*x35;
    double x37 = 16.628925236306479*x35;
    double x38 = x16*x32;
    double x39 = x14 + x38;
    double x40 = x31*x33;
    double x41 = x39*x40;
    double x42 = pow(x32, -2);
    double x43 = x34*x42;
    double x44 = x31*x43;
    double x45 = x1*x37 + x1*x41 - x1*x44 + x36;
    double x46 = x30 + x45 + x8;
    double x47 = x2*x46;
    double x48 = (*endmember[0].dmu0dT)(T, P);
    double x49 = -x2*x4;
    double x50 = -x2*x6;
    double x51 = x49 + x50;
    double x52 = log(x0*x2);
    double x53 = 8.3144626181532395*x52;
    double x54 = n2*x2;
    double x55 = -16.628925236306479*x54;
    double x56 = x1*x28 + x53 + x55;
    double x57 = log(x2*x32);
    double x58 = 8.3144626181532395*x57;
    double x59 = x1*x36 + x58;
    double x60 = x48 + x51 + x56 + x59;
    double x61 = x3*x60;
    double x62 = 24.943387854459719*x35;
    double x63 = 24.943387854459719*x1;
    double x64 = x33*x39;
    double x65 = 6*x15;
    double x66 = pow(x1, -4);
    double x67 = 6*x66;
    double x68 = -x32*x67;
    double x69 = x1*(x65 + x68);
    double x70 = x1*x31;
    double x71 = 2*x70;
    double x72 = x39*x42;
    double x73 = x34/((x32)*(x32)*(x32));
    double x74 = x40*x69 + 2*x41 - x43*x63 - 2*x44 + x62 + x63*x64 - x71*x72 + x71*x73;
    double x75 = 33.257850472612958*x15;
    double x76 = n2*x75;
    double x77 = -x76;
    double x78 = 16.628925236306479*x15;
    double x79 = n3*x78;
    double x80 = -x79;
    double x81 = n4*x78;
    double x82 = -x81;
    double x83 = x80 + x82;
    double x84 = x77 + x83;
    double x85 = 24.943387854459719*x11;
    double x86 = x18*x9;
    double x87 = -x0*x67;
    double x88 = x1*(x65 + x87);
    double x89 = x1*x20;
    double x90 = 2*x89;
    double x91 = x18*x23;
    double x92 = x10/((x0)*(x0)*(x0));
    double x93 = x21*x88 + 2*x22 - x24*x63 - 2*x25 + x63*x86 + x85 - x90*x91 + x90*x92;
    double x94 = x84 + x93;
    double x95 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 1.0*n4;
    double x96 = x2*x95;
    double x97 = x3*x95;
    double x98 = x46*x97;
    double x99 = x60*x95;
    double x100 = n1*x48;
    double x101 = (*endmember[1].dmu0dT)(T, P);
    double x102 = n2*x101;
    double x103 = (*endmember[2].dmu0dT)(T, P);
    double x104 = n3*x103;
    double x105 = (*endmember[3].dmu0dT)(T, P);
    double x106 = n4*x105;
    double x107 = log(x54);
    double x108 = 16.628925236306479*x107;
    double x109 = n3*x2;
    double x110 = log(x109);
    double x111 = n4*x2;
    double x112 = log(x111);
    double x113 = n2*x108 - 26.762699999999999*n2 + x0*x53 + x100 + x102 + x104 + x106 + x110*x4 + x112*x6 + x32*x58;
    double x114 = 6.0*x113*x15 - x113*x67*x95;
    double x115 = T >= 5.0;
    double x116 = 49.886775708919437*x11;
    double x117 = 24.943387854459719*n1;
    double x118 = 24.943387854459719*n3;
    double x119 = x117 + x118;
    double x120 = x119*x9;
    double x121 = x120*x18;
    double x122 = x119*x24;
    double x123 = 49.886775708919437*x26;
    double x124 = x11*x119;
    double x125 = x123 + x124;
    double x126 = x1*x116 + x1*x121 - x1*x122 + x125;
    double x127 = 24.943387854459719*n4;
    double x128 = x117 + x127;
    double x129 = x128*x35;
    double x130 = x118*x3;
    double x131 = x127*x3;
    double x132 = x130 + x131;
    double x133 = x129 + x132;
    double x134 = 49.886775708919437*x35;
    double x135 = x128*x33;
    double x136 = x135*x39;
    double x137 = x128*x43;
    double x138 = x1*x134 + x1*x136 - x1*x137;
    double x139 = x133 + x138;
    double x140 = x126 + x139;
    double x141 = x140*x2;
    double x142 = -24.943387854459719*x109;
    double x143 = -24.943387854459719*x111;
    double x144 = x142 + x143;
    double x145 = 24.943387854459719*x52;
    double x146 = -49.886775708919437*x54;
    double x147 = x1*x124 + x145 + x146;
    double x148 = 24.943387854459719*x57;
    double x149 = x1*x129 + x148;
    double x150 = x144 + x147 + x149 + 3*x48;
    double x151 = 2.0*x3;
    double x152 = 74.830163563379159*x1;
    double x153 = x1*x128;
    double x154 = 2*x153;
    double x155 = x135*x69 + 2*x136 - 2*x137 - x152*x43 + x152*x64 - x154*x72 + x154*x73 + 74.830163563379159*x35;
    double x156 = 99.773551417838874*x15;
    double x157 = n2*x156;
    double x158 = -x157;
    double x159 = 49.886775708919437*x15;
    double x160 = n3*x159;
    double x161 = -x160;
    double x162 = n4*x159;
    double x163 = -x162;
    double x164 = x161 + x163;
    double x165 = x158 + x164;
    double x166 = x1*x119;
    double x167 = 2*x166;
    double x168 = 74.830163563379159*x11 + x120*x88 + 2*x121 - 2*x122 - x152*x24 + x152*x86 - x167*x91 + x167*x92;
    double x169 = x165 + x168;
    double x170 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4;
    double x171 = x170*x2;
    double x172 = x170*x3;
    double x173 = x140*x172;
    double x174 = x150*x170;
    double x175 = 49.886775708919437*x107;
    double x176 = sqrt(1 - 0.19999999999999998*T);
    double x177 = 1.0000000000000002*x176;
    double x178 = fmin(4, x177);
    double x179 = (4 - x177 >= 0. ? 1. : 0.)/x176;
    double x180 = -40.144050000000007*((x178)*(x178))*x179 + 80.2881*x178 - 0.10000000000000002*x179*(80.2881*T - 401.44049999999999) - 80.2881;
    double x181 = n2*x175 + n2*x180 + x0*x145 + 3*x100 + 3*x102 + 3*x104 + 3*x106 + x110*x118 + x112*x127 + x148*x32;
    double x182 = 2.0*x15*x181 - x170*x181*x67;
    double x183 = 16.628925236306479*x3;
    double x184 = x183 + x83;
    double x185 = 16.628925236306479*x1;
    double x186 = -x3;
    double x187 = x17 + x186;
    double x188 = x187*x9;
    double x189 = x187*x21;
    double x190 = 4*x15;
    double x191 = x1*(x190 + x87);
    double x192 = x187*x23;
    double x193 = x189 + x191*x21 - x192*x89 + x22 - x25;
    double x194 = x12 + x185*x188 + x193;
    double x195 = x186 + x38;
    double x196 = x195*x33;
    double x197 = x195*x40;
    double x198 = x1*(x190 + x68);
    double x199 = x195*x42;
    double x200 = x197 + x198*x40 - x199*x70 + x41 - x44;
    double x201 = x185*x196 + x200 + x37;
    double x202 = x1*x189 + x29;
    double x203 = x1*x197 + x36;
    double x204 = -33.257850472612958*x2 + x202 + x203 + x8;
    double x205 = 2.0*x2;
    double x206 = x13*x95;
    double x207 = x114 + x204*x205 - x204*x206;
    double x208 = -x2*x20;
    double x209 = -x2*x31;
    double x210 = x2 - x26;
    double x211 = x1*x210;
    double x212 = 16.628925236306479*x211;
    double x213 = x101 + x108 + x208 + x209 + x212 + x51 - 26.762699999999999;
    double x214 = x16*x95;
    double x215 = -x151*x213 + x213*x214;
    double x216 = x190*x99 + 1.0*x47 - 4.0*x61 - x98;
    double x217 = 49.886775708919437*x3;
    double x218 = 49.886775708919437*x1;
    double x219 = x120*x187;
    double x220 = x120*x191 + x121 - x122 - x166*x192 + x219;
    double x221 = x116 + x188*x218 + x220;
    double x222 = x165 + x221;
    double x223 = x135*x195;
    double x224 = x135*x198 + x136 - x137 - x153*x199 + x223;
    double x225 = x134 + x196*x218 + x224;
    double x226 = x1*x219 + x125;
    double x227 = x1*x223 + x133;
    double x228 = -99.773551417838874*x2 + x226 + x227;
    double x229 = 0.66666666666666663*x2;
    double x230 = x13*x170;
    double x231 = x182 + x228*x229 - x228*x230;
    double x232 = -x128*x2;
    double x233 = -x119*x2;
    double x234 = 49.886775708919437*x211;
    double x235 = 3*x101 + x144 + x175 + x180 + x232 + x233 + x234;
    double x236 = 0.66666666666666663*x3;
    double x237 = x16*x170;
    double x238 = -x235*x236 + x235*x237;
    double x239 = 1.3333333333333333*x3;
    double x240 = 0.33333333333333331*x141 - x150*x239 - x173 + x174*x190;
    double x241 = 8.3144626181532395*x3;
    double x242 = x114 + x216;
    double x243 = 16.628925236306479*x2;
    double x244 = -x243 + x8;
    double x245 = x203 + x244 + x30;
    double x246 = x205*x245 - x206*x245;
    double x247 = -n3*x3 + x2;
    double x248 = x1*x247;
    double x249 = 8.3144626181532395*x248;
    double x250 = x103 + 8.3144626181532395*x110 + x209 + x249 + x50 + x56;
    double x251 = -x151*x250 + x214*x250;
    double x252 = 24.943387854459719*x3;
    double x253 = x182 + x240;
    double x254 = 49.886775708919437*x2;
    double x255 = -x254;
    double x256 = x126 + x227 + x255;
    double x257 = x229*x256 - x230*x256;
    double x258 = 24.943387854459719*x248;
    double x259 = 3*x103 + 24.943387854459719*x110 + x143 + x147 + x232 + x258;
    double x260 = -x236*x259 + x237*x259;
    double x261 = x194 + x84;
    double x262 = x202 + x244 + x45;
    double x263 = x205*x262 - x206*x262;
    double x264 = -n4*x3 + x2;
    double x265 = x1*x264;
    double x266 = 8.3144626181532395*x265;
    double x267 = x105 + 8.3144626181532395*x112 + x208 + x266 + x49 + x55 + x59;
    double x268 = -x151*x267 + x214*x267;
    double x269 = x139 + x226 + x255;
    double x270 = x229*x269 - x230*x269;
    double x271 = 24.943387854459719*x265;
    double x272 = 3*x105 + 24.943387854459719*x112 + x142 + x146 + x149 + x233 + x271;
    double x273 = -x236*x272 + x237*x272;
    double x274 = x1*(x16 + x87);
    double x275 = 2*x189 + x21*x274;
    double x276 = x1*(x16 + x68);
    double x277 = 2*x197 + x276*x40 + x84;
    double x278 = x16*x99 - 2.0*x61;
    double x279 = 33.257850472612958*x3;
    double x280 = -x279;
    double x281 = 1.0/n2;
    double x282 = x20*x3;
    double x283 = x3*x31;
    double x284 = -x27 + x282 + x283;
    double x285 = x1*(x280 + x76) + x212*x281 + x243 + x284 + x8;
    double x286 = 1.0*x2;
    double x287 = 4.0*x3;
    double x288 = x285*x97;
    double x289 = x190*x95;
    double x290 = -x213*x287 + x213*x289 + x285*x286 - x288;
    double x291 = x120*x274 + 2*x219;
    double x292 = x135*x276 + x165 + 2*x223;
    double x293 = -x150*x236 + x16*x174;
    double x294 = 99.773551417838874*x3;
    double x295 = -x294;
    double x296 = x119*x3;
    double x297 = x128*x3;
    double x298 = -x123 + x132 + x296 + x297;
    double x299 = x1*(x157 + x295) + x234*x281 + x254 + x298;
    double x300 = 0.33333333333333331*x2;
    double x301 = x172*x299;
    double x302 = x170*x190;
    double x303 = -x235*x239 + x235*x302 + x299*x300 - x301;
    double x304 = 41.572313090766201*x3;
    double x305 = 8.3144626181532395*x1;
    double x306 = x114 + x278;
    double x307 = x245*x286 - x245*x97 + x251 + x306;
    double x308 = -x183;
    double x309 = x1*(x308 + x76) + x244 + x284;
    double x310 = x204*x286 - x204*x97 + x215 + x286*x309 - x309*x97;
    double x311 = 124.71693927229859*x3;
    double x312 = x182 + x293;
    double x313 = -x172*x256 + x256*x300 + x260 + x312;
    double x314 = -x217;
    double x315 = x1*(x157 + x314) - 49.886775708919444*x2 + x298;
    double x316 = -x172*x228 - x172*x315 + x228*x300 + x238 + x300*x315;
    double x317 = x275 + x84;
    double x318 = x196*x305 + x200 + 8.3144626181532395*x35;
    double x319 = x262*x286 - x262*x97;
    double x320 = x165 + x291;
    double x321 = x196*x63 + x224 + x62;
    double x322 = -x172*x269 + x269*x300;
    double x323 = 8.3144626181532395*x2;
    double x324 = 1.0/n3;
    double x325 = x283 - x5 + x7;
    double x326 = x1*(x308 + x79) + x249*x324 + x30 + x323 + x325;
    double x327 = x326*x97;
    double x328 = -x250*x287 + x250*x289 + x286*x326 - x327;
    double x329 = 74.830163563379159*x3;
    double x330 = 24.943387854459719*x2;
    double x331 = -x130 + x131 + x297;
    double x332 = x1*(x160 + x314) + x126 + x258*x324 + x330 + x331;
    double x333 = x172*x332;
    double x334 = -x239*x259 + x259*x302 + x300*x332 - x333;
    double x335 = -x241;
    double x336 = x1*(x335 + x79) + x202 + x325 - x330;
    double x337 = x268 + x286*x336 - x336*x97;
    double x338 = -x252;
    double x339 = x1*(x160 + x338) - 74.830163563379159*x2 + x226 + x331;
    double x340 = -x172*x339 + x273 + x300*x339;
    double x341 = 1.0/n4;
    double x342 = x1*(x308 + x81) + x266*x341 + x27 + x282 + x323 + x45 + x5 - x7;
    double x343 = x342*x97;
    double x344 = -x267*x287 + x267*x289 + x286*x342 - x343;
    double x345 = x1*(x162 + x314) + x123 + x129 + x130 - x131 + x138 + x271*x341 + x296 + x330;
    double x346 = x172*x345;
    double x347 = -x239*x272 + x272*x302 + x300*x345 - x346;
    double x348 = 3.0*x2;
    double x349 = 6.0*x3;
    double x350 = n2*x66;
    double x351 = -99.773551417838874*x350;
    double x352 = n2*x16;
    double x353 = x281*(x14 + x352);
    double x354 = pow(n2, -2);
    double x355 = x210*x281;
    double x356 = -x16*x20;
    double x357 = -x16*x31;
    double x358 = 66.515700945225916*x15;
    double x359 = n2*x358 + x356 + x357;
    double x360 = 16.628925236306479*x355 + x359 + x83;
    double x361 = x65*x95;
    double x362 = -299.32065425351664*x350;
    double x363 = -x119*x16;
    double x364 = -x128*x16;
    double x365 = 199.54710283567775*x15;
    double x366 = n2*x365 + x164 + x363 + x364;
    double x367 = 49.886775708919437*x355 + x366;
    double x368 = x170*x65;
    double x369 = x114 + x251;
    double x370 = x205*x309 - x206*x309;
    double x371 = x369 + x370;
    double x372 = x281*(x186 + x352);
    double x373 = x290 + x96*(x1*(x351 + x358) + x185*x372 + x280 + x360);
    double x374 = x182 + x260;
    double x375 = x229*x315 - x230*x315;
    double x376 = x374 + x375;
    double x377 = x171*(x1*(x362 + x365) + x218*x372 + x295 + x367) + x303;
    double x378 = x114 + x370;
    double x379 = x182 + x375;
    double x380 = x215 + x96*(x1*(x351 + x75) + x184 + x359);
    double x381 = x378 + x380;
    double x382 = x171*(x1*(x156 + x362) + 49.886775708919444*x3 + x366) + x238;
    double x383 = x379 + x382;
    double x384 = n3*x66;
    double x385 = -49.886775708919437*x384;
    double x386 = n3*x16;
    double x387 = x324*(x14 + x386);
    double x388 = pow(n3, -2);
    double x389 = x247*x324;
    double x390 = n3*x75 + x357 + x77 + x82;
    double x391 = 8.3144626181532395*x389 + x390;
    double x392 = 149.66032712675832*x15;
    double x393 = -149.66032712675832*x384;
    double x394 = n3*x156 + x158 + x163 + x364;
    double x395 = 24.943387854459719*x389 + x394;
    double x396 = x324*(x186 + x386);
    double x397 = x205*x336 - x206*x336;
    double x398 = x229*x339 - x230*x339;
    double x399 = n4*x66;
    double x400 = x264*x341;
    double x401 = x341*(n4*x16 + x14);
    double x402 = pow(n4, -2);

if (x115) {
   result[0] = x114 + 3.0*x47 - 6.0*x61 + x65*x99 + x96*(x74 + x94) - 3*x98;
}
else {
   result[0] = 1.0*x141 - x150*x151 + x171*(x155 + x169) - 3*x173 + x174*x65 + x182;
}
if (x115) {
   result[1] = x207 + x215 + x216 + x96*(x184 + x194 + x201 + x77);
}
else {
   result[1] = x171*(x217 + x222 + x225) + x231 + x238 + x240;
}
if (x115) {
   result[2] = x242 + x246 + x251 + x96*(x201 + x241 + x94);
}
else {
   result[2] = x171*(x169 + x225 + x252) + x253 + x257 + x260;
}
if (x115) {
   result[3] = x242 + x263 + x268 + x96*(x241 + x261 + x74);
}
else {
   result[3] = x171*(x155 + x222 + x252) + x253 + x270 + x273;
}
if (x115) {
   result[4] = x207 + x278 + x290 + x96*(x217 + x275 + x277);
}
else {
   result[4] = x171*(x291 + x292 + 149.66032712675832*x3) + x231 + x293 + x303;
}
if (x115) {
   result[5] = x307 + x310 + x96*(8.3144626181532395*x11 + x188*x305 + x193 + x277 + x304);
}
else {
   result[5] = x171*(x188*x63 + x220 + x292 + x311 + x85) + x313 + x316;
}
if (x115) {
   result[6] = x268 + x306 + x310 + x319 + x96*(x304 + x317 + x318);
}
else {
   result[6] = x171*(x311 + x320 + x321) + x273 + x312 + x316 + x322;
}
if (x115) {
   result[7] = x246 + x306 + x328 + x96*(x252 + x277 + x93);
}
else {
   result[7] = x171*(x168 + x292 + x329) + x257 + x312 + x334;
}
if (x115) {
   result[8] = x307 + x319 + x337 + x96*(x252 + x261 + x318);
}
else {
   result[8] = x171*(x222 + x321 + x329) + x313 + x322 + x340;
}
if (x115) {
   result[9] = x263 + x306 + x344 + x96*(x252 + x317 + x74);
}
else {
   result[9] = x171*(x155 + x320 + x329) + x270 + x312 + x347;
}
if (x115) {
   result[10] = x114 - x213*x349 + x213*x361 + x285*x348 - 3*x288 + x96*(x1*(x156 + x351) + x185*x353 - x212*x354 - 66.515700945225916*x3 + x360);
}
else {
   result[10] = -x151*x235 + x171*(x1*(299.32065425351664*x15 + x362) + x218*x353 - x234*x354 - 199.54710283567775*x3 + x367) + x182 + x235*x368 + x286*x299 - 3*x301;
}
if (x115) {
   result[11] = x371 + x373;
}
else {
   result[11] = x376 + x377;
}
if (x115) {
   result[12] = x268 + x373 + x378;
}
else {
   result[12] = x273 + x377 + x379;
}
if (x115) {
   result[13] = x328 + x381;
}
else {
   result[13] = x334 + x383;
}
if (x115) {
   result[14] = x337 + x371 + x380;
}
else {
   result[14] = x340 + x376 + x382;
}
if (x115) {
   result[15] = x344 + x381;
}
else {
   result[15] = x347 + x383;
}
if (x115) {
   result[16] = x114 - x250*x349 + x250*x361 + x326*x348 - 3*x327 + x96*(x1*(x159 + x385) - x249*x388 + x280 + x305*x387 + x391 + x93);
}
else {
   result[16] = -x151*x259 + x171*(x1*(x392 + x393) + x168 - x258*x388 + x295 + x387*x63 + x395) + x182 + x259*x368 + x286*x332 - 3*x333;
}
if (x115) {
   result[17] = x114 + x268 + x328 + x397 + x96*(x1*(x385 + x75) + x194 + x305*x396 + x335 + x391);
}
else {
   result[17] = x171*(x1*(x156 + x393) + x221 + x338 + x395 + x396*x63) + x182 + x273 + x334 + x398;
}
if (x115) {
   result[18] = x344 + x369 + x397 + x96*(x1*(x385 + x78) + x275 + x279 + x390);
}
else {
   result[18] = x171*(x1*(x159 + x393) + x291 + x294 + x394) + x347 + x374 + x398;
}
if (x115) {
   result[19] = x114 - x267*x349 + x267*x361 + x342*x348 - 3*x343 + x96*(n4*x75 + x1*(x159 - 49.886775708919437*x399) - x266*x402 + x280 + x305*x401 + x356 + 8.3144626181532395*x400 + x74 + x77 + x80);
}
else {
   result[19] = -x151*x272 + x171*(n4*x156 + x1*(x392 - 149.66032712675832*x399) + x155 + x158 + x161 - x271*x402 + x295 + x363 + 24.943387854459719*x400 + x401*x63) + x182 + x272*x368 + x286*x345 - 3*x346;
}
}
        
static double coder_dgdp(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = 1.0/(n1 + n2 + n3 + n4);
    double x1 = n1*(*endmember[0].dmu0dP)(T, P);
    double x2 = n2*(*endmember[1].dmu0dP)(T, P);
    double x3 = n3*(*endmember[2].dmu0dP)(T, P);
    double x4 = n4*(*endmember[3].dmu0dP)(T, P);

if (T >= 5.0) {
   result = x0*(1.0*n1 + 1.0*n2 + 1.0*n3 + 1.0*n4)*(x1 + x2 + x3 + x4);
}
else {
   result = x0*(0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4)*(3*x1 + 3*x2 + 3*x3 + 3*x4);
}
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2 + n3 + n4;
    double x2 = 1.0/x1;
    double x3 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 1.0*n4;
    double x4 = x2*x3;
    double x5 = n1*x0;
    double x6 = (*endmember[1].dmu0dP)(T, P);
    double x7 = n2*x6;
    double x8 = (*endmember[2].dmu0dP)(T, P);
    double x9 = n3*x8;
    double x10 = (*endmember[3].dmu0dP)(T, P);
    double x11 = n4*x10;
    double x12 = x11 + x5 + x7 + x9;
    double x13 = pow(x1, -2);
    double x14 = -x12*x13*x3 + 1.0*x12*x2;
    double x15 = T >= 5.0;
    double x16 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4;
    double x17 = 3*x16*x2;
    double x18 = 3*x11 + 3*x5 + 3*x7 + 3*x9;
    double x19 = -x13*x16*x18 + 0.33333333333333331*x18*x2;

if (x15) {
   result[0] = x0*x4 + x14;
}
else {
   result[0] = x0*x17 + x19;
}
if (x15) {
   result[1] = x14 + x4*x6;
}
else {
   result[1] = x17*x6 + x19;
}
if (x15) {
   result[2] = x14 + x4*x8;
}
else {
   result[2] = x17*x8 + x19;
}
if (x15) {
   result[3] = x10*x4 + x14;
}
else {
   result[3] = x10*x17 + x19;
}
}
        
static void coder_d3gdn2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2 + n3 + n4;
    double x2 = 1.0/x1;
    double x3 = x0*x2;
    double x4 = 2.0*x3;
    double x5 = pow(x1, -2);
    double x6 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 1.0*n4;
    double x7 = x5*x6;
    double x8 = x0*x7;
    double x9 = n1*x0;
    double x10 = (*endmember[1].dmu0dP)(T, P);
    double x11 = n2*x10;
    double x12 = (*endmember[2].dmu0dP)(T, P);
    double x13 = n3*x12;
    double x14 = (*endmember[3].dmu0dP)(T, P);
    double x15 = n4*x14;
    double x16 = x11 + x13 + x15 + x9;
    double x17 = 2/((x1)*(x1)*(x1));
    double x18 = x16*x17*x6 - 2.0*x16*x5;
    double x19 = T >= 5.0;
    double x20 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4;
    double x21 = x20*x5;
    double x22 = x0*x21;
    double x23 = 3*x11 + 3*x13 + 3*x15 + 3*x9;
    double x24 = x17*x20*x23 - 0.66666666666666663*x23*x5;
    double x25 = x10*x7;
    double x26 = -x25;
    double x27 = 1.0*x3;
    double x28 = 1.0*x2;
    double x29 = x10*x28;
    double x30 = x27 + x29;
    double x31 = x18 - x8;
    double x32 = 3*x21;
    double x33 = -x10*x32;
    double x34 = -3*x22 + x24;
    double x35 = x12*x7;
    double x36 = -x35;
    double x37 = x12*x28;
    double x38 = x27 + x37;
    double x39 = -x12*x32;
    double x40 = x14*x7;
    double x41 = -x40;
    double x42 = x14*x28;
    double x43 = x27 + x42;
    double x44 = -x14*x32;
    double x45 = 2.0*x2;
    double x46 = x10*x45;
    double x47 = 6*x21;
    double x48 = x29 + x37;
    double x49 = x18 + x26;
    double x50 = x24 + x33;
    double x51 = x29 + x42;
    double x52 = x12*x45;
    double x53 = x37 + x42;
    double x54 = x14*x45;

if (x19) {
   result[0] = x18 + x4 - 2*x8;
}
else {
   result[0] = -6*x22 + x24 + x4;
}
if (x19) {
   result[1] = x26 + x30 + x31;
}
else {
   result[1] = x30 + x33 + x34;
}
if (x19) {
   result[2] = x31 + x36 + x38;
}
else {
   result[2] = x34 + x38 + x39;
}
if (x19) {
   result[3] = x31 + x41 + x43;
}
else {
   result[3] = x34 + x43 + x44;
}
if (x19) {
   result[4] = x18 - 2*x25 + x46;
}
else {
   result[4] = -x10*x47 + x24 + x46;
}
if (x19) {
   result[5] = x36 + x48 + x49;
}
else {
   result[5] = x39 + x48 + x50;
}
if (x19) {
   result[6] = x41 + x49 + x51;
}
else {
   result[6] = x44 + x50 + x51;
}
if (x19) {
   result[7] = x18 - 2*x35 + x52;
}
else {
   result[7] = -x12*x47 + x24 + x52;
}
if (x19) {
   result[8] = x18 + x36 + x41 + x53;
}
else {
   result[8] = x24 + x39 + x44 + x53;
}
if (x19) {
   result[9] = x18 - 2*x40 + x54;
}
else {
   result[9] = -x14*x47 + x24 + x54;
}
}
        
static void coder_d4gdn3dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = n1 + n2 + n3 + n4;
    double x2 = pow(x1, -2);
    double x3 = x0*x2;
    double x4 = -6.0*x3;
    double x5 = 1.0*n1 + 1.0*n2 + 1.0*n3 + 1.0*n4;
    double x6 = 6*x5;
    double x7 = pow(x1, -3);
    double x8 = x0*x7;
    double x9 = n1*x0;
    double x10 = (*endmember[1].dmu0dP)(T, P);
    double x11 = n2*x10;
    double x12 = (*endmember[2].dmu0dP)(T, P);
    double x13 = n3*x12;
    double x14 = (*endmember[3].dmu0dP)(T, P);
    double x15 = n4*x14;
    double x16 = x11 + x13 + x15 + x9;
    double x17 = pow(x1, -4);
    double x18 = -x16*x17*x6 + 6.0*x16*x7;
    double x19 = T >= 5.0;
    double x20 = 0.33333333333333331*n1 + 0.33333333333333331*n2 + 0.33333333333333331*n3 + 0.33333333333333331*n4;
    double x21 = x20*x8;
    double x22 = 3*x11 + 3*x13 + 3*x15 + 3*x9;
    double x23 = 6*x20;
    double x24 = -x17*x22*x23 + 2.0*x22*x7;
    double x25 = x10*x7;
    double x26 = 2*x5;
    double x27 = x25*x26;
    double x28 = 2.0*x2;
    double x29 = -x10*x28;
    double x30 = -4.0*x3;
    double x31 = x29 + x30;
    double x32 = 4*x5;
    double x33 = x18 + x32*x8;
    double x34 = x23*x25;
    double x35 = 12*x21 + x24;
    double x36 = x12*x7;
    double x37 = x26*x36;
    double x38 = -x12*x28;
    double x39 = x30 + x38;
    double x40 = x23*x36;
    double x41 = x14*x7;
    double x42 = x26*x41;
    double x43 = -x14*x28;
    double x44 = x30 + x43;
    double x45 = x23*x41;
    double x46 = x25*x32;
    double x47 = -2.0*x3;
    double x48 = 4.0*x2;
    double x49 = -x10*x48;
    double x50 = x47 + x49;
    double x51 = x18 + x26*x8;
    double x52 = 12*x20;
    double x53 = x25*x52;
    double x54 = x23*x8 + x24;
    double x55 = x29 + x47;
    double x56 = x38 + x55;
    double x57 = x27 + x51;
    double x58 = x34 + x54;
    double x59 = x43 + x55;
    double x60 = x32*x36;
    double x61 = -x12*x48;
    double x62 = x47 + x61;
    double x63 = x36*x52;
    double x64 = x38 + x43;
    double x65 = x47 + x64;
    double x66 = x37 + x42;
    double x67 = x40 + x45;
    double x68 = x32*x41;
    double x69 = -x14*x48;
    double x70 = x47 + x69;
    double x71 = x41*x52;
    double x72 = 6.0*x2;
    double x73 = -x10*x72;
    double x74 = 18*x20;
    double x75 = x38 + x49;
    double x76 = x18 + x46;
    double x77 = x24 + x53;
    double x78 = x43 + x49;
    double x79 = x29 + x61;
    double x80 = x18 + x27;
    double x81 = x24 + x34;
    double x82 = x29 + x64;
    double x83 = x29 + x69;
    double x84 = -x12*x72;
    double x85 = x43 + x61;
    double x86 = x38 + x69;
    double x87 = -x14*x72;

if (x19) {
   result[0] = x18 + x4 + x6*x8;
}
else {
   result[0] = 18*x21 + x24 + x4;
}
if (x19) {
   result[1] = x27 + x31 + x33;
}
else {
   result[1] = x31 + x34 + x35;
}
if (x19) {
   result[2] = x33 + x37 + x39;
}
else {
   result[2] = x35 + x39 + x40;
}
if (x19) {
   result[3] = x33 + x42 + x44;
}
else {
   result[3] = x35 + x44 + x45;
}
if (x19) {
   result[4] = x46 + x50 + x51;
}
else {
   result[4] = x50 + x53 + x54;
}
if (x19) {
   result[5] = x37 + x56 + x57;
}
else {
   result[5] = x40 + x56 + x58;
}
if (x19) {
   result[6] = x42 + x57 + x59;
}
else {
   result[6] = x45 + x58 + x59;
}
if (x19) {
   result[7] = x51 + x60 + x62;
}
else {
   result[7] = x54 + x62 + x63;
}
if (x19) {
   result[8] = x51 + x65 + x66;
}
else {
   result[8] = x54 + x65 + x67;
}
if (x19) {
   result[9] = x51 + x68 + x70;
}
else {
   result[9] = x54 + x70 + x71;
}
if (x19) {
   result[10] = x18 + x25*x6 + x73;
}
else {
   result[10] = x24 + x25*x74 + x73;
}
if (x19) {
   result[11] = x37 + x75 + x76;
}
else {
   result[11] = x40 + x75 + x77;
}
if (x19) {
   result[12] = x42 + x76 + x78;
}
else {
   result[12] = x45 + x77 + x78;
}
if (x19) {
   result[13] = x60 + x79 + x80;
}
else {
   result[13] = x63 + x79 + x81;
}
if (x19) {
   result[14] = x66 + x80 + x82;
}
else {
   result[14] = x67 + x81 + x82;
}
if (x19) {
   result[15] = x68 + x80 + x83;
}
else {
   result[15] = x71 + x81 + x83;
}
if (x19) {
   result[16] = x18 + x36*x6 + x84;
}
else {
   result[16] = x24 + x36*x74 + x84;
}
if (x19) {
   result[17] = x18 + x42 + x60 + x85;
}
else {
   result[17] = x24 + x45 + x63 + x85;
}
if (x19) {
   result[18] = x18 + x37 + x68 + x86;
}
else {
   result[18] = x24 + x40 + x71 + x86;
}
if (x19) {
   result[19] = x18 + x41*x6 + x87;
}
else {
   result[19] = x24 + x41*x74 + x87;
}
}
        
static double coder_d2gdt2(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = 1.0*n1*(*endmember[0].d2mu0dT2)(T, P) + 1.0*n2*(*endmember[1].d2mu0dT2)(T, P) + 1.0*n3*(*endmember[2].d2mu0dT2)(T, P) + 1.0*n4*(*endmember[3].d2mu0dT2)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0000000000000002*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 80.2881*T - 401.44049999999999;
    double x7 = 1.0/(x1 - 1);
    double x8 = x7*0;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = ((x10)*(x10));

if (T >= 5.0) {
   result = x0;
}
else {
   result = -0.33333333333333331*n2*(8.0288100000000036*x10*((x5)*(x5))*x7 - 4.0144050000000018*x11*x8 + 4.014405*x11*x9 - 0.010000000000000004*x6*x8 + 0.010000000000000002*x6*x9 + 16.057620000000004*x5/x3) + x0;
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = 1.0*(*endmember[1].d2mu0dT2)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = 1 - x1;
    double x3 = sqrt(x2);
    double x4 = 1.0000000000000002*x3;
    double x5 = (4 - x4 >= 0. ? 1. : 0.);
    double x6 = 80.2881*T - 401.44049999999999;
    double x7 = 1.0/(x1 - 1);
    double x8 = x7*0;
    double x9 = x5/pow(x2, 3.0/2.0);
    double x10 = fmin(4, x4);
    double x11 = ((x10)*(x10));

result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
if (T >= 5.0) {
   result[1] = x0;
}
else {
   result[1] = x0 - 2.676270000000001*x10*((x5)*(x5))*x7 + 1.3381350000000005*x11*x8 - 1.3381349999999999*x11*x9 + 0.0033333333333333344*x6*x8 - 0.003333333333333334*x6*x9 - 5.3525400000000012*x5/x3;
}
result[2] = 1.0*(*endmember[2].d2mu0dT2)(T, P);
result[3] = 1.0*(*endmember[3].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dTdP)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dTdP)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dTdP)(T, P);
    double x3 = n4*(*endmember[3].d2mu0dTdP)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3;
}
else {
   result = x0 + x1 + x2 + x3;
}
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dTdP)(T, P);
result[3] = 1.0*(*endmember[3].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dP2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dP2)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dP2)(T, P);
    double x3 = n4*(*endmember[3].d2mu0dP2)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3;
}
else {
   result = x0 + x1 + x2 + x3;
}
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dP2)(T, P);
result[3] = 1.0*(*endmember[3].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = 1.0*n1*(*endmember[0].d3mu0dT3)(T, P) + 1.0*n2*(*endmember[1].d3mu0dT3)(T, P) + 1.0*n3*(*endmember[2].d3mu0dT3)(T, P) + 1.0*n4*(*endmember[3].d3mu0dT3)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0000000000000002*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = pow(x3, -3.0/2.0);
    double x8 = (4 - x4 >= 0. ? 1. : 0.);
    double x9 = x7*x8;
    double x10 = 80.2881*T - 401.44049999999999;
    double x11 = pow(x2, -2);
    double x12 = x11*x6;
    double x13 = x8/pow(x3, 5.0/2.0);
    double x14 = x7*0;
    double x15 = fmin(4, x4);
    double x16 = ((x15)*(x15));

if (T >= 5.0) {
   result = x0;
}
else {
   result = -0.33333333333333331*n2*(0.0030000000000000009*x10*x12 + 0.0030000000000000005*x10*x13 - 0.0010000000000000005*x10*x14 - 2.4086430000000005*x11*x15*((x8)*(x8)) + 1.2043215000000003*x12*x16 + 1.2043215*x13*x16 - 0.40144050000000026*x14*x16 - 2.4086430000000014*x15*x6*x9 + 0.80288100000000051*x7*((x8)*(x8)*(x8)) + 2.4086430000000005*x9 - 2.408643000000001*x6/x2) + x0;
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = 1.0*(*endmember[1].d3mu0dT3)(T, P);
    double x1 = 0.19999999999999998*T;
    double x2 = x1 - 1;
    double x3 = 1 - x1;
    double x4 = 1.0000000000000002*sqrt(x3);
    double x5 = x4 - 4;
    double x6 = 0;
    double x7 = pow(x3, -3.0/2.0);
    double x8 = (4 - x4 >= 0. ? 1. : 0.);
    double x9 = x7*x8;
    double x10 = 80.2881*T - 401.44049999999999;
    double x11 = pow(x2, -2);
    double x12 = x11*x6;
    double x13 = x8/pow(x3, 5.0/2.0);
    double x14 = x7*0;
    double x15 = fmin(4, x4);
    double x16 = ((x15)*(x15));

result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
if (T >= 5.0) {
   result[1] = x0;
}
else {
   result[1] = x0 - 0.0010000000000000002*x10*x12 - 0.001*x10*x13 + 0.00033333333333333348*x10*x14 + 0.80288100000000018*x11*x15*((x8)*(x8)) - 0.40144050000000009*x12*x16 - 0.40144049999999998*x13*x16 + 0.13381350000000009*x14*x16 + 0.8028810000000004*x15*x6*x9 - 0.26762700000000017*x7*((x8)*(x8)*(x8)) - 0.80288100000000018*x9 + 0.80288100000000029*x6/x2;
}
result[2] = 1.0*(*endmember[2].d3mu0dT3)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT2dP)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT2dP)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dT2dP)(T, P);
    double x3 = n4*(*endmember[3].d3mu0dT2dP)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3;
}
else {
   result = x0 + x1 + x2 + x3;
}
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dT2dP)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dTdP2)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dTdP2)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dTdP2)(T, P);
    double x3 = n4*(*endmember[3].d3mu0dTdP2)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3;
}
else {
   result = x0 + x1 + x2 + x3;
}
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dTdP2)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dP3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dP3)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dP3)(T, P);
    double x3 = n4*(*endmember[3].d3mu0dP3)(T, P);

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3;
}
else {
   result = x0 + x1 + x2 + x3;
}
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dP3)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_s(double T, double P, double n[4]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[4]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[4]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[4]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[4]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[4]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[4]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[4]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[4]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[4]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[4]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[4]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[4]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[4]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

