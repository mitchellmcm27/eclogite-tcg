#include <math.h>


static double coder_g(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = n1 + n3;
    double x1 = n2 + n4 + x0;
    double x2 = 1.0/x1;
    double x3 = n1*(*endmember[0].mu0)(T, P);
    double x4 = n2*(*endmember[1].mu0)(T, P);
    double x5 = n3*(*endmember[2].mu0)(T, P);
    double x6 = n4*(*endmember[3].mu0)(T, P);
    double x7 = n1 + n4;
    double x8 = T*(2.0*n2*log(n2*x2) + 1.0*n3*log(n3*x2) + 1.0*n4*log(n4*x2) + 1.0*x0*log(x0*x2) + 1.0*x7*log(x2*x7));
    double x9 = 16100.0*n4;
    double x10 = n1*x9 + n2*x9 + 24000.0*n3*n4 + 0.125*n4*(128800.0*n1 + 128800.0*n2 + 192000.0*n3);
    double x11 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));

if (T >= 5.0) {
   result = x2*(1.0*x1*(-n2*(26.762699999999999*T - 89.209000000000003) + x3 + x4 + x5 + x6 + 8.3144626181532395*x8) + x10);
}
else {
   result = x2*(0.33333333333333331*x1*(n2*(133.8135*((x11)*(x11)*(x11)) + (80.2881*T - 401.44049999999999)*(x11 - 1) - 133.8135) + 3*x3 + 3*x4 + 3*x5 + 3*x6 + 24.943387854459719*x8) + x10);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = n1 + n3;
    double x1 = n2 + n4 + x0;
    double x2 = pow(x1, -2);
    double x3 = (*endmember[0].mu0)(T, P);
    double x4 = n1*x3;
    double x5 = (*endmember[1].mu0)(T, P);
    double x6 = n2*x5;
    double x7 = (*endmember[2].mu0)(T, P);
    double x8 = n3*x7;
    double x9 = (*endmember[3].mu0)(T, P);
    double x10 = n4*x9;
    double x11 = 26.762699999999999*T;
    double x12 = n2*(x11 - 89.209000000000003);
    double x13 = 1.0/x1;
    double x14 = n2*x13;
    double x15 = log(x14);
    double x16 = n3*x13;
    double x17 = 1.0*log(x16);
    double x18 = n4*x13;
    double x19 = 1.0*log(x18);
    double x20 = x0*x13;
    double x21 = 1.0*log(x20);
    double x22 = n1 + n4;
    double x23 = x13*x22;
    double x24 = 1.0*log(x23);
    double x25 = 2.0*n2*x15 + n3*x17 + n4*x19 + x0*x21 + x22*x24;
    double x26 = 8.3144626181532395*T;
    double x27 = x25*x26;
    double x28 = 1.0*x1;
    double x29 = 16100.0*n4;
    double x30 = n1*x29 + n2*x29 + 24000.0*n3*n4 + 0.125*n4*(128800.0*n1 + 128800.0*n2 + 192000.0*n3);
    double x31 = -x2*(x28*(x10 - x12 + x27 + x4 + x6 + x8) + x30);
    double x32 = -x13;
    double x33 = 1.0*x18;
    double x34 = -2.0*x14;
    double x35 = x21 + x28*(-x0*x2 - x32) - x33 + x34;
    double x36 = 1.0*x16;
    double x37 = x24 + x28*(-x2*x22 - x32) - x36;
    double x38 = x35 + x37;
    double x39 = -1.0*x12;
    double x40 = 1.0*x10 + x27 + 1.0*x4 + 1.0*x6 + 1.0*x8;
    double x41 = 32200.0*n4 + x40;
    double x42 = x39 + x41;
    double x43 = T >= 5.0;
    double x44 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));
    double x45 = 133.8135*((x44)*(x44)*(x44)) + (80.2881*T - 401.44049999999999)*(x44 - 1) - 133.8135;
    double x46 = n2*x45;
    double x47 = 24.943387854459719*T;
    double x48 = 0.33333333333333331*x1;
    double x49 = -x2*(x30 + x48*(3*x10 + x25*x47 + 3*x4 + x46 + 3*x6 + 3*x8));
    double x50 = 0.33333333333333331*x46;
    double x51 = x41 + x50;
    double x52 = 1.0*x20;
    double x53 = 1.0*x23;
    double x54 = 2.0*x1*(-n2*x2 - x32) + 2.0*x15 - x33 - x36 - x52 - x53;
    double x55 = x17 + x28*(-n3*x2 - x32) + x35 - x53;
    double x56 = 48000.0*n4 + x40;
    double x57 = x19 + x28*(-n4*x2 - x32) + x34 + x37 - x52;
    double x58 = 32200.0*n1 + 32200.0*n2 + 48000.0*n3 + x40;

if (x43) {
   result[0] = x13*(x28*(x26*x38 + x3) + x42) + x31;
}
else {
   result[0] = x13*(x48*(3*x3 + x38*x47) + x51) + x49;
}
if (x43) {
   result[1] = x13*(x28*(-x11 + x26*x54 + x5 + 89.209000000000003) + x42) + x31;
}
else {
   result[1] = x13*(x48*(x45 + x47*x54 + 3*x5) + x51) + x49;
}
if (x43) {
   result[2] = x13*(x28*(x26*x55 + x7) + x39 + x56) + x31;
}
else {
   result[2] = x13*(x48*(x47*x55 + 3*x7) + x50 + x56) + x49;
}
if (x43) {
   result[3] = x13*(x28*(x26*x57 + x9) + x39 + x58) + x31;
}
else {
   result[3] = x13*(x48*(x47*x57 + 3*x9) + x50 + x58) + x49;
}
}
        
static void coder_d2gdn2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n3*x4;
    double x6 = (*endmember[3].mu0)(T, P);
    double x7 = n4*x6;
    double x8 = 26.762699999999999*T;
    double x9 = n2*(x8 - 89.209000000000003);
    double x10 = n1 + n3;
    double x11 = n2 + n4 + x10;
    double x12 = 1.0/x11;
    double x13 = log(n2*x12);
    double x14 = n3*x12;
    double x15 = 1.0*log(x14);
    double x16 = n4*x12;
    double x17 = 1.0*log(x16);
    double x18 = x10*x12;
    double x19 = 1.0*log(x18);
    double x20 = n1 + n4;
    double x21 = x12*x20;
    double x22 = 1.0*log(x21);
    double x23 = T*(2.0*n2*x13 + n3*x15 + n4*x17 + x10*x19 + x20*x22);
    double x24 = 8.3144626181532395*x23;
    double x25 = 1.0*x11;
    double x26 = 16100.0*n4;
    double x27 = n1*x26 + n2*x26 + 24000.0*n3*n4 + 0.125*n4*(128800.0*n1 + 128800.0*n2 + 192000.0*n3);
    double x28 = 2/((x11)*(x11)*(x11));
    double x29 = x28*(x25*(x1 + x24 + x3 + x5 + x7 - x9) + x27);
    double x30 = -x12;
    double x31 = pow(x11, -2);
    double x32 = x10*x31;
    double x33 = x25*(-x30 - x32);
    double x34 = 1.0*x16;
    double x35 = 2.0*x12;
    double x36 = -n2*x35;
    double x37 = x19 + x33 - x34 + x36;
    double x38 = x20*x31;
    double x39 = x25*(-x30 - x38);
    double x40 = 1.0*x14;
    double x41 = x22 + x39 - x40;
    double x42 = T*(x37 + x41);
    double x43 = 8.3144626181532395*x42;
    double x44 = -1.0*x9;
    double x45 = 1.0*x1 + x24 + 1.0*x3 + 1.0*x5 + 1.0*x7;
    double x46 = 32200.0*n4 + x45;
    double x47 = x44 + x46;
    double x48 = x25*(x0 + x43) + x47;
    double x49 = 2*x31;
    double x50 = n3*x31;
    double x51 = 1.0*x50;
    double x52 = n4*x31;
    double x53 = 1.0*x52;
    double x54 = x51 + x53;
    double x55 = -x49;
    double x56 = x10*x28;
    double x57 = n2*x31;
    double x58 = 2.0*x57;
    double x59 = 1.0*x32;
    double x60 = x58 - x59;
    double x61 = x25*(x55 + x56) + x60 + x33/x10;
    double x62 = x54 + x61;
    double x63 = 1.0*x38;
    double x64 = -x63;
    double x65 = x20*x28;
    double x66 = x25*(x55 + x65) + x64 + x39/x20;
    double x67 = x35 + x66;
    double x68 = 8.3144626181532395*T*x11;
    double x69 = x12*(2.0*x0 + 16.628925236306479*x42 + x68*(x62 + x67));
    double x70 = T >= 5.0;
    double x71 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));
    double x72 = ((x71)*(x71)*(x71));
    double x73 = (80.2881*T - 401.44049999999999)*(x71 - 1);
    double x74 = 133.8135*x72 + x73 - 133.8135;
    double x75 = n2*x74;
    double x76 = 0.33333333333333331*x11;
    double x77 = x28*(x27 + x76*(3*x1 + 24.943387854459719*x23 + 3*x3 + 3*x5 + 3*x7 + x75));
    double x78 = 0.33333333333333331*x75;
    double x79 = x46 + x78;
    double x80 = x76*(3*x0 + 24.943387854459719*x42) + x79;
    double x81 = 1.0*x2;
    double x82 = 1.0*x18;
    double x83 = 1.0*x21;
    double x84 = -x30 - x57;
    double x85 = T*(2.0*x11*x84 + 2.0*x13 - x34 - x40 - x82 - x83);
    double x86 = 8.3144626181532395*x85;
    double x87 = -x8 + x86;
    double x88 = x87 + 89.209000000000003;
    double x89 = x81 + x88;
    double x90 = -x35;
    double x91 = x54 + x90;
    double x92 = -x31;
    double x93 = x25*(x56 + x92) + x60;
    double x94 = x25*(x65 + x92) + x64;
    double x95 = 1.0*x0 + x43;
    double x96 = x68*(x91 + x93 + x94) + x95;
    double x97 = x25*(x2 + x88) + x47;
    double x98 = -x31*x97;
    double x99 = x29 - x31*x48;
    double x100 = 44.604500000000002*x72 + 0.33333333333333331*x73 + x86;
    double x101 = x100 + x81 - 44.604500000000002;
    double x102 = x76*(3*x2 + x74 + 24.943387854459719*x85) + x79;
    double x103 = -x102*x31;
    double x104 = -x31*x80 + x77;
    double x105 = x25*(-x30 - x50);
    double x106 = T*(x105 + x15 + x37 - x83);
    double x107 = 8.3144626181532395*x106;
    double x108 = x107 + 1.0*x4;
    double x109 = x12*(x108 + x68*(x62 + x94) + x95);
    double x110 = 48000.0*n4 + x45;
    double x111 = x110 + x25*(x107 + x4) + x44;
    double x112 = -x111*x31;
    double x113 = x110 + x76*(24.943387854459719*x106 + 3*x4) + x78;
    double x114 = -x113*x31;
    double x115 = x25*(-x30 - x52);
    double x116 = T*(x115 + x17 + x36 + x41 - x82);
    double x117 = 8.3144626181532395*x116;
    double x118 = x117 + 1.0*x6;
    double x119 = x12*(x118 + x68*(x54 + x66 + x93) + x95 + 32200.0);
    double x120 = 32200.0*n1 + 32200.0*n2 + 48000.0*n3 + x45;
    double x121 = x120 + x25*(x117 + x6) + x44;
    double x122 = -x121*x31;
    double x123 = x120 + x76*(24.943387854459719*x116 + 3*x6) + x78;
    double x124 = -x123*x31;
    double x125 = n2*x28;
    double x126 = 2.0*x11;
    double x127 = -x58 + x59 + x63;
    double x128 = 2.0*x2 + x68*(x126*(x125 + x55) + x127 + x35 + x54 + x126*x84/n2) + 16.628925236306479*x85;
    double x129 = x68*(x126*(x125 + x92) + x127 + x91);
    double x130 = x108 + x129;
    double x131 = x29 + x98;
    double x132 = x103 + x77;
    double x133 = x118 + x129 + x81;
    double x134 = n3*x28;
    double x135 = -x51 + x53 + x63;
    double x136 = x12*(16.628925236306479*x106 + 2.0*x4 + x68*(x135 + x25*(x134 + x55) + x35 + x61 + x105/n3));
    double x137 = x12*(x108 + x118 + x68*(x135 + x25*(x134 + x92) + x90 + x93) + 48000.0);
    double x138 = x12*(16.628925236306479*x116 + 2.0*x6 + x68*(x25*(n4*x28 + x55) + x51 - x53 + x58 + x59 + x67 + x115/n4));

if (x70) {
   result[0] = x29 - x48*x49 + x69;
}
else {
   result[0] = -x49*x80 + x69 + x77;
}
if (x70) {
   result[1] = x12*(x89 + x96) + x98 + x99;
}
else {
   result[1] = x103 + x104 + x12*(x101 + x96);
}
if (x70) {
   result[2] = x109 + x112 + x99;
}
else {
   result[2] = x104 + x109 + x114;
}
if (x70) {
   result[3] = x119 + x122 + x99;
}
else {
   result[3] = x104 + x119 + x124;
}
if (x70) {
   result[4] = x12*(-53.525399999999998*T + x128 + 178.41800000000001) + x29 - x49*x97;
}
else {
   result[4] = -x102*x49 + x12*(x128 + 89.209000000000003*x72 + 0.66666666666666663*x73 - 89.209000000000003) + x77;
}
if (x70) {
   result[5] = x112 + x12*(x130 + x89) + x131;
}
else {
   result[5] = x114 + x12*(x101 + x130) + x132;
}
if (x70) {
   result[6] = x12*(x133 + x87 + 32289.208999999999) + x122 + x131;
}
else {
   result[6] = x12*(x100 + x133 + 32155.395499999999) + x124 + x132;
}
if (x70) {
   result[7] = -x111*x49 + x136 + x29;
}
else {
   result[7] = -x113*x49 + x136 + x77;
}
if (x70) {
   result[8] = x112 + x122 + x137 + x29;
}
else {
   result[8] = x114 + x124 + x137 + x77;
}
if (x70) {
   result[9] = -x121*x49 + x138 + x29;
}
else {
   result[9] = -x123*x49 + x138 + x77;
}
}
        
static void coder_d3gdn3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = n1*x0;
    double x2 = (*endmember[1].mu0)(T, P);
    double x3 = n2*x2;
    double x4 = (*endmember[2].mu0)(T, P);
    double x5 = n3*x4;
    double x6 = (*endmember[3].mu0)(T, P);
    double x7 = n4*x6;
    double x8 = 26.762699999999999*T;
    double x9 = n2*(x8 - 89.209000000000003);
    double x10 = n1 + n3;
    double x11 = n2 + n4 + x10;
    double x12 = 1.0/x11;
    double x13 = log(n2*x12);
    double x14 = n3*x12;
    double x15 = 1.0*log(x14);
    double x16 = n4*x12;
    double x17 = 1.0*log(x16);
    double x18 = x10*x12;
    double x19 = 1.0*log(x18);
    double x20 = n1 + n4;
    double x21 = x12*x20;
    double x22 = 1.0*log(x21);
    double x23 = 2.0*n2*x13 + n3*x15 + n4*x17 + x10*x19 + x20*x22;
    double x24 = 8.3144626181532395*T;
    double x25 = x23*x24;
    double x26 = 1.0*x11;
    double x27 = 16100.0*n4;
    double x28 = n1*x27 + n2*x27 + 24000.0*n3*n4 + 0.125*n4*(128800.0*n1 + 128800.0*n2 + 192000.0*n3);
    double x29 = 6/((x11)*(x11)*(x11)*(x11));
    double x30 = x29*(x26*(x1 + x25 + x3 + x5 + x7 - x9) + x28);
    double x31 = -x30;
    double x32 = -x12;
    double x33 = pow(x11, -2);
    double x34 = x10*x33;
    double x35 = -x32 - x34;
    double x36 = x26*x35;
    double x37 = 1.0*x16;
    double x38 = 2.0*x12;
    double x39 = -n2*x38;
    double x40 = x19 + x36 - x37 + x39;
    double x41 = x20*x33;
    double x42 = -x32 - x41;
    double x43 = x26*x42;
    double x44 = 1.0*x14;
    double x45 = x22 + x43 - x44;
    double x46 = x40 + x45;
    double x47 = x24*x46;
    double x48 = -1.0*x9;
    double x49 = 1.0*x1 + x25 + 1.0*x3 + 1.0*x5 + 1.0*x7;
    double x50 = 32200.0*n4 + x49;
    double x51 = x48 + x50;
    double x52 = x26*(x0 + x47) + x51;
    double x53 = pow(x11, -3);
    double x54 = 6*x53;
    double x55 = n3*x33;
    double x56 = 1.0*x55;
    double x57 = n4*x33;
    double x58 = 1.0*x57;
    double x59 = x56 + x58;
    double x60 = 2*x33;
    double x61 = -x60;
    double x62 = 2*x53;
    double x63 = x10*x62;
    double x64 = x26*(x61 + x63);
    double x65 = 1.0/x10;
    double x66 = x35*x65;
    double x67 = n2*x33;
    double x68 = 2.0*x67;
    double x69 = 1.0*x34;
    double x70 = x68 - x69;
    double x71 = x26*x66 + x64 + x70;
    double x72 = x59 + x71;
    double x73 = 1.0*x41;
    double x74 = -x73;
    double x75 = x20*x62;
    double x76 = x26*(x61 + x75);
    double x77 = 1.0/x20;
    double x78 = x42*x77;
    double x79 = x26*x78 + x74 + x76;
    double x80 = x38 + x79;
    double x81 = x72 + x80;
    double x82 = 24.943387854459719*T;
    double x83 = 8.0*x33;
    double x84 = -x83;
    double x85 = 1.0*x78;
    double x86 = -6*x53;
    double x87 = x20*x29;
    double x88 = 4.0*x53;
    double x89 = 2.0*x53;
    double x90 = n3*x89;
    double x91 = x20*x88 - x90;
    double x92 = x26*(-x86 - x87) + x76*x77 + x85 + x91 - x43/((x20)*(x20));
    double x93 = x84 + x92;
    double x94 = 1.0*x66;
    double x95 = x10*x29;
    double x96 = n4*x89;
    double x97 = -n2*x88;
    double x98 = x10*x88 - x96 + x97;
    double x99 = x26*(-x86 - x95) + x64*x65 + x98 - x36/((x10)*(x10));
    double x100 = x94 + x99;
    double x101 = x11*x24;
    double x102 = 16.628925236306479*T;
    double x103 = x24*x81;
    double x104 = x33*(2.0*x0 + x102*x46 + x103*x11);
    double x105 = -3*x104 + x12*(x101*(x100 + x93) + x81*x82);
    double x106 = T >= 5.0;
    double x107 = fmin(4, 1.0000000000000002*sqrt(1 - 0.19999999999999998*T));
    double x108 = ((x107)*(x107)*(x107));
    double x109 = (80.2881*T - 401.44049999999999)*(x107 - 1);
    double x110 = 133.8135*x108 + x109 - 133.8135;
    double x111 = n2*x110;
    double x112 = 0.33333333333333331*x11;
    double x113 = x29*(x112*(3*x1 + x111 + x23*x82 + 3*x3 + 3*x5 + 3*x7) + x28);
    double x114 = -x113;
    double x115 = 0.33333333333333331*x111;
    double x116 = x115 + x50;
    double x117 = x112*(3*x0 + x46*x82) + x116;
    double x118 = 1.0*x18;
    double x119 = 1.0*x21;
    double x120 = -x32 - x67;
    double x121 = 2.0*x11*x120 - x118 - x119 + 2.0*x13 - x37 - x44;
    double x122 = x121*x24;
    double x123 = x122 - x8;
    double x124 = x123 + 89.209000000000003;
    double x125 = x26*(x124 + x2) + x51;
    double x126 = 1.0*x2;
    double x127 = x124 + x126;
    double x128 = -x38;
    double x129 = x128 + x59;
    double x130 = -x33;
    double x131 = x26*(x130 + x63);
    double x132 = x131 + x70;
    double x133 = x26*(x130 + x75);
    double x134 = x133 + x74;
    double x135 = x129 + x132 + x134;
    double x136 = x135*x24;
    double x137 = 1.0*x0 + x47;
    double x138 = x11*x136 + x137;
    double x139 = x127 + x138;
    double x140 = x139*x60;
    double x141 = x102*x135;
    double x142 = -4*x53;
    double x143 = x26*(-x142 - x87) + x91;
    double x144 = x26*(-x142 - x95) + x98;
    double x145 = x131*x65 + x144;
    double x146 = x143 + x145;
    double x147 = 4.0*x33;
    double x148 = -x147 + x94;
    double x149 = x133*x77 + x85;
    double x150 = x104 - x12*(x101*(x146 + x148 + x149) + x103 + x141);
    double x151 = x30 - 4*x52*x53;
    double x152 = x112*(x110 + x121*x82 + 3*x2) + x116;
    double x153 = 44.604500000000002*x108 + 0.33333333333333331*x109 + x122;
    double x154 = x126 + x153 - 44.604500000000002;
    double x155 = x138 + x154;
    double x156 = x155*x60;
    double x157 = x113 - 4*x117*x53;
    double x158 = -x32 - x55;
    double x159 = x158*x26;
    double x160 = -x119 + x15 + x159 + x40;
    double x161 = x160*x24;
    double x162 = 48000.0*n4 + x49;
    double x163 = x162 + x26*(x161 + x4) + x48;
    double x164 = x104 + x151;
    double x165 = x134 + x72;
    double x166 = x102*x165;
    double x167 = -6.0*x33 + x94;
    double x168 = x165*x24;
    double x169 = x161 + 1.0*x4;
    double x170 = x11*x168 + x137 + x169;
    double x171 = x170*x60;
    double x172 = -x12*(x101*(x143 + x149 + x167 + x99) + x103 + x166) + x171;
    double x173 = x112*(x160*x82 + 3*x4) + x115 + x162;
    double x174 = x104 + x157;
    double x175 = -x32 - x57;
    double x176 = x175*x26;
    double x177 = -x118 + x17 + x176 + x39 + x45;
    double x178 = x177*x24;
    double x179 = 32200.0*n1 + 32200.0*n2 + 48000.0*n3 + x49;
    double x180 = x179 + x26*(x178 + x6) + x48;
    double x181 = -2*x180*x53;
    double x182 = x132 + x59 + x79;
    double x183 = x102*x182;
    double x184 = x182*x24;
    double x185 = x178 + 1.0*x6;
    double x186 = x11*x184 + x137 + x185 + 32200.0;
    double x187 = x186*x60;
    double x188 = -x12*(x101*(x145 + x167 + x92) + x103 + x183) + x187;
    double x189 = x112*(x177*x82 + 3*x6) + x115 + x179;
    double x190 = -2*x189*x53;
    double x191 = n2*x62;
    double x192 = x191 + x61;
    double x193 = 2.0*x11;
    double x194 = 1.0/n2;
    double x195 = x120*x193;
    double x196 = -x68 + x69 + x73;
    double x197 = x192*x193 + x194*x195 + x196 + x38 + x59;
    double x198 = x197*x24;
    double x199 = -2*x53;
    double x200 = x26*(-x199 - x87) + x91;
    double x201 = x26*(-x199 - x95) + x98;
    double x202 = x201 + 2.0*x33;
    double x203 = x12*(x101*(x200 + x202) + x141 + x198);
    double x204 = x31 + x52*x62;
    double x205 = x102*x121 + x11*x198 + 2.0*x2;
    double x206 = x33*(-53.525399999999998*T + x205 + 178.41800000000001);
    double x207 = 4*x53;
    double x208 = x125*x207 - x206;
    double x209 = x114 + x117*x62;
    double x210 = x33*(89.209000000000003*x108 + 0.66666666666666663*x109 + x205 - 89.209000000000003);
    double x211 = x152*x207 - x210;
    double x212 = x163*x62;
    double x213 = x130 + x191;
    double x214 = x129 + x193*x213 + x196;
    double x215 = x214*x24;
    double x216 = x136 + x215;
    double x217 = -x170*x33;
    double x218 = x12*(x101*(x144 + x200) + x168 + x216) + x217;
    double x219 = x125*x62;
    double x220 = x11*x215;
    double x221 = x169 + x220;
    double x222 = x127 + x221;
    double x223 = x219 - x222*x33;
    double x224 = -x139*x33 + x204;
    double x225 = -x155*x33;
    double x226 = x173*x62;
    double x227 = x209 + x226;
    double x228 = x152*x62;
    double x229 = x154 + x221;
    double x230 = x228 - x229*x33;
    double x231 = -x186*x33;
    double x232 = x12*(x101*(x143 + x201) + x184 + x216) + x231;
    double x233 = x180*x62;
    double x234 = x126 + x185 + x220;
    double x235 = x123 + x234 + 32289.208999999999;
    double x236 = x233 - x235*x33;
    double x237 = x189*x62;
    double x238 = x153 + x234 + 32155.395499999999;
    double x239 = x237 - x238*x33;
    double x240 = -4*x163*x53;
    double x241 = x30 - 2*x52*x53;
    double x242 = n3*x62;
    double x243 = x26*(x242 + x61);
    double x244 = 1.0/n3;
    double x245 = -x56 + x58 + x73;
    double x246 = x159*x244 + x243 + x245 + x38 + x71;
    double x247 = x24*x246;
    double x248 = x33*(x102*x160 + x11*x247 + 2.0*x4);
    double x249 = -3.0*x33;
    double x250 = x249 + x94;
    double x251 = -x12*(x101*(x200 + x250 + x99) + x166 + x247) + x171 + x248;
    double x252 = -4*x173*x53;
    double x253 = x113 - 2*x117*x53;
    double x254 = x26*(x130 + x242);
    double x255 = x128 + x132 + x245 + x254;
    double x256 = x24*x255;
    double x257 = x11*x256 + x169 + x185 + 48000.0;
    double x258 = -x257*x33;
    double x259 = x12*(x101*(x146 + x250) + x168 + x184 + x256) + x217 + x231 + x258;
    double x260 = x26*(n4*x62 + x61);
    double x261 = 1.0/n4;
    double x262 = x176*x261 + x260 + x56 - x58 + x68 + x69 + x80;
    double x263 = x24*x262;
    double x264 = x33*(x102*x177 + x11*x263 + 2.0*x6);
    double x265 = -x12*(x101*(x201 + x249 + x92) + x183 + x263) + x187 + x264;
    double x266 = n2*x29;
    double x267 = x10*x89;
    double x268 = x20*x89;
    double x269 = -8.0*n2*x53 + x267 + x268 + x90 + x96;
    double x270 = -2.0*x120*x194 + x269;
    double x271 = x12*(x101*(2.0*x11*x192*x194 + 2.0*x11*(-x266 - x86) - x270 - x83 - x195/((n2)*(n2))) + x197*x82);
    double x272 = -x222*x60 + x31;
    double x273 = x102*x214;
    double x274 = x12*(x101*(2.0*x11*x194*x213 + 2.0*x11*(-x142 - x266) - x147 - x270) + x198 + x273);
    double x275 = x208 + x274;
    double x276 = x114 - x229*x60;
    double x277 = x211 + x274;
    double x278 = -x235*x60 + x31;
    double x279 = x114 - x238*x60;
    double x280 = x101*(2.0*x11*(-x199 - x266) - x269 + 2.0*x33) + x273;
    double x281 = x12*(x247 + x280) - x248;
    double x282 = x212 + x31;
    double x283 = x12*(x256 + x280) + x258;
    double x284 = x114 + x226;
    double x285 = x180*x207;
    double x286 = -x264;
    double x287 = x12*(x263 + x280) + x286;
    double x288 = x189*x207;
    double x289 = n3*x29;
    double x290 = n3*x88 - x268;
    double x291 = 1.0*x158*x244 + x290;
    double x292 = x12*(x101*(x100 + x243*x244 + x26*(-x289 - x86) + x291 + x84 - x159/((n3)*(n3))) + x246*x82) - 3*x248;
    double x293 = x102*x255;
    double x294 = x257*x60;
    double x295 = -x12*(x101*(x145 + x148 + x244*x254 + x26*(-x142 - x289) + x291) + x247 + x293) + x248 + x294;
    double x296 = x12*(x101*(x202 + x26*(-x199 - x289) + x290) + x263 + x293) + x286 - x294;
    double x297 = x12*(x101*(n4*x88 + 1.0*x175*x261 + x26*(-n4*x29 - x86) + x260*x261 - x267 + x93 + x97 - x176/((n4)*(n4))) + x262*x82) - 3*x264;

if (x106) {
   result[0] = x105 + x31 + x52*x54;
}
else {
   result[0] = x105 + x114 + x117*x54;
}
if (x106) {
   result[1] = 2*x125*x53 - x140 - x150 - x151;
}
else {
   result[1] = -x150 + 2*x152*x53 - x156 - x157;
}
if (x106) {
   result[2] = 2*x163*x53 - x164 - x172;
}
else {
   result[2] = -x172 + 2*x173*x53 - x174;
}
if (x106) {
   result[3] = -x164 - x181 - x188;
}
else {
   result[3] = -x174 - x188 - x190;
}
if (x106) {
   result[4] = -x140 + x203 + x204 + x208;
}
else {
   result[4] = -x156 + x203 + x209 + x211;
}
if (x106) {
   result[5] = x212 + x218 + x223 + x224;
}
else {
   result[5] = x218 + x225 + x227 + x230;
}
if (x106) {
   result[6] = x219 + x224 + x232 + x236;
}
else {
   result[6] = x209 + x225 + x228 + x232 + x239;
}
if (x106) {
   result[7] = -x240 - x241 - x251;
}
else {
   result[7] = -x251 - x252 - x253;
}
if (x106) {
   result[8] = x204 + x212 + x233 + x259;
}
else {
   result[8] = x227 + x237 + x259;
}
if (x106) {
   result[9] = 4*x180*x53 - x241 - x265;
}
else {
   result[9] = 4*x189*x53 - x253 - x265;
}
if (x106) {
   result[10] = x125*x54 - 3*x206 + x271 + x31;
}
else {
   result[10] = x114 + x152*x54 - 3*x210 + x271;
}
if (x106) {
   result[11] = x212 + x272 + x275;
}
else {
   result[11] = x226 + x276 + x277;
}
if (x106) {
   result[12] = x233 + x275 + x278;
}
else {
   result[12] = x237 + x277 + x279;
}
if (x106) {
   result[13] = x163*x207 + x219 + x272 + x281;
}
else {
   result[13] = x173*x207 + x228 + x276 + x281;
}
if (x106) {
   result[14] = x223 + x236 + x282 + x283;
}
else {
   result[14] = x230 + x239 + x283 + x284;
}
if (x106) {
   result[15] = x219 + x278 + x285 + x287;
}
else {
   result[15] = x228 + x279 + x287 + x288;
}
if (x106) {
   result[16] = x163*x54 + x292 + x31;
}
else {
   result[16] = x114 + x173*x54 + x292;
}
if (x106) {
   result[17] = -x181 - x240 - x295 - x30;
}
else {
   result[17] = -x113 - x190 - x252 - x295;
}
if (x106) {
   result[18] = x282 + x285 + x296;
}
else {
   result[18] = x284 + x288 + x296;
}
if (x106) {
   result[19] = x180*x54 + x297 + x31;
}
else {
   result[19] = x114 + x189*x54 + x297;
}
}
        
static double coder_dgdt(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = n1 + n3;
    double x1 = 1.0/(n2 + n4 + x0);
    double x2 = n1 + n4;
    double x3 = 1.0*n1*(*endmember[0].dmu0dT)(T, P) + 16.628925236306479*n2*log(n2*x1) + 1.0*n2*(*endmember[1].dmu0dT)(T, P) + 8.3144626181532395*n3*log(n3*x1) + 1.0*n3*(*endmember[2].dmu0dT)(T, P) + 8.3144626181532395*n4*log(n4*x1) + 1.0*n4*(*endmember[3].dmu0dT)(T, P) + 8.3144626181532395*x0*log(x0*x1) + 8.3144626181532395*x2*log(x1*x2);
    double x4 = sqrt(1 - 0.19999999999999998*T);
    double x5 = 1.0000000000000002*x4;
    double x6 = fmin(4, x5);
    double x7 = (4 - x5 >= 0. ? 1. : 0.)/x4;

if (T >= 5.0) {
   result = -26.762699999999999*n2 + x3;
}
else {
   result = 0.33333333333333331*n2*(-40.144050000000007*((x6)*(x6))*x7 + 80.2881*x6 - 0.10000000000000002*x7*(80.2881*T - 401.44049999999999) - 80.2881) + x3;
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = n1 + n3;
    double x1 = n2 + n4 + x0;
    double x2 = 1.0/x1;
    double x3 = x0*x2;
    double x4 = -x2;
    double x5 = pow(x1, -2);
    double x6 = 8.3144626181532395*x1;
    double x7 = n4*x2;
    double x8 = 8.3144626181532395*x7;
    double x9 = n2*x2;
    double x10 = -16.628925236306479*x9;
    double x11 = x10 + x6*(-x0*x5 - x4) - x8 + 8.3144626181532395*log(x3);
    double x12 = n1 + n4;
    double x13 = x12*x2;
    double x14 = n3*x2;
    double x15 = 8.3144626181532395*x14;
    double x16 = -x15 + x6*(-x12*x5 - x4) + 8.3144626181532395*log(x13);
    double x17 = 8.3144626181532395*x3;
    double x18 = 8.3144626181532395*x13;
    double x19 = -16.628925236306479*x1*(-n2*x5 - x4) + x15 + x17 + x18 + x8 - 16.628925236306479*log(x9) - 1.0*(*endmember[1].dmu0dT)(T, P) + 26.762699999999999;
    double x20 = sqrt(1 - 0.19999999999999998*T);
    double x21 = 1.0000000000000002*x20;
    double x22 = fmin(4, x21);
    double x23 = (4 - x21 >= 0. ? 1. : 0.)/x20;

result[0] = x11 + x16 + 1.0*(*endmember[0].dmu0dT)(T, P);
if (T >= 5.0) {
   result[1] = -x19;
}
else {
   result[1] = -x19 - 13.381350000000001*((x22)*(x22))*x23 + 26.762699999999999*x22 - 0.03333333333333334*x23*(80.2881*T - 401.44049999999999);
}
result[2] = x11 - x18 + x6*(-n3*x5 - x4) + 8.3144626181532395*log(x14) + 1.0*(*endmember[2].dmu0dT)(T, P);
result[3] = x10 + x16 - x17 + x6*(-n4*x5 - x4) + 8.3144626181532395*log(x7) + 1.0*(*endmember[3].dmu0dT)(T, P);
}
        
static void coder_d3gdn2dt(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = n1 + n3;
    double x1 = n2 + n4 + x0;
    double x2 = pow(x1, -2);
    double x3 = n3*x2;
    double x4 = 8.3144626181532395*x3;
    double x5 = n4*x2;
    double x6 = 8.3144626181532395*x5;
    double x7 = x4 + x6;
    double x8 = -2*x2;
    double x9 = 2/((x1)*(x1)*(x1));
    double x10 = x0*x9;
    double x11 = 8.3144626181532395*x1;
    double x12 = 1.0/x1;
    double x13 = -x12;
    double x14 = x0*x2;
    double x15 = n2*x2;
    double x16 = 16.628925236306479*x15;
    double x17 = 8.3144626181532395*x14;
    double x18 = x16 - x17;
    double x19 = x11*(x10 + x8) + x18 + x11*(-x13 - x14)/x0;
    double x20 = x19 + x7;
    double x21 = 16.628925236306479*x12;
    double x22 = n1 + n4;
    double x23 = x2*x22;
    double x24 = 8.3144626181532395*x23;
    double x25 = -x24;
    double x26 = x22*x9;
    double x27 = x11*(x26 + x8) + x11*(-x13 - x23)/x22 + x25;
    double x28 = x21 + x27;
    double x29 = -x21;
    double x30 = x29 + x7;
    double x31 = -x2;
    double x32 = x11*(x10 + x31) + x18;
    double x33 = x11*(x26 + x31) + x25;
    double x34 = n2*x9;
    double x35 = 16.628925236306479*x1;
    double x36 = -x16 + x17 + x24;
    double x37 = x30 + x35*(x31 + x34) + x36;
    double x38 = n3*x9;
    double x39 = x24 - x4 + x6;

result[0] = x20 + x28;
result[1] = x30 + x32 + x33;
result[2] = x20 + x33;
result[3] = x27 + x32 + x7;
result[4] = x21 + x35*(x34 + x8) + x36 + x7 + x35*(-x13 - x15)/n2;
result[5] = x37;
result[6] = x37;
result[7] = x11*(x38 + x8) + x19 + x21 + x39 + x11*(-x13 - x3)/n3;
result[8] = x11*(x31 + x38) + x29 + x32 + x39;
result[9] = x11*(n4*x9 + x8) + x16 + x17 + x28 + x4 - x6 + x11*(-x13 - x5)/n4;
}
        
static void coder_d4gdn3dt(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = n1 + n3;
    double x1 = n2 + n4 + x0;
    double x2 = pow(x1, -2);
    double x3 = 66.515700945225916*x2;
    double x4 = -x3;
    double x5 = -1/x1;
    double x6 = n1 + n4;
    double x7 = -x2*x6 - x5;
    double x8 = 8.3144626181532395/x6;
    double x9 = x7*x8;
    double x10 = pow(x1, -3);
    double x11 = -6*x10;
    double x12 = 6/((x1)*(x1)*(x1)*(x1));
    double x13 = x12*x6;
    double x14 = 8.3144626181532395*x1;
    double x15 = -2*x2;
    double x16 = 2*x10;
    double x17 = x16*x6;
    double x18 = x1*x8;
    double x19 = 33.257850472612958*x10;
    double x20 = 16.628925236306479*x10;
    double x21 = n3*x20;
    double x22 = x19*x6 - x21;
    double x23 = x14*(-x11 - x13) - x14*x7/((x6)*(x6)) + x18*(x15 + x17) + x22 + x9;
    double x24 = x23 + x4;
    double x25 = -x0*x2 - x5;
    double x26 = 8.3144626181532395/x0;
    double x27 = x25*x26;
    double x28 = x0*x12;
    double x29 = x0*x16;
    double x30 = x1*x26;
    double x31 = n4*x20;
    double x32 = -n2*x19;
    double x33 = x0*x19 - x31 + x32;
    double x34 = x14*(-x11 - x28) + x30*(x15 + x29) + x33 - x14*x25/((x0)*(x0));
    double x35 = x27 + x34;
    double x36 = -4*x10;
    double x37 = x14*(-x13 - x36) + x22;
    double x38 = -x2;
    double x39 = x14*(-x28 - x36) + x33;
    double x40 = x30*(x29 + x38) + x39;
    double x41 = x37 + x40;
    double x42 = 33.257850472612958*x2;
    double x43 = x27 - x42;
    double x44 = x18*(x17 + x38) + x9;
    double x45 = -49.886775708919444*x2 + x27;
    double x46 = -2*x10;
    double x47 = x14*(-x13 - x46) + x22;
    double x48 = x14*(-x28 - x46) + x33;
    double x49 = 16.628925236306479*x2 + x48;
    double x50 = -24.943387854459719*x2;
    double x51 = x27 + x50;
    double x52 = n2*x12;
    double x53 = -n2*x2 - x5;
    double x54 = 1.0/n2;
    double x55 = n2*x16;
    double x56 = x0*x20;
    double x57 = x20*x6;
    double x58 = -66.515700945225916*n2*x10 + x21 + x31 + x56 + x57;
    double x59 = -16.628925236306479*x53*x54 + x58;
    double x60 = 16.628925236306479*x1*x54*(x38 + x55) + 16.628925236306479*x1*(-x36 - x52) - x42 - x59;
    double x61 = 16.628925236306479*x1*(-x46 - x52) + 16.628925236306479*x2 - x58;
    double x62 = n3*x12;
    double x63 = n3*x16;
    double x64 = 1.0/n3;
    double x65 = x14*x64;
    double x66 = -n3*x2 - x5;
    double x67 = n3*x19 - x57;
    double x68 = 8.3144626181532395*x64*x66 + x67;
    double x69 = 1.0/n4;
    double x70 = -n4*x2 - x5;

result[0] = x24 + x35;
result[1] = x41 + x43 + x44;
result[2] = x34 + x37 + x44 + x45;
result[3] = x23 + x40 + x45;
result[4] = x47 + x49;
result[5] = x39 + x47;
result[6] = x37 + x48;
result[7] = x34 + x47 + x51;
result[8] = x41 + x51;
result[9] = x23 + x48 + x50;
result[10] = 16.628925236306479*x1*x54*(x15 + x55) + 16.628925236306479*x1*(-x11 - x52) - x3 - x59 - 16.628925236306479*x1*x53/((n2)*(n2));
result[11] = x60;
result[12] = x60;
result[13] = x61;
result[14] = x61;
result[15] = x61;
result[16] = x14*(-x11 - x62) + x35 + x4 + x65*(x15 + x63) + x68 - x14*x66/((n3)*(n3));
result[17] = x14*(-x36 - x62) + x40 + x43 + x65*(x38 + x63) + x68;
result[18] = x14*(-x46 - x62) + x49 + x67;
result[19] = n4*x19 + x14*x69*(n4*x16 + x15) + x14*(-n4*x12 - x11) + x24 + x32 - x56 + 8.3144626181532395*x69*x70 - x14*x70/((n4)*(n4));
}
        
static double coder_dgdp(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = 1.0*n1*(*endmember[0].dmu0dP)(T, P) + 1.0*n2*(*endmember[1].dmu0dP)(T, P) + 1.0*n3*(*endmember[2].dmu0dP)(T, P) + 1.0*n4*(*endmember[3].dmu0dP)(T, P);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 1.0*(*endmember[0].dmu0dP)(T, P);
result[1] = 1.0*(*endmember[1].dmu0dP)(T, P);
result[2] = 1.0*(*endmember[2].dmu0dP)(T, P);
result[3] = 1.0*(*endmember[3].dmu0dP)(T, P);
}
        
static void coder_d3gdn2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = n1*(*endmember[0].d2mu0dT2)(T, P);
    double x1 = n2*(*endmember[1].d2mu0dT2)(T, P);
    double x2 = n3*(*endmember[2].d2mu0dT2)(T, P);
    double x3 = n4*(*endmember[3].d2mu0dT2)(T, P);
    double x4 = 0.19999999999999998*T - 1;
    double x5 = -x4;
    double x6 = sqrt(x5);
    double x7 = 1.0000000000000002*x6;
    double x8 = x7 - 4;
    double x9 = (-x8 >= 0. ? 1. : 0.);
    double x10 = 80.2881*T - 401.44049999999999;
    double x11 = 1.0/x4;
    double x12 = x11*0;
    double x13 = x9/pow(x5, 3.0/2.0);
    double x14 = fmin(4, x7);
    double x15 = ((x14)*(x14));

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3;
}
else {
   result = -0.33333333333333331*n2*(-0.010000000000000004*x10*x12 + 0.010000000000000002*x10*x13 + 8.0288100000000036*x11*x14*((x9)*(x9)) - 4.0144050000000018*x12*x15 + 4.014405*x13*x15 + 16.057620000000004*x9/x6) + 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3;
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = (*endmember[1].d2mu0dT2)(T, P);
    double x1 = 0.19999999999999998*T - 1;
    double x2 = -x1;
    double x3 = sqrt(x2);
    double x4 = 1.0000000000000002*x3;
    double x5 = x4 - 4;
    double x6 = (-x5 >= 0. ? 1. : 0.);
    double x7 = 80.2881*T - 401.44049999999999;
    double x8 = 1.0/x1;
    double x9 = 0;
    double x10 = x6/pow(x2, 3.0/2.0);
    double x11 = fmin(4, x4);
    double x12 = ((x11)*(x11));

result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
if (T >= 5.0) {
   result[1] = 1.0*x0;
}
else {
   result[1] = 1.0*x0 - 1.3381349999999999*x10*x12 - 0.003333333333333334*x10*x7 - 2.676270000000001*x11*((x6)*(x6))*x8 + 1.3381350000000005*x12*x8*x9 + 0.0033333333333333344*x7*x8*x9 - 5.3525400000000012*x6/x3;
}
result[2] = 1.0*(*endmember[2].d2mu0dT2)(T, P);
result[3] = 1.0*(*endmember[3].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P) + n3*(*endmember[2].d2mu0dTdP)(T, P) + n4*(*endmember[3].d2mu0dTdP)(T, P));
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dTdP)(T, P);
result[3] = 1.0*(*endmember[3].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P) + n3*(*endmember[2].d2mu0dP2)(T, P) + n4*(*endmember[3].d2mu0dP2)(T, P));
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dP2)(T, P);
result[3] = 1.0*(*endmember[3].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    
    double x0 = n1*(*endmember[0].d3mu0dT3)(T, P);
    double x1 = n2*(*endmember[1].d3mu0dT3)(T, P);
    double x2 = n3*(*endmember[2].d3mu0dT3)(T, P);
    double x3 = n4*(*endmember[3].d3mu0dT3)(T, P);
    double x4 = 0.19999999999999998*T - 1;
    double x5 = -x4;
    double x6 = 1.0000000000000002*sqrt(x5);
    double x7 = x6 - 4;
    double x8 = 0;
    double x9 = pow(x5, -3.0/2.0);
    double x10 = (-x7 >= 0. ? 1. : 0.);
    double x11 = x10*x9;
    double x12 = 80.2881*T - 401.44049999999999;
    double x13 = pow(x4, -2);
    double x14 = x13*x8;
    double x15 = x10/pow(x5, 5.0/2.0);
    double x16 = x9*0;
    double x17 = fmin(4, x6);
    double x18 = ((x17)*(x17));

if (T >= 5.0) {
   result = 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3;
}
else {
   result = -0.33333333333333331*n2*(0.80288100000000051*((x10)*(x10)*(x10))*x9 - 2.4086430000000005*((x10)*(x10))*x13*x17 - 2.4086430000000014*x11*x17*x8 + 2.4086430000000005*x11 + 0.0030000000000000009*x12*x14 + 0.0030000000000000005*x12*x15 - 0.0010000000000000005*x12*x16 + 1.2043215000000003*x14*x18 + 1.2043215*x15*x18 - 0.40144050000000026*x16*x18 - 2.408643000000001*x8/x4) + 1.0*x0 + 1.0*x1 + 1.0*x2 + 1.0*x3;
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];

    double x0 = 1.0*(*endmember[1].d3mu0dT3)(T, P);
    double x1 = 0.19999999999999998*T - 1;
    double x2 = -x1;
    double x3 = 1.0000000000000002*sqrt(x2);
    double x4 = x3 - 4;
    double x5 = 0;
    double x6 = pow(x2, -3.0/2.0);
    double x7 = (-x4 >= 0. ? 1. : 0.);
    double x8 = x6*x7;
    double x9 = 80.2881*T - 401.44049999999999;
    double x10 = pow(x1, -2);
    double x11 = x10*x5;
    double x12 = x7/pow(x2, 5.0/2.0);
    double x13 = x6*0;
    double x14 = fmin(4, x3);
    double x15 = ((x14)*(x14));

result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
if (T >= 5.0) {
   result[1] = x0;
}
else {
   result[1] = x0 + 0.80288100000000018*x10*x14*((x7)*(x7)) - 0.40144050000000009*x11*x15 - 0.0010000000000000002*x11*x9 - 0.40144049999999998*x12*x15 - 0.001*x12*x9 + 0.13381350000000009*x13*x15 + 0.00033333333333333348*x13*x9 + 0.8028810000000004*x14*x5*x8 - 0.26762700000000017*x6*((x7)*(x7)*(x7)) - 0.80288100000000018*x8 + 0.80288100000000029*x5/x1;
}
result[2] = 1.0*(*endmember[2].d3mu0dT3)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P) + n3*(*endmember[2].d3mu0dT2dP)(T, P) + n4*(*endmember[3].d3mu0dT2dP)(T, P));
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dT2dP)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P) + n3*(*endmember[2].d3mu0dTdP2)(T, P) + n4*(*endmember[3].d3mu0dTdP2)(T, P));
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dTdP2)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P) + n3*(*endmember[2].d3mu0dP3)(T, P) + n4*(*endmember[3].d3mu0dP3)(T, P));
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dP3)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[4], double result[4]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
}
        
static double coder_s(double T, double P, double n[4]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[4]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[4]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[4]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[4]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[4]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[4]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[4]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[4]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[4]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[4]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[4]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[4]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[4]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

