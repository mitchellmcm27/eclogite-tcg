#include <math.h>


static double coder_g(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n4 + n5;
    double x1 = n1 + n2 + n3;
    double x2 = x0 + x1;
    double x3 = 1.0/x2;
    double x4 = log(n5*x3);
    double x5 = n1 + n4;
    double x6 = n5 + x1;

result = 1.0*x3*(0.0625*n1*(240000.0*n3 + 170400.0*n4) + 0.0625*n3*(240000.0*n1 + 464000.0*n4) + 0.0625*n4*(170400.0*n1 + 464000.0*n3) + 1.0*x2*(8.3144626181532395*T*(3.0*n2*log(n2*x3) + 3.0*n3*log(n3*x3) + 1.0*n4*log(n4*x3) + 0.99999999900000003*n5*(x4 - 1.0986122896681101) + 1.9999999980000001*n5*(x4 - 0.40546510910816402) + 1.0*x0*log(x0*x3) + 1.0*x1*log(x1*x3) + 3.0*x5*log(x3*x5) + 1.0*x6*log(x3*x6)) + n1*(*endmember[0].mu0)(T, P) + n2*(*endmember[1].mu0)(T, P) + n3*(*endmember[2].mu0)(T, P) + n4*(*endmember[3].mu0)(T, P) + n5*(*endmember[4].mu0)(T, P)));
    return result;
}
        
static void coder_dgdn(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n1 + n4;
    double x1 = n2 + n3;
    double x2 = n5 + x0 + x1;
    double x3 = pow(x2, -2);
    double x4 = (*endmember[0].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[1].mu0)(T, P);
    double x7 = n2*x6;
    double x8 = (*endmember[2].mu0)(T, P);
    double x9 = n3*x8;
    double x10 = (*endmember[3].mu0)(T, P);
    double x11 = n4*x10;
    double x12 = (*endmember[4].mu0)(T, P);
    double x13 = n5*x12;
    double x14 = 1.0/x2;
    double x15 = n2*x14;
    double x16 = 3.0*log(x15);
    double x17 = n3*x14;
    double x18 = 3.0*log(x17);
    double x19 = n4*x14;
    double x20 = 1.0*log(x19);
    double x21 = n5*x14;
    double x22 = log(x21);
    double x23 = x0*x14;
    double x24 = 3.0*log(x23);
    double x25 = n4 + n5;
    double x26 = x14*x25;
    double x27 = log(x26);
    double x28 = 1.0*x27;
    double x29 = n1 + x1;
    double x30 = x14*x29;
    double x31 = 1.0*log(x30);
    double x32 = n5 + x29;
    double x33 = x14*x32;
    double x34 = log(x33);
    double x35 = 1.0*x34;
    double x36 = 8.3144626181532395*T;
    double x37 = x36*(n2*x16 + n3*x18 + n4*x20 + 0.99999999900000003*n5*(x22 - 1.0986122896681101) + 1.9999999980000001*n5*(x22 - 0.40546510910816402) + x0*x24 + x25*x28 + x29*x31 + x32*x35);
    double x38 = 1.0*x2;
    double x39 = 1.0*x3*(0.0625*n1*(240000.0*n3 + 170400.0*n4) + 0.0625*n3*(240000.0*n1 + 464000.0*n4) + 0.0625*n4*(170400.0*n1 + 464000.0*n3) + x38*(x11 + x13 + x37 + x5 + x7 + x9));
    double x40 = -x14;
    double x41 = 3.0*x2;
    double x42 = 3.0*x15;
    double x43 = -x42;
    double x44 = 3.0*x17;
    double x45 = -x44;
    double x46 = -2.9999999970000002*x21;
    double x47 = x24 + x41*(-x0*x3 - x40) + x43 + x45 + x46;
    double x48 = -x3*x32 - x40;
    double x49 = 1.0*x19;
    double x50 = -1.0*x26 + x31 + x35 + x38*x48 + x38*(-x29*x3 - x40) - x49;
    double x51 = 1.0*x11 + 1.0*x13 + x37 + 1.0*x5 + 1.0*x7 + 1.0*x9;
    double x52 = 3.0*x23;
    double x53 = x46 + x50 - x52;
    double x54 = -x25*x3 - x40;
    double x55 = 1.0*x30;

result[0] = 1.0*x14*(30000.0*n3 + 21300.0*n4 + x38*(x36*(x47 + x50) + x4) + x51) - x39;
result[1] = 1.0*x14*(x38*(x36*(x16 + x41*(-n2*x3 - x40) + x45 + x53) + x6) + x51) - x39;
result[2] = 1.0*x14*(30000.0*n1 + 58000.0*n4 + x38*(x36*(x18 + x41*(-n3*x3 - x40) + x43 + x53) + x8) + x51) - x39;
result[3] = 1.0*x14*(21300.0*n1 + 58000.0*n3 + x38*(x10 + x36*(x20 + x28 - 1.0*x33 + x38*x54 + x38*(-n4*x3 - x40) + x47 - x55)) + x51) - x39;
result[4] = 1.0*x14*(x38*(x12 + x36*(1.0*x2*x48 + 1.0*x2*x54 + 2.9999999970000002*x2*(-n5*x3 - x40) + 2.9999999970000002*x22 + 1.0*x27 + 1.0*x34 - x42 - x44 - x49 - x52 - x55 - 1.9095425059748956)) + x51) - x39;
}
        
static void coder_d2gdn2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n1 + n4;
    double x1 = n2 + n3;
    double x2 = n5 + x0 + x1;
    double x3 = pow(x2, -3);
    double x4 = (*endmember[0].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[1].mu0)(T, P);
    double x7 = n2*x6;
    double x8 = (*endmember[2].mu0)(T, P);
    double x9 = n3*x8;
    double x10 = (*endmember[3].mu0)(T, P);
    double x11 = n4*x10;
    double x12 = (*endmember[4].mu0)(T, P);
    double x13 = n5*x12;
    double x14 = 1.0/x2;
    double x15 = n2*x14;
    double x16 = 3.0*log(x15);
    double x17 = n3*x14;
    double x18 = 3.0*log(x17);
    double x19 = n4*x14;
    double x20 = 1.0*log(x19);
    double x21 = n5*x14;
    double x22 = log(x21);
    double x23 = x0*x14;
    double x24 = 3.0*log(x23);
    double x25 = n4 + n5;
    double x26 = x14*x25;
    double x27 = log(x26);
    double x28 = 1.0*x27;
    double x29 = n1 + x1;
    double x30 = x14*x29;
    double x31 = 1.0*log(x30);
    double x32 = n5 + x29;
    double x33 = x14*x32;
    double x34 = log(x33);
    double x35 = 1.0*x34;
    double x36 = 8.3144626181532395*T;
    double x37 = x36*(n2*x16 + n3*x18 + n4*x20 + 0.99999999900000003*n5*(x22 - 1.0986122896681101) + 1.9999999980000001*n5*(x22 - 0.40546510910816402) + x0*x24 + x25*x28 + x29*x31 + x32*x35);
    double x38 = 1.0*x2;
    double x39 = 2.0*x3*(0.0625*n1*(240000.0*n3 + 170400.0*n4) + 0.0625*n3*(240000.0*n1 + 464000.0*n4) + 0.0625*n4*(170400.0*n1 + 464000.0*n3) + x38*(x11 + x13 + x37 + x5 + x7 + x9));
    double x40 = pow(x2, -2);
    double x41 = -x14;
    double x42 = x0*x40;
    double x43 = 3.0*x2;
    double x44 = x43*(-x41 - x42);
    double x45 = 3.0*x15;
    double x46 = -x45;
    double x47 = 3.0*x17;
    double x48 = -x47;
    double x49 = -2.9999999970000002*x21;
    double x50 = x24 + x44 + x46 + x48 + x49;
    double x51 = x29*x40;
    double x52 = x38*(-x41 - x51);
    double x53 = x32*x40;
    double x54 = -x41 - x53;
    double x55 = x38*x54;
    double x56 = 1.0*x19;
    double x57 = -1.0*x26 + x31 + x35 + x52 + x55 - x56;
    double x58 = T*(x50 + x57);
    double x59 = 8.3144626181532395*x58;
    double x60 = 1.0*x11 + 1.0*x13 + x37 + 1.0*x5 + 1.0*x7 + 1.0*x9;
    double x61 = x40*(30000.0*n3 + 21300.0*n4 + x38*(x4 + x59) + x60);
    double x62 = n4*x40;
    double x63 = 1.0*x62;
    double x64 = 1.0*x53;
    double x65 = -x64;
    double x66 = n2*x40;
    double x67 = 3.0*x66;
    double x68 = 3.0*x42;
    double x69 = x67 - x68;
    double x70 = x63 + x65 + x69;
    double x71 = -2*x40;
    double x72 = 2*x3;
    double x73 = x0*x72;
    double x74 = x43*(x71 + x73) + x44/x0;
    double x75 = x70 + x74;
    double x76 = 5.0*x14;
    double x77 = x25*x40;
    double x78 = 1.0*x77;
    double x79 = 1.0*x51;
    double x80 = -x79;
    double x81 = n3*x40;
    double x82 = 3.0*x81;
    double x83 = n5*x40;
    double x84 = 2.9999999970000002*x83;
    double x85 = x82 + x84;
    double x86 = x78 + x80 + x85;
    double x87 = x29*x72;
    double x88 = x32*x72;
    double x89 = x38*(x71 + x88) + x55/x32;
    double x90 = x38*(x71 + x87) + x89 + x52/x29;
    double x91 = x86 + x90;
    double x92 = x76 + x91;
    double x93 = x2*x36;
    double x94 = 1.0*x14;
    double x95 = x43*(-x41 - x66);
    double x96 = 3.0*x23;
    double x97 = x49 + x57 - x96;
    double x98 = x16 + x48 + x95 + x97;
    double x99 = x36*x98;
    double x100 = 1.0*x6 + x99;
    double x101 = -x40;
    double x102 = x43*(x101 + x73);
    double x103 = x91 - x94;
    double x104 = 1.0*x4 + x59;
    double x105 = x104 + x93*(x102 + x103 + x70);
    double x106 = x38*(x6 + x99) + x60;
    double x107 = 1.0*x40;
    double x108 = -x106*x107;
    double x109 = x39 - 1.0*x61;
    double x110 = x43*(-x41 - x81);
    double x111 = x110 + x18 + x46 + x97;
    double x112 = x111*x36;
    double x113 = x112 + 1.0*x8;
    double x114 = 30000.0*n1 + 58000.0*n4 + x38*(x112 + x8) + x60;
    double x115 = -x107*x114;
    double x116 = x38*(x101 + x88);
    double x117 = x38*(x101 + x87);
    double x118 = x117 + x86;
    double x119 = x116 + x118;
    double x120 = x38*(-x41 - x62);
    double x121 = -x41 - x77;
    double x122 = x121*x38;
    double x123 = 1.0*x30;
    double x124 = x120 + x122 - x123 + x20 + x28 - 1.0*x33 + x50;
    double x125 = x124*x36;
    double x126 = 1.0*x10 + x125;
    double x127 = 21300.0*n1 + 58000.0*n3 + x38*(x10 + x125) + x60;
    double x128 = -x107*x127;
    double x129 = -2.9999999970000002*x14;
    double x130 = x102 + x129;
    double x131 = x118 + x89;
    double x132 = -x41 - x83;
    double x133 = 1.0*x121*x2 - x123 + 2.9999999970000002*x132*x2 + 1.0*x2*x54 + 2.9999999970000002*x22 + 1.0*x27 + 1.0*x34 - x45 - x47 - x56 - x96 - 1.9095425059748956;
    double x134 = x133*x36;
    double x135 = 1.0*x12 + x134;
    double x136 = x38*(x12 + x134) + x60;
    double x137 = -x107*x136;
    double x138 = 2.0*x40;
    double x139 = 16.628925236306479*T;
    double x140 = n2*x72;
    double x141 = x63 + x65 + x68;
    double x142 = x141 - x67;
    double x143 = x142 + x43*(x101 + x140);
    double x144 = x108 + x39;
    double x145 = -x76;
    double x146 = n3*x72;
    double x147 = x141 + x67;
    double x148 = x147 + x78 + x80 - x82 + x84;
    double x149 = x117 + x148 + x43*(x101 + x146);
    double x150 = x115 + x39;
    double x151 = n4*x72;
    double x152 = x122/x25 + x38*(x25*x72 + x71) - x78 + x79;
    double x153 = x152 - x63 + x64 + x69 + x85;
    double x154 = 2.9999999970000002*x2;

result[0] = x39 - 2.0*x61 + x94*(2.0*x4 + 16.628925236306479*x58 + x93*(x75 + x92));
result[1] = x108 + x109 + x94*(x100 + x105);
result[2] = x109 + x115 + x94*(x105 + x113 + 30000.0);
result[3] = x109 + x128 + x94*(x104 + x126 + x93*(x119 + x75 + x94) + 21300.0);
result[4] = x109 + x137 + x94*(x104 + x135 + x93*(x130 + x131 + x70));
result[5] = -x106*x138 + x39 + x94*(x139*x98 + 2.0*x6 + x93*(x142 + x43*(x140 + x71) + x92 + x95/n2));
result[6] = x115 + x144 + x94*(x100 + x113 + x93*(x103 + x143));
result[7] = x128 + x144 + x94*(x100 + x126 + x93*(x119 + x143 + x145));
result[8] = x137 + x144 + x94*(x100 + x135 + x93*(x129 + x131 + x143));
result[9] = -x114*x138 + x39 + x94*(x111*x139 + 2.0*x8 + x93*(x148 + x43*(x146 + x71) + x76 + x90 + x110/n3));
result[10] = x128 + x150 + x94*(x113 + x126 + x93*(x116 + x145 + x149) + 58000.0);
result[11] = x137 + x150 + x94*(x113 + x135 + x93*(x129 + x149 + x89));
result[12] = -x127*x138 + x39 + x94*(2.0*x10 + x124*x139 + x93*(x153 + x38*(x151 + x71) + x74 + x76 + x120/n4));
result[13] = x128 + x137 + x39 + x94*(x126 + x135 + x93*(x130 + x153 + x38*(x101 + x151)));
result[14] = -x136*x138 + x39 + x94*(2.0*x12 + x133*x139 + x93*(4.9999999969999998*x14 + x147 + x152 + x154*(n5*x72 + x71) + x82 - x84 + x89 + x132*x154/n5));
}
        
static void coder_d3gdn3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n4 + n5;
    double x1 = n1 + n2 + n3;
    double x2 = x0 + x1;
    double x3 = pow(x2, -4);
    double x4 = (*endmember[0].mu0)(T, P);
    double x5 = n1*x4;
    double x6 = (*endmember[1].mu0)(T, P);
    double x7 = n2*x6;
    double x8 = (*endmember[2].mu0)(T, P);
    double x9 = n3*x8;
    double x10 = (*endmember[3].mu0)(T, P);
    double x11 = n4*x10;
    double x12 = (*endmember[4].mu0)(T, P);
    double x13 = n5*x12;
    double x14 = 1.0/x2;
    double x15 = n2*x14;
    double x16 = 3.0*log(x15);
    double x17 = n3*x14;
    double x18 = 3.0*log(x17);
    double x19 = n4*x14;
    double x20 = 1.0*log(x19);
    double x21 = n5*x14;
    double x22 = log(x21);
    double x23 = n1 + n4;
    double x24 = x14*x23;
    double x25 = 3.0*log(x24);
    double x26 = x0*x14;
    double x27 = log(x26);
    double x28 = 1.0*x27;
    double x29 = x1*x14;
    double x30 = 1.0*log(x29);
    double x31 = n5 + x1;
    double x32 = x14*x31;
    double x33 = log(x32);
    double x34 = 1.0*x33;
    double x35 = 8.3144626181532395*T;
    double x36 = x35*(n2*x16 + n3*x18 + n4*x20 + 0.99999999900000003*n5*(x22 - 1.0986122896681101) + 1.9999999980000001*n5*(x22 - 0.40546510910816402) + x0*x28 + x1*x30 + x23*x25 + x31*x34);
    double x37 = 1.0*x2;
    double x38 = 6.0*x3*(0.0625*n1*(240000.0*n3 + 170400.0*n4) + 0.0625*n3*(240000.0*n1 + 464000.0*n4) + 0.0625*n4*(170400.0*n1 + 464000.0*n3) + x37*(x11 + x13 + x36 + x5 + x7 + x9));
    double x39 = -x38;
    double x40 = -x14;
    double x41 = pow(x2, -2);
    double x42 = x23*x41;
    double x43 = -x40 - x42;
    double x44 = 3.0*x2;
    double x45 = x43*x44;
    double x46 = 3.0*x15;
    double x47 = -x46;
    double x48 = 3.0*x17;
    double x49 = -x48;
    double x50 = -2.9999999970000002*x21;
    double x51 = x25 + x45 + x47 + x49 + x50;
    double x52 = x1*x41;
    double x53 = -x40 - x52;
    double x54 = x37*x53;
    double x55 = x31*x41;
    double x56 = -x40 - x55;
    double x57 = x37*x56;
    double x58 = 1.0*x19;
    double x59 = -1.0*x26 + x30 + x34 + x54 + x57 - x58;
    double x60 = x51 + x59;
    double x61 = x35*x60;
    double x62 = 1.0*x11 + 1.0*x13 + x36 + 1.0*x5 + 1.0*x7 + 1.0*x9;
    double x63 = 30000.0*n3 + 21300.0*n4 + x37*(x4 + x61) + x62;
    double x64 = pow(x2, -3);
    double x65 = 6.0*x64;
    double x66 = 16.628925236306479*T;
    double x67 = n4*x41;
    double x68 = 1.0*x67;
    double x69 = 1.0*x55;
    double x70 = -x69;
    double x71 = n2*x41;
    double x72 = 3.0*x71;
    double x73 = 3.0*x42;
    double x74 = x72 - x73;
    double x75 = x68 + x70 + x74;
    double x76 = -2*x41;
    double x77 = 2*x64;
    double x78 = x23*x77;
    double x79 = x44*(x76 + x78);
    double x80 = 1.0/x23;
    double x81 = x43*x80;
    double x82 = x44*x81 + x79;
    double x83 = x75 + x82;
    double x84 = 5.0*x14;
    double x85 = x0*x41;
    double x86 = 1.0*x85;
    double x87 = 1.0*x52;
    double x88 = -x87;
    double x89 = n3*x41;
    double x90 = 3.0*x89;
    double x91 = n5*x41;
    double x92 = 2.9999999970000002*x91;
    double x93 = x90 + x92;
    double x94 = x86 + x88 + x93;
    double x95 = x1*x77;
    double x96 = x37*(x76 + x95);
    double x97 = 1.0/x1;
    double x98 = x53*x97;
    double x99 = x31*x77;
    double x100 = x37*(x76 + x99);
    double x101 = 1.0/x31;
    double x102 = x101*x56;
    double x103 = x100 + x102*x37;
    double x104 = x103 + x37*x98 + x96;
    double x105 = x104 + x94;
    double x106 = x105 + x84;
    double x107 = T*(x106 + x83);
    double x108 = 8.3144626181532395*x107;
    double x109 = x108*x2 + 2.0*x4 + x60*x66;
    double x110 = 3.0*x41;
    double x111 = -6*x64;
    double x112 = 6*x3;
    double x113 = x112*x23;
    double x114 = -n2*x65;
    double x115 = 12.0*x64;
    double x116 = x114 + x115*x23;
    double x117 = x116 + 3.0*x81;
    double x118 = x117 + x44*(-x111 - x113) + x79*x80 - x45/((x23)*(x23));
    double x119 = 1.0*x102;
    double x120 = 4.0*x64;
    double x121 = x1*x120;
    double x122 = 2.0*x64;
    double x123 = -x0*x122;
    double x124 = -n3*x65;
    double x125 = n5*x64;
    double x126 = -5.9999999940000004*x125;
    double x127 = x124 + x126;
    double x128 = x121 + x123 + x127;
    double x129 = x112*x31;
    double x130 = x100*x101 + x37*(-x111 - x129) - x57/((x31)*(x31));
    double x131 = x128 + x130;
    double x132 = x119 + x131;
    double x133 = 1.0*x98;
    double x134 = x120*x31;
    double x135 = -n4*x122;
    double x136 = x134 + x135;
    double x137 = x133 + x136;
    double x138 = x132 + x137;
    double x139 = -20.0*x41;
    double x140 = x1*x112;
    double x141 = x37*(-x111 - x140) + x96*x97 - x54/((x1)*(x1));
    double x142 = x139 + x141;
    double x143 = x2*x35;
    double x144 = 1.0*x14;
    double x145 = -x40 - x71;
    double x146 = x145*x44;
    double x147 = 3.0*x24;
    double x148 = -x147 + x50 + x59;
    double x149 = x146 + x148 + x16 + x49;
    double x150 = x149*x35;
    double x151 = x37*(x150 + x6) + x62;
    double x152 = -2.0*x151*x64;
    double x153 = x150 + 1.0*x6;
    double x154 = -x41;
    double x155 = x44*(x154 + x78);
    double x156 = x105 - x144;
    double x157 = x155 + x156 + x75;
    double x158 = x157*x35;
    double x159 = 1.0*x4 + x61;
    double x160 = x158*x2 + x159;
    double x161 = x153 + x160;
    double x162 = 2.0*x41;
    double x163 = x161*x162 + x38;
    double x164 = x157*x66;
    double x165 = -4*x64;
    double x166 = x44*(-x113 - x165);
    double x167 = x117 + x155*x80 + x166;
    double x168 = x138 + x167;
    double x169 = x141 - 14.0*x41;
    double x170 = 1.0*x41;
    double x171 = x109*x170 - 4.0*x63*x64;
    double x172 = -1.0*x14*(x108 + x143*(x168 + x169) + x164) + x171;
    double x173 = -x40 - x89;
    double x174 = x173*x44;
    double x175 = x148 + x174 + x18 + x47;
    double x176 = x175*x35;
    double x177 = 30000.0*n1 + 58000.0*n4 + x37*(x176 + x8) + x62;
    double x178 = -2.0*x177*x64;
    double x179 = x176 + 1.0*x8;
    double x180 = x160 + x179 + 30000.0;
    double x181 = x162*x180 + x38;
    double x182 = x37*(x154 + x99);
    double x183 = x37*(x154 + x95);
    double x184 = x183 + x94;
    double x185 = x182 + x184;
    double x186 = x144 + x185 + x83;
    double x187 = x186*x35;
    double x188 = -x40 - x67;
    double x189 = x188*x37;
    double x190 = -x40 - x85;
    double x191 = x190*x37;
    double x192 = 1.0*x29;
    double x193 = x189 + x191 - x192 + x20 + x28 - 1.0*x32 + x51;
    double x194 = x193*x35;
    double x195 = 1.0*x10 + x194;
    double x196 = x159 + x187*x2 + x195 + 21300.0;
    double x197 = x162*x196;
    double x198 = x186*x66;
    double x199 = x37*(-x129 - x165);
    double x200 = x128 + x199;
    double x201 = x183*x97 + x37*(-x140 - x165);
    double x202 = x101*x182 + x201;
    double x203 = x200 + x202;
    double x204 = x137 + x203;
    double x205 = 21300.0*n1 + 58000.0*n3 + x37*(x10 + x194) + x62;
    double x206 = -2.0*x205*x64;
    double x207 = x171 + x38;
    double x208 = -2.9999999970000002*x14;
    double x209 = x155 + x208;
    double x210 = x103 + x184;
    double x211 = x209 + x210 + x75;
    double x212 = x211*x35;
    double x213 = -x40 - x91;
    double x214 = -x147 + 1.0*x190*x2 - x192 + 2.9999999970000002*x2*x213 + 1.0*x2*x56 + 2.9999999970000002*x22 + 1.0*x27 + 1.0*x33 - x46 - x48 - x58 - 1.9095425059748956;
    double x215 = x214*x35;
    double x216 = 1.0*x12 + x215;
    double x217 = x159 + x2*x212 + x216;
    double x218 = x162*x217;
    double x219 = x211*x66;
    double x220 = -12.000000003*x41;
    double x221 = x201 + x220;
    double x222 = x37*(x12 + x215) + x62;
    double x223 = -2.0*x222*x64;
    double x224 = n2*x77;
    double x225 = x44*(x224 + x76);
    double x226 = 1.0/n2;
    double x227 = x68 + x70 + x73;
    double x228 = x227 - x72;
    double x229 = x106 + x146*x226 + x225 + x228;
    double x230 = x229*x35;
    double x231 = -2*x64;
    double x232 = x44*(-x113 - x231);
    double x233 = x116 + x119;
    double x234 = x131 + x233;
    double x235 = x137 + x232 + x234;
    double x236 = 5.0*x41;
    double x237 = x141 - x236;
    double x238 = x143*(x235 + x237) + x164;
    double x239 = -2.0*x63*x64;
    double x240 = x149*x66 + x2*x230 + 2.0*x6;
    double x241 = -4.0*x151*x64 + x170*x240;
    double x242 = x122*x151;
    double x243 = x122*x177;
    double x244 = x44*(x154 + x224);
    double x245 = x228 + x244;
    double x246 = x156 + x245;
    double x247 = x246*x35;
    double x248 = x161*x170;
    double x249 = x153 + x179 + x2*x247;
    double x250 = x170*x249;
    double x251 = x170*x180;
    double x252 = x122*x63 + x39;
    double x253 = -x84;
    double x254 = x185 + x245 + x253;
    double x255 = x254*x35;
    double x256 = x153 + x195 + x2*x255;
    double x257 = x170*x256;
    double x258 = x143*(x166 + x204 + x233 - 7.0*x41) + x158 + x187;
    double x259 = x152 + x239 + x248;
    double x260 = x170*x196 + x206;
    double x261 = x260 + x38;
    double x262 = x208 + x210 + x245;
    double x263 = x262*x35;
    double x264 = x153 + x2*x263 + x216;
    double x265 = x170*x264;
    double x266 = x201 - 3.0000000029999998*x41;
    double x267 = x143*(x235 + x266) + x158 + x212;
    double x268 = x223 + x38;
    double x269 = x170*x217 + x268;
    double x270 = n3*x77;
    double x271 = x44*(x270 + x76);
    double x272 = 1.0/n3;
    double x273 = x227 + x72;
    double x274 = x273 + x86 + x88 - x90 + x92;
    double x275 = x104 + x174*x272 + x271 + x274 + x84;
    double x276 = x275*x35;
    double x277 = x175*x66 + x2*x276 + 2.0*x8;
    double x278 = x170*x277 - 4.0*x177*x64;
    double x279 = x44*(x154 + x270);
    double x280 = x183 + x274 + x279;
    double x281 = x182 + x253 + x280;
    double x282 = x281*x35;
    double x283 = x179 + x195 + x2*x282 + 58000.0;
    double x284 = x170*x283 + x178;
    double x285 = x239 + x251;
    double x286 = x103 + x208 + x280;
    double x287 = x286*x35;
    double x288 = x179 + x2*x287 + x216;
    double x289 = x170*x288;
    double x290 = x178 + x289;
    double x291 = n4*x77;
    double x292 = x37*(x291 + x76);
    double x293 = 1.0/n4;
    double x294 = x37*(x0*x77 + x76);
    double x295 = 1.0/x0;
    double x296 = x191*x295 + x294 - x86 + x87;
    double x297 = x296 - x68 + x69 + x74 + x93;
    double x298 = x189*x293 + x292 + x297 + x82 + x84;
    double x299 = x298*x35;
    double x300 = -10.0*x41;
    double x301 = x37*(-x129 - x231);
    double x302 = x128 + x301;
    double x303 = x37*(-x140 - x231);
    double x304 = x136 + x303;
    double x305 = 2.0*x10 + x193*x66 + x2*x299;
    double x306 = x170*x305;
    double x307 = x120*x205 - x306;
    double x308 = x37*(x154 + x291);
    double x309 = x209 + x297 + x308;
    double x310 = x309*x35;
    double x311 = x195 + x2*x310 + x216;
    double x312 = x170*x311;
    double x313 = 2.9999999970000002*x2;
    double x314 = x313*(n5*x77 + x76);
    double x315 = 1.0/n5;
    double x316 = x213*x313;
    double x317 = x103 + 4.9999999969999998*x14 + x273 + x296 + x314 + x315*x316 + x90 - x92;
    double x318 = x317*x35;
    double x319 = -5.9999996082638063e-9*x41;
    double x320 = x232 + x319;
    double x321 = 2.0*x12 + x2*x318 + x214*x66;
    double x322 = x120*x222 - x170*x321;
    double x323 = 24.943387854459719*T;
    double x324 = n2*x112;
    double x325 = n2*x115;
    double x326 = 3.0*x145*x226 + x325;
    double x327 = x134 + x135 - x23*x65;
    double x328 = x133 + x327;
    double x329 = x142 + x328;
    double x330 = x162*x249;
    double x331 = x246*x66;
    double x332 = x226*x244 + x326 + x44*(-x165 - x324);
    double x333 = x132 + x332;
    double x334 = x241 + x38;
    double x335 = x162*x256;
    double x336 = x254*x66;
    double x337 = x119 + x328;
    double x338 = x162*x264;
    double x339 = x262*x66;
    double x340 = x221 + x328;
    double x341 = x325 + x44*(-x231 - x324);
    double x342 = x132 + x341;
    double x343 = x328 + x342;
    double x344 = x278 + x38;
    double x345 = x200 + x341;
    double x346 = x202 + x337;
    double x347 = x152 + x250;
    double x348 = x206 + x284;
    double x349 = x265 + x268;
    double x350 = x303 + x327;
    double x351 = x236 + x350;
    double x352 = x242 + x39;
    double x353 = x350 + 2.9999999970000002*x41;
    double x354 = x319 + x350;
    double x355 = n3*x112;
    double x356 = x119 + x130;
    double x357 = n3*x115 + x114 + x121 + x123 + x126;
    double x358 = 3.0*x173*x272 + x357;
    double x359 = x162*x283;
    double x360 = x281*x66;
    double x361 = x272*x279 + x358 + x44*(-x165 - x355);
    double x362 = x162*x288;
    double x363 = x286*x66;
    double x364 = x357 + x44*(-x231 - x355);
    double x365 = x243 + x39;
    double x366 = n4*x112;
    double x367 = x0*x120 - x1*x122 + 1.0*x190*x295 + x294*x295 + x37*(-x0*x112 - x111) - x191/((x0)*(x0));
    double x368 = n4*x120 - x122*x31 + x127 + x367;
    double x369 = 1.0*x188*x293 + x368;
    double x370 = x162*x311;
    double x371 = x309*x66;

result[0] = -x109*x110 + x144*(24.943387854459719*x107 + x143*(x118 + x138 + x142)) + x39 + x63*x65;
result[1] = -x152 - x163 - x172;
result[2] = -x172 - x178 - x181;
result[3] = 1.0*x14*(x108 + x143*(x118 + x119 + x204 - 16.0*x41) + x198) - x197 - x206 - x207;
result[4] = 1.0*x14*(x108 + x143*(x168 + x221) + x219) - x207 - x218 - x223;
result[5] = 1.0*x14*(x230 + x238) - x163 - x239 - x241;
result[6] = x144*(x238 + x247) + x242 + x243 - x248 - x250 - x251 + x252;
result[7] = 1.0*x14*(x255 + x258) - x257 - x259 - x261;
result[8] = 1.0*x14*(x263 + x267) - x259 - x265 - x269;
result[9] = 1.0*x14*(x238 + x276) - x181 - x239 - x278;
result[10] = 1.0*x14*(x258 + x282) - x261 - x284 - x285;
result[11] = 1.0*x14*(x267 + x287) - x269 - x285 - x290;
result[12] = x144*(x143*(x118 + x300 + x302 + x304) + x198 + x299) - x197 + x252 + x307;
result[13] = 1.0*x14*(x143*(x167 + x200 + x304 - 6.0000000030000002*x41) + x187 + x212 + x310) - x239 - x260 - x269 - x312;
result[14] = x144*(x143*(x234 + x304 + x320) + x219 + x318) - x218 + x252 + x322;
result[15] = -x110*x240 + x144*(x143*(x132 + x225*x226 + x326 + x329 + x44*(-x111 - x324) - x146/((n2)*(n2))) + x229*x323) + x151*x65 + x39;
result[16] = 1.0*x14*(x143*(x169 + x328 + x333) + x230 + x331) - x178 - x330 - x334;
result[17] = 1.0*x14*(x143*(x203 + x300 + x332 + x337) + x230 + x336) - x206 - x334 - x335;
result[18] = 1.0*x14*(x143*(x333 + x340) + x230 + x339) - x223 - x334 - x338;
result[19] = 1.0*x14*(x143*(x237 + x343) + x276 + x331) - x152 - x330 - x344;
result[20] = 1.0*x14*(x143*(-x170 + x345 + x346) + x247 + x255 + x282) - x257 - x347 - x348 - x38;
result[21] = 1.0*x14*(x143*(x266 + x343) + x247 + x263 + x287) - x290 - x347 - x349;
result[22] = x144*(x143*(x302 + x341 + x351) + x299 + x336) + x307 - x335 + x352;
result[23] = 1.0*x14*(x143*(x345 + x353) + x255 + x263 + x310) - x152 - x206 - x257 - x312 - x349;
result[24] = x144*(x143*(x342 + x354) + x318 + x339) + x322 - x338 + x352;
result[25] = -x110*x277 + x144*(x143*(x271*x272 + x329 + x356 + x358 + x44*(-x111 - x355) - x174/((n3)*(n3))) + x275*x323) + x177*x65 + x39;
result[26] = 1.0*x14*(x143*(x199 + x300 + x346 + x361) + x276 + x360) - x206 - x344 - x359;
result[27] = 1.0*x14*(x143*(x340 + x356 + x361) + x276 + x363) - x223 - x344 - x362;
result[28] = x144*(x143*(x301 + x351 + x364) + x299 + x360) + x307 - x359 + x365;
result[29] = 1.0*x14*(x143*(x199 + x353 + x364) + x282 + x287 + x310) - x268 - x289 - x312 - x348;
result[30] = x144*(x143*(x354 + x356 + x364) + x318 + x363) + x322 - x362 + x365;
result[31] = -x110*x305 + x144*(x143*(x118 + x139 + x292*x293 + x369 + x37*(-x111 - x366) - x189/((n4)*(n4))) + x298*x323) + x205*x65 + x39;
result[32] = 1.0*x14*(x143*(x167 + x220 + x293*x308 + x369 + x37*(-x165 - x366)) + x299 + x371) + 4.0*x205*x64 - x268 - x306 - x370;
result[33] = x122*x205 + x144*(x143*(x116 + x320 + x368 + x37*(-x231 - x366)) + x318 + x371) + x322 - x370 + x39;
result[34] = -x110*x321 + x144*(x143*(x114 + x124 + 11.999999988000001*x125 + 2.9999999970000002*x213*x315 + x313*(-n5*x112 - x111) + x314*x315 + x327 + x356 + x367 - 19.999999987999999*x41 - x316/((n5)*(n5))) + x317*x323) + x222*x65 + x39;
}
        
static double coder_dgdt(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    
    double x0 = n4 + n5;
    double x1 = n1 + n2 + n3;
    double x2 = 1.0/(x0 + x1);
    double x3 = log(n5*x2);
    double x4 = n1 + n4;
    double x5 = n5 + x1;

result = 1.0*n1*(*endmember[0].dmu0dT)(T, P) + 24.943387854459719*n2*log(n2*x2) + 1.0*n2*(*endmember[1].dmu0dT)(T, P) + 24.943387854459719*n3*log(n3*x2) + 1.0*n3*(*endmember[2].dmu0dT)(T, P) + 8.3144626181532395*n4*log(n4*x2) + 1.0*n4*(*endmember[3].dmu0dT)(T, P) + 8.3144626098387775*n5*(x3 - 1.0986122896681101) + 16.628925219677555*n5*(x3 - 0.40546510910816402) + 1.0*n5*(*endmember[4].dmu0dT)(T, P) + 8.3144626181532395*x0*log(x0*x2) + 8.3144626181532395*x1*log(x1*x2) + 24.943387854459719*x4*log(x2*x4) + 8.3144626181532395*x5*log(x2*x5);
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n1 + n4;
    double x1 = n2 + n3;
    double x2 = n5 + x0 + x1;
    double x3 = 1.0/x2;
    double x4 = x0*x3;
    double x5 = -x3;
    double x6 = pow(x2, -2);
    double x7 = 24.943387854459719*x2;
    double x8 = n5*x3;
    double x9 = -24.943387829516332*x8;
    double x10 = n2*x3;
    double x11 = -24.943387854459719*x10;
    double x12 = n3*x3;
    double x13 = -24.943387854459719*x12;
    double x14 = x11 + x13 + x7*(-x0*x6 - x5) + x9 + 24.943387854459719*log(x4);
    double x15 = n1 + x1;
    double x16 = x15*x3;
    double x17 = 8.3144626181532395*x2;
    double x18 = n4 + n5;
    double x19 = x18*x3;
    double x20 = n5 + x15;
    double x21 = x20*x3;
    double x22 = n4*x3;
    double x23 = x17*(-x20*x6 - x5) - 8.3144626181532395*x22 + 8.3144626181532395*log(x21);
    double x24 = x17*(-x15*x6 - x5) - 8.3144626181532395*x19 + x23 + 8.3144626181532395*log(x16);
    double x25 = -24.943387854459719*x4;
    double x26 = x13 + x25;
    double x27 = x24 + x9;
    double x28 = -8.3144626181532395*x16 + x17*(-x18*x6 - x5) + 8.3144626181532395*log(x19);

result[0] = x14 + x24 + 1.0*(*endmember[0].dmu0dT)(T, P);
result[1] = x26 + x27 + x7*(-n2*x6 - x5) + 24.943387854459719*log(x10) + 1.0*(*endmember[1].dmu0dT)(T, P);
result[2] = x11 + x25 + x27 + x7*(-n3*x6 - x5) + 24.943387854459719*log(x12) + 1.0*(*endmember[2].dmu0dT)(T, P);
result[3] = x14 + x17*(-n4*x6 - x5) - 8.3144626181532395*x21 + x28 + 8.3144626181532395*log(x22) + 1.0*(*endmember[3].dmu0dT)(T, P);
result[4] = x11 + 24.943387829516332*x2*(-n5*x6 - x5) + x23 + x26 + x28 + 24.943387829516332*log(x8) + 1.0*(*endmember[4].dmu0dT)(T, P) - 15.876819783702929;
}
        
static void coder_d3gdn2dt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n4 + n5;
    double x1 = n1 + n2 + n3;
    double x2 = x0 + x1;
    double x3 = pow(x2, -2);
    double x4 = n4*x3;
    double x5 = 8.3144626181532395*x4;
    double x6 = n5 + x1;
    double x7 = x3*x6;
    double x8 = 8.3144626181532395*x7;
    double x9 = -x8;
    double x10 = n2*x3;
    double x11 = 24.943387854459719*x10;
    double x12 = n1 + n4;
    double x13 = x12*x3;
    double x14 = 24.943387854459719*x13;
    double x15 = x11 - x14;
    double x16 = x15 + x5 + x9;
    double x17 = -2*x3;
    double x18 = 2/((x2)*(x2)*(x2));
    double x19 = x12*x18;
    double x20 = 24.943387854459719*x2;
    double x21 = 1.0/x2;
    double x22 = -x21;
    double x23 = x20*(x17 + x19) + x20*(-x13 - x22)/x12;
    double x24 = x16 + x23;
    double x25 = 41.572313090766201*x21;
    double x26 = x0*x3;
    double x27 = 8.3144626181532395*x26;
    double x28 = x1*x3;
    double x29 = 8.3144626181532395*x28;
    double x30 = -x29;
    double x31 = n5*x3;
    double x32 = 24.943387829516332*x31;
    double x33 = n3*x3;
    double x34 = 24.943387854459719*x33;
    double x35 = x32 + x34;
    double x36 = x27 + x30 + x35;
    double x37 = x1*x18;
    double x38 = 8.3144626181532395*x2;
    double x39 = x18*x6;
    double x40 = x38*(x17 + x39) + x38*(-x22 - x7)/x6;
    double x41 = x38*(x17 + x37) + x40 + x38*(-x22 - x28)/x1;
    double x42 = x36 + x41;
    double x43 = x25 + x42;
    double x44 = -x3;
    double x45 = x20*(x19 + x44);
    double x46 = 8.3144626181532395*x21;
    double x47 = x42 - x46;
    double x48 = x16 + x45 + x47;
    double x49 = x38*(x39 + x44);
    double x50 = x38*(x37 + x44);
    double x51 = x36 + x50;
    double x52 = x49 + x51;
    double x53 = -24.943387829516332*x21;
    double x54 = x45 + x53;
    double x55 = x40 + x51;
    double x56 = n2*x18;
    double x57 = x14 + x5 + x9;
    double x58 = -x11 + x57;
    double x59 = x20*(x44 + x56) + x58;
    double x60 = -x25;
    double x61 = n3*x18;
    double x62 = x11 + x57;
    double x63 = x27 + x30 + x32 - x34 + x62;
    double x64 = x20*(x44 + x61) + x50 + x63;
    double x65 = n4*x18;
    double x66 = -x27 + x29 + x38*(x0*x18 + x17) + x38*(-x22 - x26)/x0;
    double x67 = x15 + x35 - x5 + x66 + x8;
    double x68 = 24.943387829516332*x2;

result[0] = x24 + x43;
result[1] = x48;
result[2] = x48;
result[3] = x24 + x46 + x52;
result[4] = x16 + x54 + x55;
result[5] = x20*(x17 + x56) + x43 + x58 + x20*(-x10 - x22)/n2;
result[6] = x47 + x59;
result[7] = x52 + x59 + x60;
result[8] = x53 + x55 + x59;
result[9] = x20*(x17 + x61) + x25 + x41 + x63 + x20*(-x22 - x33)/n3;
result[10] = x49 + x60 + x64;
result[11] = x40 + x53 + x64;
result[12] = x23 + x25 + x38*(x17 + x65) + x67 + x38*(-x22 - x4)/n4;
result[13] = x38*(x44 + x65) + x54 + x67;
result[14] = 41.572313065822811*x21 - x32 + x34 + x40 + x62 + x66 + x68*(n5*x18 + x17) + x68*(-x22 - x31)/n5;
}
        
static void coder_d4gdn3dt(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];

    double x0 = n1 + n4;
    double x1 = n2 + n3;
    double x2 = n5 + x0 + x1;
    double x3 = pow(x2, -3);
    double x4 = -6*x3;
    double x5 = 6/((x2)*(x2)*(x2)*(x2));
    double x6 = x0*x5;
    double x7 = 24.943387854459719*x2;
    double x8 = pow(x2, -2);
    double x9 = -2*x8;
    double x10 = 2*x3;
    double x11 = x0*x10;
    double x12 = 24.943387854459719/x0;
    double x13 = x12*x2;
    double x14 = -1/x2;
    double x15 = -x0*x8 - x14;
    double x16 = 49.886775708919437*x3;
    double x17 = -n2*x16;
    double x18 = 99.773551417838874*x3;
    double x19 = x0*x18 + x17;
    double x20 = x12*x15 + x19;
    double x21 = x13*(x11 + x9) + x20 + x7*(-x4 - x6) - x15*x7/((x0)*(x0));
    double x22 = n1 + x1;
    double x23 = n5 + x22;
    double x24 = -x14 - x23*x8;
    double x25 = 8.3144626181532395/x23;
    double x26 = x24*x25;
    double x27 = 33.257850472612958*x3;
    double x28 = x22*x27;
    double x29 = n4 + n5;
    double x30 = 16.628925236306479*x3;
    double x31 = -x29*x30;
    double x32 = n5*x3;
    double x33 = -49.886775659032665*x32;
    double x34 = -n3*x16;
    double x35 = x33 + x34;
    double x36 = x28 + x31 + x35;
    double x37 = x23*x5;
    double x38 = 8.3144626181532395*x2;
    double x39 = x10*x23;
    double x40 = x2*x25;
    double x41 = x38*(-x37 - x4) + x40*(x39 + x9) - x24*x38/((x23)*(x23));
    double x42 = x36 + x41;
    double x43 = x26 + x42;
    double x44 = -x14 - x22*x8;
    double x45 = 8.3144626181532395/x22;
    double x46 = x44*x45;
    double x47 = x23*x27;
    double x48 = -n4*x30;
    double x49 = x47 + x48;
    double x50 = x46 + x49;
    double x51 = x43 + x50;
    double x52 = -166.2892523630648*x8;
    double x53 = x22*x5;
    double x54 = x10*x22;
    double x55 = x2*x45;
    double x56 = x38*(-x4 - x53) + x55*(x54 + x9) - x38*x44/((x22)*(x22));
    double x57 = x52 + x56;
    double x58 = -4*x3;
    double x59 = x7*(-x58 - x6);
    double x60 = -x8;
    double x61 = x13*(x11 + x60) + x20 + x59;
    double x62 = x51 + x61;
    double x63 = x56 - 116.40247665414537*x8;
    double x64 = x62 + x63;
    double x65 = x38*(-x37 - x58);
    double x66 = x36 + x65;
    double x67 = x38*(-x53 - x58) + x55*(x54 + x60);
    double x68 = x40*(x39 + x60) + x67;
    double x69 = x66 + x68;
    double x70 = x50 + x69;
    double x71 = -99.773551442782264*x8;
    double x72 = x67 + x71;
    double x73 = -2*x3;
    double x74 = x7*(-x6 - x73);
    double x75 = x19 + x26;
    double x76 = x42 + x75;
    double x77 = x50 + x74 + x76;
    double x78 = 41.572313090766201*x8;
    double x79 = x56 - x78;
    double x80 = x77 + x79;
    double x81 = x59 + x70 + x75 - 58.201238327072673*x8;
    double x82 = x67 - 24.943387879403105*x8;
    double x83 = x77 + x82;
    double x84 = x38*(-x37 - x73);
    double x85 = x36 + x84;
    double x86 = x38*(-x53 - x73);
    double x87 = x49 + x86;
    double x88 = -4.9886779152075178e-8*x8;
    double x89 = x74 + x88;
    double x90 = n2*x5;
    double x91 = n2*x10;
    double x92 = 1.0/n2;
    double x93 = x7*x92;
    double x94 = -n2*x8 - x14;
    double x95 = n2*x18;
    double x96 = 24.943387854459719*x92*x94 + x95;
    double x97 = -x0*x16 + x47 + x48;
    double x98 = x46 + x97;
    double x99 = x57 + x98;
    double x100 = x7*(-x58 - x90) + x93*(x60 + x91) + x96;
    double x101 = x100 + x43;
    double x102 = -83.144626181532402*x8;
    double x103 = x26 + x98;
    double x104 = x72 + x98;
    double x105 = x7*(-x73 - x90) + x95;
    double x106 = x105 + x43;
    double x107 = x106 + x98;
    double x108 = x105 + x66;
    double x109 = x103 + x68;
    double x110 = x86 + x97;
    double x111 = x110 + x78;
    double x112 = x110 + 24.943387829516329*x8;
    double x113 = x110 + x88;
    double x114 = n3*x5;
    double x115 = n3*x10;
    double x116 = 1.0/n3;
    double x117 = x116*x7;
    double x118 = -n3*x8 - x14;
    double x119 = x26 + x41;
    double x120 = n3*x18 + x17 + x28 + x31 + x33;
    double x121 = 24.943387854459719*x116*x118 + x120;
    double x122 = x117*(x115 + x60) + x121 + x7*(-x114 - x58);
    double x123 = x120 + x7*(-x114 - x73);
    double x124 = n4*x5;
    double x125 = n4*x10;
    double x126 = 1.0/n4;
    double x127 = x126*x38;
    double x128 = -n4*x8 - x14;
    double x129 = 1.0/x29;
    double x130 = -x14 - x29*x8;
    double x131 = 8.3144626181532395*x129*x130 + x129*x38*(x10*x29 + x9) - x130*x38/((x29)*(x29)) - x22*x30 + x27*x29 + x38*(-x29*x5 - x4);
    double x132 = n4*x27 + x131 - x23*x30 + x35;
    double x133 = 8.3144626181532395*x126*x128 + x132;
    double x134 = -n5*x8 - x14;
    double x135 = 24.943387829516332/n5;
    double x136 = 24.943387829516332*x2;

result[0] = x21 + x51 + x57;
result[1] = x64;
result[2] = x64;
result[3] = x21 + x26 + x70 - 133.03140189045183*x8;
result[4] = x62 + x72;
result[5] = x80;
result[6] = x80;
result[7] = x81;
result[8] = x83;
result[9] = x80;
result[10] = x81;
result[11] = x83;
result[12] = x21 - 83.144626181532388*x8 + x85 + x87;
result[13] = x61 + x66 - 49.886775733862819*x8 + x87;
result[14] = x76 + x87 + x89;
result[15] = x43 + x7*(-x4 - x90) + x93*(x9 + x91) + x96 + x99 - x7*x94/((n2)*(n2));
result[16] = x101 + x63 + x98;
result[17] = x100 + x102 + x103 + x69;
result[18] = x101 + x104;
result[19] = x107 + x79;
result[20] = x108 + x109 - 8.3144626181532395*x8;
result[21] = x107 + x82;
result[22] = x105 + x111 + x85;
result[23] = x108 + x112;
result[24] = x106 + x113;
result[25] = x117*(x115 + x9) + x119 + x121 + x7*(-x114 - x4) + x99 - x118*x7/((n3)*(n3));
result[26] = x102 + x109 + x122 + x65;
result[27] = x104 + x119 + x122;
result[28] = x111 + x123 + x84;
result[29] = x112 + x123 + x65;
result[30] = x113 + x119 + x123;
result[31] = x127*(x125 + x9) + x133 + x21 + x38*(-x124 - x4) + x52 - x128*x38/((n4)*(n4));
result[32] = x127*(x125 + x60) + x133 + x38*(-x124 - x58) + x61 + x71;
result[33] = x132 + x19 + x38*(-x124 - x73) + x89;
result[34] = x119 + x131 + x134*x135 + x135*x2*(n5*x10 + x9) + x136*(-n5*x5 - x4) + x17 + 99.77355131806533*x32 + x34 - 166.28925226329125*x8 + x97 - x134*x136/((n5)*(n5));
}
        
static double coder_dgdp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = 1.0*n1*(*endmember[0].dmu0dP)(T, P) + 1.0*n2*(*endmember[1].dmu0dP)(T, P) + 1.0*n3*(*endmember[2].dmu0dP)(T, P) + 1.0*n4*(*endmember[3].dmu0dP)(T, P) + 1.0*n5*(*endmember[4].dmu0dP)(T, P);
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].dmu0dP)(T, P);
result[1] = 1.0*(*endmember[1].dmu0dP)(T, P);
result[2] = 1.0*(*endmember[2].dmu0dP)(T, P);
result[3] = 1.0*(*endmember[3].dmu0dP)(T, P);
result[4] = 1.0*(*endmember[4].dmu0dP)(T, P);
}
        
static void coder_d3gdn2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dT2)(T, P) + n2*(*endmember[1].d2mu0dT2)(T, P) + n3*(*endmember[2].d2mu0dT2)(T, P) + n4*(*endmember[3].d2mu0dT2)(T, P) + n5*(*endmember[4].d2mu0dT2)(T, P));
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d2mu0dT2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dT2)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dT2)(T, P);
result[3] = 1.0*(*endmember[3].d2mu0dT2)(T, P);
result[4] = 1.0*(*endmember[4].d2mu0dT2)(T, P);
}
        
static void coder_d4gdn2dt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dTdP)(T, P) + n2*(*endmember[1].d2mu0dTdP)(T, P) + n3*(*endmember[2].d2mu0dTdP)(T, P) + n4*(*endmember[3].d2mu0dTdP)(T, P) + n5*(*endmember[4].d2mu0dTdP)(T, P));
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d2mu0dTdP)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dTdP)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dTdP)(T, P);
result[3] = 1.0*(*endmember[3].d2mu0dTdP)(T, P);
result[4] = 1.0*(*endmember[4].d2mu0dTdP)(T, P);
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = 1.0*(n1*(*endmember[0].d2mu0dP2)(T, P) + n2*(*endmember[1].d2mu0dP2)(T, P) + n3*(*endmember[2].d2mu0dP2)(T, P) + n4*(*endmember[3].d2mu0dP2)(T, P) + n5*(*endmember[4].d2mu0dP2)(T, P));
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d2mu0dP2)(T, P);
result[1] = 1.0*(*endmember[1].d2mu0dP2)(T, P);
result[2] = 1.0*(*endmember[2].d2mu0dP2)(T, P);
result[3] = 1.0*(*endmember[3].d2mu0dP2)(T, P);
result[4] = 1.0*(*endmember[4].d2mu0dP2)(T, P);
}
        
static void coder_d4gdn2dp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dT3)(T, P) + n2*(*endmember[1].d3mu0dT3)(T, P) + n3*(*endmember[2].d3mu0dT3)(T, P) + n4*(*endmember[3].d3mu0dT3)(T, P) + n5*(*endmember[4].d3mu0dT3)(T, P));
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d3mu0dT3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT3)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dT3)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dT3)(T, P);
result[4] = 1.0*(*endmember[4].d3mu0dT3)(T, P);
}
        
static void coder_d5gdn2dt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dT2dP)(T, P) + n2*(*endmember[1].d3mu0dT2dP)(T, P) + n3*(*endmember[2].d3mu0dT2dP)(T, P) + n4*(*endmember[3].d3mu0dT2dP)(T, P) + n5*(*endmember[4].d3mu0dT2dP)(T, P));
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d3mu0dT2dP)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dT2dP)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dT2dP)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dT2dP)(T, P);
result[4] = 1.0*(*endmember[4].d3mu0dT2dP)(T, P);
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dTdP2)(T, P) + n2*(*endmember[1].d3mu0dTdP2)(T, P) + n3*(*endmember[2].d3mu0dTdP2)(T, P) + n4*(*endmember[3].d3mu0dTdP2)(T, P) + n5*(*endmember[4].d3mu0dTdP2)(T, P));
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d3mu0dTdP2)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dTdP2)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dTdP2)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dTdP2)(T, P);
result[4] = 1.0*(*endmember[4].d3mu0dTdP2)(T, P);
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];
    double result;
    

result = 1.0*(n1*(*endmember[0].d3mu0dP3)(T, P) + n2*(*endmember[1].d3mu0dP3)(T, P) + n3*(*endmember[2].d3mu0dP3)(T, P) + n4*(*endmember[3].d3mu0dP3)(T, P) + n5*(*endmember[4].d3mu0dP3)(T, P));
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 1.0*(*endmember[0].d3mu0dP3)(T, P);
result[1] = 1.0*(*endmember[1].d3mu0dP3)(T, P);
result[2] = 1.0*(*endmember[2].d3mu0dP3)(T, P);
result[3] = 1.0*(*endmember[3].d3mu0dP3)(T, P);
result[4] = 1.0*(*endmember[4].d3mu0dP3)(T, P);
}
        
static void coder_d5gdn2dp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[5], double result[5]) {
    double n1 = n[0];
    double n2 = n[1];
    double n3 = n[2];
    double n4 = n[3];
    double n5 = n[4];


result[0] = 0;
result[1] = 0;
result[2] = 0;
result[3] = 0;
result[4] = 0;
result[5] = 0;
result[6] = 0;
result[7] = 0;
result[8] = 0;
result[9] = 0;
result[10] = 0;
result[11] = 0;
result[12] = 0;
result[13] = 0;
result[14] = 0;
result[15] = 0;
result[16] = 0;
result[17] = 0;
result[18] = 0;
result[19] = 0;
result[20] = 0;
result[21] = 0;
result[22] = 0;
result[23] = 0;
result[24] = 0;
result[25] = 0;
result[26] = 0;
result[27] = 0;
result[28] = 0;
result[29] = 0;
result[30] = 0;
result[31] = 0;
result[32] = 0;
result[33] = 0;
result[34] = 0;
}
        
static double coder_s(double T, double P, double n[5]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[5]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[5]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[5]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[5]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[5]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[5]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[5]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[5]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[5]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[5]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[5]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[5]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[5]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

