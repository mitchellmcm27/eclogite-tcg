#include <math.h>


static double coder_g(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = fmin(4, 1.0*sqrt(1.7130620985010707e-5*P - 0.0021413276231263384*T + 1));

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result = n1*(0.079999999999999988*P - 10.0*T + x0 + 3113.333333333333);
}
else {
   result = (1.0/3.0)*n1*(3*x0 + 4670.0*((x1)*(x1)*(x1)) - (x1 - 1)*(0.23999999999999999*P - 30.0*T + 14010.0) - 4670.0);
}
    return result;
}
        
static void coder_dgdn(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].mu0)(T, P);
    double x1 = fmin(4, 1.0*sqrt(1.7130620985010707e-5*P - 0.0021413276231263384*T + 1));

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result[0] = 0.079999999999999988*P - 10.0*T + x0 + 3113.333333333333;
}
else {
   result[0] = x0 + 1556.6666666666665*((x1)*(x1)*(x1)) - 1.0/3.0*(x1 - 1)*(0.23999999999999999*P - 30.0*T + 14010.0) - 1556.6666666666665;
}
}
        
static void coder_d2gdn2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d3gdn3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_dgdt(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].dmu0dT)(T, P);
    double x1 = sqrt(1.7130620985010707e-5*P - 0.0021413276231263384*T + 1);
    double x2 = 1.0*x1;
    double x3 = fmin(4, x2);
    double x4 = (4 - x2 >= 0. ? 1. : 0.)/x1;

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result = n1*(x0 - 10.0);
}
else {
   result = (1.0/3.0)*n1*(3*x0 - 15.0*((x3)*(x3))*x4 + 30.0*x3 + 0.0010706638115631692*x4*(0.23999999999999999*P - 30.0*T + 14010.0) - 30.0);
}
    return result;
}
        
static void coder_d2gdndt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].dmu0dT)(T, P) - 10.0;
    double x1 = sqrt(1.7130620985010707e-5*P - 0.0021413276231263384*T + 1);
    double x2 = 1.0*x1;
    double x3 = fmin(4, x2);
    double x4 = (4 - x2 >= 0. ? 1. : 0.)/x1;

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - 5.0*((x3)*(x3))*x4 + 10.0*x3 + 0.00035688793718772306*x4*(0.23999999999999999*P - 30.0*T + 14010.0);
}
}
        
static void coder_d3gdn2dt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d4gdn3dt(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_dgdp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].dmu0dP)(T, P);
    double x1 = sqrt(1.7130620985010707e-5*P - 0.0021413276231263384*T + 1);
    double x2 = 1.0*x1;
    double x3 = fmin(4, x2);
    double x4 = (4 - x2 >= 0. ? 1. : 0.)/x1;

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result = n1*(x0 + 0.079999999999999988);
}
else {
   result = (1.0/3.0)*n1*(3*x0 + 0.12000000000000001*((x3)*(x3))*x4 - 0.23999999999999999*x3 - 8.5653104925053537e-6*x4*(0.23999999999999999*P - 30.0*T + 14010.0) + 0.23999999999999999);
}
    return result;
}
        
static void coder_d2gdndp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].dmu0dP)(T, P) + 0.079999999999999988;
    double x1 = sqrt(1.7130620985010707e-5*P - 0.0021413276231263384*T + 1);
    double x2 = 1.0*x1;
    double x3 = fmin(4, x2);
    double x4 = (4 - x2 >= 0. ? 1. : 0.)/x1;

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result[0] = x0;
}
else {
   result[0] = x0 + 0.040000000000000001*((x3)*(x3))*x4 - 0.079999999999999988*x3 - 2.8551034975017843e-6*x4*(0.23999999999999999*P - 30.0*T + 14010.0);
}
}
        
static void coder_d3gdn2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d4gdn3dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdt2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = 1.7130620985010707e-5*P - 0.0021413276231263384*T + 1;
    double x2 = sqrt(x1);
    double x3 = 1.0*x2;
    double x4 = x3 - 4;
    double x5 = (-x4 >= 0. ? 1. : 0.);
    double x6 = 2.7511703937383359e-7*P - 3.4389629921729205e-5*T + 0.016059957173447537;
    double x7 = 1.0/x1;
    double x8 = x7*0;
    double x9 = x5/pow(x1, 3.0/2.0);
    double x10 = fmin(4, x3);
    double x11 = 0.016059957173447537*((x10)*(x10));

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result = n1*x0;
}
else {
   result = (1.0/3.0)*n1*(3*x0 + 0.032119914346895075*x10*((x5)*(x5))*x7 - x11*x8 - x11*x9 + x6*x8 + x6*x9 - 0.064239828693790149*x5/x2);
}
    return result;
}
        
static void coder_d3gdndt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d2mu0dT2)(T, P);
    double x1 = 1.7130620985010707e-5*P - 0.0021413276231263384*T + 1;
    double x2 = sqrt(x1);
    double x3 = 1.0*x2;
    double x4 = x3 - 4;
    double x5 = (-x4 >= 0. ? 1. : 0.);
    double x6 = 9.1705679791277878e-8*P - 1.1463209973909735e-5*T + 0.0053533190578158463;
    double x7 = 1.0/x1;
    double x8 = x7*0;
    double x9 = x5/pow(x1, 3.0/2.0);
    double x10 = fmin(4, x3);
    double x11 = 0.0053533190578158455*((x10)*(x10));

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result[0] = x0;
}
else {
   result[0] = x0 + 0.010706638115631691*x10*((x5)*(x5))*x7 - x11*x8 - x11*x9 + x6*x8 + x6*x9 - 0.021413276231263382*x5/x2;
}
}
        
static void coder_d4gdn2dt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dt2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdtdp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d2mu0dTdP)(T, P);
    double x1 = 1.7130620985010707e-5*P - 0.0021413276231263384*T + 1;
    double x2 = sqrt(x1);
    double x3 = 1.0*x2;
    double x4 = x3 - 4;
    double x5 = (-x4 >= 0. ? 1. : 0.);
    double x6 = 1.0/x1;
    double x7 = x6*0;
    double x8 = 2.2009363149906689e-9*P - 2.7511703937383365e-7*T + 0.0001284796573875803;
    double x9 = x5/pow(x1, 3.0/2.0);
    double x10 = fmin(4, x3);
    double x11 = 0.00012847965738758033*((x10)*(x10));

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result = n1*x0;
}
else {
   result = (1.0/3.0)*n1*(3*x0 - 0.00025695931477516065*x10*((x5)*(x5))*x6 + x11*x7 + x11*x9 - x7*x8 - x8*x9 + 0.0005139186295503212*x5/x2);
}
    return result;
}
        
static void coder_d3gdndtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d2mu0dTdP)(T, P);
    double x1 = 1.7130620985010707e-5*P - 0.0021413276231263384*T + 1;
    double x2 = sqrt(x1);
    double x3 = 1.0*x2;
    double x4 = x3 - 4;
    double x5 = (-x4 >= 0. ? 1. : 0.);
    double x6 = 1.0/x1;
    double x7 = x6*0;
    double x8 = 7.3364543833022292e-10*P - 9.1705679791277865e-8*T + 4.2826552462526762e-5;
    double x9 = x5/pow(x1, 3.0/2.0);
    double x10 = fmin(4, x3);
    double x11 = 4.2826552462526775e-5*((x10)*(x10));

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - 8.5653104925053551e-5*x10*((x5)*(x5))*x6 + x11*x7 + x11*x9 - x7*x8 - x8*x9 + 0.00017130620985010705*x5/x2;
}
}
        
static void coder_d4gdn2dtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dtdp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d2gdp2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d2mu0dP2)(T, P);
    double x1 = 1.7130620985010707e-5*P - 0.0021413276231263384*T + 1;
    double x2 = sqrt(x1);
    double x3 = 1.0*x2;
    double x4 = x3 - 4;
    double x5 = (-x4 >= 0. ? 1. : 0.);
    double x6 = 1.7607490519925353e-11*P - 2.2009363149906689e-9*T + 1.0278372591006424e-6;
    double x7 = 1.0/x1;
    double x8 = x7*0;
    double x9 = x5/pow(x1, 3.0/2.0);
    double x10 = fmin(4, x3);
    double x11 = 1.0278372591006426e-6*((x10)*(x10));

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result = n1*x0;
}
else {
   result = (1.0/3.0)*n1*(3*x0 + 2.0556745182012853e-6*x10*((x5)*(x5))*x7 - x11*x8 - x11*x9 + x6*x8 + x6*x9 - 4.1113490364025697e-6*x5/x2);
}
    return result;
}
        
static void coder_d3gdndp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d2mu0dP2)(T, P);
    double x1 = 1.7130620985010707e-5*P - 0.0021413276231263384*T + 1;
    double x2 = sqrt(x1);
    double x3 = 1.0*x2;
    double x4 = x3 - 4;
    double x5 = (-x4 >= 0. ? 1. : 0.);
    double x6 = 5.8691635066417837e-12*P - 7.3364543833022292e-10*T + 3.4261241970021414e-7;
    double x7 = 1.0/x1;
    double x8 = x7*0;
    double x9 = x5/pow(x1, 3.0/2.0);
    double x10 = fmin(4, x3);
    double x11 = 3.4261241970021419e-7*((x10)*(x10));

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result[0] = x0;
}
else {
   result[0] = x0 + 6.8522483940042839e-7*x10*((x5)*(x5))*x7 - x11*x8 - x11*x9 + x6*x8 + x6*x9 - 1.3704496788008566e-6*x5/x2;
}
}
        
static void coder_d4gdn2dp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d5gdn3dp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdt3(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = 1.7130620985010707e-5*P - 0.0021413276231263384*T + 1;
    double x2 = 1.0*sqrt(x1);
    double x3 = x2 - 4;
    double x4 = 0;
    double x5 = 0.00010316888976518761*x4;
    double x6 = pow(x1, -3.0/2.0);
    double x7 = (-x3 >= 0. ? 1. : 0.);
    double x8 = x6*x7;
    double x9 = 0.23999999999999999*P - 30.0*T + 14010.0;
    double x10 = pow(x1, -2);
    double x11 = x10*x4;
    double x12 = x7/pow(x1, 5.0/2.0);
    double x13 = x6*0;
    double x14 = fmin(4, x2);
    double x15 = ((x14)*(x14));
    double x16 = 5.1584444882593803e-5*x15;

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result = n1*x0;
}
else {
   result = (1.0/3.0)*n1*(3*x0 + 0.00010316888976518761*x10*x14*((x7)*(x7)) - x11*x16 + 3.6819732250245404e-9*x11*x9 - x12*x16 + 3.68197322502454e-9*x12*x9 + 1.7194814960864602e-5*x13*x15 - 1.2273244083415135e-9*x13*x9 + x14*x5*x8 - 3.4389629921729205e-5*x6*((x7)*(x7)*(x7)) - 0.00010316888976518761*x8 - x5/x1);
}
    return result;
}
        
static void coder_d4gdndt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d3mu0dT3)(T, P);
    double x1 = 1.7130620985010707e-5*P - 0.0021413276231263384*T + 1;
    double x2 = 1.0*sqrt(x1);
    double x3 = x2 - 4;
    double x4 = 0;
    double x5 = 3.4389629921729198e-5*x4;
    double x6 = pow(x1, -3.0/2.0);
    double x7 = (-x3 >= 0. ? 1. : 0.);
    double x8 = x6*x7;
    double x9 = 0.23999999999999999*P - 30.0*T + 14010.0;
    double x10 = pow(x1, -2);
    double x11 = x10*x4;
    double x12 = x7/pow(x1, 5.0/2.0);
    double x13 = x6*0;
    double x14 = fmin(4, x2);
    double x15 = ((x14)*(x14));
    double x16 = 1.7194814960864599e-5*x15;

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result[0] = x0;
}
else {
   result[0] = x0 + 3.4389629921729198e-5*x10*x14*((x7)*(x7)) - x11*x16 + 1.2273244083415135e-9*x11*x9 - x12*x16 + 1.2273244083415133e-9*x12*x9 + 5.7316049869548674e-6*x13*x15 - 4.0910813611383779e-10*x13*x9 + x14*x5*x8 - 1.1463209973909735e-5*x6*((x7)*(x7)*(x7)) - 3.4389629921729198e-5*x8 - x5/x1;
}
}
        
static void coder_d5gdn2dt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dt3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdt2dp(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x1 = 1.7130620985010707e-5*P - 0.0021413276231263384*T + 1;
    double x2 = 1.0*sqrt(x1);
    double x3 = x2 - 4;
    double x4 = 0;
    double x5 = pow(x1, -3.0/2.0);
    double x6 = (-x3 >= 0. ? 1. : 0.);
    double x7 = x5*x6;
    double x8 = 0.23999999999999999*P - 30.0*T + 14010.0;
    double x9 = pow(x1, -2);
    double x10 = x4*x9;
    double x11 = x6/pow(x1, 5.0/2.0);
    double x12 = x5*0;
    double x13 = fmin(4, x2);
    double x14 = ((x13)*(x13));
    double x15 = 4.1267555906075052e-7*x14;
    double x16 = 8.2535111812150105e-7*x13;

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result = n1*x0;
}
else {
   result = (1.0/3.0)*n1*(3*x0 + x10*x15 - 2.9455785800196324e-11*x10*x8 + x11*x15 - 2.9455785800196318e-11*x11*x8 - 1.3755851968691685e-7*x12*x14 + 9.8185952667321075e-12*x12*x8 - x16*x4*x7 - x16*((x6)*(x6))*x9 + 2.751170393738337e-7*x5*((x6)*(x6)*(x6)) + 8.2535111812150094e-7*x7 + 8.2535111812150094e-7*x4/x1);
}
    return result;
}
        
static void coder_d4gdndt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d3mu0dT2dP)(T, P);
    double x1 = 1.7130620985010707e-5*P - 0.0021413276231263384*T + 1;
    double x2 = 1.0*sqrt(x1);
    double x3 = x2 - 4;
    double x4 = 0;
    double x5 = 2.7511703937383365e-7*x4;
    double x6 = pow(x1, -3.0/2.0);
    double x7 = (-x3 >= 0. ? 1. : 0.);
    double x8 = x6*x7;
    double x9 = 0.23999999999999999*P - 30.0*T + 14010.0;
    double x10 = pow(x1, -2);
    double x11 = x10*x4;
    double x12 = x7/pow(x1, 5.0/2.0);
    double x13 = x6*0;
    double x14 = fmin(4, x2);
    double x15 = ((x14)*(x14));
    double x16 = 1.3755851968691682e-7*x15;

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - 2.7511703937383365e-7*x10*x14*((x7)*(x7)) + x11*x16 - 9.8185952667321075e-12*x11*x9 + x12*x16 - 9.8185952667321059e-12*x12*x9 - 4.5852839895638946e-8*x13*x15 + 3.2728650889107024e-12*x13*x9 - x14*x5*x8 + 9.1705679791277891e-8*x6*((x7)*(x7)*(x7)) + 2.7511703937383365e-7*x8 + x5/x1;
}
}
        
static void coder_d5gdn2dt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dt2dp(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdtdp2(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x1 = 1.7130620985010707e-5*P - 0.0021413276231263384*T + 1;
    double x2 = 1.0*sqrt(x1);
    double x3 = x2 - 4;
    double x4 = 0;
    double x5 = pow(x1, -3.0/2.0);
    double x6 = (-x3 >= 0. ? 1. : 0.);
    double x7 = x5*x6;
    double x8 = 0.23999999999999999*P - 30.0*T + 14010.0;
    double x9 = 2.3564628640157058e-13*x8;
    double x10 = pow(x1, -2);
    double x11 = x10*x4;
    double x12 = x6/pow(x1, 5.0/2.0);
    double x13 = x5*0;
    double x14 = fmin(4, x2);
    double x15 = ((x14)*(x14));
    double x16 = 6.6028089449720091e-9*x14;

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result = n1*x0;
}
else {
   result = (1.0/3.0)*n1*(3*x0 + x10*x16*((x6)*(x6)) - 3.3014044724860045e-9*x11*x15 + x11*x9 - 3.3014044724860041e-9*x12*x15 + x12*x9 + 1.1004681574953348e-9*x13*x15 - 7.8548762133856859e-14*x13*x8 + x16*x4*x7 - 2.2009363149906697e-9*x5*((x6)*(x6)*(x6)) - 6.6028089449720074e-9*x7 - 6.6028089449720074e-9*x4/x1);
}
    return result;
}
        
static void coder_d4gdndtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d3mu0dTdP2)(T, P);
    double x1 = 1.7130620985010707e-5*P - 0.0021413276231263384*T + 1;
    double x2 = 1.0*sqrt(x1);
    double x3 = x2 - 4;
    double x4 = 0;
    double x5 = pow(x1, -3.0/2.0);
    double x6 = (-x3 >= 0. ? 1. : 0.);
    double x7 = x5*x6;
    double x8 = 0.23999999999999999*P - 30.0*T + 14010.0;
    double x9 = 7.8548762133856859e-14*x8;
    double x10 = pow(x1, -2);
    double x11 = x10*x4;
    double x12 = x6/pow(x1, 5.0/2.0);
    double x13 = x5*0;
    double x14 = fmin(4, x2);
    double x15 = ((x14)*(x14));
    double x16 = 2.2009363149906697e-9*x14;

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result[0] = x0;
}
else {
   result[0] = x0 + x10*x16*((x6)*(x6)) - 1.1004681574953348e-9*x11*x15 + x11*x9 - 1.1004681574953346e-9*x12*x15 + x12*x9 + 3.6682271916511161e-10*x13*x15 - 2.6182920711285617e-14*x13*x8 + x16*x4*x7 - 7.3364543833022323e-10*x5*((x6)*(x6)*(x6)) - 2.2009363149906689e-9*x7 - 2.2009363149906689e-9*x4/x1;
}
}
        
static void coder_d5gdn2dtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dtdp2(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_d3gdp3(double T, double P, double n[1]) {
    double n1 = n[0];
    double result;
    
    double x0 = (*endmember[0].d3mu0dP3)(T, P);
    double x1 = 1.7130620985010707e-5*P - 0.0021413276231263384*T + 1;
    double x2 = 1.0*sqrt(x1);
    double x3 = x2 - 4;
    double x4 = 0;
    double x5 = pow(x1, -3.0/2.0);
    double x6 = (-x3 >= 0. ? 1. : 0.);
    double x7 = x5*x6;
    double x8 = pow(x1, -2);
    double x9 = x4*x8;
    double x10 = 0.23999999999999999*P - 30.0*T + 14010.0;
    double x11 = 1.8851702912125646e-15*x10;
    double x12 = x6/pow(x1, 5.0/2.0);
    double x13 = x5*0;
    double x14 = fmin(4, x2);
    double x15 = ((x14)*(x14));
    double x16 = 5.2822471559776065e-11*x14;

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result = n1*x0;
}
else {
   result = (1.0/3.0)*n1*(3*x0 + 6.2839009707085486e-16*x10*x13 - x11*x12 - x11*x9 + 2.6411235779888036e-11*x12*x15 - 8.803745259962678e-12*x13*x15 + 2.6411235779888032e-11*x15*x9 - x16*x4*x7 - x16*((x6)*(x6))*x8 + 1.7607490519925356e-11*x5*((x6)*(x6)*(x6)) + 5.2822471559776058e-11*x7 + 5.2822471559776058e-11*x4/x1);
}
    return result;
}
        
static void coder_d4gdndp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];

    double x0 = (*endmember[0].d3mu0dP3)(T, P);
    double x1 = 1.7130620985010707e-5*P - 0.0021413276231263384*T + 1;
    double x2 = 1.0*sqrt(x1);
    double x3 = x2 - 4;
    double x4 = 0;
    double x5 = 1.7607490519925353e-11*x4;
    double x6 = pow(x1, -3.0/2.0);
    double x7 = (-x3 >= 0. ? 1. : 0.);
    double x8 = x6*x7;
    double x9 = pow(x1, -2);
    double x10 = x4*x9;
    double x11 = 0.23999999999999999*P - 30.0*T + 14010.0;
    double x12 = 6.2839009707085486e-16*x11;
    double x13 = x7/pow(x1, 5.0/2.0);
    double x14 = x6*0;
    double x15 = fmin(4, x2);
    double x16 = ((x15)*(x15));

if (0.0080000000000000002*P - 1.0*T <= -467.0) {
   result[0] = x0;
}
else {
   result[0] = x0 - x10*x12 + 8.8037452599626764e-12*x10*x16 + 2.0946336569028494e-16*x11*x14 - x12*x13 + 8.803745259962678e-12*x13*x16 - 2.9345817533208927e-12*x14*x16 - x15*x5*x8 - 1.7607490519925353e-11*x15*((x7)*(x7))*x9 + 5.8691635066417853e-12*x6*((x7)*(x7)*(x7)) + 1.7607490519925353e-11*x8 + x5/x1;
}
}
        
static void coder_d5gdn2dp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static void coder_d6gdn3dp3(double T, double P, double n[1], double result[1]) {
    double n1 = n[0];


result[0] = 0;
}
        
static double coder_s(double T, double P, double n[1]) {
    double result = -coder_dgdt(T, P, n);
    return result;
}

static double coder_dsdt(double T, double P, double n[1]) {
    double result = -coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dsdp(double T, double P, double n[1]) {
    double result = -coder_d2gdtdp(T, P, n);
    return result;
}

static double coder_v(double T, double P, double n[1]) {
    double result = coder_dgdp(T, P, n);
    return result;
}

static double coder_cv(double T, double P, double n[1]) {
    double result = -T*coder_d2gdt2(T, P, n);
    double dvdt = coder_d2gdtdp(T, P, n);
    double dvdp = coder_d2gdp2(T, P, n);
    result += T*dvdt*dvdt/dvdp;
    return result;
}

static double coder_cp(double T, double P, double n[1]) {
    double result = -T*coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdt(double T, double P, double n[1]) {
    double result = -T*coder_d3gdt3(T, P, n) - coder_d2gdt2(T, P, n);
    return result;
}

static double coder_dcpdp(double T, double P, double n[1]) {
    double result = -T*coder_d3gdt2dp(T, P, n);
    return result;
}

static double coder_alpha(double T, double P, double n[1]) {
    double result = coder_d2gdtdp(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_dalphadt(double T, double P, double n[1]) {
    double dgdp = coder_dgdp(T, P, n);
    double d2gdtdp = coder_d2gdtdp(T, P, n);
    double result = coder_d3gdt2dp(T, P, n)/dgdp - d2gdtdp*d2gdtdp/dgdp/dgdp;
    return result;
}

static double coder_dalphadp(double T, double P, double n[1]) {
    double dgdp = coder_dgdp(T, P, n);
    double result = coder_d3gdtdp2(T, P, n)/dgdp - coder_d2gdp2(T, P, n)*coder_d2gdtdp(T, P, n)/dgdp/dgdp;
    return result;
}

static double coder_beta(double T, double P, double n[1]) {
    double result = -coder_d2gdp2(T, P, n)/coder_dgdp(T, P, n);
    return result;
}

static double coder_K(double T, double P, double n[1]) {
    double result = -coder_dgdp(T, P, n)/coder_d2gdp2(T, P, n);
    return result;
}

static double coder_Kp(double T, double P, double n[1]) {
    double result = coder_dgdp(T, P, n);
    result *= coder_d3gdp3(T, P, n);
    result /= pow(coder_d2gdp2(T, P, n), 2.0);
    return result - 1.0;
}

